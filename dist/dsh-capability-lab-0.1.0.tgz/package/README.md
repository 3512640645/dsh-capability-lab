# dsh-capability-lab

把一套**已经跑通、已经量过、已经踩完坑**的「操控电脑 + 出片」能力，封装成一个可发布的 DSH 插件。

它不是一个新框架，而是把散落在 `D:\dsh-tools\`、`D:\dsh-arena\`、`D:\dsh-video\` 里的真实代码与真实判据
收进一个包里：**能装、能被宿主发现、能让模型照着做**。

---

## 1. 定位

* **面向谁**：需要让 AI 真的去点鼠标、真的去按键、真的去打靶场、真的出一部片子的使用者。
* **解决什么**：这些能力原本是三套互不相干的脚本目录，装进 DSH 后模型看不见它们、也不知道先决策什么。
  本插件做两件事：把**技能（skills）**落地到 `$DSH_HOME/skills` 让宿主发现；把**源码副本**随包发布，命令可直接跑。
* **不解决什么**：它不新写一个自动化框架，也不替宿主造 MCP。它把已有实现打包 + 写清判据与决策顺序。

---

## 2. 能力清单

| # | 能力 | 位置 | 现状 |
|---|---|---|---|
| 1 | 真实指针输入（贝塞尔平滑轨迹、按键保持/组合、连按、定时序列、常驻注入器） | `tools/aim/input.mjs`（1013 行） | 可用 |
| 2 | 视觉定位（零依赖 PNG 解码 → 颜色连通域找靶 → 坐标/DPI 换算） | `tools/aim/vision.mjs`（480 行） | 可用 |
| 3 | 示例闭环（离屏找靶、真机只截屏、打一局靶场；默认 dry-run） | `tools/aim/examples/` | 可用 |
| 4 | 元素优先自动化（UIA 定位 + invoke + 多通道校验 + 收紧扫描提速） | `tools/winctl/` | 可用，基准 100%/3307ms |
| 5 | 能力判据（L1/L2/L3 + 三层延迟口径） | `tools/CONTROL-BENCH.md` | 已定稿 |
| 6 | 自建靶场（WPF，靶心带 UIA 特征，30s 一局，落盘 JSON） | `tools/arena/arena.ps1` | 可用 |
| 7 | 测量脚本（点击延迟/按键延迟/L3 定时/分段成本/逐局分析） | `tools/arena/bench/` | 可用 |
| 8 | 回归总闸（12 项检查，三态 PASS/FAIL/SKIP，任一 FAIL → 退出码 1） | `tools/run-regression.mjs` | 可用 |
| 9 | 场景化视频流水线（五步出片 + 双画幅 + 音频 10 项/视频 6 项质检） | `tools/engine/` + `tools/audio/make-audio.py` | 可用 |

---

## 3. 判据（这是本套东西的"验收标准"）

判据原文见 [`tools/CONTROL-BENCH.md`](<tools/CONTROL-BENCH.md>)。要点：

* **L1 可靠**：winctl 通道元素定位点击成功率 **≥90%**（必须分通道报，禁止混算）；
  单步动作延迟分通道报（naive p50 <1.5s / p90 <6s）。
* **L2 熟练**：自建靶场 30 秒一局 —— 命中 **≥20**、命中率 **≥90%**、平均反应 **≤700ms**、连续 3 局得分极差 **≤5**。
* **L3 游戏级**：视觉闭环 **≥2 Hz**；目标变小/漂移时命中率仍 ≥70%；连续 3 分钟不掉速（差 ≤20%）。
* **三层延迟口径（硬要求）**：定时序列偏差必须分 ① 调度精度（`|dev|` 中位 ≤15ms/最大 ≤50ms）
  ② 注入延迟（中位 ≤5ms/p90 ≤10ms、loss=0，且按键盘/鼠标 × 消息/raw 四类分列）
  ③ 端到端（中位 ≤30ms/最大 ≤80ms）三层报，**三层数字必须来自同一批实验并注明 run id 与数据文件名**。

> 为什么把口径写这么死：同一批数据在六种同样"合理"的口径下给出 **67.8% → 98.1%**，跨度 30 个百分点。
> 不写清"谁进分母、按哪条通道、取哪批报告"的成功率，不具备判定效力。

---

## 4. 安装

### 4.1 tarball（推荐）

```powershell
# 在 DSH 里执行安装
dsh plugin install https://github.com/PLACEHOLDER/PLACEHOLDER/releases/latest/download/dsh-capability-lab-0.1.0.tgz
```

或者本地 tarball（先自己 `npm pack` 出 `dsh-capability-lab-0.1.0.tgz`）：

```powershell
dsh plugin install D:\dsh-out\plugin\dsh-capability-lab-0.1.0.tgz
```

### 4.2 git

```powershell
dsh plugin install https://github.com/PLACEHOLDER/PLACEHOLDER.git
```

### 4.3 手动（把目录塞进当前 profile）

```powershell
$profile = $env:DSH_PROFILE_DIR          # 例：C:\Users\<you>\AppData\Roaming\dsh-desktop\harness\profiles\web
Copy-Item D:\dsh-plugin "$profile\node_modules\dsh-capability-lab" -Recurse -Force
# 让 profile 清单把它当 bundle（读 dsh.bundle.patch 才会挂上 cordis.patch.yml）
# 最稳的做法仍是走 `dsh plugin install`，手拷只用于排错
```

安装后自检：

```powershell
# 1) 入口能语法检查、能加载
node --check D:\dsh-plugin\lib\index.js
node -e "import('file:///D:/dsh-plugin/lib/index.js').then(m=>console.log(m.default.name, Object.keys(m.default)))"

# 2) 技能是否落到 $DSH_HOME\skills\*.md（宿主 skill 提供方只扫这个根）
Get-ChildItem "$env:DSH_HOME\skills" -Filter *.md
```

**要求**：Node ≥18；Windows（`os: win32`）。插件不打包 `node_modules`，运行期只依赖 Node 内置模块。

---

## 5. 四个技能怎么用

宿主从 `$DSH_HOME/skills/<name>.md` 发现技能（front-matter 契约：`name` 必须 kebab-case、`description` 必填单行）。
本包装完会把下面四份同步过去：

| 技能 | 什么时候用 | 里面有什么 |
|---|---|---|
| **`pc-control`** | 目标只有像素（画布/游戏/自绘 UI/视频帧），需要真的动指针 | 先讲清**两条通道怎么选**（元素 vs 真实指针）、`input.mjs`/`vision.mjs` 的最小闭环代码、**三层延迟口径警告**、8 个高频坑 |
| **`pc-elements`** | 目标是标准控件、原生对话框、有 UIA 树的应用 | 五条设计原则、`connect→locate→invoke→waitForAnyText` 照抄流程、`selfcheck/bench` 命令、9.3s→5.1s 的提速三招、10 个实战坑 |
| **`control-bench`** | 要宣称"能操控电脑"之前 | L1/L2/L3 判据与三层延迟表、靶场开法与四条测量规矩、回归总闸 12 项与三态读法、阈值推导规则 |
| **`video-pipeline`** | 要出一部带配乐与字幕的成片 | 五步命令、场景 JSON 写法与 10 个内置组件、双画幅适配做法、音频 10 项/视频 6 项质检指标含义、已知限制 |

一份"决策顺序"记牢：**元素优先 → 像素兜底；先 dry-run → 再加 `--live`；动作之后必须校验。**

---

## 6. 目录树

```
dsh-capability-lab/
├── package.json              2.4 KB   插件清单（name/main/exports/files/engines/peerDependencies/dsh）
├── cordis.patch.yml          1.7 KB   bundle patch：把本包挂进 profile 的 cordis 配置树
├── LICENSE                   1.1 KB   MIT © 2026 YG
├── README.md                          本文件
├── lib/
│   └── index.js              9.5 KB   插件入口：name/inject/apply + default 插件对象；技能落地 + 只读状态工具
├── skills/                  30.7 KB   四份技能（宿主发现根是 $DSH_HOME/skills，装包时同步过去）
│   ├── pc-control.md         7.8 KB
│   ├── pc-elements.md        7.1 KB
│   ├── control-bench.md      8.2 KB
│   └── video-pipeline.md     8.3 KB
└── tools/                    5.4 MB   源码副本（原目录未改动，这里只复制）
    ├── aim/                  146 KB   input.mjs / vision.mjs / self-test.mjs / README.md / examples/
    ├── winctl/               280 KB   mcp.mjs / index.mjs / bench.mjs(62KB) / selfcheck.mjs / reports/ / probe-*/
    ├── arena/                4.6 MB   arena.ps1 / arena-beat.ps1 / README.md / BENCH-*.md / bench/ / tools/ / probe/
    ├── engine/               295 KB   lib.mjs / render.mjs / build.mjs / qa.mjs / subs*.mjs / compare.mjs / scenes/ / fixtures/
    ├── audio/                 34 KB   make-audio.py（规格驱动配乐，含 10 项质检）
    ├── CONTROL-BENCH.md      8.3 KB   L1/L2/L3 判据原文
    └── run-regression.mjs     71 KB   回归总闸（12 项，三态）
```

`tools/` 里**没有**打包：视频成片（`D:\dsh-video\out\`，太大）、ffmpeg 三个 exe（合计 ~500MB）、
靶场逐局结果 `runs\`、日志 `logs\`、截图 `bench\shots*\`。这些是产物或体量失控项，不是源码。

---

## 7. 插件契约（本包照它实装，随便你复核）

* **入口**：`main`/`exports` 指向 `lib/index.js`，导出 cordis 插件对象 `{ name, inject, apply }`（default 导出）。
  参照实装：`dsh-purge-community/lib/index.js` 尾部 `export const name = "dsh-purge-community"; export const inject = ["systemPrompt","tools"]; const plugin = { name, inject, apply }; export default plugin;`
* **bundle patch**：`dsh.bundle.patch = "./cordis.patch.yml"`。宿主 `dsh-plugin-manager` 读到它后
  `loadOverlayPatches()` 把文件当覆盖层，顶层的 `- insert:` 把插件行插入 cordis 配置。
* **技能格式**：`---` 包围的 YAML front-matter，`name`（kebab-case）+ `description`（单行必填）为最小集，
  可选 `whenToUse`；宿主 `dsh-skill-filesystem` 从 `$DSH_HOME/skills` 发现**平铺 `<name>.md`** 或**目录包 `<id>/SKILL.md`**。

本包用**平铺形态**（`$DSH_HOME/skills/pc-control.md`），避免与用户自建的同名目录包互相覆盖；
内容一致时跳过写入（`overwrite:false` 时按 front-matter 判断），可用 `config.overwrite: true` 强制覆盖。

---

## 8. 已知限制（如实写，别当成待办清单看）

1. **raw 输入类目标收不到消息通道的按键**。消息通道（PostMessage）投递 0.17–0.33ms、loss=0、不需要前台，
   但实测 raw 输入类目标只收到 0–2/20，`GetAsyncKeyState` 也不响应。也就是说：
   **"能在记事本里打字" ≠ "能在游戏里按键"**，判据必须绑定通道，并报 loss。
2. **插件整条调用延迟很高**。同一次投递，插件整条调用耗时 **296–604ms（键盘）/ 73–446ms（鼠标）**，
   前置成本占 99.5%。它**不是投递延迟**，禁止写进三层口径的任何一层；要测投递延迟只能用常驻注入器或 SendInput 直测。
3. **真机通道没有 CI 覆盖**。回归总闸只跑"可离线验证"的项（自测、语法、编译、音频、质检、闸门）；
   真实指针打靶、UIA 点击、音频合成这类需要独占桌面/长耗时的部分，只能本机手动跑。
   第 11/12 项闸门读的是历史成绩 JSON，**数据超过 6 小时就标 `STALE_DATA` 并降级 SKIP**，不去编造新鲜度。
4. **`tools/run-regression.mjs` 里写死了绝对路径**（`D:\dsh-tools`、`D:\dsh-video`、本机 node 与 python 路径）。
   它是本机总闸的副本，装到别的机器上必须先改这几个常量；这是原样复制，不是本插件引入的问题。
5. **鼠标通道当前未达标**：L3 定稿判据要求鼠标投递中位 ≤5ms，实测 **7.787ms / p90 14.060ms ❌**；
   raw 通道**无数据，无法判定**。如实标注，不折算成"通过"。
6. **视觉通道依赖降采样档位**：`--max-width 720` 让 decode 从 103ms 降到 31ms，但 56px 的靶只剩 28px；
   报"闭环频率"必须同时说画幅与降采样档，否则数字不可比。
7. **多显示器与 DPI 未实测**：本机 1440×900 @96dpi（缩放 1.0），代码里保留换算位但没在缩放环境验证。
8. **视频流水线很慢**：双画幅一次 ≈9 分钟（串行），且需要自备 ffmpeg/ffprobe —— 本包**不含** ffmpeg。
9. **Windows 键被上游 wcu 插件设计性屏蔽**（Win+R / Win+D 做不到），只能换入口。
10. **本包的大部分 `tools/` 代码是复制品**，不是本插件原创；版权与致谢见下一节。改这些代码请改上游原目录，
    否则下次复制会被覆盖。

---

## 9. 许可与致谢

* 本插件（`package.json` / `cordis.patch.yml` / `lib/` / `skills/` / `README.md`）：**MIT © 2026 YG**。
* `tools/` 下的源码副本来自使用者自己的三套工程（`D:\dsh-tools`、`D:\dsh-arena`、`D:\dsh-video`），随包以 MIT 一并分发。
* 上游依赖与致谢：
  * [`dsh-computer-use-win`](https://www.npmjs.com/package/dsh-computer-use-win) —— winctl 与 aim 的 UIA/截图/输入后端（MCP stdio）。
  * DeepSeek Harness 官方组件：`@deepseek-ai/dsh-skill-filesystem`（技能发现根与 front-matter 契约）、
    `@deepseek-ai/dsh-plugin-manager`（bundle patch 装载）、`dsh-purge-community`（插件对象与工具注册的实装参照）。
  * ffmpeg —— 视频渲染/质检的外部工具链（未随包分发）。
* 免责：`tools/arena/` 是我们自己写的靶场，允许随便压测。真实指针通道是正常输入，**不绕过任何反作弊**；
  联机游戏的自动化判定是账号级不可逆的，不要拿它当靶子。
