# aim —— 把「真实指针操控」封装成可复用能力

`D:\dsh-tools\aim\` 只有三件东西：**输入引擎**（`input.mjs`）、**视觉与坐标**（`vision.mjs`）、**示例**（`examples/`）。
本 README 的每一条都对着源码核过（`input.mjs` 1013 行 / `vision.mjs` 480 行），并附本次真跑的原始输出。

> 一句话：`vision.mjs` 负责「看见并算坐标」，`input.mjs` 负责「像人一样把指针移过去并按下去」，
> 两者之间只有一个契约 —— **`screen = bounds.origin + imagePixel / imageScale`**。

---

## 1. 文件与依赖

| 路径 | 作用 | 备注 |
|---|---|---|
| `D:\dsh-tools\aim\input.mjs` | 纯函数时序/轨迹 + Sender 适配器 + `InputEngine` | 只读依赖 wcu 插件的 `move/drag/click/keypress`，或本地 `keybd_event` |
| `D:\dsh-tools\aim\vision.mjs` | 零依赖 PNG 解码 + 颜色连通域找靶 + 坐标换算 | **自身没有截屏能力**，只吃 PNG 文件 |
| `D:\dsh-tools\aim\examples\screen.mjs` | 示例共用胶水：CLI 解析 / 只读截屏 / 找靶 / 换算 / 装配引擎 | 本次新增 |
| `D:\dsh-tools\aim\examples\aim-at.mjs` | 最小闭环：截屏 → 找靶 → 平滑移动 → 点击（默认 dry-run） | 本次新增 |
| `D:\dsh-tools\aim\examples\play-arena.mjs` | 完整闭环：打一局 `D:\dsh-arena\arena.ps1` 并打印成绩（默认 dry-run） | 本次新增 |
| `D:\dsh-tools\aim\self-test.mjs` | 纯函数自测（虚拟时钟，无桌面） | 别人写的，未改动 |

外部事实（以源码为准）：

- 后端 `move(x,y)` = `SetCursorPos`，**瞬时跳变、无 duration** → 平滑轨迹必须自己拆多段（`input.mjs` 头部注释 L13-17 写明了）。
- 后端 `drag(path[])` 内部逐点 `Start-Sleep 25ms` → 直接喂稠密路径。
- 后端 `keypress(keys[])` = `SendKeys`，**只有「按一下」** → 要控制按住时长必须走 `PowerShellRawKey`（`keybd_event`）。
- 后端 `click(x,y,button,dispatch)` 只有 `dispatch:'foreground'` 才是真实输入；`InputEngine` 发坐标点击时固定用 `foreground`。
- 截屏工具回传 `meta = { path, bounds, imageScale, method, occludedPossible }`，PNG 落在 `$env:TEMP`（本机被固定为 `D:\dsh-tmp`），
  且 `base64` 在 text 里被替换成占位符 → 可以安全 JSON.parse（`wcu\package\scripts\windows-uia.ps1` L2343-2362）。

---

## 2. 30 秒跑通

```powershell
$env:TEMP='D:\dsh-tmp'; $env:TMP='D:\dsh-tmp'
$node='C:\Users\35126\AppData\Roaming\dsh-desktop\harness\.desktop-bin\node.cmd'

# ① 最小闭环（离线图，完全不碰桌面）
& $node D:\dsh-tools\aim\examples\aim-at.mjs --image D:\dsh-arena\probe\targets-b.png --min-area 100

# ② 最小闭环（真机只读截屏；仍然不点）
& $node D:\dsh-tools\aim\examples\aim-at.mjs --scope desktop --max-width 1440 --color e8452c --min-area 300 --max-area 20000

# ③ 打一局靶场（dry-run：不拉窗口、不动鼠标）
& $node D:\dsh-tools\aim\examples\play-arena.mjs --cycles 4 --min-area 100

# ④ 真的动鼠标（只有显式 --live，且桌面必须归你独占）
& $node D:\dsh-tools\aim\examples\play-arena.mjs --live --duration 10 --seed 20261107
```

`aim-at.mjs` 真机只读截屏那次的实际输出（未加 `--live`，所以只记录）：

```
[1/4] 截屏 D:\dsh-tmp\windows-computer-use-a1f9d04e26ce4cbc9e73cf78d944abfd.png  bounds=(0,0,1440,900) scale=1 耗时=1882ms occluded=false
[2/4] 目标 #1 rgb(232,69,44) 图像(564.0,233.4) r=23.0 area=1522 circ=0.841 bbox=48x48@(538,211)  （候选共 4 个，取第 1 名）
[3/4] 换算 屏幕=(564,233) 窗口=(564,233)  bounds=(0,0,1440,900) scaleX=1.0000
[4/4] 轨迹起点=预演假设(404,343)（dry-run 无真实指针；--pointer x,y 可指定）
[4/4] dry-run：move 15 次 + click 1 次已记录（未发出）  计划步数=16 plannedMs=250 时钟耗时=252ms
       轨迹 404,343 → 564,233（16 点，贝塞尔+缓动）
```

`play-arena.mjs` dry-run 的实际输出（尾部，成绩段是只读解析既有 run 文件）：

```
[dry-run] 预演合计: cycles=6 计划成功=6 失败=0  平均 planned=220ms / 平均耗时=229ms（含真实 sleep，dry 下不产生任何键鼠）
[dry-run] DryRunSender 记录: {"move":78,"click":6}（共 84 次调用，未发出）
[dry-run] 成绩解析自既有 run 文件（只读，非本局）：D:\dsh-arena\runs\run-20261107-030814.json
  score=43  hits=43  misses=0  hitRate=1
  avgReactionMs=668.3  min=624  max=1093  median=658  p90=677
  elapsedMs=30083  aborted=false  roundId=20261107-030744-492  seed=0  targetSizePx=80
[dry-run] 判定：本次没有发出一条真实鼠标指令（--live 未给）。
```

「没动鼠标」的自证：dry-run 前后各读一次真实指针（`node input.mjs --pointer`）→ `x=913 y=205` → 跑完 → **仍是 `x=913 y=205`**。

---

## 3. API 速查表

### 3.1 `input.mjs` —— 纯函数（无 IO、可离屏单测）

| 函数 | 参数 | 返回 | 失败语义 |
|---|---|---|---|
| `clamp(v,lo,hi)` / `lerp(a,b,t)` | — | number | — |
| `mulberry32(seed)` | seed | `()=>number` 确定性 PRNG | 同 seed 同轨迹，便于断言 |
| `ease(name,t)` / `EASINGS` | `linear/easeInOutSine/easeInOutQuad/easeInOutCubic/easeOutCubic/easeOutSine` | 0..1 | 未知名 → 回退 `easeInOutSine`，不抛 |
| `bezierPoint(points,t)` | 控制点数组（含首尾） | `{x,y}` | — |
| `makeCurve(from,to,{curvature=0.18,seed=1,variant='arc'\|'s'})` | — | 控制点数组 | `curvature=0` 时严格退化为匀速直线 |
| `stepCount(distance,durationMs,{stepMs=15,minSteps=6,maxSteps=120})` | — | 步数 | 距离极短时自动减点，避免原地重复 |
| `planMove({from,to,durationMs=320,stepMs,easing,curvature,seed,jitter,variant,minSteps,maxSteps})` | `from/to` **必填** | `{from,to,points[],steps,durationMs,distance,curvePoints}` | 缺 `from/to` → **throw** `planMove: from/to 必填` |
| `vkOf(key)` | `'a'`/`'enter'`/`'f5'`/`0x41`/`'key a'` | VK 码 | 认不出 → **throw** `vkOf: 无法识别的按键 "x"` |
| `planKeyHold({key,holdMs=80,taperMs=0})` | — | `{vk,events[],holdMs,totalMs}` | — |
| `planChord({keys,holdMs=70,staggerMs=12})` | `keys` **必填** | `{keys,events[],lastDownMs,firstUpMs,totalMs}` | 空数组 → **throw**；`holdMs` = **主键**按住时长 |
| `planKeyRepeat({key,count=3,intervalMs=60,holdMs=20})` | — | `{vk,events[],count,totalMs}` | `count<1` → **throw** |
| `normalizeAction(raw)` | 字符串 / 数组 / 对象 / 中文别名 | `{name,...}` | 未知 name 原样透传，后续 `expandAction` 才抛 |
| `estimateActionMs(action)` | — | 预估毫秒 | **`drag` 少算 50ms**（见第 6 节） |
| `advanceAnchor(anchor,a)` | — | 落点 `{x,y}` | 未知动作 → 原 anchor |
| `planSchedule(actions,[{anchor}])` | 动作串 | `{timeline[],segments[],totalMs,count,endAnchor}` | 各段起点**链式衔接**上一动作落点 |
| `expandAction(a,{startMs,index})` | 单个动作 | `{steps[],endMs}` | 未知动作 → **throw** `expandAction: 未知动作` |
| `timelineStats(timeline)` | — | `{count,byKind,totalMs,maxGapMs,monotonic}` | — |

### 3.2 `input.mjs` —— 时钟 / Sender

| 组件 | 参数 | 返回 | 失败语义 |
|---|---|---|---|
| `createClock()` | — | `{now,sleep(ms),virtual:false}` | 真实时间 |
| `createVirtualClock()` | — | `{now,sleep,sleeps[],virtual:true}` | `sleep` 只推进数字，不等待 |
| `new McpSender({root,mode='full',server,dryRun})` | `root` 默认 `WCU_ROOT` 或 `D:\dsh-tools\wcu\package`；`mode='lite'` **没有 move/drag** | `.start() .listTools() .resolveTool(name) .call(tool,args) .close()`，`.log[]` | `dryRun` 时 `call` 只记录并返回 `{ok:true,dryRun:true}`；RPC 错误 → `{ok:false,error}`；后端 `isError` → `{ok:false,isError:true,text}`；工具名解析不到会**拼** `windows_computer_use_<name>` 交给后端报错 |
| `new PowerShellRawKey({pwsh})` | ops=`[{at,op:'down'\|'up',vk}]` | `.run(ops,{timeoutMs=5000})` → `{ok,elapsedMs,ops,code,stderr}` | spawn 失败/超时/非 0 退出 → `{ok:false,error,elapsedMs:null}`；成功时 `stderr` 只是噪声留档，不代表失败 |
| `new DryRunSender(clock)` | — | `.call() .rawKey()` 只 push 到 `.calls[]` | 永不失败 |
| `new FakeSender(clock,{tool:{failFirst,hangs,remainingFailures}})` | 编排失败/挂死 | `.calls[].verdict` | 被用于自测重试路径 |
| `readPointerPosition({pwsh,timeoutMs=6000})` | **只读** | `{x,y,exe}` | 超时/无输出 → **throw** `读指针位置失败` |
| `withRetry(fn,{attempts=3,backoffMs=[0,40,120],timeoutMs=15000,clock,label})` | — | `{ok,attempts,elapsedMs,value}` / 失败 `{ok:false,attempts,elapsedMs,error}` | **超时用真实定时器**，虚时钟不会被 timeout 提前推进（源码 L729-734 的显式注释） |
| `RETRY_DEFAULT` | — | `{attempts:3,backoffMs:[0,40,120],timeoutMs:15000}` | — |

### 3.3 `input.mjs` —— `createEngine(opts)` / `InputEngine`

`createEngine({sender:'mcp'|'dry'|实例, rawKey, clock, pointer, pointerSource, retry, stepMs, maxSteps, curvature, jitter, seed, easing, mcp:{...}, dryRun})`

| 方法 | 参数 | 返回 | 失败语义 |
|---|---|---|---|
| `getPointer({force})` | — | `{x,y}` | 没给 `pointer/pointerSource` 且 sender 非 `mcp` → **throw** `指针位置未知` |
| `setPointer(x,y)` | — | void | 手动修正锚点 |
| `moveRel(dx,dy,durationMs=320)` | — | `{..._run, from,to,distance,trajectory[]}` | 单步失败计数 → `ok:false`（`allowFailures` 可放宽） |
| `moveTo(x,y,durationMs=320,{allowFailures,...})` | — | 同上 | 同上 |
| `click(x,y,{durationMs=180,settleMs=30,button,double,from})` | — | `{..._run,to,trajectory[]}` | 点击走 `dispatch:'foreground'` |
| `drag(from,to,{durationMs=400,stepMs=25,mode:'stepped',chunk})` | — | `{pathPoints,from,to,..._run}` | 稠密路径整条交给后端；`stepped` 模式分段发 |
| `keyHold(key,holdMs,opts)` | — | `{vk,requestedHoldMs,ops[],..._run}` | 无 `rawKey` 实例 → 降级成 `keypress` 并标 `degraded:true` |
| `keyRepeat(key,count,{intervalMs,holdMs})` / `chord(keys,{holdMs,staggerMs,mode:'tool'})` | — | 同上 | `mode:'tool'` 时交给后端 `SendKeys`（只按一下） |
| `schedule(actions,{anchorFrom,allowFailures})` | — | `{segments[],timelineMs,endAnchor,stats}` | 按绝对时间戳执行，`_run` 逐 step 对齐 |
| `calibrate({distance,durationMs})` | — | `{suggestedStepMs,realElapsedMs,...}` | 供后续调 `stepMs` |
| `close()` | — | void | 关闭 sender / rawKey（异常吞掉） |
| `stats` / `calibration[]` | — | `{primitives,steps,retries,failures,virtualMs}` / 每原语实测单步耗时 | 用于帧级标定 |

`_run` 的统一返回：`{ok, label, steps, failed, attempts, elapsedMs, plannedMs, avgStepMs, driftMs, error}`；
`ok = failed <= allowFailures`，`error` 只保留前 3 条。**这就是「失败语义」的主入口**：不抛异常，靠 `ok/failed/error` 判断。

CLI（全部只读）：`--list-tools` / `--health` / `--pointer`。

### 3.4 `vision.mjs` —— 图像与坐标

| 函数 | 参数 | 返回 | 失败语义 |
|---|---|---|---|
| `decodePng(buf)` | `Buffer\|Uint8Array` | `{width,height,data:RGBA,meta}` | 签名不对 → **throw** `PNG: bad signature`；不支持的 filter → throw |
| `decodePngViaFfmpeg(file,{ffmpeg,tmpDir})` | 退路 | 同上 + `meta.decoder='ffmpeg'` | ffmpeg 不存在 → **throw**；尺寸解析失败 → throw |
| `loadImage(file,{decoder:'auto'\|'zlib'\|'ffmpeg'})` | — | `{width,height,data,meta}` | `auto`：zlib 失败自动转 ffmpeg，`meta.fallbackReason` 记录原因；`'zlib'` 直接抛 |
| `parseColor(spec)` | `'ff0000'`/`'#f00'`/`'r,g,b'`/数组 | `[r,g,b]` | 解析不了 → **throw** `bad color spec` |
| `buildMask(img,{color,tolerance=60,alphaMin=16})` | — | `Uint8Array` 掩码 | 欧氏 RGB 距离 |
| `guessColor(img,{alphaMin,minSat=40})` | — | `{color,pixels}` 或 `null` | **扔掉低饱和像素**，只猜「最饱和主色」 |
| `connectedComponents(mask,w,h,{connectivity=8,minArea=8,maxArea})` | — | `[{area,centroid,bbox,fillRatio,radiusArea,radiusBbox}]` | 按 `minArea/maxArea` 过滤，越界直接丢 |
| `detectTargets(img,{color='auto',tolerance=60,minArea=8,maxArea,connectivity,sort='area'\|'circularity',top,radiusFrom='mean'\|'area'\|'bbox'})` | — | 候选数组 `[{id,rank,center,centerBbox,radius,bbox,area,fillRatio,circularity,score,color}]` | **没有候选返回 `[]`，不抛**；`color` 非法才抛 |
| `resolveCapture(capture)` | `{bounds,imageScale?,imageWidth?,imageHeight?,dpi?}` | `{bounds,imageWidth,imageHeight,scaleX,scaleY,dpi}` | 不给 `imageScale` 时按 `imageWidth/bounds.width` 推 |
| `imageToScreen(pt,capture)` / `screenToImage` | — | `{x,y}` | 契约：`screen = origin + px/scale` |
| `imageToWindow(pt,capture,windowRect,{insets,dpi})` | — | `{image,screen,window,windowLogical,click:{screenX,screenY,windowX,windowY}}` | `insets` 缺省 0（窗口边框/标题栏厚度） |
| `screenToWindow` / `windowToScreen` | — | `{x,y,physical,clientOrigin,insets,logical?}` | `windowToScreen` 传 `{logical:true,dpi}` 才按 DIP 反算 |
| `toPhysical` / `toLogical` / `dpiScaleFromDpi` | — | `{x,y}` / number | `dpi/96` |
| `targetToClick(target,capture,windowRect,{point='center'\|'bboxCenter',offset,radiusScale,dpi})` | — | 同 `imageToWindow`，直接给 `click.*` | `radiusScale:0` 打靶心，`0.9` 打边缘（最严苛） |

CLI：`node vision.mjs <png> [--color auto|ff0000|r,g,b] [--tol 60] [--min-area 8] [--connectivity 8] [--sort area|circularity] [--top 5] [--radius-from mean|area|bbox] [--decoder auto|zlib|ffmpeg] [--json]`

### 3.5 examples 的 CLI

| 脚本 | 关键参数 | 行为 |
|---|---|---|
| `aim-at.mjs` | `--image PATH`（离线，配 `--bounds x,y,w,h` / `--image-scale`）；不给则真机只读截屏：`--scope desktop\|active_window`、`--window-title`、`--max-width`；找靶：`--color --tol --min-area --max-area --rank --sort --min-side --min-circularity`；点击：`--point --radius-scale --pointer x,y --duration --settle`；开关：`--live --json` | 默认 dry-run；无靶 → 退出码 2；有 step 失败 → 退出码 1 |
| `play-arena.mjs` | `--live`（真打）；`--duration --seed --cycles --max-cycles --image A.png,B.png --min-area --color --dur-move --settle --runs-dir --log --force --json` | dry-run 预演整条链路 + 只读解析既有 run 文件；`--live` 启动靶场、真实点击、一局结束读 `run-*.json` 打印成绩；检测到已有 Arena 窗口时 `--live` 直接停手（除非 `--force`） |

### 3.6 共用契约：capture 对象

```js
capture = { bounds: {x,y,width,height}, imageScale, imageWidth, imageHeight }   // vision.resolveCapture 输出
screen  = { x: bounds.x + imagePixelX / imageScale, y: bounds.y + imagePixelY / imageScale }
```

- 真机截屏：`bounds`/`imageScale` 从 `screenshot` 的 meta 直接拿（本机整屏 = `(0,0,1440,900)`，`maxWidth≥1440` 时 `scale=1`）。
- 离线图：不给 `--bounds` 时按「图像即屏幕、1:1」解释 —— **只适合预演**，真机必须给真实 bounds。
- `imageScale < 1` 是**降采样**（截图被缩小），不是 DPI 缩放；DPI 换算另走 `toPhysical/toLogical`。

---

## 4. 两条通道怎么选：元素通道 vs 真实指针

同一个靶子（`D:\dsh-arena`）给了两条完全不同的路，别混着谈成绩。

| 维度 | 元素通道（UIA） | 真实指针（本目录） |
|---|---|---|
| 入口 | `find query:"target"` → `click {elementId}`（`background:Invoke`） | `screenshot` → `vision.detectTargets` → `move` + `click {x,y,dispatch:'foreground'}` |
| 依赖 | 目标必须是**可访问元素**（有 `automationId`/`name`） | 只依赖**像素**：画布、游戏、自绘 UI、视频帧都能打 |
| 目标在动 | 不影响（元素在动也 invoke 得中） | 要**提前量**，预测错就是误击 |
| 碰不碰前台/指针 | 不碰（后台 invoke） | 会拿前台和指针，点下去就是真鼠标 |
| 单拍延迟（本机实测） | `find 419ms + click 164ms ≈ 583ms`（1.7Hz） | `截屏 258–266ms + 卡顿检测 ~40ms + move 170ms + click 202ms ≈ 468–479ms`（2.1Hz） |
| 命中率/结果（移动靶 3 局×30s） | 48/48/48 命中，误击 0，平均反应 610ms，极差 0 | 43/44/43 命中，误击 0，平均反应 668ms，极差 1；130 次命中**全部落在圆内**（中位 8.9px） |
| 冷启动 | 首拍 `find` 更慢 | **首拍真实耗时 1159ms**（计划 150ms，drift 1009ms）→ 第二次起稳定 |
| 自证能力 | 强（元素属性 + HUD 文本可复核） | 中（只能靠结果状态复核，截屏本身不证明动作成功） |
| 典型坑 | 无 `automationId` 就找不到；`Invoke` **不产生真实鼠标事件**（不能用来测真实输入延迟）；树可能是稀疏的 | 见下 |

> 上表延迟/成绩来自 `D:\dsh-arena\BENCH-REAL.md`（第 3–7 节，别人的基准报告，只读引用）；
> 截屏与解码是我在本机另测的（见下）。

**选哪条 —— 按目标形状决策**

1. 目标是标准控件（按钮/输入框/列表项）→ **元素通道**。更稳、更快、不抢前台。
2. 目标是自绘/画布/游戏/图片/视频里的东西，或没有可访问性 → **真实指针**。
3. 需要测「真实输入延迟 / 拟人轨迹」→ 只有真实指针成立。
4. 两者都要：**元素优先兜底像素**（`find` 打不到就截图找色块）。

**延迟量级（本次实测，整屏 1440×900，`screenshot scope=desktop`）**

```
冷启动首张:   1872ms（含 MCP server + PowerShell 后端启动）
预热后截屏:   267 / 490 / 416ms（同一进程连拍 4 张）
vision 解码:  1440px 103–159ms | 720px(scale .5) 31–40ms | 360px(scale .25) 6–11ms
move+click:   计划 220ms → 实测 223–235ms（dry-run 下含真实 sleep，误差 <15ms）
```

**真实指针的坑（都踩过）**

1. `color:'auto'` 在**整屏**截图上会猜出壁纸色：我实测 `rgb(152,186,211)` 命中一块 571035px 的「背景」并把它当靶 → 真机请显式给 `--color`（靶场红 = `e8452c`）。
2. 同色的小碎块是干扰（HUD 红字、图标）：用 `--min-area`（靶场靶 ≈ 2400–4000px）+ `--max-area` 压掉；`circularity` 在极小连通域上会 >1（离散误差），别拿它当唯一判据。
3. **降采样是把双刃剑**：`--max-width 720` 让 decode 从 103ms 掉到 31ms、噪声候选从 4–6 个降到 1 个，但 56px 的靶只有 28px 了；`360` 更省（decode 6–11ms），再小就有丢靶风险。
4. 坐标必须先有 `bounds/imageScale` 才能乘：拿「图片像素」当「屏幕坐标」只在 1:1 全屏截图时恰好成立，一旦窗口裁剪/降采样就整体偏。
5. `--min-area` 设太大 → 一局都找不到靶（我这次默认 300 就把 146px 的小靶滤掉了，属于预期行为）。
6. 真实点击会**抢前台**：目标窗口被别的窗口压住时坐标点会被拒（`POINT_COVERED`）；别和别人同时驱动同一桌面。
7. **轨迹锚点默认值陷阱**：`createEngine` 只要 `pointer` 有值就 `pointerKnown=true`，引擎**不会**去读真实指针；
   随手写 `pointer:{x:0,y:0}` 会让 live 首段从屏幕左上角划一条长线过来（真实指针在原地，屏幕却先跳走）。
   examples 里 live 模式一律 `pointer:null`，先只读一次 `Cursor.Position` 作为起点。

---

## 5. 不要拿它做什么

- **联机游戏 / 竞技对局的自动瞄准、反作弊绕过、多开代打。** 真实指针通道本身是 `SendCursorPos`/`SendInput` 级别的正常输入，
  它**不绕过**任何反作弊；要"过检测"就得去注入/改内存/伪造输入源，那已经不属于本目录能力范围（本目录只做「合法输入 + 视觉定位」）。
  另外网易/腾讯/EA 这类联机反作弊的判定与封禁是账号级不可逆的，拿它当靶子评测会污染自己的账号数据。
- **别人的账号、别人的桌面。** 这套东西会真的移动指针、真的按下左键，且 `click` 走 `foreground` 会抢前台；
  只能在自己拥有/被明确授权操作的会话里跑（靶场 `arena.ps1`、自己的测试机）。共用桌面上跑 `--live` 会打断别人的操作。
- **把 `--live` 当默认。** 所有示例默认 dry-run，就是防「以为在预演、其实在点」。加 `--live` 前先确认桌面空闲。
- **拿截屏当动作成功的证据。** `screenshot` 只证明"当时长这样"，不证明点击生效；要复核就看目标的 HUD/结果 JSON（`play-arena.mjs` 就是这么做的）。
- **拿真实指针去测"输入延迟"之外的东西。** 靶场记录的"反应时间"是**整环**口径（截屏+移动+点击），别和元素通道的数字直接比大小。

---

## 6. 已知问题（只报告，未改 `input.mjs`）

1. **dry sender 拦不住原生按键通道**（`input.mjs` L765-771、L870-883）。
   `sender` 与 `rawKey` 在构造里相互独立：`createEngine({sender:'dry'})` 之后调 `keyHold('a',180)` 仍会走 `PowerShellRawKey` → **真的按下 A 键**。
   降级分支（`degraded:true`）只在 `rawKey === null` 时生效。本目录的 `examples/screen.mjs → makeEngine()` 因此显式传 `rawKey: null`。
   建议：`sender` 为 dry 时默认 `rawKey=null`（或给 `dryRun` 一个覆盖两边的语义）。
2. **`estimateActionMs('drag')` 少算 50ms**（L258 vs L426）：预估返回 `durationMs`，而 `expandAction` 的 `endMs = startMs + 50 + durationMs`。用 `estimateActionMs` 做预算的调用方会系统性偏乐观。
3. **`McpSender` 丢掉 image 内容**（L571 只留 `type==='text'`）：`screenshot`/`snapshot`/`ocr(includeScreenshot)` 的 PNG 拿不到，
   只能解析 text 里的 `meta.path`（TEMP 文件）——`path` 是后端临时文件，会被清理，长流程要自己另存。
   另外 `resolveTool` 解析不到名字时会**拼**一个 `windows_computer_use_<name>`（L555-560），错误信息会显示成"工具不存在"，掩盖真实拼写问题。
4. **`McpSender` 硬编码 `TEMP/TMP = D:\dsh-tmp` 但不创建它**（L483、L506、L621、L696）：
   目录不存在时后端 `Bitmap.Save($env:TEMP\...)` 直接失败。对比 `vision.decodePngViaFfmpeg` 会 `mkdirSync(tmpDir)`（vision.mjs L168）——
   同一台机器上两套代码对"临时目录"的假设不一致。我在 `screen.mjs` 的调用侧保证 `D:\dsh-tmp` 存在。

---

## 7. 本次真跑的证据

| 命令 | 结果 |
|---|---|
| `aim-at.mjs --image probe\targets-b.png --min-area 100` | 找到 `rgb(255,0,0)` 靶 (480,120)，16 点轨迹 320,230→480,120，`move 15 + click 1` 仅记录，耗时 258ms |
| `aim-at.mjs --scope desktop --max-width 1440 --color e8452c --min-area 300` | 真机截屏 `bounds=(0,0,1440,900) scale=1`，1868ms 冷启动；找到靶 → 屏幕 (564,233)；dry-run 记录 |
| `play-arena.mjs`（默认） | 6 拍预演全绿，`{"move":78,"click":6}` 未发出；只读解析 `run-20261107-030814.json` → `score=43 hits=43 misses=0 avgReactionMs=668.3` |
| `play-arena.mjs --min-area 100 --cycles 4 --image A,B --json` | 双图轮换 4 拍，JSON 汇总 `ok=4 failed=0 plannedAvgMs=220 elapsedAvgMs=227` |
| 指针不动自证 | dry-run 前后 `node input.mjs --pointer` 均为 `x=913 y=205` |
| 截屏/解码标定 | 冷 1872ms、热 267/416/490ms；decode 1440px 103–159ms、720px 31–40ms、360px 6–11ms |

本轮**没有执行 `--live`**：桌面归靶场（V1）使用，本轮禁止真实键鼠。所有数值均来自 dry-run 与只读工具。
