#!/usr/bin/env node
/**
 * examples/aim-at.mjs —— 最小可用闭环：「看到屏幕上的目标就点它」
 *
 *   截屏(screenshot，只读) → vision 找靶 → vision 换算屏幕坐标 → input 平滑移动 → 点击
 *
 * 用法（默认 dry-run，一次真实输入都不发）：
 *   node examples/aim-at.mjs --image D:\dsh-arena\probe\targets-b.png --min-area 100
 *   node examples/aim-at.mjs --image D:\dsh-arena\probe\targets-b.png --color 00ff00 --min-area 20
 *   node examples/aim-at.mjs --scope desktop --min-area 800 --json           # 真截屏（只读），仍 dry-run
 *   node examples/aim-at.mjs --scope desktop --min-area 800 --live           # 才会真的动指针（桌面须归你）
 *
 * 关键参数
 *   --image PATH        离线：直接吃现成 PNG，不连 MCP、不碰桌面（预演/回归用）
 *   --bounds x,y,w,h    离线时必须给：这张图对应屏幕上的哪块区域（不给=假设图像即屏幕、1:1）
 *   --image-scale S     图被降采样过时给（真机截屏由 screenshot 自动回报）
 *   --scope desktop|active_window / --window-title / --max-width   真截屏的三个旋钮
 *   --color auto|ff0000|r,g,b  --tol 60  --min-area 300  --rank 1  --sort area|circularity
 *   --point center|bboxCenter  --radius-scale 0（0=靶心；0.9=打边缘，最严苛）
 *   --pointer x,y       轨迹起点（不给：dry-run 用目标点附近；live 用真实指针位置，只读）
 *   --duration 220 --settle 30 --live --json --help
 */

import {
  parseArgs, has, num, pt, rect, fmt, openSender, shot, captureFrom,
  findTargets, pickTarget, clickPoint, describe, makeEngine,
} from './screen.mjs';

const USAGE = `aim-at.mjs —— 截屏→找靶→移动→点击（默认 dry-run）

  node examples/aim-at.mjs --image PATH [--bounds x,y,w,h] [--image-scale S] [--min-area N] [--color auto|ff0000] [--rank N]
  node examples/aim-at.mjs [--scope desktop|active_window] [--window-title T] [--max-width 1600] [--min-area N]
  通用： --point center|bboxCenter  --radius-scale 0..1  --pointer x,y  --duration 220  --settle 30  --json  --live`;

async function main() {
  const a = parseArgs();
  if (has(a, 'help') || a._.includes('help')) { console.log(USAGE); return; }

  const live = has(a, 'live');
  const color = a.color ?? 'auto';
  const minArea = num(a['min-area'], 300);
  const rank = num(a.rank, 1);
  const windowRect = a['window-rect'] ? rect(a['window-rect']) : { x: 0, y: 0 };
  const step = (n, msg) => console.log(`[${n}/4] ${msg}`);

  let sender = null;
  let imagePath;
  let bounds = a.bounds ? rect(a.bounds) : null;
  let imageScale = a['image-scale'] != null ? num(a['image-scale'], 1) : null;
  let source;

  try {
    /* 1) 取图：离线文件，或真机只读截屏 */
    if (a.image) {
      imagePath = String(a.image);
      source = 'file';
      step(1, `离线图像 ${imagePath}${bounds ? `  bounds=${a.bounds}  scale=${imageScale ?? 1}` : '  （未给 --bounds → 按「图像即屏幕」1:1 解释）'}`);
    } else {
      sender = await openSender();
      const s = await shot(sender, {
        scope: a.scope ?? 'desktop',
        windowTitle: a['window-title'] ?? null,
        maxWidth: num(a['max-width'], 1600),
        timeoutMs: num(a['timeout-ms'], 20000),
      });
      imagePath = s.path; bounds = s.bounds; imageScale = s.imageScale ?? 1;
      source = `mcp:screenshot:${s.method ?? '?'}`;
      step(1, `截屏 ${imagePath}  bounds=(${bounds.x},${bounds.y},${bounds.width},${bounds.height}) scale=${imageScale} 耗时=${s.ms}ms occluded=${s.occludedPossible}`);
    }

    /* 2) vision：解码 → 找靶 */
    const { image, capture } = captureFrom(imagePath, { bounds, imageScale: imageScale ?? 1 });
    const targets = findTargets(image, { color, tolerance: num(a.tol, 60), minArea, maxArea: num(a['max-area'], Infinity), sort: a.sort ?? 'area', connectivity: num(a.connectivity, 8) });
    const t = pickTarget(targets, { rank, minCircularity: num(a['min-circularity'], 0), minSide: num(a['min-side'], 0) });
    if (!t) {
      console.error(`[2/4] 没找到目标：图 ${image.width}x${image.height}，候选 ${targets.length} 个（color=${color} tol=${num(a.tol, 60)} min-area=${minArea}）`);
      console.error('      → 放大 --tol、调低 --min-area，或指定 --color（vision.mjs --json 可以先看候选）');
      process.exitCode = 2;
      return;
    }
    step(2, `目标 ${describe(t)}  （候选共 ${targets.length} 个，取第 ${rank} 名）`);

    /* 3) 换算：图像像素 → 屏幕物理坐标（契约 screen = bounds.origin + pixel / imageScale） */
    const hit = clickPoint(t, capture, {
      windowRect,
      point: a.point ?? 'center',
      radiusScale: num(a['radius-scale'], 0),
      dpi: a.dpi ? num(a.dpi, 96) : null,
    });
    step(3, `换算 屏幕=(${hit.click.screenX},${hit.click.screenY}) 窗口=(${hit.click.windowX},${hit.click.windowY})  bounds=(${capture.bounds.x},${capture.bounds.y},${capture.bounds.width},${capture.bounds.height}) scaleX=${fmt(capture.scaleX, 4)}`);

    /* 4) input：平滑移动 + 点击 */
    const engine = makeEngine({ live, pointer: a.pointer ? pt(a.pointer) : null });
    if (!a.pointer) {
      if (live) {
        const p = await engine.getPointer();
        step(4, `轨迹起点=真实指针(${p.x},${p.y})（只读 Cursor.Position，不移动指针）`);
      } else {
        // dry-run 不知道真实指针在哪 → 用一个确定性的假设起点，让轨迹是可观察的（不是原地 16 点）
        const start = { x: Math.max(0, hit.click.screenX - 160), y: Math.max(0, hit.click.screenY + 110) };
        engine.setPointer(start.x, start.y);
        step(4, `轨迹起点=预演假设(${start.x},${start.y})（dry-run 无真实指针；--pointer x,y 可指定）`);
      }
    }
    const r = await engine.click(hit.click.screenX, hit.click.screenY, { durationMs: num(a.duration, 220), settleMs: num(a.settle, 30) });

    const calls = engine.sender.calls ?? [];
    if (live) {
      step(4, `真实输入：steps=${r.steps} failed=${r.failed} plannedMs=${r.plannedMs} 真实耗时=${r.elapsedMs}ms 平均单步=${r.avgStepMs}ms 轨迹点=${r.trajectory.length}`);
    } else {
      const kinds = calls.reduce((m, c) => { m[c.tool] = (m[c.tool] ?? 0) + 1; return m; }, {});
      step(4, `dry-run：move ${kinds.move ?? 0} 次 + click ${kinds.click ?? 0} 次已记录（未发出）  计划步数=${r.steps} plannedMs=${r.plannedMs} 时钟耗时=${r.elapsedMs}ms`);
      console.log(`       轨迹 ${r.trajectory[0].x},${r.trajectory[0].y} → ${r.trajectory.at(-1).x},${r.trajectory.at(-1).y}（${r.trajectory.length} 点，贝塞尔+缓动）`);
      console.log('       要真的点下去：加 --live（桌面必须归你独占，别和别的自动化抢鼠标）');
    }

    if (has(a, 'json')) {
      console.log(JSON.stringify({
        source, image: { path: imagePath, width: image.width, height: image.height },
        color: t.color, target: t, capture: { bounds: capture.bounds, imageScale: capture.imageScale }, click: hit.click,
        live, result: { steps: r.steps, failed: r.failed, plannedMs: r.plannedMs, elapsedMs: r.elapsedMs, avgStepMs: r.avgStepMs, driftMs: r.driftMs },
      }, null, 2));
    }
    process.exitCode = r.failed ? 1 : 0;
  } finally {
    try { await sender?.close(); } catch { /* ignore */ }
  }
}

main().catch((e) => { console.error('aim-at 失败:', e.message); process.exitCode = 1; });
