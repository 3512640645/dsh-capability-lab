#!/usr/bin/env node
/**
 * examples/play-arena.mjs —— 完整闭环示例：用「真实指针」把 D:\dsh-arena\arena.ps1 打一局并打印成绩
 *
 * 闭环：启动靶场 → 等窗口 → 截屏(只读) → vision 找红靶 → input 平滑移动 → 真实点击 → 一局结束 → 读 run-*.json
 *
 *   node examples/play-arena.mjs                    # 默认 dry-run：不动鼠标、不拉窗口，静态靶位图预演 + 打印成绩解析
 *   node examples/play-arena.mjs --live --duration 10 --seed 20261107   # 真打（桌面必须归你独占）
 *
 * 说明
 *   · dry-run 下**不会**启动靶场、不会 move/click、不会读真实指针；只把整条链路的时序与坐标演一遍，
 *     并把「成绩打印」这段代码用真实的 run-*.json 跑通（只读 D:\dsh-arena\runs）。
 *   · --live 才真的动鼠标：默认把本局的 run/log 写到 D:\dsh-tmp\arena-runs 与 D:\dsh-tmp\arena-*.log，
 *     不污染靶场自己的 D:\dsh-arena\{runs,logs}。
 *   · 安全闸：--live 时若已存在 DSH Arena 窗口（别人正在打），直接停手，除非 --force。
 */

import { spawn } from 'node:child_process';
import path from 'node:path';
import {
  parseArgs, has, num, sleep, fmt, openSender, shot, captureFrom, findTargets, pickTarget,
  clickPoint, describe, makeEngine, listRuns, readRun, ensureDir, firstJsonObject,
} from './screen.mjs';

const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const ARENA = 'D:\\dsh-arena\\arena.ps1';
const TMP = 'D:\\dsh-tmp';

const USAGE = `play-arena.mjs —— 打一局 DSH Arena 并打印成绩（默认 dry-run）

  node examples/play-arena.mjs [--cycles 6] [--image A.png,B.png] [--min-area 300] [--color auto]
  node examples/play-arena.mjs --live [--duration 10] [--seed N] [--max-cycles 200] [--force]
  参数： --duration 秒  --seed 固定靶位  --target-size 56  --dur-move 200  --settle 20  --json  --force`;

/* ── 枚举窗口（只读） ─────────────────────────────────────────────────── */
async function listWindows(sender) {
  const r = await sender.call('list_windows', { includeInvisible: false, maxWindows: 200 });
  if (!r.ok) throw new Error(`list_windows 失败: ${r.error ?? r.text}`);
  return firstJsonObject(r.text)?.windows ?? [];
}
const isArena = (w) => /DSH\s*Arena/i.test(w.name ?? w.title ?? '');

/* ── 成绩打印：run schema = dsh-arena/run/1 ──────────────────────────── */
function printScore(run, label) {
  console.log(`${label}`);
  console.log(`  score=${run.score}  hits=${run.hits}  misses=${run.misses}  hitRate=${run.hitRate}`);
  console.log(`  avgReactionMs=${run.avgReactionMs}  min=${run.minReactionMs}  max=${run.maxReactionMs}  median=${run.medianReactionMs}  p90=${run.p90ReactionMs}`);
  console.log(`  elapsedMs=${run.elapsedMs}  aborted=${run.aborted}  roundId=${run.roundId}  seed=${run.seed}  targetSizePx=${run.targetSizePx}`);
}
function loadRun(file) {
  const run = readRun(file);
  run.__file = file;
  return run;
}

/* ── dry-run：静态靶位图预演整条闭环 ─────────────────────────────────── */
async function dryRun(a) {
  const images = String(a.image ?? 'D:\\dsh-arena\\probe\\targets-b.png').split(',').map((s) => s.trim()).filter(Boolean);
  const cycles = num(a.cycles, 6);
  const minArea = num(a['min-area'], 300);
  const engine = makeEngine({ live: false, pointer: { x: 0, y: 0 } });
  const rows = [];
  let ok = 0, failed = 0;

  console.log(`[dry-run] 不启动靶场、不发真实输入。预演图: ${images.join(' , ')}`);
  console.log('序号 读数                   图像中心        屏幕坐标    步数  planned  elapsed  状态');
  for (let i = 0; i < cycles; i++) {
    const file = images[i % images.length];
    const { image, capture } = captureFrom(file, {});
    const targets = findTargets(image, { color: a.color ?? 'auto', tolerance: num(a.tol, 60), minArea, sort: 'area' });
    const t = pickTarget(targets, { rank: (i % Math.max(1, targets.length)) + 1 });
    if (!t) {
      console.log(`${String(i + 1).padStart(2)}   ——  ${path.basename(file)} 候选 ${targets.length} 个，全部被 --min-area ${minArea} 滤掉`);
      failed++;
      continue;
    }
    const hit = clickPoint(t, capture, { windowRect: { x: 0, y: 0 } });
    const r = await engine.click(hit.click.screenX, hit.click.screenY, { durationMs: num(a['dur-move'], 200), settleMs: num(a.settle, 20) });
    if (r.failed) failed++; else ok++;
    rows.push({ i: i + 1, file: path.basename(file), center: `${fmt(t.center.x)},${fmt(t.center.y)}`, screen: `${hit.click.screenX},${hit.click.screenY}`, steps: r.steps, plannedMs: r.plannedMs, elapsedMs: r.elapsedMs });
    console.log(`${String(i + 1).padStart(2)}  ${describe(t).padEnd(66)}→ (${hit.click.screenX},${hit.click.screenY})  ${String(r.steps).padStart(3)}  ${String(r.plannedMs).padStart(6)}  ${String(r.elapsedMs).padStart(8)}  ${r.failed ? 'FAIL' : '记录'}`);
  }
  const calls = engine.sender.calls ?? [];
  const kinds = calls.reduce((m, c) => { m[c.tool] = (m[c.tool] ?? 0) + 1; return m; }, {});
  const avg = (k) => (rows.length ? Math.round(rows.reduce((s, r) => s + r[k], 0) / rows.length) : 0);
  console.log(`[dry-run] 预演合计: cycles=${rows.length} 计划成功=${ok} 失败=${failed}  平均 planned=${avg('plannedMs')}ms / 平均耗时=${avg('elapsedMs')}ms（含真实 sleep，dry 下不产生任何键鼠）`);
  console.log(`[dry-run] DryRunSender 记录: ${JSON.stringify(kinds)}（共 ${calls.length} 次调用，未发出）`);
  await engine.close();

  // 成绩打印路径：用真实的 run 文件跑通（只读）
  const runsDir = a['runs-dir'] ?? 'D:\\dsh-arena\\runs';
  const runs = listRuns(runsDir);
  if (runs.length) {
    const run = loadRun(runs[0].file);
    printScore(run, `[dry-run] 成绩解析自既有 run 文件（只读，非本局）：${run.__file}`);
    console.log(`  reactionMs 前 8 个: ${JSON.stringify((run.reactionMs ?? []).slice(0, 8))}`);
  } else {
    console.log(`[dry-run] ${runsDir} 下没有 run-*.json，成绩打印路径本回合没有真实数据可验`);
  }

  const liveCmd = `"${PS}" -NoProfile -STA -ExecutionPolicy Bypass -File "${ARENA}" -Duration ${num(a.duration, 10)} -Seed ${num(a.seed, 20261107)} -ExitOnFinish -RunsDir ${a['runs-dir'] ?? `${TMP}\\arena-runs`} -LogFile ${TMP}\\arena-<ts>.log`;
  console.log(`[dry-run] --live 将会执行: ${liveCmd}`);
  console.log(`[dry-run] 判定：本次没有发出一条真实鼠标指令（--live 未给）。`);
  return { mode: 'dry-run', rows, ok, failed, plannedAvgMs: avg('plannedMs'), elapsedAvgMs: avg('elapsedMs') };
}

/* ── live：真打一局 ─────────────────────────────────────────────────── */
async function liveRun(a) {
  const duration = num(a.duration, 10);
  const seed = num(a.seed, 0);
  const runsDir = ensureDir(a['runs-dir'] ?? `${TMP}\\arena-runs`);
  const logFile = a.log ?? `${TMP}\\arena-${Date.now()}.log`;
  const maxCycles = num(a['max-cycles'], 400);
  const startedAt = Date.now();

  const sender = await openSender();
  const engine = makeEngine({ live: true, pointer: null });   // null = 锚点未知 → 首段轨迹从真实指针出发
  const p0 = await engine.getPointer();                        // 只读 Cursor.Position
  console.log(`[live] 真实指针起点 = (${p0.x},${p0.y})（只读，未移动指针）`);

  const pre = (await listWindows(sender)).filter(isArena);
  if (pre.length && !has(a, 'force')) {
    await sender.close();
    throw new Error(`已经有一个 DSH Arena 窗口（hwnd=${pre[0].nativeWindowHandle}）在跑，--live 会让两套驱动抢鼠标。确认无人使用后加 --force`);
  }

  const child = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ARENA,
    '-Duration', String(duration), '-Seed', String(seed), '-ExitOnFinish',
    '-RunsDir', runsDir, '-LogFile', logFile], {
    env: { ...process.env, TEMP: TMP, TMP }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true,
  });
  child.stderr.on('data', () => { /* 靶场把错误写进自己的 log，这里不刷屏 */ });

  let win = null;
  for (let i = 0; i < 50 && !win; i++) { await sleep(300); win = (await listWindows(sender)).find(isArena) ?? null; }
  if (!win) { child.kill(); await sender.close(); throw new Error(`50 次轮询（15s）没等到 "DSH Arena" 窗口；看 log: ${logFile}`); }
  console.log(`[live] 靶场窗口 hwnd=${win.nativeWindowHandle} pid=${win.processId} box=${JSON.stringify(win.boundingBox)}  Duration=${duration}s Seed=${seed}`);

  let cycles = 0, clicked = 0, shotMs = 0, clickMs = 0, misses = 0;
  const deadline = startedAt + (duration + 20) * 1000;
  while (cycles < maxCycles && Date.now() < deadline) {
    cycles++;
    if (listRuns(runsDir).some((r) => r.mtime >= startedAt)) break;          // 一局结束：结果已落盘
    const files = await listWindows(sender);
    if (!files.some(isArena)) break;                                          // 窗口没了
    let s;
    try { s = await shot(sender, { scope: 'active_window', nativeWindowHandle: win.nativeWindowHandle, maxWidth: 0, timeoutMs: 15000 }); }
    catch (e) { console.log(`[live] cycle ${cycles} 截屏失败: ${e.message}`); await sleep(120); continue; }
    shotMs += s.ms;
    const { image, capture } = captureFrom(s.path, { bounds: s.bounds, imageScale: s.imageScale });
    const t = pickTarget(findTargets(image, { color: a.color ?? 'auto', tolerance: num(a.tol, 60), minArea: num(a['min-area'], 300) }), { rank: 1 });
    if (!t) { misses++; await sleep(80); continue; }                           // 靶没刷出来 / 被挡
    const hit = clickPoint(t, capture, { windowRect: win.boundingBox ?? { x: 0, y: 0 } });
    const r = await engine.click(hit.click.screenX, hit.click.screenY, { durationMs: num(a['dur-move'], 200), settleMs: num(a.settle, 20) });
    clickMs += r.elapsedMs;
    if (r.failed) { misses++; } else { clicked++; }
    if (cycles % 5 === 0 || cycles <= 3) console.log(`[live] cycle ${cycles} 靶(${hit.click.screenX},${hit.click.screenY}) 图(${fmt(t.center.x)},${fmt(t.center.y)}) 截屏=${s.ms}ms 点击=${r.elapsedMs}ms`);
  }

  await engine.close();
  await sender.close();
  const runs = listRuns(runsDir).filter((r) => r.mtime >= startedAt);
  const summary = {
    mode: 'live', cycles, clicked, probeMisses: misses,
    avgShotMs: clicked ? Math.round(shotMs / Math.max(1, cycles)) : 0,
    avgClickMs: cycles ? Math.round(clickMs / Math.max(1, cycles)) : 0,
    runFile: runs[0]?.file ?? null, logFile,
  };
  if (runs[0]) printScore(loadRun(runs[0].file), `[live] 本局成绩（${runs[0].file}）`);
  else console.log(`[live] 没有等到 run-*.json（${runsDir}）；成绩/日志: ${logFile}`);
  console.log(`[live] 指针闭环: cycles=${cycles} 真实点击=${clicked} 空轮=${misses} 平均截屏=${summary.avgShotMs}ms 平均点击=${summary.avgClickMs}ms`);
  return summary;
}

async function main() {
  const a = parseArgs();
  if (has(a, 'help')) { console.log(USAGE); return; }
  const live = has(a, 'live');
  const out = live ? await liveRun(a) : await dryRun(a);
  if (has(a, 'json')) console.log(JSON.stringify(out, null, 2));
  process.exitCode = out.failed ? 1 : 0;
}

main().catch((e) => { console.error('play-arena 失败:', e.message); process.exitCode = 1; });
