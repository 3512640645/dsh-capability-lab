/**
 * examples/screen.mjs —— 两个示例共用的胶水层（不是引擎，只是把 input.mjs / vision.mjs 接起来）
 *
 * 事实来源（以源码为准，不抄别人的描述）：
 *   · input.mjs 导出：createEngine / InputEngine / McpSender / PowerShellRawKey / DryRunSender /
 *     FakeSender / readPointerPosition / planMove / planSchedule / plan*m 系列 / withRetry / 时钟
 *   · vision.mjs 导出：loadImage / decodePng / detectTargets / buildMask / connectedComponents /
 *     guessColor / resolveCapture / imageToScreen / screenToImage / imageToWindow / targetToClick
 *   · vision 只吃 PNG 文件，自身**没有截屏能力** —— 截屏靠 MCP 工具 screenshot（只读），
 *     它回传 meta：{ path, bounds, imageScale, method, occludedPossible }，并且把 base64 换成占位符，
 *     所以 text 内容很小、可以安全 JSON.parse（见 wcu/package/scripts/windows-uia.ps1 L2343-2362）。
 *
 * 坐标契约（两条通道唯一的分界）：screen = bounds.origin + imagePixel / imageScale
 */

import { readFileSync, existsSync, mkdirSync, statSync, readdirSync } from 'node:fs';
import { createEngine, McpSender } from '../input.mjs';
import { loadImage, detectTargets, resolveCapture, targetToClick } from '../vision.mjs';

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ── CLI 解析：--k v 取值，裸 --flag 记为 true（并进 flags 集合） ───────── */
export function parseArgs(argv = process.argv.slice(2)) {
  const out = { _: [], flags: new Set() };
  for (let i = 0; i < argv.length; i++) {
    const s = argv[i];
    if (!s.startsWith('--')) { out._.push(s); continue; }
    const k = s.slice(2);
    const next = argv[i + 1];
    if (next !== undefined && !next.startsWith('--')) { out[k] = next; i++; } else { out[k] = true; out.flags.add(k); }
  }
  return out;
}
export const has = (a, k) => a[k] === true || a.flags?.has(k) === true;
export const num = (v, dflt) => { const n = Number(v); return Number.isFinite(n) ? n : dflt; };
export const pt = (spec) => { const [x, y] = String(spec).split(',').map(Number); return { x, y }; };
export const rect = (spec) => { const [x, y, width, height] = String(spec).split(',').map(Number); return { x, y, width, height }; };
export const fmt = (n, d = 1) => (Number.isFinite(n) ? n.toFixed(d) : String(n));

/* ── 从一段文本里抠出第一个完整 JSON 对象（meta 后面可能还有别的 text 块） ── */
export function firstJsonObject(text) {
  const s = String(text ?? '');
  try { return JSON.parse(s.trim()); } catch { /* 继续扫描 */ }
  for (let i = s.indexOf('{'); i !== -1; i = s.indexOf('{', i + 1)) {
    let depth = 0, inStr = false, esc = false;
    for (let j = i; j < s.length; j++) {
      const c = s[j];
      if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; continue; }
      if (c === '"') { inStr = true; continue; }
      if (c === '{') depth++;
      else if (c === '}') { depth--; if (depth === 0) { try { return JSON.parse(s.slice(i, j + 1)); } catch { break; } } }
    }
  }
  return null;
}

/* ── MCP 发送端（真机只读/输入的唯一出口；mode=full 才有 move/drag） ─────── */
export async function openSender({ mode = process.env.WCU_MODE ?? 'full' } = {}) {
  const sender = new McpSender({ mode });
  await sender.start();
  return sender;
}

/**
 * 只读截屏。scope=desktop 截全屏；给 nativeWindowHandle / windowTitle 则裁该窗口。
 * 不改前台、不动指针（wcu 文档：reads touch nothing）。
 * @returns {{path:string,bounds:{x,y,width,height},imageScale:number,method?:string,ms:number,raw:object}}
 */
export async function shot(sender, { scope = 'desktop', windowTitle = null, nativeWindowHandle = null, maxWidth = 1600, timeoutMs = 20000 } = {}) {
  const args = { scope, maxWidth, __timeoutMs: timeoutMs };
  if (windowTitle) args.windowTitle = windowTitle;
  if (nativeWindowHandle) args.nativeWindowHandle = nativeWindowHandle;
  const t0 = Date.now();
  const r = await sender.call('screenshot', args);
  const ms = Date.now() - t0;
  if (!r.ok) throw new Error(`screenshot 失败: ${r.error ?? r.text}`);
  const data = firstJsonObject(r.text);
  const meta = data?.screenshot ?? data ?? {};
  if (!meta.path) throw new Error(`screenshot 响应里没有 path；原文前 200 字: ${String(r.text).slice(0, 200)}`);
  return {
    path: meta.path, bounds: meta.bounds, imageScale: meta.imageScale ?? 1, origin: meta.origin ?? null,
    method: meta.method, occludedPossible: !!meta.occludedPossible, bytes: meta.bytes, ms, raw: meta,
  };
}

/**
 * 载图 + 归一化成 vision 的 capture。
 * bounds 缺省 = 「图像即屏幕」：原点 (0,0) 且 1:1（离线预演用；真机截屏必须传真实 bounds）。
 */
export function captureFrom(image, { bounds = null, imageScale = 1 } = {}) {
  const img = typeof image === 'string' ? loadImage(image, { decoder: 'auto' }) : image;
  const b = bounds ?? { x: 0, y: 0, width: img.width, height: img.height };
  const capture = resolveCapture({ bounds: b, imageWidth: img.width, imageHeight: img.height, imageScale });
  return { image: img, capture };
}

/** 颜色阈值 → 连通域找靶。color='auto' 时 vision 自己猜主色（饱和像素众数）。 */
export function findTargets(image, opts = {}) {
  return detectTargets(image, {
    color: opts.color ?? 'auto',
    tolerance: opts.tolerance ?? 60,
    minArea: opts.minArea ?? 8,
    maxArea: opts.maxArea ?? Infinity,
    connectivity: opts.connectivity ?? 8,
    sort: opts.sort ?? 'area',
    radiusFrom: opts.radiusFrom ?? 'mean',
    top: opts.top ?? 0,
  });
}

/** 取第 rank 名；再按最小圆度/最小边长过滤（滤掉同色的 HUD 文字碎块） */
export function pickTarget(targets, { rank = 1, minCircularity = 0, minSide = 0 } = {}) {
  const list = targets.filter((t) => t.circularity >= minCircularity && Math.min(t.bbox.width, t.bbox.height) >= minSide);
  return list[rank - 1] ?? null;
}

/** 靶 → 屏幕点击坐标（vision 纯函数，两种通道共用这一份换算） */
export function clickPoint(target, capture, { windowRect = { x: 0, y: 0 }, point = 'center', radiusScale = 0, offset = null, dpi = null } = {}) {
  const opts = { point, radiusScale };
  if (offset) opts.offset = offset;
  if (dpi) opts.dpi = dpi;
  return targetToClick(target, capture, windowRect, opts);
}

export function describe(target) {
  return `#${target.rank} rgb(${target.color.join(',')}) 图像(${fmt(target.center.x)},${fmt(target.center.y)}) r=${fmt(target.radius)} area=${target.area} circ=${fmt(target.circularity, 3)} bbox=${target.bbox.width}x${target.bbox.height}@(${target.bbox.x},${target.bbox.y})`;
}

/**
 * 装配引擎。
 * live=false → DryRunSender：move/click 只记录；**必须显式 rawKey:null**，
 *              否则 keyHold/chord 仍会走 PowerShellRawKey 发真实按键（详见 README「坑」）。
 * pointer 默认 null = 「锚点未知」：live 时让引擎去读真实指针（只读 Cursor.Position），
 *              避免用一个假定的 (0,0) 当轨迹起点（那会从屏幕左上角划一条长线过来）。
 */
export function makeEngine({ live = false, pointer = null, sender = null, retry = {}, mcp = {} } = {}) {
  if (live) {
    return createEngine({ sender: sender ?? 'mcp', mcp: { mode: 'full', ...mcp }, pointer, retry: { attempts: 2, ...retry } });
  }
  return createEngine({ sender: 'dry', rawKey: null, pointer, retry: { attempts: 1, timeoutMs: 3000, ...retry } });
}

/* ── 结果文件：拿时间戳最新的 run-*.json，并做 UTF-8(BOM) 容错 ──────────── */
export function listRuns(dir) {
  if (!existsSync(dir)) return [];
  return readdirSync(dir)
    .filter((f) => /^run-.*\.json$/i.test(f))
    .map((f) => { const p = `${dir}\\${f}`; return { file: p, mtime: statSync(p).mtimeMs }; })
    .sort((a, b) => b.mtime - a.mtime);
}
export function readRun(file) {
  const txt = readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
  return JSON.parse(txt);
}
export function ensureDir(dir) { if (!existsSync(dir)) mkdirSync(dir, { recursive: true }); return dir; }
