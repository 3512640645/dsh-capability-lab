#!/usr/bin/env node
/**
 * D:\dsh-tools\aim\input.mjs —— 「像人一样操作电脑」的输入引擎
 *
 * 设计要点
 *  1. 纯函数区（PURE，无副作用、无 IO）负责全部数学与时序：插值、贝塞尔轨迹、缓动、
 *     按键序列、时间戳展开。无桌面即可单测（见 self-test.mjs）。
 *  2. 适配器区（Adapter）负责真正的落地：McpSender（插件 stdio JSON-RPC）、
 *     PowerShellRawKey（keybd_event，毫秒级按住/释放）、DryRunSender（只记录不发）。
 *  3. 执行器（InputEngine）把「计划」交给「时钟 + sender」执行：每个原语都有
 *     重试 / 超时 / 实际耗时（elapsedMs）/ 逐次尝试次数（attempts）。
 *
 * 后端事实（来自 D:\dsh-tools\wcu\package\docs\wiki\mcp-tools.md 与 windows-uia.ps1）
 *  - move(x,y)       : SetCursorPos，瞬时跳变，无 duration  → 平滑轨迹必须自己多段调用
 *  - drag(path[])    : 后端逐点 SetCursorPos 且 Start-Sleep 25ms/点 → 直接喂稠密路径
 *  - keypress(keys[]) : SendKeys，只有「按一下」，没有按住时长      → keyHold 走 keybd_event
 *  - click(x,y,button,dispatch) : dispatch='foreground' 才是真实输入
 *
 * 用法
 *   import { createEngine, planMove } from 'D:/dsh-tools/aim/input.mjs';
 *   const e = createEngine({ sender: 'mcp' });
 *   await e.moveRel(120, -60, 260);          // 平滑相对移动
 *   await e.keyHold('a', 180);               // 按住 180ms
 *   await e.chord(['ctrl', 'c'], { holdMs: 90 });
 *   await e.schedule([...]);                 // 时间戳序列
 *   e.close();
 *
 * 只读 CLI（不做任何真实键鼠动作）：
 *   node input.mjs --list-tools      列出插件工具名
 *   node input.mjs --health          调用 health（只读）
 *   node input.mjs --pointer         读取当前指针坐标（只读）
 */

import { spawn, spawnSync } from 'node:child_process';
import path from 'node:path';

/**
 * 解析可用的 PowerShell 解释器。
 * 本机实测：PATH 里没有 pwsh（spawn ENOENT），插件后端跑的是 Windows PowerShell 5.1
 * （health 报 "powershell":"5.1.26100.8115"），所以回退顺序是 pwsh → powershell → System32 绝对路径。
 */
let psCache = null;
export function resolvePowerShell(preferred = null) {
  if (preferred) return preferred;
  if (process.env.AIM_PWSH) return process.env.AIM_PWSH;
  if (psCache) return psCache;
  const candidates = [
    'pwsh',
    'powershell',
    path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'),
  ];
  for (const c of candidates) {
    const r = spawnSync(c, ['-NoProfile', '-NonInteractive', '-Command', 'exit 0'], { windowsHide: true, timeout: 8000, stdio: 'ignore' });
    if (!r.error) { psCache = c; return c; }
  }
  psCache = 'powershell';
  return psCache;
}

// ════════════════════════════════════════════════════════════════════════════
// PURE：数学
// ════════════════════════════════════════════════════════════════════════════

export const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
export const lerp = (a, b, t) => a + (b - a) * t;

/** 确定性伪随机（同一 seed → 同一轨迹，便于复现与断言） */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const EASINGS = {
  linear: (t) => t,
  easeInOutSine: (t) => -(Math.cos(Math.PI * t) - 1) / 2,
  easeInOutQuad: (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
  easeInOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  easeOutCubic: (t) => 1 - Math.pow(1 - t, 3),
  easeOutSine: (t) => Math.sin((t * Math.PI) / 2),
};
export const ease = (name, t) => (EASINGS[name] ?? EASINGS.easeInOutSine)(clamp(t, 0, 1));

/** 任意阶 Bézier（de Casteljau），points 为控制点（含首尾） */
export function bezierPoint(points, t) {
  let pts = points.map((p) => ({ x: p.x, y: p.y }));
  while (pts.length > 1) {
    const next = [];
    for (let i = 0; i < pts.length - 1; i++) {
      next.push({ x: lerp(pts[i].x, pts[i + 1].x, t), y: lerp(pts[i].y, pts[i + 1].y, t) });
    }
    pts = next;
  }
  return pts[0];
}

/**
 * 由起点/终点生成控制点。
 * 关键：arc 变体的控制点落在线段中点 —— 这样 curvature=0 时二阶 Bézier 退化为
 * 匀速直线（x(t) 严格线性）；s 变体控制点取 1/3、2/3，同理保证直线上匀速。
 * 早期版本用 0.33/0.66 偏移，导致"直线"上各段位移 14~26px 抖动，已修正。
 */
export function makeCurve(from, to, { curvature = 0.18, seed = 1, variant = 'arc' } = {}) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const dist = Math.hypot(dx, dy) || 1;
  const nx = -dy / dist;
  const ny = dx / dist;
  const rng = mulberry32(seed);
  const sign = variant === 's' ? 1 : rng() < 0.5 ? -1 : 1;
  const bow = dist * curvature * sign;
  if (variant === 's') {
    return [
      from,
      { x: from.x + dx / 3 + nx * bow, y: from.y + dy / 3 + ny * bow },
      { x: from.x + (dx * 2) / 3 - nx * bow, y: from.y + (dy * 2) / 3 - ny * bow },
      to,
    ];
  }
  const mx = from.x + dx / 2;
  const my = from.y + dy / 2;
  // 0.9 是轻微的"非对称人手感"系数（最大值偏离 ≈ 0.45*dist*curvature）
  return [from, { x: mx + nx * bow * 0.9, y: my + ny * bow * 0.9 }, to];
}

/** 步数：按时间切片，距离过短时减少步数，避免原地重复点 */
export function stepCount(distance, durationMs, opts = {}) {
  const { stepMs = 15, minSteps = 6, maxSteps = 120 } = opts;
  let n = Math.round(durationMs / stepMs);
  n = clamp(n, minSteps, maxSteps);
  if (distance > 0 && distance < n) n = Math.max(2, Math.round(distance));
  return n;
}

/**
 * 平滑移动计划（纯函数）。
 * 返回 { points:[{x,y,t,atMs}], steps, durationMs, stepMs, distance, curvePoints }
 * 不变量：points[0] === from，points.at(-1) === to，atMs 单调不减且末点 === durationMs。
 */
export function planMove(opts = {}) {
  const {
    from, to, durationMs = 320, stepMs = 15, easing = 'easeInOutSine',
    curvature = 0.18, seed = 1, jitter = 0, variant = 'arc',
    minSteps = 6, maxSteps = 120,
  } = opts;
  if (!from || !to) throw new Error('planMove: from/to 必填');
  const start = { x: Math.round(from.x), y: Math.round(from.y) };
  const end = { x: Math.round(to.x), y: Math.round(to.y) };
  const distance = Math.hypot(end.x - start.x, end.y - start.y);
  const n = stepCount(distance, durationMs, { stepMs, minSteps, maxSteps });
  const curvePoints = makeCurve(start, end, { curvature, seed, variant });
  const rng = mulberry32((seed * 2654435761) >>> 0);
  const points = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const p = bezierPoint(curvePoints, ease(easing, t));
    let x = Math.round(p.x);
    let y = Math.round(p.y);
    if (jitter > 0 && i > 0 && i < n) {
      x += Math.round((rng() - 0.5) * jitter);
      y += Math.round((rng() - 0.5) * jitter);
    }
    points.push({ x, y, t: Math.round(t * 1e4) / 1e4, atMs: Math.round(t * durationMs) });
  }
  points[0] = { x: start.x, y: start.y, t: 0, atMs: 0 };
  points[points.length - 1] = { x: end.x, y: end.y, t: 1, atMs: durationMs };
  return { from: start, to: end, points, steps: points.length - 1, durationMs, stepMs, distance, curvePoints, easing };
}

// ════════════════════════════════════════════════════════════════════════════
// PURE：按键 / 序列时序
// ════════════════════════════════════════════════════════════════════════════

/** 虚拟键码表（keybd_event / SendInput 用） */
export const VK = {
  backspace: 0x08, tab: 0x09, enter: 0x0d, return: 0x0d, shift: 0x10, ctrl: 0x11, control: 0x11,
  alt: 0x12, menu: 0x12, pause: 0x13, capslock: 0x14, esc: 0x1b, escape: 0x1b, space: 0x20,
  pageup: 0x21, prior: 0x21, pagedown: 0x22, next: 0x22, end: 0x23, home: 0x24,
  left: 0x25, up: 0x26, right: 0x27, down: 0x28, insert: 0x2d, delete: 0x2e, del: 0x2e,
  lwin: 0x5b, rwin: 0x5c, numpad0: 0x60, numpad1: 0x61, numpad2: 0x62, numpad3: 0x63,
  numpad4: 0x64, numpad5: 0x65, numpad6: 0x66, numpad7: 0x67, numpad8: 0x68, numpad9: 0x69,
  multiply: 0x6a, add: 0x6b, subtract: 0x6d, decimal: 0x6e, divide: 0x6f,
  f1: 0x70, f2: 0x71, f3: 0x72, f4: 0x73, f5: 0x74, f6: 0x75, f7: 0x76, f8: 0x77,
  f9: 0x78, f10: 0x79, f11: 0x7a, f12: 0x7b,
};
for (let c = 0; c <= 9; c++) VK[String(c)] = 0x30 + c;
for (let i = 0; i < 26; i++) VK[String.fromCharCode(97 + i)] = 0x41 + i;

export function vkOf(key) {
  if (typeof key === 'number') return key;
  const k = String(key).trim().toLowerCase().replace(/^key|^vk[:_]?/, '');
  if (VK[k] !== undefined) return VK[k];
  if (/^[a-z]$/.test(k)) return 0x41 + k.charCodeAt(0) - 97;
  if (/^[0-9]$/.test(k)) return 0x30 + Number(k);
  if (/^f([1-9]|1[0-2])$/.test(k)) return 0x70 + Number(k.slice(1)) - 1;
  // 单个可打印 ASCII 字符：直接用其大写码位（keybd_event 语义）
  if (k.length === 1) return k.toUpperCase().charCodeAt(0);
  throw new Error(`vkOf: 无法识别的按键 "${key}"`);
}

/** keyHold：按下 → 保持 holdMs → 释放（纯事件表） */
export function planKeyHold({ key, holdMs = 80, taperMs = 0 }) {
  const vk = vkOf(key);
  const events = [
    { atMs: 0, op: 'down', key: String(key), vk },
    { atMs: holdMs, op: 'up', key: String(key), vk },
  ];
  return { key: String(key), vk, holdMs, totalMs: holdMs + taperMs, events };
}

/**
 * chord：修饰键依次按下（错峰）→ 主键 → 保持 → 逆序释放。
 * 语义约定：holdMs = **主键（最后一个键）实际按住的毫秒数**（与 keyHold 一致；
 * 单键时 chord([k],{holdMs}) 与 keyHold(k,holdMs) 完全等价）。
 */
export function planChord({ keys, holdMs = 70, staggerMs = 12 } = {}) {
  if (!Array.isArray(keys) || keys.length === 0) throw new Error('planChord: keys 必填');
  const ordered = keys.map((k) => ({ key: String(k), vk: vkOf(k) }));
  const lastDownMs = (ordered.length - 1) * staggerMs;
  const events = ordered.map((k, i) => ({ atMs: i * staggerMs, op: 'down', ...k }));
  const firstUpMs = lastDownMs + holdMs;
  for (let i = ordered.length - 1; i >= 0; i--) {
    events.push({ atMs: firstUpMs + (ordered.length - 1 - i) * staggerMs, op: 'up', ...ordered[i] });
  }
  return {
    keys: ordered.map((k) => k.key), events, holdMs, staggerMs,
    lastDownMs, firstUpMs, totalMs: firstUpMs + (ordered.length - 1) * staggerMs,
  };
}

/** keyRepeat：同一键重复 count 次，每次按住 holdMs，间隔 intervalMs */
export function planKeyRepeat({ key, count = 3, intervalMs = 60, holdMs = 20 } = {}) {
  if (count < 1) throw new Error('planKeyRepeat: count 需 ≥1');
  const vk = vkOf(key);
  const events = [];
  for (let i = 0; i < count; i++) {
    const base = i * intervalMs;
    events.push({ atMs: base, op: 'down', key: String(key), vk, index: i });
    events.push({ atMs: base + holdMs, op: 'up', key: String(key), vk, index: i });
  }
  return { key: String(key), vk, events, count, intervalMs, holdMs, totalMs: (count - 1) * intervalMs + holdMs };
}

/** 单个 action 的预估耗时（给 schedule 的 after 语义用） */
export function estimateActionMs(action = {}) {
  const a = normalizeAction(action);
  switch (a.name) {
    case 'moveRel': case 'moveTo': return a.durationMs ?? 320;
    case 'wait': return a.ms ?? 0;
    case 'keyHold': return planKeyHold(a).totalMs;
    case 'chord': return planChord(a).totalMs;
    case 'keyRepeat': return planKeyRepeat(a).totalMs;
    case 'drag': return (a.durationMs ?? 400) ;
    case 'click': return (a.durationMs ?? 180) + 60;
    case 'doubleClick': return (a.durationMs ?? 180) + 90;
    case 'keypress': return 40 * (a.keys?.length ?? 1);
    default: return 0;
  }
}

const ACTION_ALIASES = {
  moverel: 'moveRel', move_rel: 'moveRel', rel: 'moveRel',
  moveto: 'moveTo', move_to: 'moveTo', move: 'moveTo',
  click: 'click', doubleclick: 'doubleClick', dblclick: 'doubleClick',
  keyhold: 'keyHold', hold: 'keyHold', key: 'keyHold',
  chord: 'chord', combo: 'chord',
  keyrepeat: 'keyRepeat', repeat: 'keyRepeat', press: 'keyRepeat',
  drag: 'drag', dragpath: 'drag',
  wait: 'wait', sleep: 'wait', delay: 'wait',
  keypress: 'keypress', tap: 'keypress',
};

/** 把宽松写法（名字大小写/中文别名/数组简写）规范成 {name,...params} */
export function normalizeAction(raw) {
  if (typeof raw === 'string') return { name: normalizeName(raw), keys: [raw] };
  if (Array.isArray(raw)) {
    const [name, ...rest] = raw;
    return normalizeRawAction({ name: normalizeName(name), args: rest });
  }
  const name = normalizeName(raw.name ?? raw.action ?? raw.type ?? raw.kind ?? '');
  return normalizeRawAction({ ...raw, name });
}
function normalizeName(name) {
  const key = String(name).replace(/[\s_-]/g, '').toLowerCase();
  return ACTION_ALIASES[key] ?? ACTION_ALIASES[String(name).toLowerCase()] ?? String(name);
}
function normalizeRawAction(a) {
  switch (a.name) {
    case 'moveRel': {
      const [dx, dy, durationMs, extra] = a.args ?? [];
      return { name: 'moveRel', dx: a.dx ?? dx ?? 0, dy: a.dy ?? dy ?? 0, durationMs: a.durationMs ?? durationMs, ...extra, ...pick(a) };
    }
    case 'moveTo': {
      const [x, y, durationMs, extra] = a.args ?? [];
      return { name: 'moveTo', x: a.x ?? x, y: a.y ?? y, durationMs: a.durationMs ?? durationMs, ...extra, ...pick(a) };
    }
    case 'keyHold': {
      const [key, holdMs, extra] = a.args ?? [];
      return { name: 'keyHold', key: a.key ?? key, holdMs: a.holdMs ?? holdMs, ...extra, ...pick(a) };
    }
    case 'keyRepeat': {
      const [key, count, intervalMs, extra] = a.args ?? [];
      return { name: 'keyRepeat', key: a.key ?? key, count: a.count ?? count, intervalMs: a.intervalMs ?? intervalMs, ...extra, ...pick(a) };
    }
    case 'keypress': {
      const keys = a.keys ?? a.args ?? [];
      return { name: 'keypress', keys: Array.isArray(keys) ? keys : [keys], ...pick(a) };
    }
    case 'drag': {
      const [from, to, extra] = a.args ?? [];
      return { name: 'drag', from: a.from ?? from, to: a.to ?? to, button: a.button ?? extra?.button ?? 'left', ...extra, ...pick(a) };
    }
    case 'click': case 'doubleClick': {
      const [x, y, extra] = a.args ?? [];
      return { name: a.name, x: a.x ?? x, y: a.y ?? y, button: a.button ?? extra?.button ?? 'left', ...pick(a) };
    }
    case 'wait': {
      const ms = a.ms ?? a.args?.[0] ?? 0;
      return { name: 'wait', ms };
    }
    default: return { name: a.name, ...pick(a) };
  }
}
function pick(a) {
  const { name, args, action, type, kind, ...rest } = a;
  return rest;
}

/** 动作执行后把「当前指针位置」推进到哪里（schedule 的链式锚点） */
export function advanceAnchor(anchor, a) {
  switch (a.name) {
    case 'moveRel': return { x: anchor.x + (a.dx ?? 0), y: anchor.y + (a.dy ?? 0) };
    case 'moveTo': return { x: a.x ?? anchor.x, y: a.y ?? anchor.y };
    case 'click': case 'doubleClick': return { x: a.x ?? anchor.x, y: a.y ?? anchor.y };
    case 'drag': {
      if (a.to) return { ...a.to };
      if (Array.isArray(a.path) && a.path.length) return { ...a.path[a.path.length - 1] };
      return anchor;
    }
    default: return anchor;
  }
}

/**
 * schedule：把一串动作展开成绝对时间戳时间线（纯函数）。
 * 条目按顺序链式衔接：未显式给 from 的动作，起点自动取上一个动作的落点
 * （所以写 ["moveRel 去 A", "点一下", "moveRel 再去 B"] 时，B 段是从点击点继续走的，
 *  而不是每段都从同一个锚点重新出发 —— 早期版本的 bug）。
 * 每个条目：{ at: 绝对毫秒 | after: 相对上一动作结束的毫秒 }
 * 返回 { timeline, segments, totalMs, count, endAnchor }
 */
export function planSchedule(actions = [], opts = {}) {
  const timeline = [];
  const segments = [];
  let cursor = 0;
  let anchor = { x: 0, y: 0, ...(opts.anchor ?? {}) };
  actions.forEach((raw, index) => {
    const a = normalizeAction(raw);
    if (!a.from) a.from = { ...anchor };
    const start = raw && typeof raw === 'object' && typeof raw.at === 'number'
      ? raw.at
      : cursor + (typeof raw?.after === 'number' ? raw.after : 0);
    const plan = expandAction(a, { startMs: start, index });
    timeline.push(...plan.steps);
    segments.push({ name: a.name, startMs: start, endMs: plan.endMs, index, from: { ...a.from } });
    anchor = advanceAnchor(anchor, a);
    cursor = plan.endMs;
  });
  timeline.sort((p, q) => p.atMs - q.atMs || (p.order ?? 0) - (q.order ?? 0));
  const totalMs = timeline.length ? timeline[timeline.length - 1].atMs : cursor;
  return { timeline, segments, totalMs, count: timeline.length, endAnchor: { ...anchor } };
}

/** 单个动作 → 时间线片段 */
export function expandAction(a, { startMs = 0, index = 0 } = {}) {
  const steps = [];
  let endMs = startMs;
  const tag = (s) => ({ ...s, actionIndex: index });
  switch (a.name) {
    case 'wait':
      endMs = startMs + (a.ms ?? 0);
      break;
    case 'moveRel': {
      const from = a.from ?? { x: 0, y: 0 };
      const to = { x: from.x + (a.dx ?? 0), y: from.y + (a.dy ?? 0) };
      const plan = planMove({ from, to, durationMs: a.durationMs ?? 320, ...a });
      plan.points.forEach((p, i) => { if (i > 0) steps.push(tag({ atMs: startMs + p.atMs, kind: 'move', x: p.x, y: p.y, order: i })); });
      endMs = startMs + plan.durationMs;
      break;
    }
    case 'moveTo': {
      const from = a.from ?? { x: 0, y: 0 };
      const plan = planMove({ from, to: { x: a.x ?? 0, y: a.y ?? 0 }, durationMs: a.durationMs ?? 320, ...a });
      plan.points.forEach((p, i) => { if (i > 0) steps.push(tag({ atMs: startMs + p.atMs, kind: 'move', x: p.x, y: p.y, order: i })); });
      endMs = startMs + plan.durationMs;
      break;
    }
    case 'click': case 'doubleClick': {
      const plan = planMove({ from: a.from ?? { x: a.x ?? 0, y: a.y ?? 0 }, to: { x: a.x ?? 0, y: a.y ?? 0 }, durationMs: a.durationMs ?? 180, ...a });
      plan.points.forEach((p, i) => { if (i > 0) steps.push(tag({ atMs: startMs + p.atMs, kind: 'move', x: p.x, y: p.y, order: i })); });
      steps.push(tag({ atMs: startMs + plan.durationMs, kind: a.name === 'click' ? 'click' : 'double_click', x: a.x, y: a.y, button: a.button ?? 'left', order: 900 }));
      endMs = startMs + plan.durationMs + (a.name === 'click' ? 60 : 90);
      break;
    }
    case 'keyHold': case 'chord': case 'keyRepeat': {
      // 整段按键时序作为*一次*原生调用发出（单进程内 Stopwatch 对齐），
      // 避免每个 down/up 各起一个 pwsh 进程：那样进程启动开销会吞掉毫秒精度。
      const p = a.name === 'keyHold' ? planKeyHold(a)
        : a.name === 'chord' ? planChord(a)
        : planKeyRepeat(a);
      const ops = p.events.map((e) => ({ at: e.atMs, op: e.op, vk: e.vk, key: e.key }));
      steps.push(tag({ atMs: startMs, kind: 'rawkey', ops, durationMs: p.totalMs, blocking: true, order: 0 }));
      endMs = startMs + p.totalMs;
      break;
    }
    case 'drag': {
      const from = a.from ?? { x: 0, y: 0 };
      const to = a.to ?? { x: 0, y: 0 };
      const plan = a.path ? { points: a.path, durationMs: a.durationMs ?? 400 } : planMove({ from, to, durationMs: a.durationMs ?? 400, stepMs: a.stepMs ?? 25, ...a });
      steps.push(tag({ atMs: startMs + 50, kind: 'drag', path: plan.points.map((p) => ({ x: p.x, y: p.y })), button: a.button ?? 'left', order: 900 }));
      endMs = startMs + 50 + plan.durationMs;
      break;
    }
    case 'keypress': {
      (a.keys ?? []).forEach((k, i) => steps.push(tag({ atMs: startMs + i * 40, kind: 'keypress', keys: [k], order: i })));
      endMs = startMs + 40 * (a.keys?.length ?? 0);
      break;
    }
    default:
      throw new Error(`expandAction: 未知动作 "${a.name}"`);
  }
  return { steps, endMs };
}

/** 时间线统计（自测与日志用） */
export function timelineStats(timeline = []) {
  const byKind = {};
  let maxGap = 0;
  for (let i = 0; i < timeline.length; i++) {
    byKind[timeline[i].kind] = (byKind[timeline[i].kind] ?? 0) + 1;
    if (i > 0) maxGap = Math.max(maxGap, timeline[i].atMs - timeline[i - 1].atMs);
  }
  return {
    count: timeline.length,
    byKind,
    totalMs: timeline.length ? timeline[timeline.length - 1].atMs : 0,
    maxGapMs: maxGap,
    monotonic: timeline.every((s, i) => i === 0 || s.atMs >= timeline[i - 1].atMs),
  };
}

// ════════════════════════════════════════════════════════════════════════════
// 时钟
// ════════════════════════════════════════════════════════════════════════════

export function createClock() {
  const t0 = Date.now();
  return { now: () => Date.now() - t0, sleep: (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms))), virtual: false };
}

/** 虚拟时钟：sleep 只推进时间，不真等待 —— 无桌面自测的核心 */
export function createVirtualClock() {
  let t = 0;
  const sleeps = [];
  return {
    now: () => t,
    sleep: (ms) => { const d = Math.max(0, ms); if (d > 0) { sleeps.push({ from: t, to: t + d }); t += d; } return Promise.resolve(); },
    sleeps,
    virtual: true,
  };
}

// ════════════════════════════════════════════════════════════════════════════
// Sender：真机（插件 MCP） / 干跑 / 假
// ════════════════════════════════════════════════════════════════════════════

export const DEFAULT_WCU_ROOT = process.env.WCU_ROOT ?? 'D:\\dsh-tools\\wcu\\package';
const D_TMP = 'D:\\dsh-tmp';

/** 通过 stdio JSON-RPC 调插件工具；工具名自动解析（windows_computer_use_xxx 或短名） */
export class McpSender {
  constructor(opts = {}) {
    this.root = opts.root ?? DEFAULT_WCU_ROOT;
    // 默认 full：lite 只暴露 10 个常用工具，没有 move/drag，输入引擎必需二者
    this.mode = opts.mode ?? process.env.WCU_MODE ?? 'full';
    this.server = opts.server ?? path.join(this.root, 'mcp', 'server.mjs');
    this.dryRun = !!opts.dryRun;
    this.child = null;
    this.buffer = '';
    this.waiters = new Map();
    this.nextId = 0;
    this.toolNames = null;
    this.stderrTail = [];
    this.log = [];
  }

  async start() {
    if (this.child) return this;
    this.child = spawn(process.execPath, [this.server], {
      cwd: this.root,
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', WCU_TOOL_MODE: this.mode, WCU_BROWSER_HEADLESS: '1', TEMP: D_TMP, TMP: D_TMP },
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    });
    this.child.stdout.setEncoding('utf8');
    this.child.stdout.on('data', (chunk) => {
      this.buffer += chunk;
      for (;;) {
        const nl = this.buffer.indexOf('\n');
        if (nl === -1) break;
        const line = this.buffer.slice(0, nl).trim();
        this.buffer = this.buffer.slice(nl + 1);
        if (!line.startsWith('{')) continue;
        let msg;
        try { msg = JSON.parse(line); } catch { continue; }
        const w = msg.id !== undefined ? this.waiters.get(msg.id) : null;
        if (w) { this.waiters.delete(msg.id); w.resolve(msg); }
      }
    });
    this.child.stderr.setEncoding('utf8');
    this.child.stderr.on('data', (c) => { this.stderrTail.push(c); if (this.stderrTail.length > 50) this.stderrTail.shift(); });
    this.child.on('exit', (code) => {
      for (const { reject } of this.waiters.values()) reject(new Error(`MCP server 退出 code=${code} ${this.stderrTail.join('').slice(-400)}`));
      this.waiters.clear();
      this.child = null;
    });
    await this.#rpc('initialize', { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'aim-input', version: '1.0' } });
    this.#notify('notifications/initialized', {});
    return this;
  }

  #rpc(method, params, timeoutMs = 30000) {
    const id = ++this.nextId;
    return new Promise((resolve, reject) => {
      this.waiters.set(id, { resolve, reject });
      this.child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', id, method, params })}\n`);
      setTimeout(() => { if (this.waiters.delete(id)) reject(new Error(`${method} 超时 (${timeoutMs}ms)`)); }, timeoutMs);
    });
  }
  #notify(method, params) { this.child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', method, params })}\n`); }

  async listTools() {
    await this.start();
    const res = await this.#rpc('tools/list', {});
    this.toolNames = (res.result?.tools ?? []).map((t) => t.name);
    return this.toolNames;
  }

  /** 短名 → 真实工具名 */
  async resolveTool(name) {
    const names = this.toolNames ?? (await this.listTools());
    if (names.includes(name)) return name;
    const hit = names.find((n) => n === `windows_computer_use_${name}` || n.endsWith(`_${name}`) || n.split('_').pop() === name);
    return hit ?? `windows_computer_use_${name}`;
  }

  /** 所有真实输入的唯一出口；dryRun 时只记录 */
  async call(tool, args = {}) {
    if (this.dryRun) { this.log.push({ tool, args, at: Date.now() }); return { ok: true, dryRun: true, text: 'dry-run' }; }
    await this.start();
    const real = await this.resolveTool(tool);
    const payload = { ...args };
    delete payload.__timeoutMs; // 不把内部键转发给后端（会被参数校验拒绝）
    const res = await this.#rpc('tools/call', { name: real, arguments: payload }, args.__timeoutMs ?? 30000);
    if (res.error) return { ok: false, error: res.error.message ?? JSON.stringify(res.error) };
    const text = (res.result?.content ?? []).filter((c) => c.type === 'text').map((c) => c.text).join('\n');
    this.log.push({ tool: real, args: payload, at: Date.now(), text: text.slice(0, 200) });
    return { ok: !res.result?.isError, text, isError: !!res.result?.isError };
  }

  async close() {
    if (!this.child) return;
    try { this.child.stdin.end(); } catch { /* ignore */ }
    const c = this.child;
    await new Promise((r) => setTimeout(r, 120));
    try { if (c.exitCode === null) c.kill(); } catch { /* ignore */ }
    this.child = null;
  }
}

/**
 * PowerShellRawKey —— keybd_event 精确按住/释放。
 * keypress(SendKeys) 只能「按一下」，无法控制按住时长；需要 keyHold/chord 的真实时序时用这里。
 * ops: [{at:ms, op:'down'|'up', vk:number}]，单个 pwsh 进程内用 Stopwatch 对齐绝对时刻，
 * 结束时输出 ELAPSED=<真实毫秒> 供引擎记录（返回值带实际耗时）。
 */
export class PowerShellRawKey {
  constructor(opts = {}) {
    this.pwsh = opts.pwsh ?? null;
    this.log = [];
  }
  async run(ops, { timeoutMs = 5000 } = {}) {
    const payload = Buffer.from(JSON.stringify(ops), 'utf8').toString('base64');
    const script = [
      `$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'`,
      `Add-Type -TypeDefinition @'`,
      `using System; using System.Runtime.InteropServices;`,
      `public class AimKey {`,
      `  [DllImport("user32.dll")] public static extern void keybd_event(byte v, byte s, uint f, UIntPtr e);`,
      `  public static void Down(int v){ keybd_event((byte)v,0,0,UIntPtr.Zero); }`,
      `  public static void Up(int v){ keybd_event((byte)v,0,2,UIntPtr.Zero); }`,
      `}`,
      `'@`,
      `$ops = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${payload}')) | ConvertFrom-Json`,
      `$sw = [System.Diagnostics.Stopwatch]::StartNew()`,
      `foreach ($o in $ops) {`,
      `  $target = [int]$o.at`,
      `  while ($sw.ElapsedMilliseconds -lt $target) { if ($target - $sw.ElapsedMilliseconds -gt 2) { Start-Sleep -Milliseconds 1 } }`,
      `  if ($o.op -eq 'down') { [AimKey]::Down([int]$o.vk) } elseif ($o.op -eq 'up') { [AimKey]::Up([int]$o.vk) }`,
      `}`,
      `Write-Output ("ELAPSED=" + $sw.ElapsedMilliseconds)`,
    ].join('\n');
    const enc = Buffer.from(script, 'utf16le').toString('base64');
    const exe = resolvePowerShell(this.pwsh);
    const child = spawn(exe, ['-NoProfile', '-NonInteractive', '-EncodedCommand', enc], {
      env: { ...process.env, TEMP: D_TMP, TMP: D_TMP },
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });
    let out = '', err = '';
    child.stdout.on('data', (c) => { out += c; });
    child.stderr.on('data', (c) => { err += c; });
    const result = await new Promise((resolve) => {
      let settled = false;
      const finish = (v) => { if (!settled) { settled = true; resolve(v); } };
      const timer = setTimeout(() => { try { child.kill(); } catch { /* ignore */ } finish({ code: -1, timeout: true }); }, timeoutMs);
      // spawn 失败（如解释器不在 PATH）必须以 error 事件收口，否则整段挂死在未捕获异常上
      child.on('error', (e) => { clearTimeout(timer); finish({ code: -2, spawnError: String(e?.message ?? e) }); });
      child.on('exit', (code) => { clearTimeout(timer); finish({ code }); });
    });
    const m = /ELAPSED=(\d+)/.exec(out);
    // stderr 单独留存（PowerShell 的 progress/CLIXML 噪声会在成功时也出现，不能当成失败）
    const rec = { exe, ops: ops.length, elapsedMs: m ? Number(m[1]) : null, code: result.code, timeout: !!result.timeout, stderr: err.trim().slice(0, 300) || null };
    this.log.push(rec);
    if (result.spawnError) return { ok: false, error: `无法启动 PowerShell (${exe}): ${result.spawnError}`, ...rec };
    if (result.timeout) return { ok: false, error: `rawKey 超时 (${timeoutMs}ms)`, ...rec };
    if (result.code !== 0) return { ok: false, error: rec.stderr ?? `powershell 退出 ${result.code}`, ...rec };
    return { ok: true, ...rec };
  }
  async close() { /* 每个动作独立进程，无需常驻 */ }
}

/** 干跑 sender：只记录，不发真实输入（无桌面验证 / 桌面互斥时的安全模式） */
export class DryRunSender {
  constructor(clock = null) { this.clock = clock; this.calls = []; }
  async call(tool, args = {}) { const at = this.clock ? this.clock.now() : Date.now(); this.calls.push({ tool, args, at }); return { ok: true, dryRun: true, text: 'dry-run' }; }
  async rawKey(ops) { const at = this.clock ? this.clock.now() : Date.now(); this.calls.push({ tool: 'rawKey', args: { ops }, at }); return { ok: true, dryRun: true, elapsedMs: ops.length ? ops[ops.length - 1].at : 0 }; }
  async close() {}
}

/** 假 sender：自测用，可编排「失败 N 次后成功」「一直失败」「挂住不返回」 */
export class FakeSender {
  constructor(clock, plan = {}) {
    this.clock = clock;
    this.calls = [];
    this.plan = plan;
    this.hangs = [];
  }
  #verdict(tool) {
    const rule = this.plan?.[tool] ?? this.plan?.['*'];
    if (!rule) return 'ok';
    if (typeof rule === 'function') return rule(this.calls.filter((c) => c.tool === tool).length + 1, this) ?? 'ok';
    const seen = this.calls.filter((c) => c.tool === tool).length + 1;
    if (typeof rule.failFirst === 'number' && seen <= rule.failFirst) return 'fail';
    if (rule.hang) return 'hang';
    if (typeof rule.remainingFailures === 'number' && rule.remainingFailures > 0) { rule.remainingFailures--; return 'fail'; }
    return 'ok';
  }
  async call(tool, args = {}) {
    const verdict = this.#verdict(tool);
    this.calls.push({ tool, args, at: this.clock.now(), verdict });
    if (verdict === 'fail') throw new Error(`fake sender: ${tool} 失败`);
    if (verdict === 'hang') { this.hangs.push(tool); return new Promise(() => {}); }
    return { ok: true, text: `fake:${tool}` };
  }
  async rawKey(ops) {
    const verdict = this.#verdict('rawKey');
    this.calls.push({ tool: 'rawKey', args: { ops }, at: this.clock.now(), verdict });
    if (verdict === 'fail') throw new Error('fake sender: rawKey 失败');
    if (verdict === 'hang') { this.hangs.push('rawKey'); return new Promise(() => {}); }
    return { ok: true, elapsedMs: ops.length ? ops[ops.length - 1].at : 0 };
  }
  async close() {}
}

/** 读取当前指针位置（只读，无输入）。默认走 System.Windows.Forms.Cursor.Position。 */
export async function readPointerPosition({ pwsh = null, timeoutMs = 6000 } = {}) {
  const script = `Add-Type -AssemblyName System.Windows.Forms; $p=[System.Windows.Forms.Cursor]::Position; Write-Output ("PT=" + $p.X + "," + $p.Y)`;
  const enc = Buffer.from(script, 'utf16le').toString('base64');
  const exe = resolvePowerShell(pwsh);
  const child = spawn(exe, ['-NoProfile', '-NonInteractive', '-EncodedCommand', enc], {
    env: { ...process.env, TEMP: D_TMP, TMP: D_TMP }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true,
  });
  let out = '';
  child.stdout.on('data', (c) => { out += c; });
  const done = await new Promise((resolve) => {
    let settled = false;
    const finish = (v) => { if (!settled) { settled = true; resolve(v); } };
    const timer = setTimeout(() => { try { child.kill(); } catch { /* ignore */ } finish(false); }, timeoutMs);
    child.on('error', () => { clearTimeout(timer); finish(false); });
    child.on('exit', () => { clearTimeout(timer); finish(true); });
  });
  const m = /PT=(-?\d+),(-?\d+)/.exec(out);
  if (!done || !m) throw new Error(`读指针位置失败（${exe}）`);
  return { x: Number(m[1]), y: Number(m[2]), exe };
}

// ════════════════════════════════════════════════════════════════════════════
// 执行器：重试 / 超时 / 计时
// ════════════════════════════════════════════════════════════════════════════

export const RETRY_DEFAULT = { attempts: 3, backoffMs: [0, 40, 120], timeoutMs: 15000 };

/** 带重试与超时的一次调用：返回 {ok, attempts, elapsedMs, error} */
export async function withRetry(fn, opts = {}) {
  const { attempts = RETRY_DEFAULT.attempts, backoffMs = RETRY_DEFAULT.backoffMs, timeoutMs = RETRY_DEFAULT.timeoutMs, clock = createClock(), label = 'call' } = opts;
  const t0 = clock.now();
  let lastError = null;
  for (let i = 0; i < attempts; i++) {
    if (i > 0) {
      // 退避走时钟：虚时钟下秒过，真机下真等（并计入 elapsedMs）
      await clock.sleep(backoffMs[Math.min(i, backoffMs.length - 1)] ?? 0);
    }
    // 超时用真实定时器，不借用时钟 —— 否则虚时钟会被 timeoutMs 提前推进，污染计时断言
    let timer = null;
    const timeoutPromise = new Promise((_, reject) => {
      // 不 unref：取消 ref 会让「发送端挂死」时进程先于超时退出，超时形同虚设
      timer = setTimeout(() => reject(new Error(`${label} 超时 (${timeoutMs}ms)`)), timeoutMs);
    });
    try {
      const value = await Promise.race([fn(i + 1), timeoutPromise]);
      return { ok: true, attempts: i + 1, elapsedMs: clock.now() - t0, value };
    } catch (error) {
      lastError = error;
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
  return { ok: false, attempts, elapsedMs: clock.now() - t0, error: String(lastError?.message ?? lastError) };
}

// ════════════════════════════════════════════════════════════════════════════
// InputEngine
// ════════════════════════════════════════════════════════════════════════════

export function createEngine(opts = {}) {
  return new InputEngine(opts);
}

export class InputEngine {
  /**
   * @param {object} opts
   *  sender      : 'mcp' | 'dry' | 自定义 sender 实例（含 call/rawKey）
   *  rawKey      : PowerShellRawKey 实例 | null（无则 keyHold 降级为「连击」并标记 degraded）
   *  clock       : 自定义时钟（自测用虚拟时钟）
   *  pointer     : {x,y} 初始已知坐标；或提供 pointerSource: async () => {x,y}
   *  retry       : {attempts,backoffMs,timeoutMs}
   *  stepMs/maxSteps/curvature/jitter/seed/easing : planMove 默认参数
   */
  constructor(opts = {}) {
    this.opts = opts;
    this.clock = opts.clock ?? createClock();
    this.sender = opts.sender === 'dry' ? new DryRunSender(this.clock)
      : opts.sender && typeof opts.sender === 'object' ? opts.sender
      : new McpSender({ dryRun: false, ...(opts.mcp ?? {}) });
    this.rawKey = opts.rawKey === null ? null : (opts.rawKey ?? new PowerShellRawKey(opts.rawKeyOptions ?? {}));
    if (opts.sender === 'mcp') this.sender.dryRun = !!opts.dryRun;
    this.retry = { ...RETRY_DEFAULT, ...(opts.retry ?? {}) };
    this.moveDefaults = {
      stepMs: opts.stepMs ?? 15, maxSteps: opts.maxSteps ?? 120, minSteps: opts.minSteps ?? 6,
      curvature: opts.curvature ?? 0.18, jitter: opts.jitter ?? 0, easing: opts.easing ?? 'easeInOutSine',
      seed: opts.seed ?? 1,
    };
    this.pointer = opts.pointer ?? null;
    this.pointerSource = opts.pointerSource ?? null;
    this.pointerKnown = !!opts.pointer;
    this.stats = { primitives: 0, steps: 0, retries: 0, failures: 0, virtualMs: 0 };
    this.calibration = [];   // 每次原语的真实步耗，供 T2 帧级标定
  }

  // ── 指针位置（相对移动的锚点） ──────────────────────────────────────
  async getPointer({ force = false } = {}) {
    if (this.pointerKnown && !force) return { ...this.pointer };
    const src = this.pointerSource ?? (this.sender instanceof McpSender || this.opts.sender === 'mcp' ? () => readPointerPosition() : null);
    if (!src) throw new Error('指针位置未知：请传 pointer:{x,y} / pointerSource，或使用真机 sender');
    const p = await src();
    this.pointer = { x: Math.round(p.x), y: Math.round(p.y) };
    this.pointerKnown = true;
    return { ...this.pointer };
  }
  setPointer(x, y) { this.pointer = { x: Math.round(x), y: Math.round(y) }; this.pointerKnown = true; }

  // ── 内部：时间线执行（统一走 clock，自测时零等待） ────────────────
  async _run(steps, { label = 'run', from = null, allowFailures = 0 } = {}) {
    const t0 = this.clock.now();
    let failed = 0;
    let attemptsTotal = 0;
    const errors = [];
    const stepTimes = [];
    for (const step of steps) {
      const target = t0 + step.atMs;
      const wait = target - this.clock.now();
      if (wait > 0) await this.clock.sleep(wait);
      const s0 = this.clock.now();
      const r = await this._dispatch(step);
      stepTimes.push(this.clock.now() - s0);
      attemptsTotal += r.attempts;
      if (r.attempts > 1) this.stats.retries += Math.max(0, r.attempts - 1);
      if (!r.ok) { failed++; this.stats.failures++; errors.push(`${step.kind}: ${r.error}`); }
      // 阻塞型步骤（原生按键时序：一次调用内部跑完整段按住）：真机耗时由进程自己占掉，
      // 虚时钟下必须显式补记，否则 schedule 的耗时断言会凭空少一段。
      if (step.blocking && this.clock.virtual) await this.clock.sleep(step.durationMs ?? 0);
    }
    const elapsedMs = this.clock.now() - t0;
    const plannedMs = steps.reduce((m, s) => Math.max(m, s.atMs + (s.durationMs ?? 0)), 0);
    this.stats.primitives++;
    this.stats.steps += steps.length;
    this.stats.virtualMs += elapsedMs;
    const avg = stepTimes.length ? stepTimes.reduce((a, b) => a + b, 0) / stepTimes.length : 0;
    this.calibration.push({ label, steps: steps.length, avgStepMs: Math.round(avg * 100) / 100, plannedMs, elapsedMs });
    return {
      ok: failed <= allowFailures, label, steps: steps.length, failed,
      attempts: attemptsTotal, elapsedMs, plannedMs,
      avgStepMs: Math.round(avg * 100) / 100,
      driftMs: Math.round((elapsedMs - plannedMs) * 100) / 100,
      error: errors.length ? errors.slice(0, 3).join(' | ') : null,
    };
  }

  async _dispatch(step) {
    const t = this.retry.timeoutMs;
    switch (step.kind) {
      case 'move':
        return this._call('move', { x: step.x, y: step.y }, { timeoutMs: Math.min(t, 8000) }, (r) => { this.setPointer(step.x, step.y); return r; });
      case 'click':
        return this._call('click', { x: step.x, y: step.y, button: step.button ?? 'left', dispatch: 'foreground' }, { timeoutMs: t }, (r) => { this.setPointer(step.x, step.y); return r; });
      case 'double_click':
        return this._call('double_click', { x: step.x, y: step.y, button: step.button ?? 'left', dispatch: 'foreground' }, { timeoutMs: t }, () => undefined);
      case 'drag':
        return this._call('drag', { path: step.path, button: step.button ?? 'left' }, { timeoutMs: t }, () => {
          const last = step.path[step.path.length - 1];
          this.setPointer(last.x, last.y);
          return undefined;
        });
      case 'keypress':
        return this._call('keypress', { keys: step.keys, dispatch: 'foreground' }, { timeoutMs: t }, () => undefined);
      case 'rawkey':
        return this._rawKey(step.ops);
      default:
        return { ok: false, attempts: 0, elapsedMs: 0, error: `未知 step.kind=${step.kind}` };
    }
  }

  async _call(tool, args, opts, onOk) {
    const r = await withRetry(async () => {
      const res = await this.sender.call(tool, args);
      if (!res || res.ok === false || res.isError) throw new Error(res?.error ?? res?.text ?? `${tool} 返回失败`);
      return res;
    }, { ...this.retry, ...opts, clock: this.clock, label: tool });
    if (r.ok && onOk) onOk(r.value);
    return { ok: r.ok, attempts: r.attempts, elapsedMs: r.elapsedMs, error: r.error ?? null };
  }

  /** 原生按键时序：整段 ops 一次交给 PowerShellRawKey（进程内 Stopwatch 对齐） */
  async _rawKey(ops) {
    const spanMs = ops.length ? Math.max(...ops.map((o) => o.at)) : 0;
    if (!this.rawKey) {
      // 无原生按住能力时降级：用 keypress 连击近似，明确标记 degraded，不假装有 hold
      const r = await this._call('keypress', { keys: ops.map((o) => o.key).filter(Boolean).slice(0, 1), dispatch: 'foreground' }, {}, () => undefined);
      return { ...r, degraded: true, spanMs };
    }
    const r = await withRetry(async () => {
      const res = await this.rawKey.run(ops, { timeoutMs: Math.max(this.retry.timeoutMs, spanMs + 3000) });
      if (!res.ok) throw new Error(res.error ?? 'rawKey 失败');
      return res;
    }, { ...this.retry, clock: this.clock, label: 'rawKey' });
    return { ok: r.ok, attempts: r.attempts, elapsedMs: r.elapsedMs, error: r.error ?? null, native: r.value?.elapsedMs ?? null, spanMs };
  }

  // ── 公开原语 ────────────────────────────────────────────────────────

  /** 平滑相对移动（人类轨迹：贝塞尔 + 缓动 + 多段小步） */
  async moveRel(dx, dy, durationMs = 320, opts = {}) {
    const from = opts.from ?? (await this.getPointer());
    const to = { x: Math.round(from.x + dx), y: Math.round(from.y + dy) };
    return this.moveTo(to.x, to.y, durationMs, { ...opts, from });
  }

  /** 平滑绝对移动 */
  async moveTo(x, y, durationMs = 320, opts = {}) {
    const from = opts.from ?? (await this.getPointer());
    const plan = planMove({ from, to: { x, y }, durationMs, ...this.moveDefaults, ...opts });
    const steps = plan.points.filter((_, i) => i > 0).map((p, i) => ({ atMs: p.atMs, kind: 'move', x: p.x, y: p.y, order: i }));
    const r = await this._run(steps, { label: 'moveTo', from, allowFailures: opts.allowFailures ?? 0 });
    this.setPointer(plan.to.x, plan.to.y);
    return { ...r, from: plan.from, to: plan.to, distance: plan.distance, trajectory: plan.points };
  }

  /** 按住一个键 ms 毫秒（一次原生调用内完成 down→保持→up；无 rawKey 时降级并标记 degraded） */
  async keyHold(key, holdMs = 80, opts = {}) {
    const p = planKeyHold({ key, holdMs });
    const ops = p.events.map((e) => ({ at: e.atMs, op: e.op, vk: e.vk, key: e.key }));
    const r = await this._run([{ atMs: 0, kind: 'rawkey', ops, durationMs: p.totalMs, blocking: true, order: 0 }], { label: 'keyHold', ...opts });
    return { ...r, key: p.key, vk: p.vk, requestedHoldMs: holdMs, ops };
  }

  /** 重复按键：count 次 down/up，一次原生调用 */
  async keyRepeat(key, count = 3, opts = {}) {
    const p = planKeyRepeat({ key, count, intervalMs: opts.intervalMs ?? 60, holdMs: opts.holdMs ?? 20 });
    const ops = p.events.map((e) => ({ at: e.atMs, op: e.op, vk: e.vk, key: e.key }));
    const r = await this._run([{ atMs: 0, kind: 'rawkey', ops, durationMs: p.totalMs, blocking: true, order: 0 }], { label: 'keyRepeat', ...opts });
    return { ...r, key: p.key, count, intervalMs: p.intervalMs, holdMs: p.holdMs, ops };
  }

  /** 组合键：修饰键错峰按下 → 保持 → 逆序释放；mode='tool' 则交给后端 SendKeys */
  async chord(keys, opts = {}) {
    const list = Array.isArray(keys) ? keys : String(keys).split('+').map((s) => s.trim()).filter(Boolean);
    if (opts.mode === 'tool') {
      const r = await this._call('keypress', { keys: [list.join('+')], dispatch: 'foreground' }, {}, () => undefined);
      return { ...r, keys: list, mode: 'tool', steps: 1, failed: r.ok ? 0 : 1 };
    }
    const p = planChord({ keys: list, holdMs: opts.holdMs ?? 70, staggerMs: opts.staggerMs ?? 12 });
    const ops = p.events.map((e) => ({ at: e.atMs, op: e.op, vk: e.vk, key: e.key }));
    const r = await this._run([{ atMs: 0, kind: 'rawkey', ops, durationMs: p.totalMs, blocking: true, order: 0 }], { label: 'chord', ...opts });
    return { ...r, keys: p.keys, holdMs: p.holdMs, staggerMs: p.staggerMs, mode: 'raw', ops };
  }

  /** 单击：先平滑移动过去，再真实点击（dispatch=foreground） */
  async click(x, y, opts = {}) {
    const durationMs = opts.durationMs ?? 180;
    const from = opts.from ?? (await this.getPointer());
    const plan = planMove({ from, to: { x, y }, durationMs, ...this.moveDefaults, ...opts });
    const steps = plan.points.filter((_, i) => i > 0).map((p, i) => ({ atMs: p.atMs, kind: 'move', x: p.x, y: p.y, order: i }));
    steps.push({ atMs: durationMs + (opts.settleMs ?? 30), kind: opts.double ? 'double_click' : 'click', x, y, button: opts.button ?? 'left', order: 10 ** 6 });
    const r = await this._run(steps, { label: opts.double ? 'doubleClick' : 'click', from });
    this.setPointer(x, y);
    return { ...r, to: { x, y }, trajectory: plan.points };
  }

  /** 拖拽：把插值后的稠密路径整条交给后端（后端 25ms/点步进），或 stepped 模式分段发 */
  async drag(from, to, opts = {}) {
    const durationMs = opts.durationMs ?? 400;
    const plan = planMove({ from, to, durationMs, ...this.moveDefaults, ...opts, stepMs: opts.stepMs ?? 25 });
    const path = plan.points.map((p) => ({ x: p.x, y: p.y }));
    let steps;
    if (opts.mode === 'stepped' && opts.chunk > 1) {
      steps = [];
      for (let i = opts.chunk; i < path.length; i += opts.chunk) {
        steps.push({ atMs: 50 + Math.round(((i - opts.chunk) / opts.chunk) * 120), kind: 'drag', path: path.slice(Math.max(0, i - opts.chunk - 1), i + 1), button: opts.button ?? 'left', order: i });
      }
    } else {
      steps = [{ atMs: 50, kind: 'drag', path, button: opts.button ?? 'left', order: 0 }];
    }
    const r = await this._run(steps, { label: 'drag' });
    this.setPointer(to.x, to.y);
    return { ...r, pathPoints: path.length, from, to };
  }

  /** 定时序列：按时间戳执行一串动作（移动→点→按键→再移动）；各段起点链式衔接 */
  async schedule(actions, opts = {}) {
    const plan = planSchedule(actions, { anchor: opts.anchorFrom ?? this.pointer ?? { x: 0, y: 0 } });
    const r = await this._run(plan.timeline, { label: 'schedule', allowFailures: opts.allowFailures ?? 0 });
    this.setPointer(plan.endAnchor.x, plan.endAnchor.y);
    return { ...r, segments: plan.segments, timelineMs: plan.totalMs, endAnchor: plan.endAnchor, stats: timelineStats(plan.timeline) };
  }

  /** 自适应标定：跑一次移动，返回真实单步耗时，供后续调 stepMs */
  async calibrate({ distance = 200, durationMs = 300 } = {}) {
    const from = await this.getPointer();
    const r = await this.moveTo(from.x + distance, from.y, durationMs, { from });
    return { ...r, suggestedStepMs: Math.max(8, Math.round(r.avgStepMs || 15)), realElapsedMs: r.elapsedMs };
  }

  async close() {
    try { await this.sender?.close?.(); } catch { /* ignore */ }
    try { await this.rawKey?.close?.(); } catch { /* ignore */ }
  }
}

// ════════════════════════════════════════════════════════════════════════════
// 只读 CLI（不产生任何真实键鼠动作）
// ════════════════════════════════════════════════════════════════════════════

async function cli() {
  const args = process.argv.slice(2);
  const s = new McpSender({});
  try {
    if (args.includes('--list-tools')) {
      const names = await s.listTools();
      console.log(`tools(${names.length}):`);
      for (const n of names) console.log(`  ${n}`);
    } else if (args.includes('--health')) {
      const r = await s.call('health', {});
      console.log(`health ok=${r.ok}\n${(r.text ?? '').slice(0, 600)}`);
    } else if (args.includes('--pointer')) {
      const p = await readPointerPosition();
      console.log(`pointer x=${p.x} y=${p.y}`);
    } else {
      console.log('用法: node input.mjs [--list-tools|--health|--pointer]  （全部只读）');
    }
  } finally {
    await s.close();
  }
}

if (process.argv[1] && process.argv[1].replace(/\\/g, '/').endsWith('/aim/input.mjs')) {
  cli().catch((e) => { console.error('CLI 失败:', e.message); process.exitCode = 1; });
}
