#!/usr/bin/env node
/**
 * D:\dsh-tools\aim\self-test.mjs —— 无桌面自测
 *
 * 原理：输入引擎的全部数学与时序都是纯函数；执行器的时钟与 sender 都可注入。
 *   本测试注入 (1) 虚拟时钟（sleep 只推进时间），(2) 假 sender（把动作记进数组），
 *   因此不产生任何真实鼠标/键盘动作，也不会抢桌面。
 *
 * 运行： & "<node.cmd>" D:\dsh-tools\aim\self-test.mjs
 * 退出码：0 = 全过；1 = 有断言失败
 */

import {
  planMove, planKeyHold, planKeyRepeat, planChord, planSchedule, timelineStats,
  ease, stepCount, bezierPoint, vkOf, mulberry32, clamp,
  createEngine, createVirtualClock, FakeSender, withRetry, normalizeAction, estimateActionMs,
} from './input.mjs';

const results = [];
let current = null;
function test(id, name, fn) { current = { id, name, checks: [] }; try { fn(); } catch (e) { current.checks.push({ ok: false, label: '抛出异常', detail: String(e?.message ?? e) }); } results.push(current); }
function ok(label, cond, detail = '') { current.checks.push({ ok: !!cond, label, detail }); }
const near = (a, b, tol = 0.001) => Math.abs(a - b) <= tol;
const nearMs = (a, b, tol = 2) => Math.abs(a - b) <= tol;

// 假 rawKey：记录 keybd_event 级别的 down/up（含毫秒偏移）与实际调用时刻，不碰真实键盘
function fakeRawKey(sink, clock = null) {
  return {
    log: sink,
    async run(ops) {
      sink.push({ kind: 'rawKey', at: clock ? clock.now() : null, ops: ops.map((o) => ({ ...o })) });
      return { ok: true, elapsedMs: ops.length ? ops[ops.length - 1].at : 0, ops: ops.length };
    },
    async close() {},
  };
}

// ════════════════════════════════════════════════════════════════════════════
console.log('=== aim/input.mjs 自测（无桌面：虚时钟 + 假 sender）===');
console.log(`node ${process.version} | cwd=${process.cwd()}\n`);

// T1 轨迹点数量 ────────────────────────────────────────────────────────────
test('T1', 'moveRel 轨迹点数量符合时间切片预期', () => {
  const durationMs = 300, stepMs = 15;
  const p = planMove({ from: { x: 100, y: 100 }, to: { x: 500, y: 100 }, durationMs, stepMs });
  const expectSteps = Math.round(durationMs / stepMs);
  ok(`steps=${p.steps} === round(${durationMs}/${stepMs})=${expectSteps}`, p.steps === expectSteps, `points=${p.points.length}`);
  ok('points.length === steps+1', p.points.length === p.steps + 1, `${p.points.length} vs ${p.steps + 1}`);
  ok('首点 === from', p.points[0].x === 100 && p.points[0].y === 100, JSON.stringify(p.points[0]));
  ok('末点 === to', p.points.at(-1).x === 500 && p.points.at(-1).y === 100, JSON.stringify(p.points.at(-1)));
  ok('步数下限保护（极短时长仍 ≥ minSteps）', stepCount(200, 30, { stepMs: 15, minSteps: 6 }) >= 6);
  ok('步数上限保护（超长时长 ≤ maxSteps）', stepCount(5000, 6000, { stepMs: 15, maxSteps: 120 }) <= 120);
});

// T2 时间分配 / 单调性 ─────────────────────────────────────────────────────
test('T2', '时间分配：atMs 单调、切片均匀、总时长精确', () => {
  const durationMs = 300, stepMs = 15;
  const p = planMove({ from: { x: 0, y: 0 }, to: { x: 400, y: 300 }, durationMs, stepMs });
  let mono = true, maxGap = 0;
  for (let i = 0; i < p.points.length; i++) {
    if (i) { maxGap = Math.max(maxGap, p.points[i].atMs - p.points[i - 1].atMs); if (p.points[i].atMs < p.points[i - 1].atMs) mono = false; }
  }
  ok('atMs 单调不减', mono);
  ok('末点 atMs === durationMs', p.points.at(-1).atMs === durationMs, String(p.points.at(-1).atMs));
  ok(`单步间隔 ≤ stepMs+1（实测 max=${maxGap}）`, maxGap <= stepMs + 1);
  const drift = Math.abs(p.points[5].atMs - 5 * stepMs);
  ok(`第 6 点时间 ≈ 5*stepMs（偏差 ${drift}ms）`, drift <= 1);
});

// T3 贝塞尔轨迹弯曲 ────────────────────────────────────────────────────────
test('T3', '贝塞尔：curvature>0 偏离直线，curvature=0 走直线', () => {
  const straight = planMove({ from: { x: 0, y: 0 }, to: { x: 400, y: 0 }, curvature: 0, durationMs: 200, stepMs: 20 });
  const curved = planMove({ from: { x: 0, y: 0 }, to: { x: 400, y: 0 }, curvature: 0.25, seed: 7, durationMs: 200, stepMs: 20 });
  ok('curvature=0 全点 y 保持 0', straight.points.every((p) => p.y === 0), JSON.stringify(straight.points.slice(0, 3)));
  const maxDev = Math.max(...curved.points.map((p) => Math.abs(p.y)));
  ok(`curvature=0.25 最大偏离 = ${maxDev}px（理论 ≈0.45*400*0.25=45，允许 30~70）`, maxDev > 30 && maxDev < 70, String(maxDev));
  ok('弯曲轨迹仍首末点精确', curved.points[0].x === 0 && curved.points.at(-1).x === 400);
  const b = bezierPoint([{ x: 0, y: 0 }, { x: 50, y: 100 }, { x: 100, y: 0 }], 0.5);
  ok('三阶 de Casteljau 中点 = (50,50)', near(b.x, 50) && near(b.y, 50), JSON.stringify(b));
});

// T4 缓动 ──────────────────────────────────────────────────────────────────
test('T4', '缓动：easeInOutSine 起步/收尾慢、中段快', () => {
  const p = planMove({ from: { x: 0, y: 0 }, to: { x: 400, y: 0 }, durationMs: 300, stepMs: 15, easing: 'easeInOutSine', curvature: 0 });
  const seg = [];
  for (let i = 1; i < p.points.length; i++) seg.push(Math.abs(p.points[i].x - p.points[i - 1].x));
  const first = seg[0], mid = seg[Math.floor(seg.length / 2)], last = seg.at(-1);
  ok(`首段增速 ${first} < 中段 ${mid}`, first < mid);
  ok(`末段增速 ${last} < 中段 ${mid}`, last < mid);
  ok('ease(0)=0, ease(1)=1', near(ease('easeInOutSine', 0), 0) && near(ease('easeInOutSine', 1), 1));
  const lin = planMove({ from: { x: 0, y: 0 }, to: { x: 400, y: 0 }, durationMs: 300, stepMs: 15, easing: 'linear', curvature: 0 });
  const lseg = []; for (let i = 1; i < lin.points.length; i++) lseg.push(Math.abs(lin.points[i].x - lin.points[i - 1].x));
  ok(`linear+curvature=0 各步位移相等（${Math.min(...lseg)}~${Math.max(...lseg)}px，理论 400/20=20）`, Math.max(...lseg) - Math.min(...lseg) <= 1, `min=${Math.min(...lseg)} max=${Math.max(...lseg)}`);
});

// T5 按键时序：keyHold ─────────────────────────────────────────────────────
test('T5', 'keyHold：按下→保持 holdMs→释放（毫秒级）', () => {
  const p = planKeyHold({ key: 'a', holdMs: 137 });
  ok('事件数 = 2', p.events.length === 2);
  ok('down@0 / up@137', p.events[0].op === 'down' && p.events[0].atMs === 0 && p.events[1].op === 'up' && p.events[1].atMs === 137, JSON.stringify(p.events));
  ok("vk('a') = 0x41", p.vk === 0x41, String(p.vk));
  ok(`维持时长 = ${p.events[1].atMs - p.events[0].atMs}ms（要求 137±0.5）`, nearMs(p.events[1].atMs - p.events[0].atMs, 137, 0.5));
  ok('totalMs = 137', p.totalMs === 137);
  ok("vk('F5')/vk('enter')/vk('左') 映射正确", vkOf('F5') === 0x74 && vkOf('enter') === 0x0d);
  let threw = false; try { vkOf('不存在的键xyz'); } catch { threw = true; }
  ok('未识别按键抛错（不静默发错键）', threw);
});

// T6 keyRepeat ─────────────────────────────────────────────────────────────
test('T6', 'keyRepeat：count×间隔×按住时长', () => {
  const p = planKeyRepeat({ key: 'left', count: 3, intervalMs: 60, holdMs: 20 });
  ok('事件数 = 6', p.events.length === 6, String(p.events.length));
  const downs = p.events.filter((e) => e.op === 'down').map((e) => e.atMs);
  const ups = p.events.filter((e) => e.op === 'up').map((e) => e.atMs);
  ok('down 时刻 = [0,60,120]', JSON.stringify(downs) === '[0,60,120]', JSON.stringify(downs));
  ok('up 时刻 = [20,80,140]', JSON.stringify(ups) === '[20,80,140]', JSON.stringify(ups));
  ok('totalMs = (count-1)*interval+hold = 140', p.totalMs === 140, String(p.totalMs));
  ok('同一 index 的 down 早于 up', p.events.every((e, i) => e.op !== 'up' || p.events.find((x) => x.op === 'down' && x.index === e.index).atMs < e.atMs));
});

// T7 chord ─────────────────────────────────────────────────────────────────
test('T7', 'chord：修饰键错峰按下→保持 holdMs→逆序释放', () => {
  const p = planChord({ keys: ['ctrl', 'shift', 'c'], holdMs: 90, staggerMs: 10 });
  const seq = p.events.map((e) => `${e.op}:${e.key}@${e.atMs}`);
  ok(`事件序列 = ${seq.join(' → ')}`, seq.join('|') === 'down:ctrl@0|down:shift@10|down:c@20|up:c@110|up:shift@120|up:ctrl@130', seq.join('|'));
  ok('totalMs = 130（lastDown 20 + hold 90 + 2×stagger 20）', p.totalMs === 130, String(p.totalMs));
  const mainHold = p.events.find((e) => e.key === 'c' && e.op === 'up').atMs - p.events.find((e) => e.key === 'c' && e.op === 'down').atMs;
  ok(`主键按住 = ${mainHold}ms === holdMs(90)`, mainHold === 90, String(mainHold));
  const single = planChord({ keys: ['a'], holdMs: 50, staggerMs: 10 });
  ok('单键 chord 与 keyHold 等价（down@0 / up@50）', single.events[0].atMs === 0 && single.events[1].atMs === 50 && single.totalMs === 50, JSON.stringify(single.events));
  const evs = p.events;
  let orderOk = true;
  for (const k of ['ctrl', 'shift', 'c']) {
    const d = evs.find((e) => e.op === 'down' && e.key === k).atMs;
    const u = evs.find((e) => e.op === 'up' && e.key === k).atMs;
    if (!(u > d)) orderOk = false;
  }
  ok('每个键 up 都晚于自己的 down', orderOk);
});

// T8 planSchedule 展开 ─────────────────────────────────────────────────────
test('T8', 'schedule：时间戳累加 + after 间隔 + 序列顺序', () => {
  const plan = planSchedule([
    { name: 'moveRel', dx: 200, dy: 0, durationMs: 200, from: { x: 0, y: 0 } },
    { name: 'keyHold', key: 'enter', holdMs: 80 },
    { after: 50, name: 'click', x: 300, y: 200, durationMs: 150 },
  ]);
  const seg = plan.segments.map((s) => `${s.name}[${s.startMs},${s.endMs}]`);
  ok(`分段 = ${seg.join(' ')}`, plan.segments[0].startMs === 0 && plan.segments[0].endMs === 200 && plan.segments[1].startMs === 200 && plan.segments[1].endMs === 280 && plan.segments[2].startMs === 330, seg.join(' '));
  ok(`链式锚点：click 段起点 = 上一段落点 ${JSON.stringify(plan.segments[2].from)}`, plan.segments[2].from.x === 200 && plan.segments[2].from.y === 0, JSON.stringify(plan.segments[2].from));
  ok(`endAnchor = (300,200)`, plan.endAnchor.x === 300 && plan.endAnchor.y === 200, JSON.stringify(plan.endAnchor));
  const st = timelineStats(plan.timeline);
  ok('时间线单调', st.monotonic);
  ok(`时间线元素 = ${st.count}（${JSON.stringify(st.byKind)}）`, st.byKind.move >= 18 && st.byKind.rawkey === 1 && st.byKind.click === 1, JSON.stringify(st.byKind));
  const raw = plan.timeline.find((s) => s.kind === 'rawkey');
  ok(`按键整段一次调用：rawkey 步含 ${raw.ops.length} 个 op（down@${raw.ops[0].at}/up@${raw.ops[1].at}）`, raw.ops.length === 2 && raw.ops[0].op === 'down' && raw.ops[1].at === 80, JSON.stringify(raw.ops));
  ok('click 落点坐标正确', plan.timeline.find((s) => s.kind === 'click').x === 300 && plan.timeline.find((s) => s.kind === 'click').y === 200);
  ok('动作别名归一化 dragpath→drag', normalizeAction(['dragpath', { x: 1, y: 1 }, { x: 2, y: 2 }]).name === 'drag', JSON.stringify(normalizeAction(['dragpath', { x: 1, y: 1 }, { x: 2, y: 2 }])));
  ok('estimateActionMs(chord 3键 hold90 stagger10) = 130', estimateActionMs({ name: 'chord', keys: ['ctrl', 'shift', 'c'], holdMs: 90, staggerMs: 10 }) === 130, String(estimateActionMs({ name: 'chord', keys: ['ctrl', 'shift', 'c'], holdMs: 90, staggerMs: 10 })));
});

// T9 虚时钟执行 moveRel（点数量 + 时间分配 + 指针更新） ─────────────────────
await (async () => {
  const clock = createVirtualClock();
  const sender = new FakeSender(clock, {});
  const engine = createEngine({ clock, sender, pointer: { x: 100, y: 100 }, rawKey: fakeRawKey([]), retry: { attempts: 3, backoffMs: [0, 40, 120], timeoutMs: 5000 } });
  const r = await engine.moveRel(400, 0, 300);
  test('T9', '虚时钟跑 moveRel：段数/落点/耗时/指针状态', () => {
    ok(`发出 move 次数 = ${sender.calls.length}（= steps ${r.steps}）`, sender.calls.length === r.steps && r.steps === 20, `${sender.calls.length} vs ${r.steps}`);
    ok('全部 move 且末次 x=500,y=100', sender.calls.every((c) => c.tool === 'move') && sender.calls.at(-1).args.x === 500 && sender.calls.at(-1).args.y === 100, JSON.stringify(sender.calls.at(-1)));
    ok(`轨迹沿途 x 单调递增（${sender.calls[0].args.x} → ${sender.calls.at(-1).args.x}）`, sender.calls.every((c, i) => i === 0 || c.args.x >= sender.calls[i - 1].args.x));
    ok(`返回带实际耗时 elapsedMs=${r.elapsedMs}（虚时钟应 ≈300）`, nearMs(r.elapsedMs, 300, 2), String(r.elapsedMs));
    ok(`plannedMs=${r.plannedMs} driftMs=${r.driftMs}`, r.plannedMs === 300 && Math.abs(r.driftMs) <= 2, `${r.plannedMs}/${r.driftMs}`);
    ok('ok=true 且无失败步', r.ok === true && r.failed === 0);
    ok('指针状态更新为 (500,100)', engine.pointer.x === 500 && engine.pointer.y === 100, JSON.stringify(engine.pointer));
    ok(`轨迹点 i 在 t=i*stepMs 到达：首步 at=${sender.calls[0].at}（=15），末步 at=${sender.calls.at(-1).at}（=300）`, sender.calls[0].at === 15 && nearMs(sender.calls.at(-1).at, 300, 2), `${sender.calls[0].at}/${sender.calls.at(-1).at}`);
    ok('时间分配均匀：第 i 次 move 的 at ≈ (i+1)*15ms', sender.calls.every((c, i) => Math.abs(c.at - (i + 1) * 15) <= 2), sender.calls.map((c) => c.at).join(','));
    ok(`calibration 记录真实步耗 avgStepMs=${r.avgStepMs}`, typeof r.avgStepMs === 'number' && engine.calibration.length === 1);
  });
  await engine.close();
})();

// T10 虚时钟执行 schedule（顺序 + 时间戳） ─────────────────────────────────
await (async () => {
  const clock = createVirtualClock();
  const raw = [];
  const sender = new FakeSender(clock, {});
  const engine = createEngine({ clock, sender, pointer: { x: 0, y: 0 }, rawKey: fakeRawKey(raw, clock), retry: { attempts: 3, backoffMs: [0], timeoutMs: 5000 } });
  const r = await engine.schedule([
    { name: 'moveRel', dx: 150, dy: 0, durationMs: 150 },
    { name: 'keyHold', key: 'enter', holdMs: 60 },
    { name: 'wait', ms: 40 },
    { name: 'moveRel', dx: -100, dy: 0, durationMs: 100 },
  ]);
  test('T10', '虚时钟跑 schedule：动作顺序与绝对时间戳', () => {
    const moves = sender.calls.filter((c) => c.tool === 'move');
    const raws = raw.filter((x) => x.kind === 'rawKey');
    ok(`调用序列 = move×${moves.length} + rawKey×${raws.length}（键鼠不交错越界）`, moves.length === 17 && raws.length === 1, `moves=${moves.length} raw=${raws.length}`);
    const ops = raws[0].ops.map((o) => `${o.op}@${o.at}`);
    ok(`按住 60ms 在一次原生调用内完成：ops = ${ops.join(' → ')}`, ops.join('|') === 'down@0|up@60', ops.join('|'));
    ok('原生按键整段下发（不是每个 down/up 各起一次）', raws.length === 1 && raws[0].ops.length === 2, `raws=${raws.length}`);
    ok(`rawKey 起点 t=${raws[0].at}（= keyHold 段起点 150，紧接在首段移动之后）`, raws[0].at === 150, String(raws[0].at));
    ok(`vtk(enter)=0x0D`, raws[0].ops[0].vk === 0x0d, String(raws[0].ops[0].vk));
    ok(`第二段 moveRel 链式衔接首段终点：${moves[9].args.x} → ${moves.at(-1).args.x}（150-100=50）`, moves[9].args.x === 150 && moves.at(-1).args.x === 50, `${moves[9].args.x} → ${moves.at(-1).args.x}`);
    ok(`schedule 结束锚点 = ${JSON.stringify(r.endAnchor)}`, r.endAnchor.x === 50 && r.endAnchor.y === 0, JSON.stringify(r.endAnchor));
    ok(`总时长 = 150+60+40+100 = 350（实测 ${r.elapsedMs}）`, r.elapsedMs === 350, String(r.elapsedMs));
    ok(`返回分段 ${r.segments.length} 条 + timelineMs=${r.timelineMs}`, r.segments.length === 4 && r.timelineMs >= 350, String(r.timelineMs));
    ok('ok=true', r.ok === true);
  });
  await engine.close();
})();

// T11 失败自愈：重试 ───────────────────────────────────────────────────────
await (async () => {
  const clock = createVirtualClock();
  const sender = new FakeSender(clock, { move: { failFirst: 2 } });
  const engine = createEngine({ clock, sender, pointer: { x: 0, y: 0 }, rawKey: fakeRawKey([]), retry: { attempts: 3, backoffMs: [0, 40, 120], timeoutMs: 5000 } });
  const r = await engine.moveRel(100, 0, 60);
  test('T11', '失败自愈：前 2 次 move 抛错后重试成功', () => {
    ok('最终 ok=true', r.ok === true, JSON.stringify({ ok: r.ok, error: r.error }));
    ok(`总尝试次数 attempts=${r.attempts}（> steps=${r.steps}）`, r.attempts > r.steps, `${r.attempts} vs ${r.steps}`);
    ok(`统计到重试次数 stats.retries=${engine.stats.retries}`, engine.stats.retries >= 2, String(engine.stats.retries));
    ok('虚时钟把退避时间计入 elapsedMs（>100）', r.elapsedMs > 100, String(r.elapsedMs));
  });
  await engine.close();
})();

// T12 失败自愈：一直失败要如实报错 ─────────────────────────────────────────
await (async () => {
  const clock = createVirtualClock();
  const sender = new FakeSender(clock, { '*': { failFirst: 999 } });
  const engine = createEngine({ clock, sender, pointer: { x: 0, y: 0 }, rawKey: fakeRawKey([]), retry: { attempts: 3, backoffMs: [0, 0, 0], timeoutMs: 5000 } });
  const r = await engine.moveRel(60, 0, 45);
  test('T12', '失败自愈：持续失败 → ok=false 且带错误与尝试数', () => {
    ok('ok=false', r.ok === false);
    ok(`failed=${r.failed} = steps=${r.steps}`, r.failed === r.steps, `${r.failed}/${r.steps}`);
    ok(`attempts=${r.attempts} = 3×steps`, r.attempts === r.steps * 3, `${r.attempts} vs ${r.steps * 3}`);
    ok('error 有内容', typeof r.error === 'string' && r.error.length > 0, r.error ?? '');
    ok('失败不计入 ok 但统计累计', engine.stats.failures > 0, String(engine.stats.failures));
  });
  await engine.close();
})();

// T13 超时 ─────────────────────────────────────────────────────────────────
await (async () => {
  const clock = createVirtualClock();
  const sender = new FakeSender(clock, { move: { hang: true } });
  const engine = createEngine({ clock, sender, pointer: { x: 0, y: 0 }, rawKey: fakeRawKey([]), retry: { attempts: 2, backoffMs: [0], timeoutMs: 40 } });
  const r = await engine.moveRel(60, 0, 30);
  test('T13', '超时：sender 挂住 → 按 timeoutMs 中止并报错', () => {
    ok('ok=false', r.ok === false);
    ok(`error 提到超时：${r.error?.slice(0, 60)}`, /超时/.test(r.error ?? ''), r.error ?? '');
    ok(`老板条挂住不阻塞后续（hang 记录 ${sender.hangs.length}）`, sender.hangs.length >= 1, String(sender.hangs.length));
  });
  await engine.close();
})();

// T14 drag 路径 ────────────────────────────────────────────────────────────
await (async () => {
  const clock = createVirtualClock();
  const sender = new FakeSender(clock, {});
  const engine = createEngine({ clock, sender, pointer: { x: 0, y: 0 }, rawKey: fakeRawKey([]), retry: { attempts: 2, backoffMs: [0], timeoutMs: 5000 } });
  const r = await engine.drag({ x: 10, y: 10 }, { x: 210, y: 110 }, { durationMs: 250 });
  test('T14', 'drag：稠密路径整条交给后端，首末点与库位一致', () => {
    const call = sender.calls.find((c) => c.tool === 'drag');
    ok('恰好 1 次 drag 调用', sender.calls.filter((c) => c.tool === 'drag').length === 1);
    ok(`path 点数 = ${r.pathPoints}（≥2 且 = 步数+1）`, r.pathPoints >= 2 && call.args.path.length === r.pathPoints, String(r.pathPoints));
    ok('path 首点 = from', call.args.path[0].x === 10 && call.args.path[0].y === 10, JSON.stringify(call.args.path[0]));
    ok('path 末点 = to', call.args.path.at(-1).x === 210 && call.args.path.at(-1).y === 110, JSON.stringify(call.args.path.at(-1)));
    ok('drag 起点时刻 = 50ms（后端先移动再按下）', call.at === 50, String(call.at));
    ok(`返回 elapsedMs=${r.elapsedMs} + ok=true`, typeof r.elapsedMs === 'number' && r.ok === true);
  });
  await engine.close();
})();

// T15 所有原语返回值都带实际耗时 ────────────────────────────────────────────
await (async () => {
  const clock = createVirtualClock();
  const sender = new FakeSender(clock, {});
  const engine = createEngine({ clock, sender, pointer: { x: 200, y: 200 }, rawKey: fakeRawKey([]), retry: { attempts: 2, backoffMs: [0], timeoutMs: 5000 } });
  const outs = [];
  outs.push(['moveRel', await engine.moveRel(50, 50, 60)]);
  outs.push(['moveTo', await engine.moveTo(300, 300, 60)]);
  outs.push(['keyHold', await engine.keyHold('a', 50)]);
  outs.push(['keyRepeat', await engine.keyRepeat('right', 2, { intervalMs: 30, holdMs: 10 })]);
  outs.push(['chord', await engine.chord(['ctrl', 'a'], { holdMs: 40, staggerMs: 5 })]);
  outs.push(['click', await engine.click(400, 400, { durationMs: 60 })]);
  outs.push(['drag', await engine.drag({ x: 0, y: 0 }, { x: 40, y: 40 }, { durationMs: 50 })]);
  outs.push(['schedule', await engine.schedule([{ name: 'wait', ms: 20 }])]);
  test('T15', '契约：每个原语都返回 {ok, attempts, elapsedMs, steps}', () => {
    for (const [name, r] of outs) {
      const shapeOk = typeof r.ok === 'boolean' && typeof r.elapsedMs === 'number' && typeof r.attempts === 'number' && typeof r.steps === 'number' && r.ok;
      ok(`${name} → ok=${r.ok} attempts=${r.attempts} steps=${r.steps} elapsedMs=${r.elapsedMs}`, shapeOk, JSON.stringify(r).slice(0, 120));
    }
    ok(`引擎统计 primitives=${engine.stats.primitives} steps=${engine.stats.steps} 覆盖 8 个原语`, engine.stats.primitives === 8, String(engine.stats.primitives));
  });
  await engine.close();
})();

// T16 纯函数可复现性 + 无副作用 ─────────────────────────────────────────────
test('T16', '纯函数：同 seed 复现一致；planMove 不改入参', () => {
  const from = { x: 3, y: 4 }, to = { x: 203, y: 104 };
  const snapshot = JSON.stringify({ from, to });
  const a = planMove({ from, to, durationMs: 200, stepMs: 20, seed: 42, jitter: 2 });
  const b = planMove({ from, to, durationMs: 200, stepMs: 20, seed: 42, jitter: 2 });
  ok('两次调用轨迹完全一致', JSON.stringify(a.points) === JSON.stringify(b.points));
  ok('入参对象未被修改', JSON.stringify({ from, to }) === snapshot, JSON.stringify({ from, to }));
  const c = planMove({ from, to, durationMs: 200, stepMs: 20, seed: 43, jitter: 2 });
  ok('不同 seed 抖动不同（抖动生效）', JSON.stringify(a.points) !== JSON.stringify(c.points));
  ok('mulberry32 确定性', mulberry32(5)() === mulberry32(5)());
  ok('clamp 边界', clamp(-1, 0, 10) === 0 && clamp(99, 0, 10) === 10);
});

// ════════════════════════════════════════════════════════════════════════════
let pass = 0, fail = 0;
for (const t of results) {
  const bad = t.checks.filter((c) => !c.ok);
  const status = bad.length === 0 ? 'PASS' : 'FAIL';
  if (bad.length === 0) pass++; else fail++;
  console.log(`[${status}] ${t.id} ${t.name}`);
  for (const c of t.checks) console.log(`        ${c.ok ? '✓' : '✗'} ${c.label}${c.detail ? `   ⟨${c.detail}⟩` : ''}`);
}
console.log(`\n=== 汇总：${pass} 组 PASS / ${fail} 组 FAIL，断言 ${results.reduce((a, t) => a + t.checks.length, 0)} 条 ===`);
console.log('说明：本次运行 sender 为假、时钟为虚拟，未发出任何真实鼠标/键盘事件。');
process.exitCode = fail === 0 ? 0 : 1;
