#!/usr/bin/env node
/**
 * vision.mjs — 屏幕视觉闭环：看见屏幕 → 找到靶心 → 算出点击坐标
 *
 * 三段能力：
 *   1) readPng / loadImage   : 自带 PNG 解码（node:zlib 解 IDAT，零第三方依赖）
 *                             支持 bitDepth 1/2/4/8/16，colorType 0/2/3/4/6，filter 0~4
 *                             退路：loadImage(path,{decoder:'ffmpeg'}) 走 ffmpeg 转裸 RGB
 *   2) detectTargets         : 颜色阈值 → 连通域 → 质心/半径/圆度，按面积（或圆度）排序
 *   3) 坐标换算（纯函数）    : 图像坐标 → 屏幕坐标 → 窗口坐标（含截图区域偏移 + DPI 缩放）
 *
 * 与 winctl 的契约一致：SCREEN = bounds.origin + imagePixel / imageScale
 *
 * CLI:
 *   node vision.mjs <png> [--color ff0000|r,g,b|auto] [--tol 60] [--min-area 8]
 *                         [--connectivity 8] [--sort area|circularity] [--top 5] [--json]
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync, statSync } from 'node:fs';
import { inflateSync } from 'node:zlib';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

/* ═══════════════════════════════════════════════════════════════════
 * 1. PNG 解码（零依赖）
 * ═══════════════════════════════════════════════════════════════════ */

const PNG_SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
const CT_CHANNELS = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 };
const CT_NAMES = { 0: 'gray', 2: 'rgb', 3: 'palette', 4: 'gray+alpha', 6: 'rgba' };

function paethValue(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  return pb <= pc ? b : c;
}

/** 逆 PNG 行过滤（filter 0..4）。raw 已去掉每行前的 filter-type 字节。 */
function unfilterRows(raw, height, stride, bpp) {
  const out = new Uint8Array(height * stride);
  let pos = 0;
  for (let y = 0; y < height; y++) {
    const ft = raw[pos++];
    const rowStart = y * stride;
    const prevStart = (y - 1) * stride;
    for (let i = 0; i < stride; i++) {
      const x = raw[pos + i];
      const a = i >= bpp ? out[rowStart + i - bpp] : 0;
      const b = y > 0 ? out[prevStart + i] : 0;
      const c = (y > 0 && i >= bpp) ? out[prevStart + i - bpp] : 0;
      let v;
      switch (ft) {
        case 0: v = x; break;
        case 1: v = x + a; break;
        case 2: v = x + b; break;
        case 3: v = x + ((a + b) >> 1); break;
        case 4: v = x + paethValue(a, b, c); break;
        default: throw new Error(`PNG: unsupported filter type ${ft} at row ${y}`);
      }
      out[rowStart + i] = v & 0xff;
    }
    pos += stride;
  }
  return out;
}

/** 结构化样本 → RGBA8。bitDepth 16 取高字节（视觉阈值检测足够）。 */
function toRgba8(raw, width, height, stride, bitDepth, colorType, palette, trns) {
  const out = new Uint8Array(width * height * 4);
  const channels = CT_CHANNELS[colorType];
  const subByte = bitDepth < 8;
  const maxVal = (1 << bitDepth) - 1;
  const bytesPerSample = bitDepth === 16 ? 2 : 1;
  for (let y = 0; y < height; y++) {
    const row = y * stride;
    for (let x = 0; x < width; x++) {
      let r = 0, g = 0, b = 0, a = 255;
      if (subByte) {
        const bit = x * bitDepth;
        const byteIdx = row + (bit >> 3);
        const shift = 8 - bitDepth - (bit & 7);
        const v = (raw[byteIdx] >> shift) & maxVal;
        if (colorType === 3) {
          const pi = v * 3;
          r = palette[pi]; g = palette[pi + 1]; b = palette[pi + 2];
          if (trns && v < trns.length) a = trns[v];
        } else {
          const s = Math.round((v * 255) / maxVal);
          r = g = b = s;
        }
      } else {
        const idx = row + x * channels * bytesPerSample;
        const rd = (o) => (bitDepth === 16 ? raw[idx + o * 2] : raw[idx + o]);
        switch (colorType) {
          case 0: r = g = b = rd(0); break;
          case 2: r = rd(0); g = rd(1); b = rd(2); break;
          case 3: {
            const pi = rd(0) * 3;
            r = palette[pi]; g = palette[pi + 1]; b = palette[pi + 2];
            if (trns && rd(0) < trns.length) a = trns[rd(0)];
            break;
          }
          case 4: r = g = b = rd(0); a = rd(1); break;
          case 6: r = rd(0); g = rd(1); b = rd(2); a = rd(3); break;
        }
      }
      const o = (y * width + x) * 4;
      out[o] = r; out[o + 1] = g; out[o + 2] = b; out[o + 3] = a;
    }
  }
  return out;
}

/**
 * 解码 PNG Buffer → { width, height, data: Uint8Array(RGBA), meta }
 * @param {Buffer|Uint8Array} input
 */
export function decodePng(input) {
  const buf = Buffer.isBuffer(input) ? input : Buffer.from(input);
  if (buf.length < 8 || !buf.subarray(0, 8).equals(PNG_SIG)) throw new Error('PNG: bad signature');
  let off = 8, width = 0, height = 0, bitDepth = 0, colorType = 0, interlace = 0;
  let palette = null, trns = null;
  const idat = [];
  while (off + 8 <= buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.toString('latin1', off + 4, off + 8);
    const dataStart = off + 8;
    const data = buf.subarray(dataStart, dataStart + len);
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
      if (data[10] !== 0) throw new Error('PNG: unsupported compression method');
      if (data[11] !== 0) throw new Error('PNG: unsupported filter method');
      interlace = data[12];
    } else if (type === 'PLTE') palette = Buffer.from(data);
    else if (type === 'tRNS') trns = Buffer.from(data);
    else if (type === 'IDAT') idat.push(Buffer.from(data));
    else if (type === 'IEND') break;
    off = dataStart + len + 4;
  }
  if (!width || !height) throw new Error('PNG: missing IHDR');
  if (!(colorType in CT_CHANNELS)) throw new Error(`PNG: unsupported colorType ${colorType}`);
  if (colorType === 3 && !palette) throw new Error('PNG: indexed image without PLTE');
  if (interlace !== 0) throw new Error('PNG: Adam7 interlaced image not supported (use decoder:"ffmpeg")');
  const bppBits = CT_CHANNELS[colorType] * bitDepth;
  const stride = Math.ceil((width * bppBits) / 8);
  const bpp = Math.max(1, Math.ceil(bppBits / 8));
  const raw = inflateSync(Buffer.concat(idat));
  const expect = height * (stride + 1);
  if (raw.length < expect) throw new Error(`PNG: inflated size ${raw.length} < expected ${expect}`);
  const pixels = unfilterRows(raw, height, stride, bpp);
  const data = toRgba8(pixels, width, height, stride, bitDepth, colorType, palette, trns);
  return {
    width, height, data,
    meta: { bitDepth, colorType, colorTypeName: CT_NAMES[colorType], filterUnit: bpp, stride, bytes: buf.length },
  };
}

/** ffmpeg 退路：PNG → 裸 RGBA 再读（PNG 解码走不通时使用）。 */
export function decodePngViaFfmpeg(file, opts = {}) {
  const ffmpeg = opts.ffmpeg || 'D:\\dsh-video\\tools\\ffmpeg\\ffmpeg.exe';
  const tmpDir = opts.tmpDir || 'D:\\dsh-tmp';
  if (!existsSync(ffmpeg)) throw new Error(`ffmpeg fallback unavailable: ${ffmpeg}`);
  mkdirSync(tmpDir, { recursive: true });
  const probe = spawnSync(ffmpeg, ['-hide_banner', '-i', file], { encoding: 'utf8', windowsHide: true });
  const text = `${probe.stderr || ''}${probe.stdout || ''}`;
  const m = /Video:.*?(\d{2,5})x(\d{2,5})/.exec(text);
  if (!m) throw new Error('ffmpeg: cannot parse image size');
  const width = Number(m[1]), height = Number(m[2]);
  const rawPath = path.join(tmpDir, `ffmpeg-${path.basename(file)}.rgba`);
  const r = spawnSync(ffmpeg, ['-y', '-loglevel', 'error', '-i', file, '-f', 'rawvideo', '-pix_fmt', 'rgba', rawPath], { encoding: 'utf8', windowsHide: true });
  if (r.status !== 0) throw new Error(`ffmpeg raw dump failed: ${(r.stderr || '').trim()}`);
  const data = new Uint8Array(readFileSync(rawPath));
  if (data.length < width * height * 4) throw new Error('ffmpeg: short raw dump');
  return { width, height, data, meta: { decoder: 'ffmpeg', ffmpeg, rawPath } };
}

/** 统一读图入口。decoder: 'auto'（默认）| 'zlib' | 'ffmpeg' */
export function loadImage(file, opts = {}) {
  const decoder = opts.decoder || 'auto';
  if (decoder === 'ffmpeg') return decodePngViaFfmpeg(file, opts);
  try {
    const img = decodePng(readFileSync(file));
    img.meta.decoder = 'zlib';
    img.meta.file = file;
    return img;
  } catch (err) {
    if (decoder === 'zlib') throw err;
    const img = decodePngViaFfmpeg(file, opts);
    img.meta.fallbackReason = err.message;
    return img;
  }
}

/* ═══════════════════════════════════════════════════════════════════
 * 2. 靶心检测：颜色阈值 + 连通域
 * ═══════════════════════════════════════════════════════════════════ */

export function parseColor(spec) {
  if (Array.isArray(spec)) return spec.slice(0, 3).map(Number);
  const s = String(spec).trim().replace(/^#/, '');
  if (/^[0-9a-fA-F]{6}$/.test(s)) return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
  if (/^[0-9a-fA-F]{3}$/.test(s)) return s.split('').map((c) => parseInt(c + c, 16));
  const parts = s.split(',').map(Number);
  if (parts.length === 3 && parts.every((n) => Number.isFinite(n))) return parts;
  throw new Error(`bad color spec: ${spec}`);
}

/** 在 RGBA 图上按容差建二值掩码（欧氏 RGB 距离）。 */
export function buildMask(img, { color, tolerance = 60, alphaMin = 16 } = {}) {
  const c = parseColor(color);
  const { width, height, data } = img;
  const mask = new Uint8Array(width * height);
  const t2 = tolerance * tolerance;
  for (let p = 0, i = 0; p < width * height; p++, i += 4) {
    if (data[i + 3] < alphaMin) continue;
    const dr = data[i] - c[0], dg = data[i + 1] - c[1], db = data[i + 2] - c[2];
    if (dr * dr + dg * dg + db * db <= t2) mask[p] = 1;
  }
  return mask;
}

/** 掩码直方图猜主色（饱和像素的 4bit/通道众数）。 */
export function guessColor(img, { alphaMin = 16, minSat = 40 } = {}) {
  const { width, height, data } = img;
  const hist = new Map();
  for (let p = 0, i = 0; p < width * height; p++, i += 4) {
    if (data[i + 3] < alphaMin) continue;
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    if (max - min < minSat) continue; // 灰色/低饱和不算靶心色
    const key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
    const e = hist.get(key) || { n: 0, r: 0, g: 0, b: 0 };
    e.n++; e.r += r; e.g += g; e.b += b;
    hist.set(key, e);
  }
  let best = null;
  for (const e of hist.values()) if (!best || e.n > best.n) best = e;
  if (!best) return null;
  return { color: [Math.round(best.r / best.n), Math.round(best.g / best.n), Math.round(best.b / best.n)], pixels: best.n };
}

/** 连通域（迭代栈，无递归），返回原始统计。 */
export function connectedComponents(mask, width, height, { connectivity = 8, minArea = 8, maxArea = Infinity } = {}) {
  const seen = new Uint8Array(width * height);
  const stack = new Int32Array(width * height);
  const neighbors = connectivity === 4
    ? [[1, 0], [-1, 0], [0, 1], [0, -1]]
    : [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  const comps = [];
  for (let p0 = 0; p0 < width * height; p0++) {
    if (!mask[p0] || seen[p0]) continue;
    let sp = 0;
    stack[sp++] = p0;
    seen[p0] = 1;
    let area = 0, sumX = 0, sumY = 0;
    let minX = width, minY = height, maxX = -1, maxY = -1;
    while (sp > 0) {
      const p = stack[--sp];
      const y = (p / width) | 0, x = p - y * width;
      area++; sumX += x; sumY += y;
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      for (const [dx, dy] of neighbors) {
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
        const q = ny * width + nx;
        if (mask[q] && !seen[q]) { seen[q] = 1; stack[sp++] = q; }
      }
    }
    if (area < minArea || area > maxArea) continue;
    const bw = maxX - minX + 1, bh = maxY - minY + 1;
    comps.push({
      area,
      centroid: { x: sumX / area, y: sumY / area },
      bboxCenter: { x: minX + (bw - 1) / 2, y: minY + (bh - 1) / 2 },
      bbox: { x: minX, y: minY, width: bw, height: bh },
      radiusArea: Math.sqrt(area / Math.PI),
      radiusBbox: (bw + bh) / 4,
      fillRatio: area / (bw * bh),
    });
  }
  return comps;
}

/**
 * 靶心检测主入口。
 * @returns {Array} 候选，默认按面积降序：[{id, center:{x,y}, centroid, radius, radiusArea, radiusBbox,
 *                    bbox, area, fillRatio, circularity, score, color}]
 */
export function detectTargets(img, opts = {}) {
  const {
    color = 'auto', tolerance = 60, minArea = 8, maxArea = Infinity,
    connectivity = 8, sort = 'area', top = 0, alphaMin = 16, radiusFrom = 'mean',
  } = opts;
  const resolved = String(color) === 'auto' ? (guessColor(img, { alphaMin })?.color ?? [255, 0, 0]) : parseColor(color);
  const mask = buildMask(img, { color: resolved, tolerance, alphaMin });
  const comps = connectedComponents(mask, img.width, img.height, { connectivity, minArea, maxArea });
  const out = comps.map((c, i) => {
    const r = radiusFrom === 'area' ? c.radiusArea
      : radiusFrom === 'bbox' ? c.radiusBbox
        : (c.radiusArea + c.radiusBbox) / 2;
    const rMax = Math.max(c.bbox.width, c.bbox.height) / 2;
    const circularity = rMax > 0 ? c.area / (Math.PI * rMax * rMax) : 0;
    return {
      id: i,
      center: { x: c.centroid.x, y: c.centroid.y },
      centerBbox: c.bboxCenter,
      centroid: c.centroid,
      radius: r,
      radiusArea: c.radiusArea,
      radiusBbox: c.radiusBbox,
      bbox: c.bbox,
      area: c.area,
      fillRatio: c.fillRatio,
      circularity,
      score: Math.min(circularity, 1),
      color: resolved,
    };
  });
  out.sort(sort === 'circularity' ? (a, b) => (b.score - a.score) || (b.area - a.area) : (a, b) => b.area - a.area);
  out.forEach((t, i) => { t.id = i; t.rank = i + 1; });
  return top > 0 ? out.slice(0, top) : out;
}

/* ═══════════════════════════════════════════════════════════════════
 * 3. 坐标换算（纯函数）
 *    契约：SCREEN = bounds.origin + imagePixel / imageScale
 * ═══════════════════════════════════════════════════════════════════ */

export function dpiScaleFromDpi(dpi) {
  return dpi / 96;
}

/** 逻辑(DIP) → 物理像素 */
export function toPhysical(pt, dpi) {
  const s = dpiScaleFromDpi(dpi);
  return { x: pt.x * s, y: pt.y * s };
}

/** 物理像素 → 逻辑(DIP) */
export function toLogical(pt, dpi) {
  const s = dpiScaleFromDpi(dpi);
  return { x: pt.x / s, y: pt.y / s };
}

/**
 * 归一化截图描述。
 * capture = { bounds:{x,y,width,height}, imageScale?, imageWidth?, imageHeight?, dpi? }
 * imageScale 缺省时按 bounds.width / imageWidth 推导。
 */
export function resolveCapture(capture = {}) {
  const bounds = capture.bounds || { x: 0, y: 0, width: capture.imageWidth, height: capture.imageHeight };
  const imageWidth = capture.imageWidth || capture.image?.width
    || (capture.imageScale ? bounds.width * capture.imageScale : bounds.width);
  const imageHeight = capture.imageHeight || capture.image?.height
    || (capture.imageScale ? bounds.height * capture.imageScale : bounds.height);
  // imageScale = 图像像素 / 屏幕物理像素（截图被降采样时 <1），契约 screen = origin + image / imageScale
  const imageScale = capture.imageScale != null
    ? capture.imageScale
    : (bounds.width ? imageWidth / bounds.width : 1);
  const scaleY = capture.imageScale != null
    ? capture.imageScale
    : (bounds.height ? imageHeight / bounds.height : imageScale);
  return { bounds, imageWidth, imageHeight, imageScale, scaleX: imageScale, scaleY, dpi: capture.dpi ?? null };
}

/** 图像坐标 → 屏幕物理坐标 */
export function imageToScreen(pt, capture) {
  const c = resolveCapture(capture);
  return { x: c.bounds.x + pt.x / c.scaleX, y: c.bounds.y + pt.y / c.scaleY };
}

/** 屏幕物理坐标 → 图像坐标 */
export function screenToImage(pt, capture) {
  const c = resolveCapture(capture);
  return { x: (pt.x - c.bounds.x) * c.scaleX, y: (pt.y - c.bounds.y) * c.scaleY };
}

/** 屏幕物理坐标 → 窗口坐标。insets 为窗口边框/标题栏厚度（物理像素）。 */
export function screenToWindow(pt, windowRect = { x: 0, y: 0 }, opts = {}) {
  const insets = { left: 0, top: 0, ...(opts.insets || {}) };
  const clientOrigin = {
    x: (windowRect.x || 0) + insets.left,
    y: (windowRect.y || 0) + insets.top,
  };
  const physical = { x: pt.x - clientOrigin.x, y: pt.y - clientOrigin.y };
  const res = { x: physical.x, y: physical.y, physical, clientOrigin, insets };
  if (opts.dpi != null) res.logical = toLogical(physical, opts.dpi);
  return res;
}

/** 窗口坐标（默认物理像素，给 logical:true 时按 logical 反算）→ 屏幕物理坐标 */
export function windowToScreen(pt, windowRect = { x: 0, y: 0 }, opts = {}) {
  const insets = { left: 0, top: 0, ...(opts.insets || {}) };
  const phys = opts.logical && opts.dpi != null ? toPhysical(pt, opts.dpi) : { x: pt.x, y: pt.y };
  return { x: phys.x + (windowRect.x || 0) + insets.left, y: phys.y + (windowRect.y || 0) + insets.top };
}

/**
 * 一条龙：图像坐标 → 屏幕坐标 → 窗口坐标（含 DPI）。
 * @returns {{image, screen, window:{x,y}, windowLogical?, clientOrigin, radius, radiusLogical?,
 *            click:{screenX,screenY,windowX,windowY,logicalX?,logicalY?}, capture, windowRect}}
 */
export function imageToWindow(pt, capture, windowRect = { x: 0, y: 0 }, opts = {}) {
  const c = resolveCapture(capture);
  const screen = imageToScreen(pt, c);
  const w = screenToWindow(screen, windowRect, opts);
  const click = {
    screenX: Math.round(screen.x),
    screenY: Math.round(screen.y),
    windowX: Math.round(w.x),
    windowY: Math.round(w.y),
  };
  if (w.logical) { click.logicalX = Math.round(w.logical.x); click.logicalY = Math.round(w.logical.y); }
  return { image: { x: pt.x, y: pt.y }, screen, window: { x: w.x, y: w.y }, windowLogical: w.logical, clientOrigin: w.clientOrigin, capture: c, windowRect, click };
}

/** 检测结果 → 点击坐标（默认取第 1 名候选中心，半径可按比例缩放成"边缘点"等） */
export function targetToClick(target, capture, windowRect, opts = {}) {
  const pt = opts.point === 'bboxCenter' ? target.centerBbox : target.center;
  const offset = opts.offset || { x: 0, y: 0 };
  const radius = target.radius * (opts.radiusScale ?? 0);
  return imageToWindow({ x: pt.x + offset.x + radius, y: pt.y + offset.y }, capture, windowRect, opts);
}

/* ═══════════════════════════════════════════════════════════════════
 * CLI
 * ═══════════════════════════════════════════════════════════════════ */

function parseArgs(argv) {
  const a = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const s = argv[i];
    if (s.startsWith('--')) {
      const k = s.slice(2);
      const v = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
      a[k] = v;
    } else a._.push(s);
  }
  return a;
}

function main() {
  const a = parseArgs(process.argv.slice(2));
  const file = a._[0];
  if (!file) {
    console.log('usage: node vision.mjs <png> [--color ff0000|r,g,b|auto] [--tol 60] [--min-area 8] [--sort area|circularity] [--top 5] [--radius-from mean|area|bbox] [--decoder auto|zlib|ffmpeg] [--json]');
    process.exit(2);
  }
  const t0 = Date.now();
  const img = loadImage(file, { decoder: a.decoder || 'auto' });
  const tDecode = Date.now() - t0;
  const t1 = Date.now();
  const targets = detectTargets(img, {
    color: a.color || 'auto',
    tolerance: a.tol != null ? Number(a.tol) : 60,
    minArea: a['min-area'] != null ? Number(a['min-area']) : 8,
    connectivity: a.connectivity != null ? Number(a.connectivity) : 8,
    sort: a.sort || 'area',
    top: a.top != null ? Number(a.top) : 0,
    radiusFrom: a['radius-from'] || 'mean',
  });
  const tDetect = Date.now() - t1;
  if (a.json) {
    console.log(JSON.stringify({ file, image: { width: img.width, height: img.height }, decoder: img.meta.decoder, decodeMs: tDecode, detectMs: tDetect, targets }, null, 2));
    return;
  }
  console.log(`${file}  ${img.width}x${img.height}  decoder=${img.meta.decoder}  decode=${tDecode}ms detect=${tDetect}ms`);
  if (!targets.length) console.log('  (no candidate)');
  for (const t of targets) {
    console.log(`  #${t.rank} color=rgb(${t.color.join(',')}) center=(${t.center.x.toFixed(2)},${t.center.y.toFixed(2)}) r=${t.radius.toFixed(2)} area=${t.area} fill=${t.fillRatio.toFixed(3)} circ=${t.circularity.toFixed(3)} bbox=${t.bbox.width}x${t.bbox.height}@(${t.bbox.x},${t.bbox.y})`);
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) main();
