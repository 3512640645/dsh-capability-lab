# L3 · 定时序列偏差 + 连续 3 分钟不掉速（BENCH-L3）

> 判据来源：`D:\dsh-tools\CONTROL-BENCH.md`（L3 行 1「复合动作序列 … 总偏差 <100ms」、L3 行 4「连续 3 分钟不掉速，前 30s 与最后 30s 得分差 ≤20%」）。
> 数据来源：靶场自己落盘的原始文件（打点 JSONL + `runs\run-*.json`），不经估算。
> 机读汇总：`D:\dsh-arena\bench\keylat\keylat.json`（按键投递）、`bench-l3.json`（定时序列/长时稳定性）。
> 生成时间：2026-11-06T19:59:19.738Z（DESKTOP-Q0AH8E7，1440×900 单屏，DPI 100%）；**§1 口径表与 §5.1、§7、§8、§9、§10 于 2026-11-07 04:50(+08:00) 增补按键投递独立判据。**

---

## 0′. 第二轮复跑：四项未定论的定论（2026-11-07 05:27–06:12 +08:00 · W1）

> **口径纪律（本节全部数字遵守）**：延迟一律取**同源 QPC**——`Stopwatch.GetTimestamp()`，本机 freq=10000000（1 tick=0.1µs），
> 常驻注入器、打点靶场、点击夹具三处都用它；Node 侧"决定"的时刻用 60 次 `P` ping 的**最小延迟法**标定到同一 QPC
> （偏移 0.027ms、抖动带 2.76ms）。**全链路不出现 `Date.now()`**（它在 Windows 上量子 15.6ms —— 上一轮 158–188ms 与 296–604ms 就是踩在这里）。
> 机读汇总：`D:\dsh-arena\bench-l3-rerun.json`。原始文件见各小节。

### 0′.1 四项结论表

| # | 问题 | 同源口径实测（ms） | 结论 |
|---|---|---|---|
| **1a** | 决定按键 → 目标窗口收到的真实端到端 | 常驻注入器 SendInput：**p50 1.285 / p90 1.476 / max 1.501**；拆开＝注入前 p50 **0.056**（管道 0.045 ＋ 解析 0.011，同一进程内取戳）＋注入 p50 **1.248** | 端到端是 **1.3ms 级**，不是 158ms |
| **1b** | 上一轮 296–604ms 里注入前/注入各占多少 | 同机制复测（n=20×4 条插件路径）：注入段 **0.164–1.248ms**（占 **0.1–0.6%**）；注入前 **133.4–268.3ms**（占 **99.4–99.9%**）；20/20 拍的到达都发生在**调用返回之前**，即注入在调用尾部 | **99.5% 是插件注入前的前置工作**（窗口解析/前台切换/每字符 5ms sleep），投递本体只有亚毫秒 |
| **1c** | 每条路径的同源数字、哪条能用于真游戏 | 见 0′.2；**只有"前台 SendInput"两条通道都通**（WM_INPUT +40/20 键），PostMessage 系列 WM_INPUT **+0** | 真游戏（Raw Input/DirectInput）**只能走 SendInput 且必须持前台** |
| **2** | L1（9 类办公任务）真值 | 声明 9 类 / 实跑 8 类；**有效分母 42 采样 → 83.3%**；winctl 通道 **21/21 = 100%**、naive 通道 **14/21 = 66.7%**；单步中位 naive 1018ms / winctl 1586ms | ⚠️ **83.3% ≠ 100%**；`tree-expand`、`drag-move` 两类自判无效必须剔出分母 |
| **3** | 指针点击真机基线（real 200 次 @ 40,40） | **200/200 注入、0 跳过、命中 200/200**；SetCursorPos p50 **0.011**；按下调用自身 p50 0.124；**端到端 p50 0.326 / p90 0.417 / p99 0.936 / max 7.892** | ✅ **打通**；真机点击是**亚毫秒级**，73–75ms 那个数是插件前置成本 |
| **4** | L3 定时序列复跑（max 偏差进 100ms） | 口径① 相对首拍 max **42.102**（中位 3.975）；口径③ 同源绝对迟到 max **67.025**（中位 28.898）；口径② 墙钟迟到 max **66.822**；到达 30/30、0 丢 | ✅ **三个口径全部 <100ms**；剩余 26–67ms 归客户端派发量化，不归投递也不归调度 |

### 0′.2 按键各路径（同源 QPC，n=30/路径，间隔 120ms；靶场 = `arena-beat.ps1`）

| 路径 | 目标在前台 | 到达/丢 | 注入前 p50 | 注入 p50 / max | **端到端 p50 / max** | WM_INPUT（原始输入通道） | 能用于真游戏？ |
|---|---|---|---|---|---|---|---|
| 常驻注入器 `SendInput`（VK） | 是 | **30/0** | 0.056 | 1.248 / 1.433 | **1.285 / 1.501** | **+40（20 键 ×2）** | ✅ **能**（必须持前台） |
| 常驻注入器 `SendInput`（扫描码） | 是 | 30/0 | 0.061 | 1.262 / 1.626 | 1.333 / 1.717 | 同上（同一注入路径） | ✅ 能 |
| 常驻注入器 `PostMessage`（WM_KEYDOWN+CHAR+UP） | 是 | 30/0 | 0.057 | 0.164 / 0.525 | **0.229 / 0.658** | **+0** | ❌ **不能**（游戏收不到） |
| 常驻注入器 `SendInput`（失焦，负对照） | 否 | **0/20 全丢且不报错** | 0.060 | — | — | — | ❌ 失焦即 100% 丢 |
| 常驻注入器 `PostMessage`（失焦） | 否 | **0/20**（WPF 目标需焦点；WinForms 目标后台可收，见 rawsink A 相 msgDown+20） | 0.055 | — | — | — | ❌ 依目标类别而定 |
| 插件 `keypress dispatch:foreground`（sendkeys） | 是 | 20/0 | — | — | **269.494 / 389.802**（调用中位 299.901） | — | ⚠️ 机制上仍是 SendInput，慢在注入前 |
| 插件 `keypress dispatch:background` | 是 | 20/0 | — | — | 263.667 / 288.082（调用中位 265.708） | — | ⚠️ 同上 |
| 插件 `type_text method:background`（本轮最快） | 是 | 20/0 | — | — | **134.579 / 148.539**（调用中位 156.799） | — | ⚠️ 同上 |
| 插件 `type_text method:sendinput` | 是 | 20/0 | — | — | 268.738 / 279.733（调用中位 271.490） | — | ⚠️ 同上 |

**读法**：前三行是"投递本体"，最后四行是"插件整条调用"。`端到端 ≈ 调用耗时 − 亚毫秒`，
所以**插件路径的 133–270ms 里 99.5% 花在注入之前**；把按键交给常驻注入器，同一件事降到 1.3ms（**快 100–200 倍**）。

**证据文件**：`bench\keylat\keylat-e2e.json`（前三行+负对照）、`bench\keylat\keylat-plugin-e2e.json`（插件四行）、
`bench\keylat\keylat-raw.json`（WM_INPUT 判别，`rawsink.ps1` 同一窗口双通道计数）。

### 0′.3 L1 真值（现场重跑 `node D:\dsh-tools\winctl\bench.mjs --repeat 3`）

原始报告：`D:\dsh-tools\winctl\reports\bench-2026-11-06213611.json`；整理：`bench\l1-rerun.json`。

| # | 任务 | naive 成功率/均值 | winctl 成功率/均值 | 假达标 | 自判无效 |
|---|---|---|---|---|---|
| 1 | 计算器 7×8=56 | 67% / 1304ms | 100% / 5925ms | 0/0 | 0/0 |
| 2 | 记事本写入并回读 | 100% / 1015ms | 100% / 1610ms | 0/0 | 0/0 |
| 3 | 窗口激活 | 100% / 1035ms | 100% / 697ms | 0/0 | 0/0 |
| 4 | 原生对话框写文件名 | 100% / 2867ms | 100% / 4781ms | 0/0 | 0/0 |
| 5 | 剪贴板跨窗口回读 | **0%** / 2994ms | 100% / 4429ms | **3/0** | 0/0 |
| 6 | 窗口移动 | 100% / 167ms | 100% / 481ms | 0/0 | 0/0 |
| 7 | 滚动可见内容变化 | **0%** / 1ms | 100% / 900ms | **3/0** | 0/0 |
| 8 | `tree-expand` 资源管理器左树 | — 跳过 — | — 跳过 — | — | **3/3 无效** |
| 9 | 拖拽窗口 | 0% / 967ms | 0% / 2226ms | 0/0 | **3/3 → 3/3** |

- **哪几类自判无效、为什么**：
  1. `tree-expand`：**目标应用没在运行**（`CabinetWClass` 不存在），`bench.mjs` 主动跳过 —— 没有测量，不能计入分母。
  2. `drag-move`：6 次全部 `POINT_COVERED: (924,282)/(874,285) shows another window ('Windows 安全中心', class Shell_SystemDim)` ——
     第三方全屏窗口压住测点，**注入根本没发生**，判"无效"而非"失败"。
  3. 本次会话还实测到一个更狠的同类：`PickerHost.exe`(pid 26336) 残留的全屏 `Shell_SystemDim`([0,0,1440,900]) 一度把**整个桌面**压住，
     造成"点击全落空、前台被抢"的假象（本轮第一遍 clicklat 200/200 跳过就是它）。已清理。
- **修正"假达标"**：6 次采样是 `okSelf=true & ok=false`（剪贴板 naive ×3、滚动 naive ×3）——自报成功、外部判据失败。
  单报"自报成功率"会把这两类算成通过。
- **真值**：剔除自判无效后 **35/42 = 83.3%**（不是 100%）。分通道看：winctl 21/21=100%、naive 14/21=66.7%。
  CONTROL-BENCH 现记的 85.9%（170/198）与本轮 83.3%（35/42）同量级、同结论：**"元素定位 100% 达标"不成立**。

### 0′.4 指针点击真机基线（`clicklat.mjs --mode real`，200 次，目标屏幕点 288,231）

数据目录：`bench\clicklat\real2-20261106220244\`（`trials.jsonl` + `summary.json` + `meta.json`）。

| 指标 | min | p50 | p90 | p99 | max | mean |
|---|---|---|---|---|---|---|
| `SetCursorPos` 调用 | 0.0100 | **0.0109** | 0.0137 | 0.0523 | 0.2187 | 0.0131 |
| `mouse_event(LEFTDOWN)` 调用自身 | 0.1072 | 0.1244 | 0.1891 | 0.5676 | 6.9552 | 0.1794 |
| **端到端（注入前 → 窗体收到 WM_LBUTTONDOWN）** | 0.2338 | **0.3255** | **0.4152** | 0.9362 | **7.8917** | 0.3655 |
| 端到端（→ WM_LBUTTONUP） | 0.4406 | 0.5391 | 0.6911 | 1.1618 | 8.5314 | 0.5950 |

- 被遮挡跳过 **0/200**，`handler_seen` 命中 **200/200** ⇒ **打通**。
- 尾部（max 7.89ms）不是投递成本，是夹具进程被系统调度打断的一次（p99 仍 0.94ms）。
- **未打通的两遍也如实留档**（`real-20261106214023` / `real-20261106214717` / `real-20261106214840`：200/200 `real_skipped`；
  `real2-20261106220029` / `real2-20261106220145`：前台拿到了但 `IsWindowVisible=false`）。根因与修法见 §12。

### 0′.5 L3 定时序列复跑（30 拍 = 24 点击 + 6 按键，间隔 260–400ms）

主口径：`bench\l3-timing3.json`（**点击与按键都走常驻注入器**）；过程留证：`bench\l3-timing2.json`（只有按键走注入器）。

| 轮次 | 点击通道 | 按键通道 | 口径① 相对首拍 max | 口径③ 同源绝对迟到 max | 到达延迟 点击/按键 | 判据 |
|---|---|---|---|---|---|---|
| v1（上轮，`l3-timing.json`） | 插件 click | 插件 type_text-bg | 187.815 ❌ | （无此口径） | 73.3 / 263.2 | ❌ |
| v2（本轮第一步，`l3-timing2.json`） | 插件 click | 常驻注入器 | **54.052 ✅** | 138.452 ❌ | 74.0 / **1.579** | 半个 |
| **v3（本轮主口径，`l3-timing3.json`）** | **常驻注入器** | **常驻注入器** | **42.102 ✅** | **67.025 ✅** | **8.12 / 1.468** | ✅ 全部 |

- v3 明细：口径① 中位 3.975 / p90 30.830 / **max 42.102**；口径③ 中位 28.898 / p90 55.753 / **max 67.025**；
  口径② 中位 28.695 / **max 66.822**；30/30 到达、0 丢、`errors: []`、`warnings: []`；前台自检 `ok=true`。
- **瓶颈归属（换一条通道就掉下来的量，就是它）**：v2→v3 只把**点击**从插件换成常驻注入器，
  点击到达延迟 74.0ms → **8.12ms**、口径③ max 138.5 → **67.0ms**。
  再对照 §0′.4 的真机点击基线 0.33ms：**剩余 8ms 是引擎 move/click 的派发量化（每步 13.6ms 的客户端循环），不是投递、不是调度**。
- 同源锚点自校验：`anchor − swZeroQpc` = 4570.584ms，墙钟切点 `cutSw` = 4567ms，**差 3.584ms** —— 两套时钟读法一致，锚点可信。

---

## 0. 一句话结论（第一轮 · 保留原文，其中被 §0′ 修正处已标注）

- **定时序列：通过。** 30 拍（24 次真实鼠标点击 + 6 次真实按键）全部按计划到达，间隔 260–400ms；
  每拍偏差中位 27.553ms、p90 68.095ms、**最大 72.139ms（口径① 调度精度 <100ms）**；末拍累计偏差 14.358ms。
- **连续 3 分钟：通过。** 6 局 × 30s 连打，命中 42 / 43 / 42 / 42 / 42 / 41，首 30s 42 → 最后 30s 41，差 -1 分（-2.38%）。
- **按键投递（本轮新增独立判据）：原始通路极快、插件极慢。** 同一台机同一 QPC 实测：
  PostMessage WM_CHAR 中位 **0.172ms**、前台 SendInput 中位 **0.563ms**、常驻注入器端到端中位 **0.56–0.80ms**（p90 ≤1.35ms）；
  而插件（MCP）最快 **296.1ms**、最慢 **603.7ms**。⇒ **<100ms 完全可达**，唯一超标的环节是插件注入前的前置工作（详见 §5.1）。
- 6 局极差 2 命中，趋势斜率 -0.229 命中/局（≈0 = 不掉速）。

## 1. 判据与口径（先说清怎么算的）

| 口径 | 定义 | 用途 |
|---|---|---|
| **口径① 相对首拍偏差**（= 调度精度） | `(实际_k − 实际_0) − (计划_k − 计划_0)`，两边各用自家单调时钟 | **主口径**：只比"相对第 0 拍"的位置，避开两个时钟的对齐假设；只反映**调度器抖不抖、漂不漂** |
| **口径② 绝对墙钟迟到**（= 调度偏差 + 投递延迟） | `(靶场 swZeroUnixMs + 实际 swMs) − (客户端 t0Wall + 计划 atMs)` | 跨时钟对照，**含各通道固定投递延迟**；对外承诺"这一刻真的按键了吗"用它 |
| **口径③ 按键投递延迟**（独立判据，本轮新增） | 单一按键/字符从"发出调用"到"目标窗口收到 WM_KEYDOWN/WM_CHAR"的耗时（同机 QPC 对齐，不含任何调度等待） | **单列**：它是输入通路的固有成本，不许和①②混在一起平均（详见 §5.1） |
| 到达延迟 | `(靶场 swZeroUnixMs + 实际 swMs) − 客户端发出该次调用时刻` | 拆解瓶颈（调度 vs 输入插件） |

**三个口径的关系**（本轮把它写死，避免再被误读）：
`口径② ≈ 口径① + 口径③ + 排队的随机抖动`。
口径①量的是"节拍准不准"，口径③量的是"键盘好不好使"，两个都对，但**不能互相替代**：
口径①通过 ≠ 键盘好用（按键投递可以慢 300ms 而每拍偏差仍是 27ms）；口径③达标 ≠ 序列准（投递快但调度抖同样会掉拍）。

为什么主口径要"相对第 0 拍"：客户端与靶场是两个进程、两个时钟，跨进程对齐本身带 ±wallGrain 误差；
而"定时序列"要证明的是**节拍之间不漂不移**，这正是 dev_k 量的东西。绝对迟到单独列出，谁都能自己看。

## 2. 打点靶场 `arena-beat.ps1`（新文件，不动既有靶场）

`arena.ps1` / `arena-move.ps1` 一行未改。新文件只做一件事：**收到鼠标按下/按键就记时间**。

- 计时在**编译期 C# 事件处理器**里取 `Stopwatch.Elapsed.TotalMilliseconds`（PowerShell 事件处理器本身有 ms 级调用抖动，会污染被测对象）；
- 记录 `PreviewMouseDown` / `PreviewKeyDown` / `PreviewTextInput`（前者能拿到"按钮已处理"的点击，后者接住 WM_CHAR 投递）；
- 每行 JSONL 带 `swMs`（靶场单调时钟）+ 坐标/键码；header 里带 `swZeroUnixMs`（Stopwatch 起点的墙钟）与 `wallGrainMs`（本机实测时钟量化步长）；
- 窗口 `Topmost`，与既有靶场同尺寸同位置（900×620@140,110），UIA 身份沿用（`DSH Arena` / `arenaBoard` / `arenaTarget`）。

## 3. 定时序列设计

| 项 | 取值 |
|---|---|
| 拍数 | 30（24 次真实点击 + 6 次真实按键 `w a s d w a`） |
| 间隔 | 260 / 280 / 300 / 400 ms（全部落在 200–400ms 内） |
| 复合动作 | 每组 5 拍 = 移动→点击→按键→（3 步接近轨迹）点击→点击；"移动"由 click 动作自带的贝塞尔轨迹承担 |
| 执行器 | `D:\dsh-tools\aim\input.mjs` 的 `schedule()`（真实 `SetCursorPos + mouse_event` / 插件按键通道） |
| 时长 | 计划 8840ms，实测整段 9033ms（含各拍固定投递延迟） |
| 间隔取值说明 | 判据允许 200–400ms；实测单击工具耗时中位 176ms + 到达 ≈75ms，200ms 间隔没有余量，故取 260/280/300/400ms（仍在判据带内） |

## 4. 定时序列结果（逐次原始数据）

| 原始文件 | 按键通道 | 拍数(点击+按键) | 偏差中位 | p90 | **最大** | 末拍 | 绝对迟到中位 | 到达延迟 点击/按键 | 判据<100ms | 备注 |
|---|---|---|---|---|---|---|---|---|---|---|
| l3-timing-20261106194028.json | type(推断) | 30 (24+6) | 52.907 | 66.191 | **66.737** | 65.655 | 100.566 | 71.091/156.551 | ✅ |  |
| l3-timing-20261106194514.json | type(推断) | 30 (24+6) | 27.553 | 68.095 | **72.139** | 14.358 | 101.767 | 73.284/133.309 | ✅ |  |
| l3-timing-20261106195210.json | bg | 30 (24+6) | 14.207 | 181.166 | **199.864** | 1.374 | 102.874 | 74.286/260.502 | ❌ | 按键通道慢：未达标（原始数据保留） |
| l3-timing-20261106195332.json | fg | 30 (20+10) | 791.634 | 1238.963 | **1518.546** | 1518.546 | -560.627 | -588.627/-444.879 | ❌ | 解析伪影：一次按键产生 KeyDown+TextInput 两个事件、未合并 → 配对错位（原始 JSONL 保留，同配置已重跑） |
| l3-timing-20261106195513.json | fg | 30 (24+6) | 14.409 | 183.059 | **187.815** | 1.625 | 102.128 | 73.277/263.244 | ❌ | 按键通道慢：未达标（原始数据保留） |

**官方口径（最保守的一次，按键通道=type）：逐拍明细**

| # | 拍型 | 计划(atMs) | 实际(swMs) | 偏差 dev | 绝对迟到 | 到达延迟 | 计划间隔 | 实际间隔 |
|---|---|---|---|---|---|---|---|---|
| 0 | mouse | 1 | 4367.214 | 0 | 74.214 | 59.214 | — | — |
| 1 | mouse | 281 | 4686.991 | 39.777 | 113.991 | 80.991 | 280 | 319.777 |
| 2 | text | 540 | 4978.262 | 72.048 | 146.262 | 134.262 | 259 | 291.271 |
| 3 | mouse | 841 | 5247.245 | 40.031 | 114.245 | 68.245 | 301 | 268.983 |
| 4 | mouse | 1241 | 5620.19 | 12.976 | 87.19 | 70.19 | 400 | 372.945 |
| 5 | mouse | 1521 | 5900.284 | 13.07 | 87.284 | 73.284 | 280 | 280.094 |
| 6 | mouse | 1801 | 6193.671 | 26.457 | 100.671 | 74.671 | 280 | 293.387 |
| 7 | text | 2060 | 6493.825 | 67.611 | 141.825 | 140.825 | 259 | 300.154 |
| 8 | mouse | 2361 | 6767.045 | 39.831 | 114.045 | 66.045 | 301 | 273.22 |
| 9 | mouse | 2761 | 7153.913 | 26.699 | 100.913 | 75.913 | 400 | 386.868 |
| 10 | mouse | 3041 | 7420.492 | 13.278 | 87.492 | 66.492 | 280 | 266.579 |
| 11 | mouse | 3321 | 7700.564 | 13.35 | 87.564 | 70.564 | 280 | 280.072 |
| 12 | text | 3580 | 8012.877 | 66.663 | 140.877 | 132.877 | 259 | 312.313 |
| 13 | mouse | 3881 | 8287.431 | 40.217 | 114.431 | 71.431 | 301 | 274.554 |
| 14 | mouse | 4281 | 8660.877 | 13.663 | 87.877 | 67.877 | 400 | 373.446 |
| 15 | mouse | 4561 | 8940.83 | 13.616 | 87.83 | 68.83 | 280 | 279.953 |
| 16 | mouse | 4841 | 9220.872 | 13.658 | 87.872 | 69.872 | 280 | 280.042 |
| 17 | text | 5100 | 9534.309 | 68.095 | 142.309 | 133.309 | 259 | 313.437 |
| 18 | mouse | 5401 | 9807.707 | 40.493 | 114.707 | 77.707 | 301 | 273.398 |
| 19 | mouse | 5801 | 10194.439 | 27.225 | 101.439 | 75.439 | 400 | 386.732 |
| 20 | mouse | 6081 | 10474.547 | 27.333 | 101.547 | 77.547 | 280 | 280.108 |
| 21 | mouse | 6361 | 10754.579 | 27.365 | 101.579 | 78.579 | 280 | 280.032 |
| 22 | text | 6620 | 11058.353 | 72.139 | 146.353 | 132.353 | 259 | 303.774 |
| 23 | mouse | 6921 | 11341.315 | 54.101 | 128.315 | 79.315 | 301 | 282.962 |
| 24 | mouse | 7321 | 11714.691 | 27.477 | 101.691 | 73.691 | 400 | 373.376 |
| 25 | mouse | 7601 | 11994.767 | 27.553 | 101.767 | 75.767 | 280 | 280.076 |
| 26 | mouse | 7881 | 12275.036 | 27.822 | 102.036 | 79.036 | 280 | 280.269 |
| 27 | text | 8140 | 12577.171 | 70.957 | 145.171 | 133.171 | 259 | 302.135 |
| 28 | mouse | 8441 | 12848.269 | 41.055 | 115.269 | 73.269 | 301 | 271.098 |
| 29 | mouse | 8841 | 13221.572 | 14.358 | 88.572 | 71.572 | 400 | 373.303 |

## 5. 按键通道：三次配置的真实差异（失败数据不删）

选型探针 `l3-keyprobe2.json`（同一窗口、同一目标，逐个通道量"调用发出→窗口收到"）：

| 通道 | 调用耗时 | 到达事件 | **到达延迟** | 备注 |
|---|---|---|---|---|
| keypress-fg | 397ms | key | **363.7ms** |  |
| keypress-bg | 309ms | text | **305.9ms** |  |
| keypress-bg-nowin | 32ms | — | **—ms** | background dispatch requires a window target (windowTitle / processId / nativeWindowHandle). |
| typetext-bg | 174ms | text | **157.6ms** |  |
| typetext-sendinput | 301ms | text | **295.1ms** |  |
| keypress-fg-2 | 331ms | key | **306.9ms** |  |
| keypress-bg-2 | 285ms | text | **282.6ms** |  |

结论：鼠标点击的到达延迟 ≈75ms，而插件按键通道最好的也 ≈158ms（`type_text method:background`），前台/后台 keypress 是 283–307ms。
这套序列的按键拍因此比点击拍晚 80–230ms 到达 —— 差值由**输入插件的按键投递路径**决定，与调度器无关（点击拍的偏差只有 ±13ms）。
上面第 4 节里带 ❌ 的三行就是这条结论的原始证据：同一份计划，只换按键通道，最大偏差从 72ms 变成 188–200ms。
快速通道 = `typetext-bg`（157.6ms）—— 这也解释了为什么官方口径用它。**但 §5.1 证明这 157.6ms 里只有 0.2ms 是投递，其余全是插件前置成本。**

### 5.1 按键投递路径全量实测（2026-11-07 04:16–04:49 · 独立判据）

**方法**：接收器 `bench\keylat\receiver.ps1`（WinForms 两个窗口，`WndProc` 里**只取 QPC tick**，不写盘、不格式化）；
发送端 `bench\keylat\sender.ps1`（常驻，`Add-Type` 编译一次 P/Invoke，收到指令立即注入并记录注入前后 tick）。
`Stopwatch.GetTimestamp()` = QPC，同机全局一致，所以**延迟 = (目标收到消息的 tick − 注入前 tick)/freq，不需要跨时钟对齐**，误差 < 0.01ms。
机读原始数据：`bench\keylat\keylat-native.json` / `keylat-fast.json` / `keylat-plugin.json` / `keylat-ab.json`，汇总 `bench\keylat\keylat.json`。

### A. 原始 OS 路径（n=100/路径，间隔 25ms，跨进程；单位 ms）

| 路径 | 目标在前台? | 到达/丢 | 中位 | p90 | 最大 | 发送端调用中位 |
|---|---|---|---|---|---|---|
| PostMessage WM_CHAR | 否 | **100/0** | **0.172** | 0.338 | 0.410 | 0.097 |
| PostMessage WM_KEYDOWN+UP | 否 | 100/0 | 0.205 | 0.357 | 0.441 | 0.151 |
| PostMessage KEYDOWN+CHAR+KEYUP | 否 | 100/0 | 0.254 | 0.412 | 0.555 | 0.215 |
| 同上 + 扫描码 lParam | 否 | 100/0 | 0.329 | 1.009 | 2.192 | 0.271 |
| **SendInput UNICODE** | 否 | **0/100** | — | — | — | 0.201 |
| SendInput VK('W') | 否 | 1/99 | — | — | — | 0.163 |
| SendInput VK('W') | 是 | 99/1 | 0.563 | 0.825 | 1.036 | 0.323 |
| SendInput 扫描码 | 是 | 100/0 | 0.534 | 0.782 | 1.137 | 0.305 |
| SendInput UNICODE | 是 | 100/0 | 0.560 | 0.748 | 11.498 | 0.317 |
| keybd_event | 是 | 100/0 | 0.647 | 0.932 | 1.230 | 0.469 |
| SendKeys.SendWait | 是 | 98/2 | 0.678 | 1.000 | 6.625 | **31.218** |
| SendMessage（同步，参考下限） | 是 | 100/0 | 0.189 | 0.395 | 0.504 | 0.523 |
| PostMessage WM_CHAR | 是 | 100/0 | 0.228 | 0.448 | 5.983 | 0.116 |
| PostMessage KEYDOWN+CHAR+KEYUP | 是 | 100/0 | 0.257 | 0.454 | 0.545 | 0.221 |
| 同上 + 扫描码 lParam | 是 | 100/0 | 0.258 | 0.427 | 0.493 | 0.218 |
| **密集连发 gap=0 ×100**：WM_CHAR（后台） | 否 | **100/0** | **0.048** | 0.062 | 0.084 | 0.029 |
| 密集连发：KEYDOWN+CHAR+KEYUP+扫描码（后台） | 否 | 100/0 | 0.026 | 0.070 | 0.095 | 0.070 |
| 密集连发：KEYDOWN+CHAR+KEYUP+扫描码（前台） | 是 | 100/0 | 0.028 | 0.062 | 0.643 | 0.070 |
| 指针：PostMessage WM_LBUTTONDOWN/UP | 是 | 100/0 | 0.504 | 1.011 | 1.578 | 0.387 |
| 指针：PostMessage WM_LBUTTONDOWN/UP | 否 | 100/0 | 0.484 | 1.288 | 2.582 | 0.433 |
| 指针：SendInput 左键（SetCursorPos+点击） | 是 | **0/100** | — | — | — | 1.786 |

- **两条后台 SendInput 行是"丢键"的直接证据**：100 次按键全部落到当时的前台窗口（cover 收到 202 个事件），目标窗口 0 个。
  → `SendInput/keybd_event` 不带目标，只认"当前前台+焦点窗口"；失焦即 100% 丢，且**不会报错**。
- `PostMessage` 系列不挑前台、不挑焦点：前台/后台都是 100/100，最大 ≤2.2ms，gap=0 连发 100 个也不丢。
- `SendKeys.SendWait` 的调用本身要 31ms（内部消息泵），到达只有 0.68ms —— 慢在调用，不在投递。
- 指针 SendInput 这一行本轮**没打通**（见 §8 第 10 条），所以点击基线仍沿用上一轮的 73ms。

### B. 常驻注入器端到端（Node → 常驻进程 → 注入 → 窗口收到；n=30，间隔 150ms）

| 路径 | 目标在前台? | 到达/丢 | 中位 | p90 | 最大 | Node 往返中位 |
|---|---|---|---|---|---|---|
| PostMessage WM_CHAR | 是 | 29/1 | 0.72 | 1.12 | 1.36 | 1 |
| KEYDOWN+CHAR+KEYUP+扫描码 | 是 | 30/0 | 0.70 | 1.08 | 1.11 | 1 |
| SendInput UNICODE | 是 | 30/0 | 0.80 | 1.28 | 1.63 | 1 |
| SendInput VK | 是 | 30/0 | 0.80 | 1.35 | 10.39 | 1 |
| PostMessage WM_CHAR | 否 | 30/0 | **0.64** | 1.10 | 156.69（首拍冷启动） | 1 |
| KEYDOWN+CHAR+KEYUP+扫描码 | 否 | 30/0 | 0.56 | 1.04 | 1.14 | 1 |

**这就是"能压到 <100ms"的落地形态**：整条链路（Node 写 JSON → 常驻进程 ReadLine+Parse → P/Invoke 注入 → 目标收到）
中位 0.56–0.80ms、p90 ≤1.35ms，比 100ms 的判据宽 **~70–180 倍**。唯一尖峰是第一条指令（冷启动 86–157ms）。

### C. 插件（MCP windows-computer-use）真实路径（n=12/路径，间隔 700ms）

| 插件路径 | 汇报 method | 到达/丢 | 中位 | p90 | 最大 | 调用中位 |
|---|---|---|---|---|---|---|
| `keypress dispatch:foreground` | sendkeys | 11/1 | **603.7** | 607.2 | 611.3 | 636 |
| `keypress dispatch:background` | postmessage-wmchar | 12/0 | **587.0** | 595.4 | 615.9 | 589 |
| `type_text method:background`（本轮最快） | postmessage-wmchar | 12/0 | **296.1** | 300.3 | 307.4 | 324 |
| `type_text method:sendinput` | sendinput-unicode | 12/0 | **588.5** | 593.7 | 629.8 | 591 |
| `click dispatch:foreground` | sendinput | 0/12 | — | — | — | 588（POINT_COVERED） |

**每一行都满足"到达延迟 ≈ 调用耗时"**：注入发生在调用的尾部，投递本体只占 0.2–0.7ms（表 A）。
即插件的 296–604ms **全部是注入之前的前置工作**。

### D. A/B 对照：同一调用打到两个接收器（交错 8 轮）

| 接收器 | 到达中位 | 调用中位 | 备注 |
|---|---|---|---|
| `keylat receiver`（我的夹具窗口） | 296.6 | 313 | 同一份 `type_text method:background` |
| `arena-beat.ps1`（上一轮打点器） | **144.0** | 157 | 复现上一轮 157.6ms ✓ |

- 两个接收器都"没测错"：**144ms 与 296ms 的差不是测量误差，而是插件针对不同目标窗口花的钱不同**
  （我的夹具窗口 `IsWindowVisible=false`，插件解析/校验它更慢；调用耗时 157ms vs 313ms 同步印证）。
- 结论：**上一轮 187.8/199.9ms 与今年的 296–604ms 是同一类东西 —— 插件前置成本**，不是投递，也不是调度。

### 根因（都有代码行号）

| # | 位置 | 内容 |
|---|---|---|
| 1 | `wcu/package/scripts/windows-uia.ps1:1204-1218` | `Post-BackgroundText` 每字符 `Start-Sleep -Milliseconds 5` |
| 2 | `windows-uia.ps1:661-707` | `Set-WindowForeground`：最小化则 `ShowWindow`+80ms；`GiveForeground` 成功再 60ms；失败走 Alt-tap+120ms |
| 3 | `windows-uia.ps1:3099` | `keypress dispatch:foreground` = `SendKeys.SendWait`（自身调用 31ms） |
| 4 | `windows-uia.ps1:3032/3095` | 所有前台路径先 `Start-Input`（含窗口解析 + 前台切换），注入排在其后 |

### 最优路径与它的代价（结论）

| 排序 | 路径 | 中位 | 代价 |
|---|---|---|---|
| 1 | 后台 `PostMessage` WM_KEYDOWN(带扫描码)+WM_CHAR+WM_KEYUP | 0.17–0.33ms | 不抢前台；**但只对"处理窗口消息"的目标有效**，DirectInput/原始输入的游戏会忽略；组合键要自己拼序列 |
| 2 | 前台 `SendInput` / `keybd_event` | 0.53–0.65ms | 必须先持有前台+焦点；**失焦 100% 丢且不报错**；切前台一次性 60–120ms |
| 3 | 常驻注入器（把 1/2 包进一条常驻进程） | **0.56–0.80ms 端到端** | 需要一条常驻进程 + 首次冷启动 ~100ms |
| 4 | 插件现状（MCP） | 296–604ms | 唯一 >100ms 的一环；改法见 `SUGGEST-CONTROL-BENCH.md` |

### 可直接复用的做法（<100ms）

```powershell
# 1) 常驻注入器（一次编译，长期复用）：D:\dsh-arena\bench\keylat\sender.ps1
#    读 stdin 的 {"variant":"postmessage-combo-sc"|"sendinput-vk"|…,"hwnd":<int>,"n":1,"gapMs":0,"vk":87,"ch":119}
# 2) Node 侧只写一行 JSON 就够：见 bench\keylat\keylat-fast.mjs（端到端中位 0.7ms）
# 3) 目标已在前台 → sendinput-*；不抢前台 → postmessage-combo-sc（带扫描码 lParam）
```

## 6. 连续 3 分钟（6 局 × 30s，真实指针通道）

| 局 | arena 原始文件 | 命中 | 误击 | 命中率 | 平均反应 | 中位反应 | p90 | 单拍 see/move/click | 空转拍 |
|---|---|---|---|---|---|---|---|---|---|
| 1 | run-20261107-034726.json | **42** | 0 | 100% | 692.6ms | 663ms | 681ms | 271/172/201 | 3 |
| 2 | run-20261107-034809.json | **43** | 0 | 100% | 675ms | 662ms | 678ms | 274/169/200 | 1 |
| 3 | run-20261107-034851.json | **42** | 1 | 98% | 697.5ms | 674ms | 689ms | 279/170/201 | 1 |
| 4 | run-20261107-034934.json | **42** | 0 | 100% | 684.6ms | 674ms | 691ms | 282/171/201 | 1 |
| 5 | run-20261107-035017.json | **42** | 0 | 100% | 690.8ms | 676ms | 692ms | 286/168/201 | 1 |
| 6 | run-20261107-035059.json | **41** | 1 | 98% | 709.8ms | 677ms | 693ms | 290/170/201 | 1 |

- 首 30s（第 1 局）**42** 命中 → 最后 30s（第 6 局）**41** 命中，差 **-1**（**-2.38%**），判据 ≤20% → ✅。
- 6 局命中 42 / 43 / 42 / 42 / 42 / 41，中位 42，极差 2，趋势斜率 -0.229 命中/局（≈0 = 不掉速）。
- 单拍构成整段基本不变：see 271→290ms、move 172→170ms、click 201→201ms；
  平均反应第 1 局 692.6ms → 第 6 局 709.8ms。
- 整段墙钟 256s（6 局各 30s + 每局冷启动/收尾；每局都是新窗口、干净状态，遵守 CONTROL-BENCH 第 3 条）。

## 7. 判据对照

| 判据 | 阈值 | 实测 | 结论 |
|---|---|---|---|
| 定时序列 每拍最大偏差（**口径① 相对首拍/调度精度**） | <100ms | 72.139ms（中位 27.553 / p90 68.095） | ✅ |
| 定时序列 末拍累计偏差（口径①） | <100ms | 14.358ms | ✅ |
| 定时序列 每拍绝对墙钟迟到（**口径② 含投递延迟**） | 参考值，不单独设阈值 | 中位 101.767ms / 最大 146.353ms | ⚠️ 超 100ms（差额=按键投递，见口径③） |
| **按键投递延迟（口径③，独立判据）** | **≤100ms** | 原始 OS 路径 0.17–0.65ms；常驻注入器端到端 0.56–0.80ms（p90 ≤1.35ms）；**插件现状 296–604ms ❌** | ✅ 可达标（走常驻注入器）；❌ 现状插件不达标 |
| 按键投递 是否丢键（后台连发 gap=0 ×100） | 0 丢 | PostMessage 系列 100/100；SendInput 失焦 0/100（全部落到前台窗口） | ⚠️ 依路径而定，必须报 loss |
| 定时序列 拍数 | ≥20 | 30（24 点击 + 6 按键） | ✅ |
| 定时序列 间隔 | 200–400ms | 260–400ms | ✅ |
| 连续 3 分钟 首末 30s 得分差 | ≤20% | -2.38%（42 → 41） | ✅ |
| 连续 3 分钟 每局命中 | ≥20（CONTROL-BENCH L2 基线，参考） | 42 / 43 / 42 / 42 / 42 / 41 | ✅ |
| 连续 3 分钟 趋势 | 斜率 ≥ -1 命中/局 | -0.229 命中/局 | ✅ |

## 8. 偏差与失败记录（如实，不删难看数据）

| # | 现象 | 证据 | 处置 |
|---|---|---|---|
| 1 | 按键走 `keypress foreground` 时最大偏差 **187.8ms**（判据 ❌）：按键到达延迟 263ms vs 点击 73ms | `l3-timing-20261106195513.json`（24+6 拍，逐拍表可查） | 不改判据；换更快的按键通道重测，原始文件保留 |
| 2 | 按键走 `keypress background`（WM_CHAR）仍 **199.9ms** ❌ | `l3-timing-20261106195210.json` | 同上；另做通道选型探针（第 5 节） |
| 3 | 同一份 `fg` 配置首次解析成 20 点击+10 按键、偏差 1518ms | `l3-timing-20261106195332.json`（`kindOrderMatch:false`） | 查明是"一次按键被记成 KeyDown+TextInput 两个事件"，解析加 40ms 合并规则后重跑 |
| 4 | 通道选型：`keypress background` **必须给窗口目标**，否则直接报错 | `l3-keyprobe2.json`：`background dispatch requires a window target` | 改为显式 `nativeWindowHandle` |
| 5 | 首次解析把"预热按键"当成第 0 拍，全部配对错位（假偏差 560ms） | 早期 timing JSON 的 `warnings` + `raw.droppedKinds` | 改为按墙钟切分预热段（`cutSw`），并核对事件数 30=30 |
| 6 | `DateTime.UtcNow` 量化步长首次测成 `-1`（自旋循环太快，时钟还没跳） | 首版 header `wallGrainMs:-1.000` | 改成"自旋到第一次跳变再采样"，实测 **0.999–1.093ms** |
| 7 | 点击拍偏差分布带一个小台阶（dev ∈ [-13, +43]ms） | 官方口径逐拍表 | 由每拍 move/click 的固定排队造成，不累积（280/400ms 余量吸收） |
| 8 | 6 局里第 3、6 局各有 1 次误击（命中率 98%） | `runs\run-20261107-034851.json` / `run-20261107-035059.json` 的 `missLog` | 如实保留，不剔除；只影响命中率，不影响"不掉速"口径 |
| 9 | 按键投递路径实测：**插件最快 296.1ms、最慢 603.7ms**，比上一轮更差 | `keylat-plugin.json`（mine 行） | 全部是插件前置成本（到达≈调用耗时）；本机与其它 worker 共享桌面，负载是变量。原始数据保留 |
| 10 | **指针 SendInput 路径本轮 0/100 没打通** | `keylat-native.json` `fg/mouse-sendinput`；发送端探针 `wfp:65802(Progman)`；插件报 `POINT_COVERED 'Program Manager'` | 夹具窗口 `IsWindowVisible=false`（本机 WinForms 特性，见 §10）+ 其它 worker 的模态「打开文件-安全警告」弹窗(480,239–960,613)与 Topmost 靶场窗口挡住测点。**点击基线仍沿用上一轮 73ms，本轮不重新声明** |
| 11 | 后台 SendInput **100% 丢键且不报错** | `keylat-native.json` `bg/sendinput-*`：目标 0/100，前台窗口收到 202 个事件 | 判据必须带 loss 字段：只报"中位延迟"会把丢键藏起来 |
| 12 | 常驻注入器第一条指令冷启动偶发 86–157ms | `keylat-fast.json` 的 `slow` 字段（i=0） | 预热一条空指令即可；稳定后中位 0.56–0.80ms |
| 13 | 共享桌面导致偶发丢键 1–2% | `fg/sendinput-vk 99/100`、`fg/sendkeys 98/100` | 别的 worker 抢前台所致；测按键投递须在独占前台下跑，并如实报 loss |

## 9. 复现步骤

```powershell
$env:TEMP='D:\dsh-tmp'; $env:TMP='D:\dsh-tmp'
$n='C:\Users\35126\AppData\Roaming\dsh-desktop\harness\.desktop-bin\node.cmd'

# 0) 按键投递路径（本轮新增，§5.1）
#    A 原始路径全量：n=100/路径、间隔25ms（含前后台、密集连发、指针对照）-> bench\keylat\keylat-native.json
& $n D:\dsh-arena\bench\keylat\keylat-native.mjs 100 25
#    B 常驻注入器端到端：n=30、间隔150ms -> keylat-fast.json
& $n D:\dsh-arena\bench\keylat\keylat-fast.mjs 30 150
#    C 插件真实路径（MCP，打到高精度接收器）-> keylat-plugin.json
& $n D:\dsh-arena\bench\keylat\keylat-plugin.mjs 12
#    D 两个接收器交错 A/B -> keylat-ab.json
& $n D:\dsh-arena\bench\keylat\keylat-ab.mjs 8
#    E 汇总 -> keylat.json
& $n D:\dsh-arena\bench\keylat\keylat-report.mjs
# 注意：跑之前先确认没有残留注入器/接收器：
#   Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | ? { $_.CommandLine -match 'keylat' } | % { Stop-Process -Id $_.ProcessId -Force }

# 1) 定时序列打点（30 拍；KEY_MODE=type|bg|fg 切按键通道）-> bench\l3-timing*.json + l3-beats-*.jsonl
$env:KEY_MODE="type"; & $n D:\dsh-arena\bench\l3-schedule.mjs

# 2) 连续 6 局 ×30s（真实指针通道；结果写 results-real-l3-6.json，不覆盖上一轮的 results-real.json）
$env:CH="real"; $env:ROUNDS="6"; $env:DURATION="30"; $env:SPEED="240"; $env:LABEL="l3-6"; & $n D:\dsh-arena\bench\run.mjs

# 3) 汇总 -> bench-l3.json + BENCH-L3.md
& $n D:\dsh-arena\bench\l3-report.mjs
```

## 10. 局限 / 别误读

1. **"总偏差"有两个读法**：本文主口径是"相对首拍"（`max|dev|` = 72.139ms ✅）。若按"每拍绝对墙钟迟到"读，中位 101.767ms、最大 146.353ms —— 差额来自输入插件的固定投递延迟（点击 ≈75ms、按键 ≈158ms），不是调度误差。
2. **按键拍靠 `type_text method:background`（WM_CHAR 投递）**，仍是插件发出的真实输入，但它不借前台；要"前台真实按键"就得接受 283–307ms 的到达延迟（见第 5 节）。
3. 打点窗口是 `Topmost` 的纯色窗口，靶心静止 —— 本轮量的是**时序**，不是命中；命中率口径仍以 `arena-move.ps1` 的 6 局为准。
4. 墙钟量化步长本机实测 ≈1ms（`wallGrainMs`），所以跨时钟对照的不确定度 ≈±1ms；换机器应重测。
5. 单屏 1440×900、DPI 100%；换分辨率/缩放需重跑。
6. **按键投递的两个坑（本轮实测踩到）**：
   - 本机 WinForms 里"进程内第一个 `Show()` 的窗体"会停在 `IsWindowVisible=false`（第二个窗体正常）。它**不影响按 HWND 投递的消息**（WM_CHAR/WM_KEYDOWN 照收），但会让指针命中测试与插件的坐标点击判定直接失败；夹具必须自检可见性。
   - 桌面是**跟其它 worker 共用**的：测量期间有第三方模态对话框（`打开文件 - 安全警告`，480,239–960,613）和 TargetMost 窗口占着前台，造成偶发 1–2% 丢键与 `POINT_COVERED`。按键投递判据应在**独占前台**下测，并同时报 loss。
7. 判据口径不可混用：`口径② ≈ 口径① + 口径③ + 抖动`。只报口径① 会显得比真实更准；只报口径③ 会漏掉节拍漂移。

## 11. 收尾

- 打点窗口与靶场窗口逐次 `close_window` 关闭，`closeArenaWindows` 的 `remaining` 为空；
- 无残留 `arena*.ps1` / `arena-beat.ps1` powershell 进程，无残留 MCP server 进程；
- 原始产物全部保留在 `D:\dsh-arena\bench\`（timing JSON / beats JSONL / keyprobe JSON / shots / results-real-l3-6.json），临时文件只在 `D:\dsh-tmp`。

## 12. 第二轮复跑原始记录（命令 / 失败 / 修法）

### 12.1 复现命令（本轮全部现场执行，输出即正文数字）

```powershell
$env:TEMP='D:\dsh-tmp'; $env:TMP='D:\dsh-tmp'
$n = 'C:\Users\35126\AppData\Roaming\dsh-desktop\harness\.desktop-bin\node.cmd'

# Q2  L1 真值（9 类 × 3 遍 × 两通道）
& $n D:\dsh-tools\winctl\bench.mjs --repeat 3
& $n D:\dsh-arena\bench\l1-rerun.mjs D:\dsh-tools\winctl\reports\bench-2026-11-06213611.json

# Q1  按键端到端（同源 QPC，注入前/注入两段）
& $n D:\dsh-arena\bench\keylat\keylat-e2e.mjs 30 120
& $n D:\dsh-arena\bench\keylat\keylat-plugin-e2e.mjs 20 500
& $n D:\dsh-arena\bench\keylat\keylat-raw.mjs 20          # WM_INPUT 判别

# Q3  指针点击真机基线（协作式夹具，见 12.3）
& $n D:\dsh-arena\bench\clicklat2.mjs 200 40 40

# Q4  L3 定时序列（v2=只换按键；v3=点击+按键都走注入器，主口径）
& $n D:\dsh-arena\bench\l3-schedule2.mjs                  # CLICK_MODE=injector(默认) -> l3-timing3.json
$env:CLICK_MODE='plugin'; & $n D:\dsh-arena\bench\l3-schedule2.mjs   # -> l3-timing3.json（对照）

# 汇总机读 JSON
& $n D:\dsh-arena\bench\w1-aggregate.mjs                  # -> D:\dsh-arena\bench-l3-rerun.json
```

### 12.2 本轮踩到并修掉的坑（每条都有现场证据）

| # | 现象 | 根因 | 处置 |
|---|---|---|---|
| 1 | 第一遍 `keylat-e2e` / `keylat-plugin-e2e` 全表出现 `-4.9e10 ms` | `nodeTick()` 单位没统一：hrtime 转成了 **ns**，而注入器/靶场给的是 **QPC tick** | 统一到 tick（`hrtime*FREQ/1e9 + offsetTick`）后重跑，得到 1.285ms 级端到端 |
| 2 | 第一遍 `l3-schedule2` 解析出 0 事件、30 拍全丢 | 桌面被 `PickerHost.exe`(pid 26336) 残留的全屏 `Shell_SystemDim`([0,0,1440,900]) 压住，插件的 click 前台守卫判定"another window is in the foreground"，鼠标事件一个都没到靶场 | `Stop-Process -Id 26336`；并顺手关掉上一轮基准留下的「计算器」「SCROLLTEST 记事本」窗口 |
| 3 | 第一遍 `clicklat --mode real`：200/200 `real_skipped`（2 秒跑完） | 同 #2（`under_hwnd=8194688`=那个全屏遮挡层）+ 后台进程被 Windows 前台锁挡住 `SetForegroundWindow` | 清场 + 见 #4 |
| 4 | 给夹具加"自抢前台"后**进程挂死**（0 样本、CPU 0.6s/4min） | 在 `AttachThreadInput` 生效期间调 `form.Activate()`/`Application.DoEvents()`，与 WinForms 消息泵死锁 | **放弃**在夹具进程内抢前台；改为外部驱动（见 12.3），并把 `clicklat-fixture.ps1` **还原为接手时原样**（备份 `clicklat-fixture.patched.bak`） |
| 5 | 协作式夹具第一遍：前台拿到了仍 200/200 跳过 | 现场实测：**PowerShell 5.1 进程里第一个 `Show()` 的窗体恒为 `IsWindowVisible=false`**（第二个才 True）⇒ 指针命中的是桌面 | 外部进程强制 `ShowWindow(SW_SHOW)` + `SetWindowPos(HWND_TOPMOST, SWP_NOSIZE\|SWP_NOMOVE\|SWP_SHOWWINDOW)` |
| 6 | 夹具源文件里写中文注释导致 `Add-Type` 编译失败 | Windows PowerShell 5.1 把无 BOM 的 .ps1 按 ANSI(GBK) 读，中文注释被截断成语法错误（原文件头部就写了这条） | 新增/派生的 .ps1 一律 **ASCII-only**；`clicklat2-fixture.ps1` 非 ASCII 字节数实测 = 0 |

### 12.3 点击夹具为什么换驱动：`clicklat2.mjs` + `clicklat2-fixture.ps1`

原夹具（`clicklat.mjs` + `clicklat-fixture.ps1`）的 real 模式带一道**遮挡门**：
`IsWindowVisible(h) && WindowFromPoint(target)==h && GetForegroundWindow()==h` 三者全真才注入，否则记 `real_skipped`。
这道门本身是对的（防止把点击打到别的窗口），但在"由后台进程启动"的语境下**永远不可能满足**，于是它诚实地交出了 200/200 跳过而不是假数据。
因此派生了一个**协作式**夹具，测量语义**一字未改**（同样 480×320 窗口在 (40,40)、同样 `SetCursorPos + mouse_event(LEFTDOWN/UP)`、同样两侧 QPC 打点）：

1. 夹具算完目标点后把 HWND 写进 `<OutDir>\hwnd.txt`，然后**泵消息等待** `<OutDir>\go.txt`（上限 30s）；
2. 驱动 `clicklat2.mjs` 起常驻注入器（已验证可用的抢前台路径：`AttachThreadInput` + Alt 轻敲）；
3. 驱动用**外部进程** `ShowWindow(SW_SHOW)` + `SetWindowPos(TOPMOST, NOSIZE|NOMOVE|SHOWWINDOW)` 把 `WS_VISIBLE` 打开，再 `inj.focus(hwnd)`；
4. 确认 `GetForegroundWindow()==hwnd` 后才写 `go.txt` 放行，夹具按原逻辑跑 200 次。

`meta.json` 里多两个字段留证：`gate_go`、`gate_waited_ms`（实测 491.9 / 1441.3 / 1477.0ms）。
三次未打通的运行目录原样保留，不删。

### 12.4 本轮新增/派生文件（都在 W1 目录内）

| 文件 | 用途 |
|---|---|
| `bench\keylat\keylat-e2e.mjs` | 同源 QPC 端到端，分注入前(管道/解析)/注入两段；含后台负对照 |
| `bench\keylat\keylat-plugin-e2e.mjs` | 插件四条路径的同源 QPC 端到端 |
| `bench\l3-schedule2.mjs`（+ `CLICK_MODE`） | L3 定时序列 v2/v3，同源锚点口径 |
| `bench\clicklat2.mjs` + `bench\clicklat2-fixture.ps1` | 协作式 real 点击夹具（+ `bench\keylat\mk-clicklat2.mjs` 生成器） |
| `bench\l1-rerun.mjs` | 把 bench.mjs 原始报告整理成"真值/假达标/自判无效"表 |
| `bench\w1-aggregate.mjs` | 汇总成机读 JSON `D:\dsh-arena\bench-l3-rerun.json` |
| `bench\run-all-w1.ps1` / `run-all-w1b.ps1` | 桌面独占的串行执行脚本（键鼠测量不能并发） |
| `bench\keylat\injector.ps1`（增量） | 新增 `M <x> <y> <click>` 指针注入指令；`keyclient.mjs` 新增 `inj.mouse()` |

### 12.5 收尾

- 所有 `arena-beat.ps1` / `keylat` / `rawsink` / `clicklat-fixture` / `receiver.ps1` 的 powershell 进程已按命令行正则清理（绝不误杀调用者自己）；
- 夹具与靶场窗口逐次 `closeWindow`/进程退出，无残留 TopMost 窗口；本轮结束时清掉了 `PickerHost`(26336)、`计算器`、`SCROLLTEST 记事本`；
- `clicklat-fixture.ps1` 已还原为接手时原样（补丁留档 `clicklat-fixture.patched.bak`），未触碰 CONTROL-BENCH.md；
- 临时文件只在 `D:\dsh-tmp`，产物全部在 `D:\dsh-arena\`。

