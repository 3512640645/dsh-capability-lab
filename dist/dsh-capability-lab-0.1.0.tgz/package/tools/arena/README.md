# DSH Arena —— 自建「操控电脑」靶场（反应 + 瞄准）

一个可被程序化打分、也可被人手玩的 WPF 小靶场：**靶心每次换位置、点中即得分、30 秒一局、结束落盘 JSON**。
存在的理由：判断"操控电脑"能力（反应速度 + 定位精度）不能靠感觉，要有一个能反复跑、能出数、能对比的靶子。

关键设计：**靶心是一个真实 WPF `Button`，带 UIA 元素特征**，所以自动化既能用像素坐标打它，也能走
**元素通道**（`find` 拿到 elementId → `click`/`invoke`）——后者不依赖前台、不受遮挡影响、且能自证命中。

---

## 1. 文件

| 路径 | 作用 |
|---|---|
| `D:\dsh-arena\arena.ps1` | 靶场本体（窗口 + 计分 + 落盘），Windows PowerShell 5.1 / STA |
| `D:\dsh-arena\runs\run-<yyyyMMdd-HHmmss>.json` | 每局结果（UTF-8 无 BOM） |
| `D:\dsh-arena\logs\arena-<时间戳>.log` | 逐事件日志（boot / ROUND start / HIT / MISS / saved / exit），出问题先看它 |
| `D:\dsh-arena\tools\smoke.mjs` | 冒烟自检：拉起窗口 → winctl 枚举 → find target → 元素通道打靶 → 读结果 JSON → 关窗 |
| `D:\dsh-arena\tools\diag.mjs` | UIA 诊断：把窗口暴露的元素逐个打出来（排查"找不到元素"用） |
| `D:\dsh-arena\smoke-report.json` | 冒烟自检的完整报告（每一步的原始返回） |

## 2. 怎么跑

```powershell
# 人在屏幕前玩（30 秒一局，结束停在结算面板，F5 再来一局，Esc 退出）
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File D:\dsh-arena\arena.ps1

# 自动化用：延迟 3 秒开局（留出枚举窗口的时间）、25 秒一局、结束自动关窗
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File D:\dsh-arena\arena.ps1 `
  -Duration 25 -StartDelayMs 3000 -ExitOnFinish

# 冒烟自检（会用真实元素通道把一局打完，然后关窗）
& "C:\Users\35126\AppData\Roaming\dsh-desktop\harness\.desktop-bin\node.cmd" D:\dsh-arena\tools\smoke.mjs
```

> 必须 `-STA`：WPF 需要单线程单元；必须走 `powershell.exe`（Windows PowerShell 5.1）。
> `arena.ps1` 必须存为 **UTF-8 with BOM**，否则 5.1 会按 GBK 读，中文注释把脚本解析坏（见第 6 节）。

### 参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `-Duration` | 30 | 一局秒数 |
| `-Width` `-Height` `-Left` `-Top` | 900 / 620 / 140 / 110 | 窗口尺寸与**固定位置**（不可缩放，保证坐标可预测） |
| `-TargetSize` | 56 | 靶心直径（像素）→ 难度旋钮 |
| `-MinMoveDistance` | 80 | 新靶与上一靶的最小圆心距离 → 防"原地连点"，逼真移动 |
| `-StartDelayMs` | 0 | 窗口出现后延迟开局（自动化先在窗口外准备） |
| `-AutoQuitAfterFinishMs` / `-ExitOnFinish` | 0 / 关 | 结算后自动关窗（跑批用） |
| `-Seed` | 0 | 非 0 = 固定靶位序列，可复现同一局 |

## 3. 计分与指标

* **得分** = 命中次数（点中靶心 +1，并**立刻**刷出下一靶，中间无停顿）。
* **误击** = 点在画布空白处（靶心自身的点击不会冒泡到画布，另有 150ms 去抖）。
* **反应时间** = 上一靶命中（或开局）→ 本次命中 的毫秒数，逐次记录在 `reactionMs` 数组里。
  ⚠️ 走元素通道的自动化打靶时，这个值 = **find + 点击 + 校验的整环开销**（本机实测 ≈1.5s），
  不是纯点击延迟；纯点击/Invoke 分发本身是 ~170ms（见第 5 节）。想要纯人体反应数据就用手玩。
* 结算 JSON 字段：`score / hits / misses / hitRate / avgReactionMs / minReactionMs / maxReactionMs /
  medianReactionMs / p90ReactionMs / reactionMs[] / elapsedMs / aborted`，另附 `window/board/screen/uia` 等环境指纹，
  便于跨机器对比时不串味。

## 4. UIA 契约（自动化接口）

| 查询 | 元素 | 说明 |
|---|---|---|
| `target` | Button，`AutomationId=arenaTarget`，`HelpText="seq <n>"` | **靶心**。只在"一局进行中"可见；不在树里 = 当前没靶 |
| `arena-restart` / `arena-again` | Button | 重开一局 |
| `arena-quit` | Button | 关窗 |
| `得分: N` / `命中: N` / `误击: N` / `平均反应: X ms` / `剩余: Y s` | Text（TxtScore/TxtHits/TxtMiss/TxtAvg/TxtTime） | 实时读数，用于自动校验"点中真的生效了" |
| `本局结束` | Text | 结果面板出现 = 本局结束（可 `wait_for element` 等它） |

典型用法（winctl，元素通道，不碰前台）：

```js
const r = await client.tool('find', { query: 'target', nativeWindowHandle: HWND, ocrFallback: false });
const t = r.data.results.find(x => x.name === 'target');
await client.tool('click', { elementId: t.id, nativeWindowHandle: HWND });   // → background:Invoke
```

## 5. 冒烟自检结果（真实输出，2026-11-07 02:16）

三步要求：**启动 → 枚举到窗口 → find 到 target → 关窗**，全部通过，附带把一局打完（8/8 命中）。

```
===== 3.list_windows =====
{"totalWindowCount":15,"matched":{"title":"DSH Arena","nativeWindowHandle":918634,
 "className":"HwndWrapper[DefaultDomain;Pipeline Execution Thread;57867bac-...]","processId":17912,
 "boundingBox":{"x":140,"y":110,"width":900,"height":620,"centerX":590,"centerY":420}}}

===== 4.find "target" =====
{"found":true,"queryMs":416,"element":{"id":"uia:rt:7-17912-29913414","name":"target",
 "controlType":"Button","automationId":"arenaTarget",
 "boundingBox":{"x":552,"y":155,"width":56,"height":56,"centerX":580,"centerY":183}}}

===== 5.element-channel clicks =====   (method=background:Invoke，无一次真实键鼠)
r1 find=389ms click=354ms 靶心(580,183) → 得分: 1 | 命中: 1
r2 find=383ms click=169ms 靶心(270,645) → 得分: 2 | 命中: 2
...                                         （每靶都在换位置，中心坐标逐次不同）
r8 find=378ms click=167ms 靶心(528,238) → 得分: 8 | 命中: 8

===== 6.round-end panel ===== {"resultPanelVisible":true}
===== 7.run json ===== run-20261107-021633.json
 {"score":8,"hits":8,"misses":0,"hitRate":1,"avgReactionMs":1507.1,"minReactionMs":1459,
  "maxReactionMs":1706,"p90ReactionMs":1706,"elapsedMs":25039,"aborted":false}
===== 8.close_window ===== {"posted":true,"windowGone":true,"arenaProcStillAlive":false}
```

关窗后复查：`diag.mjs` 报 `DSH Arena windows: []`，所有 `logs\arena-*.log` 末尾均为 `WINDOW closing → ARENA exit`
（无残留窗口/进程）。完整原始返回见 `smoke-report.json`。

## 6. 施工中真实踩到的两个坑（都已修）

1. **`arena.ps1` 存 UTF-8 无 BOM → 脚本直接解析失败**。Windows PowerShell 5.1 对无 BOM 的 `.ps1`
   按 ANSI(GBK) 解码，中文注释里的字节把引号配对搞错：
   `L259 意外的标记"ROUND" / L341 字符串缺少终止符` —— 同一个文件用 UTF-8 读进来解析却是 `OK`。
   修法：写盘时用 `UTF8Encoding($true)` 带 BOM。**同理 JSON 不能带 BOM**，否则严格解析器报错，
   所以结果文件改用 `[IO.File]::WriteAllText(..., UTF8Encoding($false))`。
2. **"延迟开局"的 DispatcherTimer 把进程搞崩**。在 `Loaded` 处理器里 `$d = New-Object DispatcherTimer`、
   再 `$d.Add_Tick({ $d.Stop(); Start-Round })`，等到 tick 触发时 `$d` 解析成了一个**字符串**：
   `使用"0"个参数调用"ShowDialog"时发生异常:方法调用失败，因为 [System.String] 不包含名为"Stop"的方法` ——
   窗口出现 3 秒后进程直接消失（日志停在 `ROUND delayed by 3000ms`，没有 exit 行，正是"崩"，不是"关"）。
   修法：定时器一律放脚本作用域（`$script:delayTimer` / `$script:quitTimer`），并给每个事件处理器套 try/catch +
   `Dispatcher.Add_UnhandledException` 落盘，异常从"窗口莫名消失"变成日志里一行可读错误。

## 7. 怎么扩成别的玩法

* **难度档**：`-TargetSize 24 -MinMoveDistance 300 -Duration 20` → 小靶+大幅移动。
* **固定关卡/可复现**：`-Seed 12345`，同一个靶位序列每次一致，便于 A/B 两条通道打同一局。
* **多目标/干扰靶**：复制 XAML 里那个 `Button`（`x:Name="Target2"`，`AutomationProperties.Name="decoy"`），
  在 `Spawn-Target` 里同时摆位；奖励靶 `target` 计 +1、干扰靶 `decoy` 计 -1（在各自 `Add_Click` 里加分支）。
* **移动靶**：加一个 20ms 的 `DispatcherTimer`，每 tick 给靶心 `Canvas.Left/Top` 做匀速位移/正弦轨迹
  （注意：这会显著抬高标准，"反应+瞄准"变成"预判"）。
* **限时/限弹**：`Update-Hud` 里加 `-ShotsLimit`，命中率与"每靶耗时"导出到 JSON 新字段。
* **换通道对比**：同一局用 `-Seed` 固定，A 通道走 `click {x,y}` 坐标真实点击，B 通道走 `click {elementId}` 元素通道，
  对比"命中率/单步耗时/自证能力"——这正是 winctl 基准那套方法论（元素优先、动作后校验）。
* **接成常驻评测**：把 `smoke.mjs` 的循环参数化（局数、通道、难度），把每局 JSON 汇总成 `score/avg/p90` 趋势表。

## 8. 已知局限

* 单显示器 1440×900、缩放 1.0 下实测；多屏/高 DPI 未验证（靶心坐标是 WPF 逻辑像素，屏幕坐标由系统换算）。
* 反应时间是"整环"口径（含 find + 点击 + 校验），跨通道对比时必须写清走的是哪条通道，否则数字不可比。
* 元素通道的 `click` 落在 WPF Button 上走的是 `Invoke` 模式：**它不产生真实鼠标事件**，因此无法用来测
  "真实输入延迟"；要测真实输入延迟，让 `smoke.mjs` 改用 `dispatch:'foreground'` 或坐标点击。
