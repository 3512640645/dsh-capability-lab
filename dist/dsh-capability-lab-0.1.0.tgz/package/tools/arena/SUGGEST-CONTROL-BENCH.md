# 给 CONTROL-BENCH.md 的补丁建议（W1 → 主会话）

> 目标文件：`D:\dsh-tools\CONTROL-BENCH.md`（6162B，117 行）。**我不改它，只给补丁。**
> 依据：`D:\dsh-arena\bench\keylat\keylat.json` + §5.1（`BENCH-L3.md`），2026-11-07 04:16–04:49 实测，同机 QPC，跨进程。
> 结论一句话：**"按键慢"不是 Windows 慢，是插件在注入之前花的钱。** 现有 4 处口径要改。

---

## 补丁 1 · 第 55–64 行「按键投递必须单列」

**改哪几行**：把 57–61 行的表**整表替换**为下面的表；63–64 行的判据补充**改写**。

| 动作 | 上一轮实测（插件通道） | **本轮实测：投递本体** | 差额是什么 |
|---|---|---|---|
| 鼠标点击 | 73–75ms | 指针 PostMessage WM_LBUTTONDOWN 0.50ms（SendInput 点击本轮未打通，见下） | 插件前置 + 前台切换 |
| 前台真实按键（SendInput/keybd_event） | 158–188ms | **0.53–0.65ms**（p90 ≤0.94ms，最大 1.23ms） | 插件前置 + `Set-WindowForeground` 的 60/80/120ms sleep |
| 后台 WM_CHAR 投递（PostMessage） | 200ms | **0.17–0.33ms**（p90 ≤1.0ms，最大 2.2ms；gap=0 连发 100 个 100/100 不丢） | 插件前置 + 每字符 5ms sleep |
| 常驻注入器（Node→常驻进程→注入） | — | **端到端中位 0.56–0.80ms，p90 ≤1.35ms** | 只有首条指令冷启动 86–157ms |

**判据补充（改写建议）**：
> L3 若要宣称"能玩需要键盘的游戏"，**必须额外满足「按键投递 ≤100ms（口径③，见 BENCH-L3 §1）」**。
> 判据本身**已可达标**（常驻注入器实测 0.6–0.8ms，余量 100 倍以上）；当前未达标的是**插件实现**——
> 它把窗口解析、前台切换、`SendKeys`/`Start-Sleep` 都算在"按键延迟"里。所以判据保留，但必须写明：
> **要么改插件加一条免激活的 raw 快路径，要么把按键交给常驻注入器**；不许用"Windows 就这样"当结论。

**为什么**：这三行现在是"插件延迟"冒充"投递延迟"。不分开写，后面要么把插件优化当成不可能，
要么把 0.2ms 的投递能力当成已经达标 —— 两种误判都会让 L3 的键鼠结论失真。

---

## 补丁 2 · 第 44–53 行「偏差必须分两种口径」

**改哪几行**：50–51 行两行数据行**各加一列「扣掉投递延迟后的净额」**；53 行后面**加一句公式**。

| 口径 | 定义 | 实测 | 结论 |
|---|---|---|---|
| 相对首拍偏差（调度精度） | 两边各用自家单调时钟 | 中位 27.6ms / p90 68.1ms / 最大 72.1ms | ✅ <100ms |
| 绝对墙钟迟到（含投递延迟） | 靶场时刻 − 客户端计划时刻 | 中位 101.8ms / 最大 146.4ms | ❌ 超 100ms |
| **（新增列）净调度 = 迟到 − 该通道投递延迟** | 点击扣 ≈73ms、按键扣 ≈158–296ms | 点击≈29ms、按键≈−（投递本身更大） | 说明**超标的成分在投递，不在调度** |

**要加的那句**：`口径② ≈ 口径① + 按键投递延迟 + 排队抖动`，三者必须分别报。
**为什么**：现在 101.8/146.4ms 这个数会被读成"调度器不准"，实际调度只占 27.6/72.1ms；
本轮实测的 296–604ms 更把这条差额放大到肉眼可见（到达延迟≈插件调用耗时）。

---

## 补丁 3 · 第 36–42 行 L3 判据表 + 第 89–100 行报告格式

**改哪几行**：L3 表加一行；报告 JSON 加三个字段。

| 指标 | 判据 | 口径必须写清 |
|---|---|---|
| **按键投递延迟（新增·独立判据）** | **≤100ms**（中位），且必须同时报 **loss**（丢键数） | 口径③：单键"发出调用→目标收到 WM_KEYDOWN/WM_CHAR"，同机 QPC |

```jsonc
"inputPathDetail": {
  "keyPath": "postmessage-combo-sc | sendinput-vk | sendkeys | plugin:keypress-bg | …",
  "keyLatencyMs": { "med": 0.7, "p90": 1.1, "max": 1.4 },   // 必须给分布，不给单值
  "keyLoss": 0,                                             // 发 100 收到多少
  "foregroundRequired": false,                              // 是否需要抢前台
  "targetAcceptsWindowMessages": true                       // false = DirectInput 类目标，PostMessage 会被忽略
}
```
**为什么**：现在报告格式里没有任何地方能记录"用了哪条按键通道、丢没丢、要不要前台"。
本轮已实测到**后台 SendInput 100% 丢键且不报错**（目标 0/100，全部落到前台窗口），
只报中位延迟会把这种失败藏起来。

---

## 补丁 4 · 第 109–117 行「已知限制」

**改哪几行**：表格末尾**追加 4 行**。

| 限制 | 后果 | 应对 |
|---|---|---|
| `SendInput/keybd_event` 不认目标窗口，只认前台+焦点 | 失焦时 100% 丢键，**且不报错**；是否"看起来还好"取决于前台窗口是不是目标 | 用 `PostMessage WM_KEYDOWN(带扫描码)+WM_CHAR+WM_KEYUP`，或先确认前台再发 |
| `PostMessage` 直投会被 DirectInput/原始输入程序忽略 | 后台字符投递"100% 到达"≠"游戏收到了" | 目标只用窗口消息时用 PostMessage；游戏内必须 `SendInput` + 保持前台 |
| 共享桌面：第三方模态弹窗 / TopMost 窗口 | 指针命中直接失败（`POINT_COVERED`/`WindowFromPoint` 落到 Progman），偶发 1–2% 丢键 | 投递类判据在独占前台跑；命中测试前先做遮盖自检 |
| WinForms 夹具"进程内第一个 `Show()` 的窗体"停在 `IsWindowVisible=false` | 指针/坐标点击全废，但按键消息照常到达（易误判成"按键正常指针也正常"） | 夹具启动即自检可见性（`IsWindowVisible` + `WindowFromPoint`） |

**为什么**：这四条本轮各踩到一次，且都会**静默**产生错数据（不报错、不崩溃，只是数不对）。

---

## 另附：给主会话的两个可执行选项（二选一或都做）

1. **改插件（推荐，治本）**：在 `wcu/package/scripts/windows-uia.ps1` 给 `keypress`/`type_text` 增加免激活通道，
   例如 `dispatch:'raw'` + `nativeWindowHandle`：直接 `SendInput`（已在前后台）或 `PostMessage WM_KEYDOWN(扫描码)+WM_CHAR+WM_KEYUP`，
   **跳过** `Set-WindowForeground`(60/80/120ms sleep) 与 `Start-Input`；批量字符去掉 `Post-BackgroundText` 的 5ms/字符。
2. **接常驻注入器（治标但立刻可用）**：把 `D:\dsh-arena\bench\keylat\sender.ps1` 起成常驻进程（先预热一条），
   Node 侧每键写一行 JSON；实测端到端 0.56–0.80ms。代价：多一条常驻进程，且需要自己维护目标 HWND。

## 复现（原文命令，输出见 BENCH-L3 §5.1 / §9）

```powershell
$env:TEMP='D:\dsh-tmp'; $env:TMP='D:\dsh-tmp'
& node D:\dsh-arena\bench\keylat\keylat-native.mjs 100 25   # 原始路径全量
& node D:\dsh-arena\bench\keylat\keylat-fast.mjs 30 150     # 常驻注入器端到端
& node D:\dsh-arena\bench\keylat\keylat-plugin.mjs 12       # 插件真实路径
& node D:\dsh-arena\bench\keylat\keylat-ab.mjs 8            # 两接收器交错 A/B
& node D:\dsh-arena\bench\keylat\keylat-report.mjs          # 汇总 keylat.json
```
