﻿<#
  DSH Arena - BEAT MODE (arena-beat.ps1)

  Why: L3 evidence for the timed-sequence criterion in D:\dsh-tools\CONTROL-BENCH.md.
  A WPF window that timestamps every real mouse-down / key-down it receives with a
  Stopwatch at sub-millisecond resolution, captured inside compiled C# event handlers
  (a PowerShell event handler would add several ms of script invocation jitter into the
  measurement path itself).

  ASCII only on purpose: Windows PowerShell 5.1 decodes a BOM-less .ps1 as ANSI/GBK,
  so non-ASCII text in this file could corrupt the parse. This file is written as
  UTF-8 with BOM as well (belt and braces).

  JSONL output (UTF-8, no BOM), one JSON object per line:
    {"kind":"header", ...}
    {"kind":"mouse","n":1,"swMs":1234.567,"x":512.0,"y":300.0,"button":"Left","clicks":1}
    {"kind":"key","n":1,"swMs":2222.001,"vk":87,"key":"W"}
    {"kind":"marker","name":"...","swMs":...,"wallUtcIso":"..."}

  The Stopwatch starts inside Attach(); the header records the wall clock read
  immediately after that start, plus the measured granularity of DateTime.UtcNow on
  this machine (wallGrainMs) so the cross-clock check can state its own uncertainty.

  Usage:
    powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File D:\dsh-arena\arena-beat.ps1 `
      -OutJsonl D:\dsh-arena\bench\l3-beats.jsonl -ExitAfterMs 90000
#>
[CmdletBinding()]
param(
  [int]$Width = 900,
  [int]$Height = 620,
  [int]$Left = 140,
  [int]$Top = 110,
  [string]$OutJsonl = 'D:\dsh-arena\bench\beats.jsonl',
  [string]$LogFile = '',
  [int]$ExitAfterMs = 60000,
  [switch]$NotTopmost
)

$ErrorActionPreference = 'Stop'

$logsDir = 'D:\dsh-arena\logs'
$outDir = Split-Path -Parent $OutJsonl
if (-not $outDir) { $outDir = 'D:\dsh-arena\bench' }
foreach ($d in @($outDir, $logsDir)) { if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null } }
if (-not $LogFile) { $LogFile = Join-Path $logsDir ('arena-beat-{0}.log' -f (Get-Date -Format 'yyyy-MM-dd-HHmmss')) }
$script:LogPath = $LogFile

function Write-Log([string]$m) {
  try { Add-Content -LiteralPath $script:LogPath -Value ('{0} {1}' -f (Get-Date -Format 'HH:mm:ss.fff'), $m) -Encoding UTF8 } catch { }
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms

$beatCs = @'
using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Input;

public static class BeatTap {
    static readonly Stopwatch _sw = new Stopwatch();
    static StreamWriter _w;
    static readonly object _g = new object();
    public static int MouseCount = 0;
    public static int KeyCount = 0;
    public static int TextCount = 0;
    public static double LastMouseMs = -1.0;

    static string F(double v, string f) { return v.ToString(f, CultureInfo.InvariantCulture); }

    public static void Attach(Window win, string path, string extraJson) {
        _w = new StreamWriter(path, false, new UTF8Encoding(false));
        _w.NewLine = "\n";
        _w.AutoFlush = true;
        long qpcZero = Stopwatch.GetTimestamp();   // 同机全局 QPC 锚点（跨进程可比），供外部注入器算投递延迟
        _sw.Start();
        DateTime wall = DateTime.UtcNow;
        MeasureGrain();
        long unixMs = (long)(wall - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
        _w.WriteLine("{\"kind\":\"header\",\"schema\":\"dsh-arena/beats/1\""
            + ",\"swZeroWallUtcIso\":\"" + wall.ToString("o", CultureInfo.InvariantCulture) + "\""
            + ",\"swZeroUnixMs\":" + unixMs
            + ",\"swZeroQpc\":" + qpcZero
            + ",\"qpcFreq\":" + Stopwatch.Frequency
            + ",\"wallGrainMs\":" + F(GrainFirst, "F3")
            + ",\"wallGrainWorstMs\":" + F(GrainWorst, "F3") + extraJson + "}");
        win.PreviewMouseDown += delegate(object s, MouseButtonEventArgs e) {
            double ms = _sw.Elapsed.TotalMilliseconds;
            Point p = e.GetPosition(win);
            lock (_g) {
                MouseCount++;
                LastMouseMs = ms;
                _w.WriteLine("{\"kind\":\"mouse\",\"n\":" + MouseCount
                    + ",\"swMs\":" + F(ms, "F3")
                    + ",\"x\":" + F(p.X, "F1") + ",\"y\":" + F(p.Y, "F1")
                    + ",\"button\":\"" + e.ChangedButton + "\",\"clicks\":" + e.ClickCount + "}");
            }
        };
        win.PreviewTextInput += delegate(object s, TextCompositionEventArgs e) {
            double ms = _sw.Elapsed.TotalMilliseconds;
            string txt = e.Text ?? "";
            string esc = "";
            foreach (char c in txt) esc += "\\u" + ((int)c).ToString("x4");
            lock (_g) {
                TextCount++;
                _w.WriteLine("{\"kind\":\"text\",\"n\":" + TextCount
                    + ",\"swMs\":" + F(ms, "F3")
                    + ",\"text\":\"" + txt.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\",\"esc\":\"" + esc + "\"}");
            }
        };
        win.PreviewKeyDown += delegate(object s, KeyEventArgs e) {
            double ms = _sw.Elapsed.TotalMilliseconds;
            int vk = (int)(e.Key == Key.System ? e.SystemKey : e.Key);
            lock (_g) {
                KeyCount++;
                _w.WriteLine("{\"kind\":\"key\",\"n\":" + KeyCount
                    + ",\"swMs\":" + F(ms, "F3")
                    + ",\"vk\":" + vk + ",\"key\":\"" + e.Key + "\"}");
            }
        };
    }

    public static double GrainFirst = -1.0;
    public static double GrainWorst = -1.0;

    // DateTime.UtcNow advances in steps (the system clock update interval). Busy-spin until
    // the first step is seen, then sample a window of steps: GrainFirst = typical step,
    // GrainWorst = largest step seen. Both are reported in the header so the cross-clock
    // check can state its own quantization uncertainty.
    public static void MeasureGrain() {
        DateTime a = DateTime.UtcNow;
        long guard = 0;
        while (GrainFirst < 0 && guard++ < 60000000L) {
            DateTime b = DateTime.UtcNow;
            double d = (b - a).TotalMilliseconds;
            if (d > 0) { GrainFirst = d; GrainWorst = d; }
            a = b;
        }
        for (int i = 0; i < 200000; i++) {
            DateTime b = DateTime.UtcNow;
            double d = (b - a).TotalMilliseconds;
            if (d > GrainWorst) GrainWorst = d;
            a = b;
        }
    }

    public static void Marker(string name) {
        lock (_g) {
            if (_w == null) return;
            _w.WriteLine("{\"kind\":\"marker\",\"name\":\"" + name + "\",\"swMs\":" + F(_sw.Elapsed.TotalMilliseconds, "F3")
                + ",\"wallUtcIso\":\"" + DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture) + "\"}");
        }
    }

    public static void Flush() { lock (_g) { try { if (_w != null) _w.Flush(); } catch { } } }
    public static void CloseFile() { lock (_g) { try { if (_w != null) { _w.Flush(); _w.Dispose(); _w = null; } } catch { } } }
}
'@

Add-Type -TypeDefinition $beatCs -ReferencedAssemblies 'PresentationCore','PresentationFramework','WindowsBase','System.Xaml'

$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:a="clr-namespace:System.Windows.Automation;assembly=PresentationCore"
        Title="DSH Arena"
        ResizeMode="NoResize"
        WindowStartupLocation="Manual"
        Background="#FF0B1118"
        FontFamily="Consolas, Microsoft YaHei UI"
        FontSize="15">
  <Grid Margin="10">
    <Grid.RowDefinitions>
      <RowDefinition Height="*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>
    <Canvas x:Name="Board" Grid.Row="0" Background="#FF0E1720" ClipToBounds="True"
            a:AutomationProperties.Name="arena-board" a:AutomationProperties.AutomationId="arenaBoard">
      <Button x:Name="Target" Width="80" Height="80" Focusable="False" Cursor="Cross"
              a:AutomationProperties.Name="target"
              a:AutomationProperties.AutomationId="arenaTarget"
              a:AutomationProperties.HelpText="beat-mode">
        <Button.Template>
          <ControlTemplate TargetType="Button">
            <Grid>
              <Ellipse Fill="#FFE8452C" Stroke="#FFFFFFFF" StrokeThickness="3"/>
              <Ellipse Width="16" Height="16" Fill="#FFFFFFFF" Opacity="0.92"
                       HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Grid>
          </ControlTemplate>
        </Button.Template>
      </Button>
    </Canvas>
    <Grid Grid.Row="1" Margin="0,8,0,0">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="Auto"/>
        <ColumnDefinition Width="*"/>
        <ColumnDefinition Width="Auto"/>
      </Grid.ColumnDefinitions>
      <TextBlock x:Name="TxtBeats" Grid.Column="0" Margin="0,0,16,0" Foreground="#FFE8452C" FontWeight="Bold" Text="mouse: 0  key: 0  last: - ms"/>
      <TextBlock x:Name="TxtHint" Grid.Column="1" Foreground="#FFB9C7D4" Text="beat mode: 只记录鼠标按下/按键到达时刻（Esc 关闭）"/>
      <Button x:Name="BtnQuit" Grid.Column="2" Content="关闭(Esc)" Padding="10,2"
              a:AutomationProperties.Name="arena-quit" a:AutomationProperties.AutomationId="arenaQuit"/>
    </Grid>
  </Grid>
</Window>
'@

$win = [System.Windows.Markup.XamlReader]::Parse($xaml)
$win.Left = $Left; $win.Top = $Top; $win.Width = $Width; $win.Height = $Height
if (-not $NotTopmost) { $win.Topmost = $true }

$board = $win.FindName('Board')
$target = $win.FindName('Target')
$txtBeats = $win.FindName('TxtBeats')

# static target, placed at board centre (clicks that land on it are still logged by the
# window-level PreviewMouseDown handler; this only exists so the window has the same
# UIA surface as the other arena scripts)
$script:beatXaml = $true

$script:hudTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:hudTimer.Interval = [TimeSpan]::FromMilliseconds(500)
$script:quitTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:quitTimer.Interval = [TimeSpan]::FromMilliseconds([math]::Max(1000, $ExitAfterMs))

$script:hudTimer.Add_Tick({
    try {
      $txtBeats.Text = ('mouse: {0}  key: {1}  last: {2} ms' -f [BeatTap]::MouseCount, [BeatTap]::KeyCount, [math]::Round([BeatTap]::LastMouseMs, 1))
    } catch { }
  })
$script:quitTimer.Add_Tick({ try { $script:quitTimer.Stop(); Write-Log 'EXIT timer firing'; $win.Close() } catch { } })

$win.FindName('BtnQuit').Add_Click({ try { $win.Close() } catch { } })
$win.Add_KeyDown({ try { if ($_.Key -eq 'Escape') { $win.Close() } } catch { } })

$win.Dispatcher.Add_UnhandledException({
    try { Write-Log ('FATAL dispatcher: ' + $_.Exception.ToString()); $_.Handled = $true } catch { }
  })

$win.Add_Loaded({
    try {
      $p = $board.PointToScreen((New-Object System.Windows.Point(0, 0)))
      $extra = ',"pid":' + $PID + ',"host":"' + $env:COMPUTERNAME + '"'
      $extra += ',"outJsonl":"' + ($OutJsonl.Replace('\', '/')) + '"'
      $extra += ',"window":{"left":' + $Left + ',"top":' + $Top + ',"width":' + $Width + ',"height":' + $Height + '}'
      $extra += ',"boardOriginScreen":{"x":' + [math]::Round($p.X, 1) + ',"y":' + [math]::Round($p.Y, 1) + '}'
      $extra += ',"boardSize":{"width":' + [int]$board.ActualWidth + ',"height":' + [int]$board.ActualHeight + '}'
      $extra += ',"hwnd":' + (New-Object System.Windows.Interop.WindowInteropHelper($win)).Handle
      [BeatTap]::Attach($win, $OutJsonl, $extra)
      [System.Windows.Controls.Canvas]::SetLeft($target, [math]::Max(0, ([double]$board.ActualWidth / 2) - 40))
      [System.Windows.Controls.Canvas]::SetTop($target, [math]::Max(0, ([double]$board.ActualHeight / 2) - 40))
      $script:hudTimer.Start()
      $script:quitTimer.Start()
      Write-Log ('BEAT attached out={0} pid={1}' -f $OutJsonl, $PID)
    } catch { Write-Log ('ERROR loaded: ' + $_.Exception.ToString()) }
  })

$win.Add_Closing({
    try { Write-Log 'WINDOW closing'; [BeatTap]::Marker('closing'); [BeatTap]::Flush(); [BeatTap]::CloseFile() }
    catch { }
  })

Write-Log ('ARENA-BEAT boot pid={0} win={1}x{2}@({3},{4}) topmost={5} out={6}' -f $PID, $Width, $Height, $Left, $Top, (-not $NotTopmost), $OutJsonl)
[void]$win.ShowDialog()
Write-Log 'ARENA-BEAT exit'
