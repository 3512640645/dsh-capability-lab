﻿<#
  DSH Arena —— 自建「操控电脑」能力靶场（反应 + 瞄准）

  设计要点
    · WPF 窗口，标题固定 "DSH Arena"，固定出现在屏幕固定位置（-Left/-Top），禁止缩放。
    · 靶心是一个 **真实 WPF Button**（圆形模板），具备 UIA 元素特征：
        AutomationProperties.Name = "target"（所有目标都叫这个名字）
        AutomationProperties.AutomationId = "arenaTarget"
        AutomationProperties.HelpText   = "seq <n>"（每次刷新递增，便于比对"是不是同一个目标"）
      → winctl / UIA 的元素通道可以直接 find + invoke/click 点它，不必靠像素坐标。
      注：只在"一局进行中"时 Visible —— 不在树里就代表当前没有靶。
    · 命中：得分 +1、命中数 +1、记录反应时间，并**立刻**刷新下一个目标（无停顿）。
    · 空点（点在画布空白处）：误击 +1。
    · 一局 30s（-Duration 可调），结束时把结果 JSON 写入 <RunsDir>\run-<时间戳>.json。

  用法见同目录 README.md
#>
[CmdletBinding()]
param(
  [int]$Duration = 30,
  [int]$Width = 900,
  [int]$Height = 620,
  [int]$Left = 140,
  [int]$Top = 110,
  [int]$TargetSize = 56,
  [int]$MinMoveDistance = 80,      # 新目标与上一个目标的圆心最小距离（像素），逼"必须移动"而不是原地连点
  [int]$StartDelayMs = 0,          # 窗口出现后延迟开局（给自动化留出枚举窗口的时间）
  [int]$AutoQuitAfterFinishMs = 0, # 一局结束后 N ms 自动关窗；0 = 不自动关
  [int]$Seed = 0,                  # 0 = 用时间种子；非 0 = 确定性复现同一串靶位
  [string]$RunsDir = 'D:\dsh-arena\runs',
  [string]$LogFile = '',
  [switch]$ExitOnFinish
)

$ErrorActionPreference = 'Stop'

if ($ExitOnFinish -and $AutoQuitAfterFinishMs -le 0) { $AutoQuitAfterFinishMs = 800 }

$root    = 'D:\dsh-arena'
$logsDir = Join-Path $root 'logs'
foreach ($d in @($RunsDir, $logsDir)) { if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null } }
if (-not $LogFile) { $LogFile = Join-Path $logsDir ('arena-{0}.log' -f (Get-Date -Format 'yyyy-MM-dd-HHmmss')) }
$script:LogPath = $LogFile

function Write-Log([string]$m) {
  $line = '{0} {1}' -f (Get-Date -Format 'HH:mm:ss.fff'), $m
  try { Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8 } catch { }
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

$screen = [System.Windows.Forms.Screen]::PrimaryScreen

$script:rng = if ($Seed -ne 0) { New-Object System.Random($Seed) } else { New-Object System.Random }

$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:a="clr-namespace:System.Windows.Automation;assembly=PresentationCore"
        Title="DSH Arena"
        ResizeMode="NoResize"
        WindowStartupLocation="Manual"
        Background="#FF0B1118"
        FontFamily="Consolas, Microsoft YaHei UI"
        FontSize="15">
  <Grid Margin="10">
    <Grid.RowDefinitions>
      <RowDefinition Height="*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>

    <Canvas x:Name="Board" Grid.Row="0" Background="#FF0E1720" ClipToBounds="True"
            a:AutomationProperties.Name="arena-board" a:AutomationProperties.AutomationId="arenaBoard">
      <Button x:Name="Target"
              Width="56" Height="56" Focusable="False" Cursor="Cross" Visibility="Hidden"
              a:AutomationProperties.Name="target"
              a:AutomationProperties.AutomationId="arenaTarget"
              a:AutomationProperties.HelpText="seq 0">
        <Button.Template>
          <ControlTemplate TargetType="Button">
            <Grid>
              <Ellipse Fill="#FFE8452C" Stroke="#FFFFFFFF" StrokeThickness="3"/>
              <Ellipse Width="16" Height="16" Fill="#FFFFFFFF" Opacity="0.92"
                       HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Grid>
          </ControlTemplate>
        </Button.Template>
      </Button>
    </Canvas>

    <Grid Grid.Row="1" Margin="0,8,0,0">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="Auto"/>
        <ColumnDefinition Width="Auto"/>
        <ColumnDefinition Width="Auto"/>
        <ColumnDefinition Width="Auto"/>
        <ColumnDefinition Width="*"/>
        <ColumnDefinition Width="Auto"/>
        <ColumnDefinition Width="Auto"/>
      </Grid.ColumnDefinitions>
      <TextBlock x:Name="TxtScore" Grid.Column="0" Margin="0,0,18,0" Foreground="#FFE8452C" FontWeight="Bold" Text="得分: 0"/>
      <TextBlock x:Name="TxtHits"  Grid.Column="1" Margin="0,0,18,0" Foreground="#FFB9C7D4" Text="命中: 0"/>
      <TextBlock x:Name="TxtMiss"  Grid.Column="2" Margin="0,0,18,0" Foreground="#FFB9C7D4" Text="误击: 0"/>
      <TextBlock x:Name="TxtAvg"   Grid.Column="3" Margin="0,0,18,0" Foreground="#FFB9C7D4" Text="平均反应: - ms"/>
      <TextBlock x:Name="TxtTime"  Grid.Column="5" Margin="0,0,18,0" Foreground="#FF7FD1AE" Text="剩余: -- s"/>
      <StackPanel Grid.Column="6" Orientation="Horizontal">
        <Button x:Name="BtnRestart" Content="重开(F5)" Padding="10,2" Margin="0,0,8,0"
                a:AutomationProperties.Name="arena-restart" a:AutomationProperties.AutomationId="arenaRestart"/>
        <Button x:Name="BtnQuit" Content="退出(Esc)" Padding="10,2"
                a:AutomationProperties.Name="arena-quit" a:AutomationProperties.AutomationId="arenaQuit"/>
      </StackPanel>
    </Grid>

    <Border x:Name="ResultPanel" Grid.RowSpan="2" Background="#E6000000" Visibility="Collapsed">
      <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center">
        <TextBlock x:Name="TxtResultTitle" Foreground="#FFFFFFFF" FontSize="26" FontWeight="Bold" HorizontalAlignment="Center" Text="本局结束"/>
        <TextBlock x:Name="TxtResult" Foreground="#FFE8EEF4" FontSize="16" Margin="0,12,0,0" HorizontalAlignment="Center" Text=""/>
        <TextBlock x:Name="TxtResultPath" Foreground="#FF7FD1AE" FontSize="13" Margin="0,10,0,0" HorizontalAlignment="Center" Text=""/>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,16,0,0">
          <Button x:Name="BtnAgain" Content="再来一局(F5)" Padding="14,4" Margin="0,0,10,0"
                  a:AutomationProperties.Name="arena-again" a:AutomationProperties.AutomationId="arenaAgain"/>
        </StackPanel>
      </StackPanel>
    </Border>
  </Grid>
</Window>
'@

$win = [System.Windows.Markup.XamlReader]::Parse($xaml)
$win.Left   = $Left
$win.Top    = $Top
$win.Width  = $Width
$win.Height = $Height

$board = $win.FindName('Board')
$target = $win.FindName('Target')
$txtScore = $win.FindName('TxtScore')
$txtHits = $win.FindName('TxtHits')
$txtMiss = $win.FindName('TxtMiss')
$txtAvg = $win.FindName('TxtAvg')
$txtTime = $win.FindName('TxtTime')
$panel = $win.FindName('ResultPanel')
$txtResult = $win.FindName('TxtResult')
$txtResultPath = $win.FindName('TxtResultPath')

# ── 状态（全部放脚本作用域：事件处理里只用 $script:xxx） ────────────────
$script:score = 0
$script:hits = 0
$script:misses = 0
$script:reactions = @()
$script:seq = 0
$script:lastX = -1
$script:lastY = -1
$script:spawnWatch = [System.Diagnostics.Stopwatch]::StartNew()
$script:roundWatch = [System.Diagnostics.Stopwatch]::StartNew()
$script:roundStart = Get-Date
$script:roundId = ''
$script:running = $false
$script:lastHitWhen = [datetime]::MinValue
$script:lastRunFile = ''
$script:quitTimer = $null
$script:delayTimer = $null

$script:timer = New-Object System.Windows.Threading.DispatcherTimer
$script:timer.Interval = [TimeSpan]::FromMilliseconds(50)

function Get-ReactionStats {
  $r = @($script:reactions | Where-Object { $null -ne $_ })
  if ($r.Count -eq 0) { return [ordered]@{ avg = $null; min = $null; max = $null; median = $null; p90 = $null } }
  $sorted = @($r | Sort-Object)
  $avg = [math]::Round((($r | Measure-Object -Average).Average), 1)
  $p90idx = [math]::Min($sorted.Count - 1, [int][math]::Ceiling($sorted.Count * 0.9) - 1)
  if ($p90idx -lt 0) { $p90idx = 0 }
  return [ordered]@{
    avg    = $avg
    min    = [int]$sorted[0]
    max    = [int]$sorted[$sorted.Count - 1]
    median = [int]$sorted[[int][math]::Floor($sorted.Count / 2)]
    p90    = [int]$sorted[$p90idx]
  }
}

function Update-Hud {
  $st = Get-ReactionStats
  $txtScore.Text = '得分: {0}' -f $script:score
  $txtHits.Text  = '命中: {0}' -f $script:hits
  $txtMiss.Text  = '误击: {0}' -f $script:misses
  $avgShown = $(if ($null -eq $st.avg) { '-' } else { [string]$st.avg })
  $txtAvg.Text = ('平均反应: {0} ms' -f $avgShown)
  if ($script:running) {
    $rem = [math]::Max(0, $Duration - $script:roundWatch.Elapsed.TotalSeconds)
    $txtTime.Text = '剩余: {0:N1} s' -f $rem
  } else {
    $txtTime.Text = '剩余: -- s'
  }
}

function Spawn-Target {
  $bw = [double]$board.ActualWidth
  $bh = [double]$board.ActualHeight
  if ($bw -lt $TargetSize -or $bh -lt $TargetSize) { $bw = 864; $bh = 529 }
  $maxX = [math]::Max(2, [int]($bw - $TargetSize - 2))
  $maxY = [math]::Max(2, [int]($bh - $TargetSize - 2))

  $x = 1; $y = 1
  for ($i = 0; $i -lt 60; $i++) {
    $x = $script:rng.Next(1, $maxX)
    $y = $script:rng.Next(1, $maxY)
    if ($script:lastX -lt 0) { break }
    $dx = $x - $script:lastX; $dy = $y - $script:lastY
    if ([math]::Sqrt($dx * $dx + $dy * $dy) -ge $MinMoveDistance) { break }
  }
  $script:lastX = $x; $script:lastY = $y
  $script:seq++
  [System.Windows.Controls.Canvas]::SetLeft($target, [double]$x)
  [System.Windows.Controls.Canvas]::SetTop($target, [double]$y)
  [System.Windows.Automation.AutomationProperties]::SetHelpText($target, ('seq {0}' -f $script:seq))
  $target.Visibility = 'Visible'
  $script:spawnWatch.Restart()
}

function Start-Round {
  $script:score = 0; $script:hits = 0; $script:misses = 0; $script:reactions = @()
  $script:seq = 0; $script:lastX = -1; $script:lastY = -1
  $script:roundStart = Get-Date
  $script:roundId = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
  $script:roundWatch.Restart()
  $panel.Visibility = 'Collapsed'
  $script:running = $true
  Spawn-Target
  Update-Hud
  $script:timer.Start()
  Write-Log ('ROUND start id={0} duration={1}s win=({2},{3},{4}x{5}) board={6}x{7} target={8}px' -f `
      $script:roundId, $Duration, $Left, $Top, $Width, $Height, [int]$board.ActualWidth, [int]$board.ActualHeight, $TargetSize)
}

function Save-Run([bool]$aborted) {
  $st = Get-ReactionStats
  $file = Join-Path $RunsDir ('run-{0}.json' -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
  $obj = [ordered]@{
    schema            = 'dsh-arena/run/1'
    arena             = 'DSH Arena'
    roundId           = $script:roundId
    aborted           = $aborted
    startedAt         = $script:roundStart.ToString('o')
    endedAt           = (Get-Date).ToString('o')
    durationSec       = $Duration
    elapsedMs         = [int]$script:roundWatch.ElapsedMilliseconds
    score             = $script:score
    hits              = $script:hits
    misses            = $script:misses
    hitRate           = $(if (($script:hits + $script:misses) -gt 0) { [math]::Round($script:hits / ($script:hits + $script:misses), 4) } else { $null })
    avgReactionMs     = $st.avg
    minReactionMs     = $st.min
    maxReactionMs     = $st.max
    medianReactionMs  = $st.median
    p90ReactionMs     = $st.p90
    reactionMs        = @($script:reactions)
    targetSizePx      = $TargetSize
    minMoveDistancePx = $MinMoveDistance
    seed              = $Seed
    uia               = [ordered]@{ targetName = 'target'; targetAutomationId = 'arenaTarget'; restartName = 'arena-restart'; quitName = 'arena-quit' }
    window            = [ordered]@{ left = [int]$win.Left; top = [int]$win.Top; width = [int]$win.Width; height = [int]$win.Height }
    board             = [ordered]@{ width = [int]$board.ActualWidth; height = [int]$board.ActualHeight }
    screen            = [ordered]@{ device = $screen.DeviceName; width = $screen.Bounds.Width; height = $screen.Bounds.Height; primary = $screen.Primary }
    host              = $env:COMPUTERNAME
    note              = '反应时间 = 目标出现(上一靶命中/开局) → 命中事件；自动化点击的耗时也计入其中。'
  }
  # 注意：不能走 Set-Content -Encoding UTF8 —— Windows PowerShell 5.1 会写 BOM，
  # 带 BOM 的 JSON 会让 JSON.parse / jq 这类严格解析器直接报错。
  $json = $obj | ConvertTo-Json -Depth 6
  [System.IO.File]::WriteAllText($file, $json, (New-Object System.Text.UTF8Encoding($false)))
  $script:lastRunFile = $file
  Write-Log ('ROUND saved file={0} score={1} hits={2} misses={3} avg={4}ms' -f $file, $script:score, $script:hits, $script:misses, $st.avg)
  return $file
}

function Stop-Round([bool]$aborted = $false) {
  if (-not $script:running) { return }
  $script:running = $false
  $script:timer.Stop()
  $target.Visibility = 'Hidden'
  $file = Save-Run -aborted $aborted
  $st = Get-ReactionStats
  $txtResult.Text = '得分 {0} · 命中 {1} · 误击 {2} · 平均反应 {3} ms · 最快 {4} ms · 最慢 {5} ms' -f `
      $script:score, $script:hits, $script:misses, $st.avg, $st.min, $st.max
  $txtResultPath.Text = '结果已写入: ' + $file
  $panel.Visibility = 'Visible'
  Update-Hud
  if ($AutoQuitAfterFinishMs -gt 0) {
    $script:quitTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:quitTimer.Interval = [TimeSpan]::FromMilliseconds($AutoQuitAfterFinishMs)
    $script:quitTimer.Add_Tick({
        try { $script:quitTimer.Stop(); Write-Log 'AUTOQUIT firing'; $win.Close() }
        catch { Write-Log ('ERROR autoquitTick: ' + $_.Exception.Message) }
      })
    $script:quitTimer.Start()
    Write-Log ('AUTOQUIT scheduled in {0}ms' -f $AutoQuitAfterFinishMs)
  }
}

# ── 事件 ───────────────────────────────────────────────────────────────
$win.Dispatcher.Add_UnhandledException({
    try { Write-Log ('FATAL dispatcher: ' + $_.Exception.ToString()); $_.Handled = $true }
    catch { }
  })

$target.Add_Click({
    try {
      if (-not $script:running) { return }
      $ms = [int]$script:spawnWatch.ElapsedMilliseconds
      $script:score++
      $script:hits++
      $script:reactions += $ms
      $script:lastHitWhen = Get-Date
      Write-Log ('HIT seq={0} at=({1},{2}) reactionMs={3} score={4}' -f $script:seq, $script:lastX, $script:lastY, $ms, $script:score)
      Spawn-Target
      Update-Hud
    } catch { Write-Log ('ERROR targetClick: ' + $_.Exception.ToString()) }
  })

$board.Add_MouseLeftButtonDown({
    try {
      if (-not $script:running) { return }
      if (((Get-Date) - $script:lastHitWhen).TotalMilliseconds -lt 150) { return }
      $p = $_.GetPosition($board)
      $script:misses++
      Write-Log ('MISS at=({0:N0},{1:N0}) misses={2}' -f $p.X, $p.Y, $script:misses)
      Update-Hud
    } catch { Write-Log ('ERROR boardClick: ' + $_.Exception.ToString()) }
  })

$script:timer.Add_Tick({
    try {
      if (-not $script:running) { return }
      Update-Hud
      if ($script:roundWatch.Elapsed.TotalSeconds -ge $Duration) { Stop-Round -aborted $false }
    } catch { Write-Log ('ERROR roundTick: ' + $_.Exception.ToString()) }
  })

$win.FindName('BtnQuit').Add_Click({ try { $win.Close() } catch { } })
$win.FindName('BtnRestart').Add_Click({ try { Start-Round } catch { Write-Log ('ERROR restart: ' + $_.Exception.Message) } })
$win.FindName('BtnAgain').Add_Click({ try { Start-Round } catch { Write-Log ('ERROR again: ' + $_.Exception.Message) } })

$win.Add_KeyDown({
    try {
      switch ($_.Key) {
        'Escape' { $win.Close() }
        'F5' { if (-not $script:running) { Start-Round } }
        default { }
      }
    } catch { Write-Log ('ERROR keydown: ' + $_.Exception.Message) }
  })

$win.Add_Closing({
    try {
      if ($script:running) { Stop-Round -aborted $true }
      Write-Log 'WINDOW closing'
    } catch { Write-Log ('ERROR closing: ' + $_.Exception.ToString()) }
  })

$win.Add_Loaded({
    try {
      Write-Log ('WINDOW shown hwnd={0}' -f (New-Object System.Windows.Interop.WindowInteropHelper($win)).Handle)
      if ($StartDelayMs -gt 0) {
        $script:delayTimer = New-Object System.Windows.Threading.DispatcherTimer
        $script:delayTimer.Interval = [TimeSpan]::FromMilliseconds($StartDelayMs)
        $script:delayTimer.Add_Tick({
            try { $script:delayTimer.Stop(); Write-Log 'DELAY elapsed -> ROUND start'; Start-Round }
            catch { Write-Log ('ERROR delayTick: ' + $_.Exception.ToString()) }
          })
        $script:delayTimer.Start()
        Write-Log ('ROUND delayed by {0}ms' -f $StartDelayMs)
      } else {
        Start-Round
      }
    } catch { Write-Log ('ERROR loaded: ' + $_.Exception.ToString()) }
  })

Write-Log ('ARENA boot pid={0} args: dur={1}s win={2}x{3}@({4},{5}) target={6}px' -f $PID, $Duration, $Width, $Height, $Left, $Top, $TargetSize)
[void]$win.ShowDialog()
Write-Log 'ARENA exit'
