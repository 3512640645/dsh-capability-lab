/** 真实指针通道的瞄准精度细看：aimPx vs 命中半径（圆 vs 方框判定） */
import fs from 'node:fs';
const B = 'D:\\dsh-arena\\bench\\';
const R = JSON.parse(fs.readFileSync(B + 'results-real.json', 'utf8'));
let rows = [];
for (const r of R.runs) for (const t of r.arenaRun.targets) rows.push({ round: r.round, id: t.id, r: t.r, aimPx: t.aimPx, hit: t.aimPx <= t.r ? 'inCircle' : (t.aimPx <= t.r * Math.SQRT2 ? 'inSquareCorner' : 'OUT') });
const early = rows.filter((x) => x.r >= 30), late = rows.filter((x) => x.r < 25);
const stat = (a) => ({ n: a.length, med: [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)], max: Math.max(...a) });
console.log('全部命中 aimPx: ', JSON.stringify(stat(rows.map((x) => x.aimPx))));
console.log('早期(r>=30) aimPx:', JSON.stringify(stat(early.map((x) => x.aimPx))));
console.log('后期(r<25)  aimPx:', JSON.stringify(stat(late.map((x) => x.aimPx))));
const cnt = {}; for (const x of rows) cnt[x.hit] = (cnt[x.hit] || 0) + 1;
console.log('落点判定:', JSON.stringify(cnt), '总命中', rows.length);
console.log('落点在方框角区(圆外方框内)的例子:', JSON.stringify(rows.filter((x) => x.hit === 'inSquareCorner').slice(0, 8)));
