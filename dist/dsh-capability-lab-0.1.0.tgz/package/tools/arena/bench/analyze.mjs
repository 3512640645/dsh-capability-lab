/** 结果分析器：node analyze.mjs <results.json> */
import fs from 'node:fs';

const f = process.argv[2];
const R = JSON.parse(fs.readFileSync(f, 'utf8'));
for (const r of R.runs) {
  const ar = r.arenaRun;
  const skip = {}, src = {};
  for (const c of r.cycles) {
    if (c.skipped) { const k = String(c.skipped).slice(0, 26); skip[k] = (skip[k] || 0) + 1; }
    if (c.lead) src[c.lead.source] = (src[c.lead.source] || 0) + 1;
  }
  console.log(`\n===== ${R.channel} round ${r.round} =====`);
  console.log(`hits=${ar?.hits} misses=${ar?.misses} hitRate=${ar?.hitRate} avg=${ar?.avgReactionMs} median=${ar?.medianReactionMs} min=${ar?.minReactionMs} max=${ar?.maxReactionMs} p90=${ar?.p90ReactionMs}`);
  console.log(`cycles=${r.cycles.length} clicked=${r.cycles.filter((c) => c.aim).length} skip=${JSON.stringify(skip)} src=${JSON.stringify(src)}`);
  console.log(`latency=${JSON.stringify(r.cycleLatency)}`);
  console.log(`miss dx=${JSON.stringify(ar?.missLog?.map((m) => m.dx))} r=${JSON.stringify(ar?.missLog?.map((m) => m.r))}`);
  console.log(`missLog=${JSON.stringify(ar?.missLog)}`);
  console.log(`hit aimPx=${JSON.stringify(ar?.targets?.map((t) => t.aimPx))}`);
  const md = r.cycles.filter((c) => c.model).map((c) => ({ n: c.n, rms: c.model.rms, v: c.model.v, src: c.lead?.source }));
  console.log(`modelUsed=${JSON.stringify(md)}`);
  console.log(`reactions=${JSON.stringify(ar?.reactionMs)}`);
}
