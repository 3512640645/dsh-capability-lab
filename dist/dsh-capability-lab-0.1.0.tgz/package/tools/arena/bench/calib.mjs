/**
 * 移动靶基准 · 第 0 步：标定（calib）
 *
 * 目的：在跑正式成绩之前，先把"真实指针通道"的每一段延迟量出来，并证明两件事：
 *   A. move 真的动了物理指针（move 不复位指针 → 前后读 Cursor.Position 应等于目标点）
 *   B. 真实 click 真的能打中移动靶（靶场自己记的 hits 会涨）
 *
 * 产出：D:\dsh-arena\bench\calib.json
 * 运行：& "<node.cmd>" D:\dsh-arena\bench\calib.mjs
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { connect, engineSender, listWindows, killStaleArena, waitArenaWindow, closeArenaWindows } from './client.mjs';
import { createEngine, readPointerPosition } from 'file:///D:/dsh-tools/aim/input.mjs';
import { decodePng, detectTargets, resolveCapture, imageToScreen } from 'file:///D:/dsh-tools/aim/vision.mjs';

const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const ARENA = 'D:\\dsh-arena\\arena-move.ps1';
const RUNS = 'D:\\dsh-arena\\runs';
const DURATION = Number(process.env.CAL_DURATION ?? 20);
const SPEED = Number(process.env.CAL_SPEED ?? 240);
const STEPS = Number(process.env.CAL_STEPS ?? 3);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const now = () => Date.now();
const med = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };

const out = { schema: 'dsh-arena/calib/1', startedAt: new Date().toISOString(), notes: [], lat: {}, evidence: {}, cycle: [] };
const T0 = now();
function note(k, v) { out.notes.push({ atMs: now() - T0, k, v }); console.log(`[${((now() - T0) / 1000).toFixed(1)}s] ${k}: ${typeof v === 'string' ? v : JSON.stringify(v)}`); }

// ── 0. 预清理（只杀跑靶场脚本的 powershell，见 client.mjs 的说明） ──────
const pc = await killStaleArena();
note('0.preclean.powershell', pc);

const client = await connect();
const pre = await closeArenaWindows(client);
if (pre.closed.length) note('0.preclean.windows', pre);
await sleep(600);

// ── 1. 起靶场（移动靶） ──────────────────────────────────────────────────
const runsBefore = new Set(fs.existsSync(RUNS) ? fs.readdirSync(RUNS) : []);
const args = ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ARENA,
  '-Duration', String(DURATION), '-SpeedPxPerSec', String(SPEED), '-StartDelayMs', '5000'];
const child = spawn(PS, args, { stdio: 'ignore' });
note('1.launch', { cmd: `powershell.exe ${args.join(' ')}`, pid: child.pid, durationSec: DURATION, speedPxPerSec: SPEED });

const { win } = await waitArenaWindow(client);
if (!win) { console.error('FAIL: 没找到 DSH Arena 窗口'); await client.close(); process.exit(2); }
const hwnd = win.nativeWindowHandle;
note('2.window', { hwnd, boundingBox: win.boundingBox, className: win.className, pid: win.processId });
const W = { x: win.boundingBox.x, y: win.boundingBox.y, width: win.boundingBox.width, height: win.boundingBox.height };

// ── 2. 等靶出现（顺便量元素通道 find 延迟） ─────────────────────────────
let findMs = [];
for (let i = 0; i < 30; i++) {
  const r = await client.tool('find', { query: 'target', nativeWindowHandle: hwnd, maxResults: 8, ocrFallback: false, maxDepth: 8, maxNodes: 900, treeTimeoutMs: 3000 });
  const hit = (r.data?.results ?? []).find((h) => String(h.name ?? '').trim() === 'target');
  if (hit) { findMs.push(r.ms); out.evidence.elementChannel = { found: true, name: hit.name, automationId: hit.automationId, controlType: hit.controlType, boundingBox: hit.boundingBox, findMs: r.ms }; break; }
  await sleep(400);
}
note('3.element.find', out.evidence.elementChannel ?? { found: false });

// ── 3. 指针读取延迟 ─────────────────────────────────────────────────────
const readMs = [], readVals = [];
for (let i = 0; i < 3; i++) { const t = now(); const p = await readPointerPosition(); readMs.push(now() - t); readVals.push(p); }
out.lat.readPointerMs = { samples: readMs, median: med(readMs) };
out.evidence.pointerStart = readVals[readVals.length - 1];
note('4.readPointer', { samples: readMs, median: med(readMs), pointer: out.evidence.pointerStart });

// ── 4. 截图 + 视觉检测延迟 ──────────────────────────────────────────────
async function see(hwnd, maxWidth) {
  const t0 = now();
  const shot = await client.tool('screenshot', { nativeWindowHandle: hwnd, maxWidth });
  const tCap = now();
  const img = decodePng(shot.png);
  const tDec = now();
  const cap = resolveCapture({ bounds: shot.data.screenshot.bounds, imageScale: shot.data.screenshot.imageScale });
  const targets = detectTargets(img, { color: process.env.CAL_COLOR ?? 'E8452C', tolerance: 70, minArea: 200, sort: 'area' });
  const tDet = now();
  const best = targets[0] ?? null;
  return {
    best, targets: targets.length, cap, shot,
    ms: { capture: tCap - t0, decode: tDec - tCap, detect: tDet - tDec, total: tDet - t0 },
    screen: best ? imageToScreen(best.center, cap) : null,
    tMid: t0 + Math.round((tCap - t0) / 2),
  };
}
const seeNative = [], seeSmall = [];
for (let i = 0; i < 3; i++) { const s = await see(hwnd, 0); seeNative.push(s.ms); await sleep(120); }
for (let i = 0; i < 3; i++) { const s = await see(hwnd, 450); seeSmall.push(s.ms); await sleep(120); }
const s0 = await see(hwnd, 0);
out.lat.screenshot = {
  native: { capture: seeNative.map((m) => m.capture), decode: seeNative.map((m) => m.decode), detect: seeNative.map((m) => m.detect), total: seeNative.map((m) => m.total) },
  maxWidth450: { capture: seeSmall.map((m) => m.capture), decode: seeSmall.map((m) => m.decode), detect: seeSmall.map((m) => m.detect), total: seeSmall.map((m) => m.total) },
};
out.evidence.vision = {
  image: { width: s0.cap.imageWidth, height: s0.cap.imageHeight, scale: s0.cap.imageScale },
  captureBounds: s0.shot.data.screenshot.bounds, method: s0.shot.data.screenshot.method,
  detected: s0.best ? { center: s0.best.center, radius: s0.best.radius, area: s0.best.area, circularity: Number(s0.best.circularity.toFixed(3)) } : null,
  screenCenter: s0.screen, candidateCount: s0.targets,
};
note('5.vision', { native: seeNative, small450: seeSmall, vision: out.evidence.vision });

// ── 5. 真实指针：move 的证据链 ───────────────────────────────────────────
const sender = engineSender(client);
const ptr = await readPointerPosition();
const engine = createEngine({
  sender, pointer: { x: ptr.x, y: ptr.y }, rawKey: null,
  stepMs: 15, maxSteps: 120, minSteps: 6, curvature: 0.18, easing: 'easeInOutSine',
  retry: { attempts: 2, backoffMs: [0, 30], timeoutMs: 15000 },
});
const moveSamples = [], clickSamples = [];
async function realClick(cx, cy) {
  const t1 = now();
  const m = await engine.moveTo(cx, cy, 150, { stepMs: 50, minSteps: 2, maxSteps: STEPS, nativeWindowHandle: hwnd, curvature: 0.15 });
  const t2 = now();
  moveSamples.push(t2 - t1);
  const c = await engine.click(cx, cy, { durationMs: 1, stepMs: 15, minSteps: 1, maxSteps: 1, settleMs: 0, nativeWindowHandle: hwnd, dispatch: 'foreground' });
  const t3 = now();
  clickSamples.push(t3 - t2);
  return { move: m, click: c, moveMs: t2 - t1, clickMs: t3 - t2, totalMs: t3 - t1 };
}

// 5a. move 不动指针 → 读回来必须等于目标点（证明真物理移动）
const probePoint = { x: Math.round(W.x + W.width - 120), y: Math.round(W.y + W.height / 2) };
const mv = await engine.moveTo(probePoint.x, probePoint.y, 150, { stepMs: 50, minSteps: 2, maxSteps: STEPS, nativeWindowHandle: hwnd });
const after = await readPointerPosition();
out.evidence.realPointer = {
  aim: probePoint, readBack: { x: after.x, y: after.y },
  deltaPx: Math.round(Math.hypot(after.x - probePoint.x, after.y - probePoint.y)),
  moveResult: { steps: mv.steps, elapsedMs: mv.elapsedMs, plannedMs: mv.plannedMs, driftMs: mv.driftMs, ok: mv.ok },
  trajectory: mv.trajectory.map((p) => ({ x: p.x, y: p.y, atMs: p.atMs })),
};
note('6.realPointer.move', out.evidence.realPointer);

// 5b. 视觉闭环真打 3 次（每次都用视觉重新找靶 + 预测提前量）
const estimator = { lead: 420 };
for (let i = 0; i < 3; i++) {
  const s = await see(hwnd, 0);
  if (!s.best) { out.cycle.push({ round: i + 1, error: 'no target' }); continue; }
  const lead = leadEstimate(estimator.lead, now() - s.tMid, med(moveSamples) ?? 200);
  const aim = { x: Math.round(s.screen.x + lead.vx * lead.sec), y: Math.round(s.screen.y) };
  const clamped = { x: Math.min(Math.max(aim.x, W.x + 6), W.x + W.width - 6), y: Math.min(Math.max(aim.y, W.y + 6), W.y + W.height - 6) };
  const r = await realClick(clamped.x, clamped.y);
  out.cycle.push({ round: i + 1, detectedScreen: s.screen, radius: s.best.radius, seeMs: s.ms.total, lead, aim: clamped, clampDelta: { dx: clamped.x - aim.x, dy: clamped.y - aim.y }, ...r, moveSteps: r.move.steps, moveDriftMs: r.move.driftMs });
  note(`7.cycle${i + 1}`, { detected: s.screen, aim: clamped, moveMs: r.moveMs, clickMs: r.clickMs, moveSteps: r.move.steps });
}

// 元素通道一次 invoke（对照：走元素不靠坐标）
const tE = now();
const fe = await client.tool('find', { query: 'target', nativeWindowHandle: hwnd, maxResults: 8, ocrFallback: false, maxDepth: 8, maxNodes: 900, treeTimeoutMs: 3000 });
const hitE = (fe.data?.results ?? []).find((h) => String(h.name ?? '').trim() === 'target');
let invokeMs = null;
if (hitE) { const t2 = now(); await client.tool('click', { elementId: hitE.id, nativeWindowHandle: hwnd }); invokeMs = now() - t2; }
out.evidence.elementInvoke = { findMs: fe.ms, invokeMs, elementId: hitE?.id ?? null, cycleMs: now() - tE };

out.lat.moveMs = { samples: moveSamples, median: med(moveSamples) };
out.lat.clickMs = { samples: clickSamples, median: med(clickSamples) };

await sleep(Math.max(0, (DURATION + 5) * 1000 - (now() - T0)));
const wins1 = await listWindows(client);
const arenaGone = !wins1.find((w) => w.nativeWindowHandle === hwnd);
const runsAfter = fs.existsSync(RUNS) ? fs.readdirSync(RUNS) : [];
const newRuns = runsAfter.filter((f) => !runsBefore.has(f));
const latest = newRuns.map((f) => path.join(RUNS, f)).sort().pop();
let runJson = null;
if (latest) { try { runJson = JSON.parse(fs.readFileSync(latest, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { runJson = { parseError: String(e) }; } }
out.evidence.arenaRun = runJson ? {
  file: latest, mode: runJson.mode, hits: runJson.hits, misses: runJson.misses, hitRate: runJson.hitRate,
  avgReactionMs: runJson.avgReactionMs, reactionMs: runJson.reactionMs, elapsedMs: runJson.elapsedMs,
  firstTargets: (runJson.targets ?? []).slice(0, 6),
  firstMisses: (runJson.missLog ?? []).slice(0, 6),
  motion: runJson.motion,
} : null;
out.evidence.windowClosed = arenaGone;
note('8.arenaRun', out.evidence.arenaRun ?? { none: true });

// 关窗收尾
const cl = await closeArenaWindows(client);
out.evidence.closeup = cl;
note('9.cleanup', cl);
try { process.kill(child.pid); } catch { }
await sleep(500);
out.evidence.staleAfter = await killStaleArena();
await client.close();
out.endedAt = new Date().toISOString();
fs.writeFileSync('D:\\dsh-arena\\bench\\calib.json', JSON.stringify(out, null, 2), 'utf8');
console.log('\n[saved] D:\\dsh-arena\\bench\\calib.json');

function leadEstimate(leadMs, sinceCaptureMid, moveMed) {
  const sec = Math.max(0.05, (sinceCaptureMid + moveMed + 120) / 1000);
  return { leadMs, sec, vx: Number(process.env.CAL_VX ?? SPEED), note: 'lead = 目标速度 × 剩余延迟（截图中点 → 鼠标按下）' };
}
