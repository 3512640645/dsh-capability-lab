/** 收尾核对：关掉所有靶场窗口 + 确认无残留进程 */
import { connect, closeArenaWindows, killStaleArena } from './client.mjs';
const c = await connect();
const w = await closeArenaWindows(c);
console.log('arena windows closed:', JSON.stringify(w));
const k = await killStaleArena();
console.log('arena powershell:', JSON.stringify(k));
await c.close();
