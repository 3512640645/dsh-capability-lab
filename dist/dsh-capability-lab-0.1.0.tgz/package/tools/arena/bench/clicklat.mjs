#!/usr/bin/env node
/**
 * clicklat.mjs —— 指针点击延迟夹具的驱动 + 统计（W4 新增，配合 clicklat-fixture.ps1）
 *
 * 用法：
 *   node clicklat.mjs --dir  D:\dsh-arena\bench\clicklat\synth-YYYYmmddHHMMSS      # 只统计已有结果
 *   node clicklat.mjs --mode synth --trials 150                                    # 跑一次 synth（不动真实指针）
 *   node clicklat.mjs --mode real  --trials 200 --x 40 --y 40                      # 跑一次 real（需要桌面独占）
 *
 * 指标含义（同一进程、同一 QPC 时钟，qpc_freq=10MHz → 1 tick = 0.1µs）：
 *   synth_sendmessage.app_down_ms  = SendMessage(WM_LBUTTONDOWN) 调用前 → 窗体处理器内的时间戳
 *                                    （同线程直接调用，等于"处理器链路 + P/Invoke"的地板值）
 *   synth_postmessage.app_down_ms  = PostMessage → DoEvents 派发到处理器的耗时（消息队列往返）
 *   real_inject.setpos_ms          = 注入前 → SetCursorPos 返回（指针已就位）
 *   real_inject.app_down_ms        = 注入前 → 窗体收到 WM_LBUTTONDOWN（**端到端延迟**，自动化最关心）
 *   real_inject.app_up_ms          = 注入前 → 窗体收到 WM_LBUTTONUP
 *   api_baseline_us.get_cursor_pos = 只读 API 的 managed→native 调用开销（代理值，不能当 SetCursorPos）
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const PS1 = 'D:\\dsh-arena\\bench\\clicklat-fixture.ps1';
const argv = process.argv.slice(2);
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i === -1 ? d : argv[i + 1]; };
const has = (n) => argv.includes('--' + n);

const stats = (xs) => {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b);
  const q = (p) => s[Math.min(s.length - 1, Math.round((s.length - 1) * p))];
  return { n: s.length, min: q(0), p50: q(0.5), p90: q(0.9), p99: q(0.99), max: q(1), mean: s.reduce((a, b) => a + b, 0) / s.length };
};
const fmt = (st, unit = 'ms', d = 4) => st
  ? `n=${String(st.n).padStart(4)}  min=${st.min.toFixed(d)}  p50=${st.p50.toFixed(d)}  p90=${st.p90.toFixed(d)}  p99=${st.p99.toFixed(d)}  max=${st.max.toFixed(d)}  mean=${st.mean.toFixed(d)} ${unit}`
  : '（无样本）';

let dir = opt('dir', '');
const mode = opt('mode', 'synth');

if (!dir) {
  const ts = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
  dir = path.join('D:\\dsh-arena\\bench\\clicklat', `${mode}-${ts}`);
  const trials = String(Number(opt('trials', '150')));
  const x = opt('x', '-1'), y = opt('y', '-1');
  console.log(`[clicklat] 启动夹具: mode=${mode} trials=${trials} out=${dir}`);
  if (mode === 'real') console.log('[clicklat] 警告：real 模式会移动真实指针，必须桌面独占（本轮 W4 无权使用真实键鼠）');
  const r = spawnSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', PS1,
    '-Mode', mode, '-OutDir', dir, '-Trials', trials, '-X', x, '-Y', y],
    { encoding: 'utf8', env: { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' } });
  process.stdout.write(r.stdout || '');
  if (r.stderr) process.stderr.write(r.stderr);
  if (r.status !== 0) console.log(`[clicklat] 夹具退出码 ${r.status}`);
}

const metaPath = path.join(dir, 'meta.json');
const jsonlPath = path.join(dir, 'trials.jsonl');
if (!fs.existsSync(metaPath) || !fs.existsSync(jsonlPath)) { console.error(`缺 ${metaPath} 或 ${jsonlPath}`); process.exit(2); }
const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
const rows = fs.readFileSync(jsonlPath, 'utf8').split(/\r?\n/).filter(Boolean).map((l) => JSON.parse(l));

const by = (m) => rows.filter((r) => r.mode === m);
const pick = (rs, k) => rs.map((r) => r[k]).filter((v) => typeof v === 'number' && v >= 0);

const send = by('synth_sendmessage'), post = by('synth_postmessage'), real = by('real_inject'), skip = by('real_skipped');

console.log(`\n=== clicklat 结果 · ${dir} ===`);
console.log(`模式=${meta.mode} 夹具窗口已显示=${meta.window_visible} 客户区=${meta.client_size} 目标屏幕点=${meta.target_screen || 'n/a'} QPC=${meta.qpc_freq}Hz(1 tick=0.1µs)`);
console.log(`行数=${meta.rows_written} 被遮挡跳过=${meta.occlusion_skips}（real 模式：遮挡时不注入也不计数）  夹具错误=${meta.error || '无'}`);
const bl = meta.api_baseline_us;
console.log(`[代理基线] GetCursorPos 调用开销: min=${bl.get_cursor_pos_min}µs p50=${bl.p50}µs p90=${bl.p90}µs max=${bl.max}µs (n=${bl.n}) —— 只读调用，不等于 SetCursorPos 代价`);

if (send.length) {
  console.log(`\n[A] synth/SendMessage（不动指针，处理器地板值）`);
  console.log(`  app_down_ms : ${fmt(stats(pick(send, 'app_down_ms')))}`);
  console.log(`  handler_seen=false 的条数: ${send.filter((r) => !r.handler_seen).length}/${send.length}`);
}
if (post.length) {
  console.log(`\n[B] synth/PostMessage+DoEvents（不动指针，消息队列往返）`);
  console.log(`  app_down_ms : ${fmt(stats(pick(post, 'app_down_ms')))}`);
  console.log(`  handler_seen=false 的条数: ${post.filter((r) => !r.handler_seen).length}/${post.length}`);
}
if (real.length) {
  console.log(`\n[C] real/SetCursorPos+mouse_event（端到端，需桌面独占）`);
  console.log(`  setpos_ms   : ${fmt(stats(pick(real, 'setpos_ms')))}`);
  console.log(`  downcall_ms : ${fmt(stats(pick(real, 'downcall_ms')))}`);
  console.log(`  app_down_ms : ${fmt(stats(pick(real, 'app_down_ms')))}   ← 端到端延迟`);
  console.log(`  app_up_ms   : ${fmt(stats(pick(real, 'app_up_ms')))}`);
  console.log(`  未命中(handler_seen=false): ${real.filter((r) => !r.handler_seen).length}/${real.length}`);
}
if (skip.length) console.log(`\n[D] real_skipped（窗口被遮挡/非前台，未注入）: ${skip.length} 条`);

const summary = {
  dir, mode: meta.mode, window_visible: meta.window_visible, target_screen: meta.target_screen,
  occlusion_skips: meta.occlusion_skips, rows: meta.rows_written, api_baseline_us: bl,
  focus_ok: meta.focus_ok ?? null, focus_tries: meta.focus_tries ?? null, focus_fixes: meta.focus_fixes ?? null,
  synth_sendmessage_app_down_ms: stats(pick(send, 'app_down_ms')),
  synth_postmessage_app_down_ms: stats(pick(post, 'app_down_ms')),
  real_setpos_ms: stats(pick(real, 'setpos_ms')),
  real_downcall_ms: stats(pick(real, 'downcall_ms')),
  real_app_down_ms: stats(pick(real, 'app_down_ms')),
  real_app_up_ms: stats(pick(real, 'app_up_ms')),
  real_missed: real.filter((r) => !r.handler_seen).length,
};
fs.writeFileSync(path.join(dir, 'summary.json'), JSON.stringify(summary, null, 2), 'utf8');
console.log(`\n[clicklat] summary → ${path.join(dir, 'summary.json')}`);
