# clicklat-fixture.ps1 -- pointer click latency fixture (owner: W4)
# ASCII-only on purpose: this file is read by Windows PowerShell 5.1, which decodes
# BOM-less files as ANSI (GBK here) and would mangle non-ASCII comments into syntax errors.
#
# One process, one QPC clock, three parts:
#   [A] real WinForms window with a 48x48 target at the client centre + MouseDown/MouseUp stamps
#   [B] switchable measurement path:
#       -Mode synth : window is created but NEVER shown; messages are delivered to our own HWND
#                     (SendMessage = direct handler path, PostMessage + DoEvents = queue path).
#                     No pointer movement, no input injection. Safe while another worker owns the desktop.
#       -Mode real  : window is shown TopMost, then SetCursorPos + mouse_event(LEFTDOWN/LEFTUP) are
#                     injected with both sides stamped. MOVES THE REAL POINTER -> needs an exclusive slot.
#   [C] read-only API baseline (GetCursorPos x2000): cost of one managed->native call of the same
#       DllImport shape. It is a proxy only, NOT a SetCursorPos measurement.
#
# Usage:
#   powershell -File clicklat-fixture.ps1 -Mode synth -OutDir D:\dsh-arena\bench\clicklat\<ts> -Trials 200
#   powershell -File clicklat-fixture.ps1 -Mode real  -OutDir D:\dsh-arena\bench\clicklat\<ts> -Trials 200
param(
  [ValidateSet('synth','real')][string]$Mode = 'synth',
  [string]$OutDir = 'D:\dsh-arena\bench\clicklat\run',
  [int]$Trials = 200,
  [int]$X = -1,
  [int]$Y = -1,
  [string]$GateDir = ''
)
$ErrorActionPreference = 'Stop'
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$cs = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

public static class ClickLatFixture
{
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }

    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
    [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT p);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
    [DllImport("user32.dll", CharSet = CharSet.Auto)] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);

    const uint WM_LBUTTONDOWN = 0x0201, WM_LBUTTONUP = 0x0202, MK_LBUTTON = 0x0001;
    const uint ME_LEFTDOWN = 0x0002, ME_LEFTUP = 0x0004;

    static readonly long Freq = Stopwatch.Frequency;
    static Form form;
    static long tAppDown, tAppUp;
    static bool gotDown, gotUp;
    static int downX, downY, upX, upY;
    static StringBuilder jsonl = new StringBuilder();
    static string jsonlPath;
    static string gateDir = "";
    static bool gateGo = false;
    static double gateWaitedMs = -1;
    static int occlusionSkips = 0, rows = 0;
    static double gcP50 = -1, gcP90 = -1, gcMin = -1, gcMax = -1, gcAvg = -1;

    static long T() { return Stopwatch.GetTimestamp(); }
    static string Ms(long a, long b) { return ((b - a) * 1000.0 / Freq).ToString("F4", CultureInfo.InvariantCulture); }

    static IntPtr LP(int x, int y) { return (IntPtr)((y << 16) | (x & 0xFFFF)); }
    static void Flush() { File.WriteAllText(jsonlPath, jsonl.ToString(), new UTF8Encoding(false)); }
    static void Row(string s) { jsonl.AppendLine(s); rows++; Flush(); }

    static double Pct(List<double> xs, double p)
    {
        List<double> c = new List<double>(xs); c.Sort();
        if (c.Count == 0) return -1;
        int i = (int)Math.Round((c.Count - 1) * p);
        return c[i];
    }

    [STAThread]
    public static void Run(string mode, string outDir, int trials, int x, int y, string gate)
    {
        Directory.CreateDirectory(outDir);
        gateDir = gate ?? "";
        jsonlPath = Path.Combine(outDir, "trials.jsonl");
        string metaPath = Path.Combine(outDir, "meta.json");
        try { SetProcessDPIAware(); } catch (Exception) { }
        if (mode == "real")
        {
            // Measured on this host: the FIRST Show()n Form inside a PowerShell 5.1 process
            // stays IsWindowVisible=false (the second one is fine). An invisible window means
            // every click lands on the desktop -> 200/200 useless samples.
            // Sacrifice one off-screen form to take the "first form" slot.
            Form dummy = new Form();
            dummy.Text = "clicklat2 dummy";
            dummy.ClientSize = new Size(120, 80);
            dummy.ShowInTaskbar = false;
            dummy.StartPosition = FormStartPosition.Manual;
            dummy.Location = new Point(-4000, -4000);
            dummy.Show();
            IntPtr dummyH = dummy.Handle;
            Application.DoEvents();
            dummy.Hide();
            Application.DoEvents();
        }
        string err = "";
        bool visible = false;
        string rect = "", target = "";
        try
        {
            form = new Form();
            form.Text = "clicklat fixture W4";
            form.FormBorderStyle = FormBorderStyle.FixedSingle;
            form.MaximizeBox = false;
            form.ClientSize = new Size(480, 320);
            form.TopMost = true;
            form.StartPosition = (x >= 0 && y >= 0) ? FormStartPosition.Manual : FormStartPosition.CenterScreen;
            if (x >= 0 && y >= 0) form.Location = new Point(x, y);
            form.Paint += delegate(object s, PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                g.Clear(Color.White);
                Point c = new Point(form.ClientSize.Width / 2, form.ClientSize.Height / 2);
                g.FillRectangle(Brushes.OrangeRed, c.X - 24, c.Y - 24, 48, 48);
                g.DrawLine(Pens.Black, c.X - 40, c.Y, c.X + 40, c.Y);
                g.DrawLine(Pens.Black, c.X, c.Y - 40, c.X, c.Y + 40);
                g.DrawString("target " + c.X + "," + c.Y, SystemFonts.DefaultFont, Brushes.Black, 8, 8);
            };
            form.MouseDown += delegate(object s, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left) { tAppDown = T(); downX = e.X; downY = e.Y; gotDown = true; }
            };
            form.MouseUp += delegate(object s, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left) { tAppUp = T(); upX = e.X; upY = e.Y; gotUp = true; }
            };
            IntPtr h = form.Handle;   // forces HWND creation; synth mode never shows the window

            int cx = form.ClientSize.Width / 2, cy = form.ClientSize.Height / 2;

            // [C] read-only baseline: cost of one managed->native call of the same DllImport shape
            List<double> gcs = new List<double>();
            POINT p0;
            for (int i = 0; i < 2000; i++) { long a = T(); GetCursorPos(out p0); long b = T(); gcs.Add((b - a) * 1000000.0 / Freq); }
            double sum = 0; for (int i = 0; i < gcs.Count; i++) sum += gcs[i];
            gcMin = Pct(gcs, 0); gcP50 = Pct(gcs, 0.5); gcP90 = Pct(gcs, 0.9); gcMax = Pct(gcs, 1.0); gcAvg = sum / gcs.Count;

            if (mode == "synth")
            {
                // [B-synth] no pointer movement: our own messages delivered to our own window
                for (int i = 0; i < trials; i++)
                {
                    gotDown = false;
                    long t0 = T();
                    SendMessage(h, WM_LBUTTONDOWN, (IntPtr)MK_LBUTTON, LP(cx, cy));
                    long t1 = T();
                    SendMessage(h, WM_LBUTTONUP, IntPtr.Zero, LP(cx, cy));
                    long t2 = T();
                    Row("{\"mode\":\"synth_sendmessage\",\"trial\":" + i + ",\"t_call_before\":" + t0 +
                        ",\"t_app_down\":" + tAppDown + ",\"t_call_after_down\":" + t1 + ",\"t_after_up\":" + t2 +
                        ",\"app_down_ms\":" + Ms(t0, tAppDown) + ",\"handler_seen\":" + (gotDown ? "true" : "false") + "}");
                }
                for (int i = 0; i < trials; i++)
                {
                    gotDown = false; gotUp = false;
                    long t0 = T();
                    PostMessage(h, WM_LBUTTONDOWN, (IntPtr)MK_LBUTTON, LP(cx, cy));
                    long t1 = T();
                    long dl = t0 + Freq / 20;
                    while (!gotDown && T() < dl) { Application.DoEvents(); Thread.Sleep(0); }
                    long t2 = T();
                    PostMessage(h, WM_LBUTTONUP, IntPtr.Zero, LP(cx, cy));
                    while (!gotUp && T() < dl) { Application.DoEvents(); Thread.Sleep(0); }
                    long t3 = T();
                    Row("{\"mode\":\"synth_postmessage\",\"trial\":" + i + ",\"t_call_before\":" + t0 +
                        ",\"t_app_down\":" + tAppDown + ",\"t_call_after_post\":" + t1 + ",\"t_after_pump\":" + t2 + ",\"t_after_up\":" + t3 +
                        ",\"app_down_ms\":" + Ms(t0, tAppDown) + ",\"handler_seen\":" + (gotDown ? "true" : "false") + "}");
                }
                // geometry / occlusion READ-OUT only (reads, no injection)
                POINT cur; GetCursorPos(out cur);
                POINT probe; probe.X = cur.X; probe.Y = cur.Y;
                Row("{\"mode\":\"synth_readout\",\"cursor_now\":\"" + cur.X + "," + cur.Y +
                    "\",\"window_under_cursor_is_ours\":" + ((WindowFromPoint(probe) == h) ? "true" : "false") +
                    ",\"our_window_visible\":" + (IsWindowVisible(h) ? "true" : "false") +
                    ",\"our_window_is_foreground\":" + ((GetForegroundWindow() == h) ? "true" : "false") + "}");
            }
            else
            {
                // [B-real] EXCLUSIVE DESKTOP REQUIRED: this moves the real pointer
                form.Show();
                form.TopMost = true;
                form.Activate();
                SetForegroundWindow(h);
                Application.DoEvents();
                Thread.Sleep(250);
                Application.DoEvents();
                visible = true;
                Rectangle scr = form.RectangleToScreen(form.ClientRectangle);
                rect = scr.X + "," + scr.Y + "," + scr.Width + "," + scr.Height;
                Point tc = form.PointToScreen(new Point(cx, cy));
                target = tc.X + "," + tc.Y;
                if (gateDir.Length > 0)
                {
                    // handshake: publish HWND, wait for the external driver to hand us the foreground
                    long tG = T();
                    File.WriteAllText(Path.Combine(gateDir, "hwnd.txt"), h.ToInt64().ToString(), new UTF8Encoding(false));
                    string goPath = Path.Combine(gateDir, "go.txt");
                    long dlw = tG + (long)(30 * Freq);
                    while (!File.Exists(goPath) && T() < dlw) { Application.DoEvents(); Thread.Sleep(20); }
                    gateGo = File.Exists(goPath);
                    gateWaitedMs = (T() - tG) * 1000.0 / Freq;
                }
                for (int i = 0; i < trials; i++)
                {
                    POINT probe; probe.X = tc.X; probe.Y = tc.Y;
                    IntPtr under = WindowFromPoint(probe);
                    bool vis = IsWindowVisible(h);
                    bool ours = (under == h);
                    bool fg = (GetForegroundWindow() == h);
                    if (!vis || !ours || !fg)
                    {
                        occlusionSkips++;
                        Row("{\"mode\":\"real_skipped\",\"trial\":" + i + ",\"visible\":" + (vis ? "true" : "false") +
                            ",\"under_is_ours\":" + (ours ? "true" : "false") + ",\"foreground_is_ours\":" + (fg ? "true" : "false") +
                            ",\"under_hwnd\":\"" + under.ToString() + "\",\"ours_hwnd\":\"" + h.ToString() + "\"}");
                        continue;
                    }
                    POINT before; GetCursorPos(out before);
                    gotDown = false; gotUp = false;
                    long t0 = T();
                    SetCursorPos(tc.X, tc.Y);
                    long t1 = T();
                    mouse_event(ME_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);
                    long t2 = T();
                    long dl = t2 + Freq / 20;
                    while (!gotDown && T() < dl) { Application.DoEvents(); Thread.Sleep(0); }
                    long t3 = T();
                    mouse_event(ME_LEFTUP, 0, 0, 0, UIntPtr.Zero);
                    long t4 = T();
                    long dl2 = t4 + Freq / 20;
                    while (!gotUp && T() < dl2) { Application.DoEvents(); Thread.Sleep(0); }
                    long t5 = T();
                    POINT after; GetCursorPos(out after);
                    Row("{\"mode\":\"real_inject\",\"trial\":" + i + ",\"t_call_before\":" + t0 + ",\"t_after_setpos\":" + t1 +
                        ",\"t_after_downcall\":" + t2 + ",\"t_pump_done\":" + t3 + ",\"t_after_upcall\":" + t4 + ",\"t_pump_up_done\":" + t5 +
                        ",\"t_app_down\":" + tAppDown + ",\"t_app_up\":" + tAppUp +
                        ",\"setpos_ms\":" + Ms(t0, t1) + ",\"downcall_ms\":" + Ms(t1, t2) + ",\"app_down_ms\":" + Ms(t0, tAppDown) +
                        ",\"app_up_ms\":" + Ms(t0, tAppUp) + ",\"cursor_before\":\"" + before.X + "," + before.Y +
                        "\",\"cursor_after\":\"" + after.X + "," + after.Y + "\",\"target\":\"" + tc.X + "," + tc.Y +
                        "\",\"hit_client\":\"" + downX + "," + downY + "\",\"handler_seen\":" + (gotDown ? "true" : "false") + "}");
                }
            }
        }
        catch (Exception ex) { err = ex.ToString().Replace("\\", "/").Replace("\"", "'").Replace("\r", " ").Replace("\n", " | "); }
        finally
        {
            string meta = "{\"mode\":\"" + mode + "\",\"trials_requested\":" + trials + ",\"rows_written\":" + rows +
                ",\"occlusion_skips\":" + occlusionSkips + ",\"window_visible\":" + (visible ? "true" : "false") +
                ",\"form_screen_rect\":\"" + rect + "\",\"target_screen\":\"" + target + "\",\"client_size\":\"" +
                (form != null ? form.ClientSize.Width + "x" + form.ClientSize.Height : "n/a") + "\"" +
                ",\"qpc_freq\":" + Freq + ",\"dpi_aware\":true,\"gate_go\":" + (gateGo ? "true" : "false") + ",\"gate_waited_ms\":" + gateWaitedMs.ToString("F1", CultureInfo.InvariantCulture) + ",\"api_baseline_us\":{\"get_cursor_pos_min\":" + gcMin.ToString("F3", CultureInfo.InvariantCulture) +
                ",\"p50\":" + gcP50.ToString("F3", CultureInfo.InvariantCulture) + ",\"p90\":" + gcP90.ToString("F3", CultureInfo.InvariantCulture) +
                ",\"max\":" + gcMax.ToString("F3", CultureInfo.InvariantCulture) + ",\"avg\":" + gcAvg.ToString("F3", CultureInfo.InvariantCulture) + ",\"n\":2000}" +
                ",\"error\":\"" + err + "\"}";
            File.WriteAllText(metaPath, meta, new UTF8Encoding(false));
            Flush();
            if (form != null) { try { form.Close(); form.Dispose(); } catch (Exception) { } }
        }
    }
}
'@

Add-Type -TypeDefinition $cs -Language CSharp -ReferencedAssemblies 'System.Windows.Forms','System.Drawing'
[ClickLatFixture]::Run($Mode, $OutDir, $Trials, $X, $Y, $GateDir)
Write-Output ("[clicklat] mode=$Mode out=$OutDir trials=$Trials")
