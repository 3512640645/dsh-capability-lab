/**
 * clicklat2.mjs —— real 模式指针点击延迟的协作式驱动
 *
 * 流程：常驻注入器就绪 → 起 clicklat2-fixture.ps1（real）→ 读到 hwnd.txt →
 *       inj.focus(hwnd)（AttachThreadInput+Alt 轻敲，已验证可用）→ 确认前台真的是它 →
 *       写 go.txt 放行 → 夹具跑 N 次 SetCursorPos+mouse_event（两侧 QPC 打点）→
 *       复用 clicklat.mjs --dir 做统计。
 *
 * 用法: node clicklat2.mjs [trials] [x] [y]
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { startInjector } from './keylat/keyclient.mjs';

const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const FIX = 'D:\\dsh-arena\\bench\\clicklat2-fixture.ps1';
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const TRIALS = Number(process.argv[2] ?? 200), X = Number(process.argv[3] ?? 40), Y = Number(process.argv[4] ?? 40);
const TS = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const DIR = `D:\\dsh-arena\\bench\\clicklat\\real2-${TS}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(DIR, { recursive: true });

const inj = await startInjector();
console.log(`[inj] pid=${inj.pid} freq=${inj.ready.freq}`);
const child = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', FIX,
  '-Mode', 'real', '-OutDir', DIR, '-Trials', String(TRIALS), '-X', String(X), '-Y', String(Y), '-GateDir', DIR],
  { env: ENV, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
let out = ''; child.stdout.on('data', (c) => { out += c; }); child.stderr.on('data', (c) => { out += c; });

let hwnd = null;
for (let i = 0; i < 600; i++) { try { const t = fs.readFileSync(path.join(DIR, 'hwnd.txt'), 'utf8').trim(); if (t) { hwnd = Number(t); break; } } catch { } await sleep(50); }
if (!hwnd) { console.log('[fatal] 夹具没报 HWND: ' + out.slice(-400)); child.kill(); await inj.close(); process.exit(1); }
console.log(`[fixture] hwnd=${hwnd}`);

const p0 = await inj.probe(hwnd);
console.log(`[probe] 拿到 HWND 后立刻探测：vis=${p0.vis} rect=${JSON.stringify(p0.rect)}`);

// 关键一步：本机 WinForms 窗体可能停在 IsWindowVisible=false（指针命中的是桌面，点击全废）。
// 用外部进程强制 ShowWindow(SW_SHOW)+SetWindowPos(TOPMOST|SHOWWINDOW) 把 WS_VISIBLE 打开。
function forceVisible(h) {
  const ps = [
    `$h=[IntPtr]::new(${h})`,
    `Add-Type -Namespace S -Name N -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c); [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h); [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x,int y,int cx,int cy,uint f); [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);'`,
    `$a=[S.N]::SetWindowPos($h,[IntPtr]::new(-1),0,0,0,0,0x0043)` + '  # NOSIZE|NOMOVE|SHOWWINDOW 保持夹具原位置(40,40)',
    `$b=[S.N]::ShowWindow($h,5)`,
    `"visible=" + [S.N]::IsWindowVisible($h) + " isWindow=" + [S.N]::IsWindow($h)`,
  ].join('; ');
  const enc = Buffer.from(ps, 'utf16le').toString('base64');
  const r = spawnSync(PS, ['-NoProfile', '-NonInteractive', '-EncodedCommand', enc], { encoding: 'utf8', env: ENV });
  return (r.stdout ?? '').trim();
}
console.log('[forceVisible] ' + forceVisible(hwnd));
await sleep(200);
const pv = await inj.probe(hwnd);
console.log(`[probe] 强制可见后：vis=${pv.vis} rect=${JSON.stringify(pv.rect)}`);
let focus = null;
for (let i = 0; i < 5; i++) { focus = await inj.focus(hwnd); if (Number(focus.fg) === hwnd) break; await sleep(150); }
await sleep(150);
const pf = await inj.probe(hwnd);
await inj.key({ key: 'esc', ms: 5, hwnd });          // 清掉 Alt 轻敲可能留下的系统菜单态
await sleep(250);
const pf2 = await inj.probe(hwnd);
console.log(`[fg] focus ok=${focus.ok} fg=${pf2.fg} == fixture ${Number(pf2.fg) === hwnd}  vis=${pf2.vis} rect=${JSON.stringify(pf2.rect)}`);
fs.writeFileSync(path.join(DIR, 'go.txt'), String(Date.now()), 'utf8');

const code = await new Promise((res) => { const t = setTimeout(() => res('timeout'), 180000); child.on('exit', (c) => { clearTimeout(t); res(c); }); });
console.log(`[fixture] exit=${code}  ${out.trim().slice(-200)}`);
try { child.kill(); } catch { }
await inj.close();

const meta = JSON.parse(fs.readFileSync(path.join(DIR, 'meta.json'), 'utf8'));
console.log(`[meta] window_visible=${meta.window_visible} gate_go=${meta.gate_go} gate_waited=${meta.gate_waited_ms}ms occlusion_skips=${meta.occlusion_skips} target=${meta.target_screen}`);
const r = spawnSync(process.execPath, ['D:\\dsh-arena\\bench\\clicklat.mjs', '--dir', DIR], { encoding: 'utf8', env: ENV });
process.stdout.write(r.stdout || ''); if (r.stderr) process.stderr.write(r.stderr);
console.log('[clicklat2] dir=' + DIR);
process.exit(0);
