/**
 * DSH Arena 移动靶基准 · MCP 客户端（带图片通道）
 *
 * winctl/mcp.mjs 只收 text 内容，截图会被丢掉；本文件把 image 内容也收下来，
 * 并给出 PNG Buffer，供 D:\dsh-tools\aim\vision.mjs 直接解码检测。
 *
 * 只读工具：list_windows / screenshot / find / ocr / element_info
 * 真实输入工具：move / click （走 windows-uia.ps1 的 SetCursorPos + mouse_event）
 */
import { spawn } from 'node:child_process';

const ROOT = process.env.WCU_ROOT ?? 'D:\\dsh-tools\\wcu\\package';
const TMP = 'D:\\dsh-tmp';

export async function connect({ mode = process.env.WCU_MODE ?? 'full' } = {}) {
  const child = spawn(process.execPath, [`${ROOT}\\mcp\\server.mjs`], {
    cwd: ROOT,
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', WCU_TOOL_MODE: mode, WCU_BROWSER_HEADLESS: '1', TEMP: TMP, TMP },
    stdio: ['pipe', 'pipe', 'pipe'],
    windowsHide: true,
  });
  let buffer = '';
  const waiters = new Map();
  const stderrTail = [];
  let nextId = 0;
  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => {
    buffer += chunk;
    for (;;) {
      const nl = buffer.indexOf('\n');
      if (nl === -1) break;
      const line = buffer.slice(0, nl).trim();
      buffer = buffer.slice(nl + 1);
      if (!line.startsWith('{')) continue;
      let msg; try { msg = JSON.parse(line); } catch { continue; }
      if (msg.id !== undefined && waiters.has(msg.id)) { const w = waiters.get(msg.id); waiters.delete(msg.id); w.resolve(msg); }
    }
  });
  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (c) => { stderrTail.push(c); if (stderrTail.length > 80) stderrTail.shift(); });
  child.on('exit', (code) => {
    for (const { reject } of waiters.values()) reject(new Error(`MCP server 退出 code=${code} ${stderrTail.join('').slice(-300)}`));
    waiters.clear();
  });

  const rpc = (method, params, timeoutMs = 60000) => {
    const id = ++nextId;
    return new Promise((resolve, reject) => {
      waiters.set(id, { resolve, reject });
      child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', id, method, params })}\n`);
      setTimeout(() => { if (waiters.delete(id)) reject(new Error(`${method} 超时(${timeoutMs}ms)`)); }, timeoutMs);
    });
  };
  await rpc('initialize', { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'arena-bench', version: '1.0' } });
  child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized', params: {} })}\n`);

  let names = null;
  const tool = async (name, args = {}) => {
    const full = name.startsWith('windows_computer_use_') ? name : `windows_computer_use_${name}`;
    const t0 = Date.now();
    const res = await rpc('tools/call', { name: full, arguments: args }, 60000);
    const ms = Date.now() - t0;
    const content = res.result?.content ?? [];
    const text = content.filter((c) => c.type === 'text').map((c) => c.text).join('\n');
    const images = content.filter((c) => c.type === 'image').map((c) => Buffer.from(c.data, 'base64'));
    let data = null;
    try { data = JSON.parse(text); } catch { /* 非 JSON 回复 */ }
    return { text, data, images, png: images[0] ?? null, isError: res.result?.isError === true, ms };
  };

  return {
    tool,
    get toolNames() { return names; },
    async listTools() { const r = await rpc('tools/list', {}); names = (r.result?.tools ?? []).map((t) => t.name); return names; },
    close: async () => { try { child.stdin.end(); } catch {} await new Promise((r) => setTimeout(r, 150)); try { if (child.exitCode === null) child.kill(); } catch {} },
  };
}

/** 适配 input.mjs 的 InputEngine：sender 只需 { call(tool,args) } */
export function engineSender(client) {
  return {
    lastRaw: null,
    async call(tool, args = {}) {
      const r = await client.tool(tool, args);
      this.lastRaw = r;
      return { ok: !r.isError, text: r.text, isError: r.isError };
    },
    async close() {},
  };
}

/** 枚举顶层窗口 */
export async function listWindows(client, max = 200) {
  const r = await client.tool('list_windows', { includeInvisible: false, maxWindows: max });
  return r.data?.windows ?? [];
}

export const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';

/** 把 PowerShell 脚本用 -EncodedCommand 跑（命令行里不留明文，避免误杀自己人） */
export function runPs(script, { timeoutMs = 20000 } = {}) {
  const enc = Buffer.from(script, 'utf16le').toString('base64');
  const child = spawn(PS, ['-NoProfile', '-NonInteractive', '-EncodedCommand', enc], {
    env: { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true,
  });
  let out = '', err = '';
  child.stdout.on('data', (c) => { out += c; });
  child.stderr.on('data', (c) => { err += c; });
  return new Promise((resolve) => {
    let done = false;
    const fin = (v) => { if (!done) { done = true; resolve(v); } };
    const timer = setTimeout(() => { try { child.kill(); } catch {} fin({ code: -1, out, err, timeout: true }); }, timeoutMs);
    child.on('error', (e) => { clearTimeout(timer); fin({ code: -2, out, err: String(e?.message ?? e) }); });
    child.on('exit', (code) => { clearTimeout(timer); fin({ code, out, err }); });
  });
}

/** 只杀"正在跑靶场脚本"的 powershell（正则现场拼接 + EncodedCommand，绝不误杀调用者自己） */
export async function killStaleArena() {
  const script = [
    `$rx = 'arena' + '(-move)?\\.ps1'`,
    `$k = @()`,
    `Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match $rx -and $_.ProcessId -ne $PID } | ForEach-Object { $k += $_.ProcessId; try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop } catch {} }`,
    `if ($k.Count) { 'killed=' + ($k -join ',') } else { 'killed=none' }`,
  ].join('; ');
  let r = await runPs(script, { timeoutMs: 15000 });
  let killed = (r.out ?? '').trim();
  // 退路：进程杀不干净时按窗口关（不需要也会是无害的空操作）
  const remaining = (r.out ?? '').includes('killed=none') ? 0 : 1;
  return { killed, remainingHint: remaining, code: r.code };
}

/** 等 "DSH Arena" 窗口出现 */
export async function waitArenaWindow(client, { tries = 40, intervalMs = 400 } = {}) {
  for (let i = 0; i < tries; i++) {
    const ws = await listWindows(client);
    const w = ws.find((x) => /DSH\s*Arena/i.test(x.name ?? ''));
    if (w) return { win: w, list: ws };
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  return { win: null, list: await listWindows(client) };
}

/** 关掉所有 DSH Arena 窗口 */
export async function closeArenaWindows(client) {
  const ws = await listWindows(client);
  const hit = ws.filter((x) => /DSH\s*Arena/i.test(x.name ?? ''));
  for (const w of hit) await client.tool('close_window', { nativeWindowHandle: w.nativeWindowHandle });
  await new Promise((r) => setTimeout(r, 1200));
  const after = await listWindows(client);
  return { closed: hit.map((w) => w.nativeWindowHandle), remaining: after.filter((x) => /DSH\s*Arena/i.test(x.name ?? '')).map((w) => w.nativeWindowHandle) };
}
