/** 诊断：按 (hwnd,msg) 统计某次 burst 时间窗内的事件 */
import fs from 'node:fs';
const DIR = 'D:\\dsh-arena\\bench\\keylat';
const raw = JSON.parse(fs.readFileSync(DIR + '\\native-events.json', 'utf8'));
const nat = JSON.parse(fs.readFileSync(DIR + '\\keylat-native.json', 'utf8'));
const label = process.argv[2] ?? 'fg/mouse-sendinput';
const c = nat.cases.find((x) => x.label === label);
const b = nat.raw.find(() => false);
const freq = raw.freq;
const t0 = nat.cases.indexOf(c) >= 0 ? null : null;
// 从 native.json 的 lat 数组反推：直接用 native-events 全量统计即可
const win = [];
for (let i = 0; i < raw.events.length; i++) {
  const e = raw.events[i];
  if (e[0] === 0x201 || e[0] === 0x202) win.push(e);
}
const byKey = {};
for (const e of win) { const k = e[3] + '/0x' + e[0].toString(16); byKey[k] = (byKey[k] ?? 0) + 1; }
console.log('target=' + raw.target + ' cover=' + raw.cover, 'mouse-down/up events by hwnd/msg:', JSON.stringify(byKey));
console.log('label=' + label + ' n=' + c.n + ' got=' + c.got + ' loss=' + c.loss + ' lat=' + JSON.stringify(c.lat));
console.log('totalEvents=' + raw.events.length + ' span=' + ((raw.exitTick - raw.anchorTick) / freq * 1000).toFixed(0) + 'ms');
