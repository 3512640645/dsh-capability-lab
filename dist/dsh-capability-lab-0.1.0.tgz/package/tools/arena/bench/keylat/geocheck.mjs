/** 只看接收器窗口的几何/可见性/指针命中（接收器自报 + 插件 list_windows 交叉验证） */
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { connect, listWindows } from '../client.mjs';
const DIR = 'D:\\dsh-arena\\bench\\keylat';
const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
for (const p of ['cmd.txt', 'status.json']) { try { fs.rmSync(DIR + '\\' + p); } catch {} }
const rec = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', DIR + '\\receiver.ps1', '-Dir', DIR, '-LifeMs', '90000'],
  { env: ENV, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
const st = async () => { try { return JSON.parse(fs.readFileSync(DIR + '\\status.json', 'utf8')); } catch { return null; } };
let s = null;
for (let i = 0; i < 80; i++) { s = await st(); if (s?.cmd) break; await sleep(200); }
console.log('boot status: ' + JSON.stringify(s));
fs.writeFileSync(DIR + '\\cmd.txt', 'fore:' + Date.now());
for (let i = 0; i < 40; i++) { s = await st(); if (s?.cmd === 'fore') break; await sleep(200); }
console.log('fore status: ' + JSON.stringify(s));
const c = await connect();
const ws = await listWindows(c);
for (const w of ws) if (/KEYLAT/i.test(w.name ?? '')) console.log('list_windows: ' + JSON.stringify({ n: w.name, h: w.nativeWindowHandle, r: w.boundingBox }));
await c.close();
fs.writeFileSync(DIR + '\\cmd.txt', 'quit:' + Date.now());
await sleep(1200);
try { rec.kill(); } catch {}
