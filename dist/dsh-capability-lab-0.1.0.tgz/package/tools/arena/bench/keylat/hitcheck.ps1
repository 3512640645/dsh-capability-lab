param()
$env:TEMP = 'D:\dsh-tmp'; $env:TMP = 'D:\dsh-tmp'
$cs = @'
using System; using System.Text; using System.Runtime.InteropServices;
public class WQ {
  [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT p);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr h, StringBuilder t, int c);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr h, StringBuilder t, int c);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int i);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h, uint f);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  public static string Dump(IntPtr h) {
    var t = new StringBuilder(300); GetWindowTextW(h, t, 300);
    var cn = new StringBuilder(300); GetClassNameW(h, cn, 300);
    RECT r; GetWindowRect(h, out r);
    return "hwnd=" + h.ToInt64() + " cls=" + cn + " text='" + t + "' isWin=" + IsWindow(h) + " vis=" + IsWindowVisible(h)
      + " rect=(" + r.L + "," + r.T + "," + r.R + "," + r.B + ") exStyle=0x" + GetWindowLong(h, -20).ToString("X")
      + " style=0x" + GetWindowLong(h, -16).ToString("X") + " root=" + GetAncestor(h, 2).ToInt64();
  }
  public static string Hit(int x, int y) {
    POINT p; p.X = x; p.Y = y;
    IntPtr w = WindowFromPoint(p);
    return "hit(" + x + "," + y + ")=" + w.ToInt64() + " [" + Dump(w) + "]";
  }
}
'@
Add-Type -TypeDefinition $cs -Language CSharp

$rec = Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -PassThru -WindowStyle Hidden `
  -ArgumentList '-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', 'D:\dsh-arena\bench\keylat\receiver.ps1', '-Dir', 'D:\dsh-arena\bench\keylat', '-LifeMs', '120000'
$st = $null
for ($i = 0; $i -lt 60; $i++) { Start-Sleep -Milliseconds 300; try { $st = Get-Content 'D:\dsh-arena\bench\keylat\status.json' -Raw | ConvertFrom-Json; if ($st.cmd) { break } } catch { } }
"target=$($st.target) cover=$($st.cover) fg=$($st.fg) fgIsTarget=$($st.fg -eq $st.target)"
[WQ]::Dump([IntPtr]$st.target)
[WQ]::Dump([IntPtr]$st.cover)
'--- 命中测试 ---'
foreach ($pt in @(@(100, 100), @(420, 320), @(700, 520), @(1100, 290))) { [WQ]::Hit($pt[0], $pt[1]) }
'--- 前台 ---'
[WQ]::Dump([WQ]::GetForegroundWindow())
Set-Content 'D:\dsh-arena\bench\keylat\cmd.txt' ('quit:' + (Get-Date).Ticks)
Start-Sleep -Milliseconds 1200
if (-not $rec.HasExited) { Stop-Process -Id $rec.Id -Force }
'receiver stopped'
