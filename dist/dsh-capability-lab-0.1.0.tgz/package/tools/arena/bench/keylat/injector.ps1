# =============================================================================
# KEYLAT RESIDENT INJECTOR  (keylat/injector.ps1)
#   One start, many injections. Compiled once (Add-Type), then a pure C# stdin
#   loop: no PowerShell per-line cost, no Add-Type per call, no window lookup.
#   Latency of one command = parse + P/Invoke only (measured, reported per line).
#
#   Protocol (one ASCII line per command, one ASCII line per reply, prefix "R "):
#     P                                  ping          -> {"op":"ping",pid,freq,t0,t1}
#     K <mode> <vk> <scan> <holdMs> <hwnd> <ch>   single key (hold = duration)
#     C <mode> <holdMs> <hwnd> <n> <vk:scan:ch> ...      chord (down xN, hold, up xN rev)
#     S <mode> <gapMs>  <hwnd> <n> <vk:scan:ch:hold> ... sequence (per step down/hold/up/gap)
#     E <hwnd>                           probe window (rect/vis/fg)
#     F <hwnd>                           give foreground to <hwnd>
#     Q                                  quit
#   modes: send=SendInput VK | sendscan=SendInput scancode | kbd=keybd_event
#          post=WM_KEYDOWN(+WM_CHAR)+WM_KEYUP with scancode lParam | postc=WM_CHAR only
#          postk=WM_KEYDOWN+WM_KEYUP only
#   hwnd 0 = resolve to the current foreground window at call time.
#   Reply for key ops: {"op","mode","vk","hwnd","fg","p0","t0","td","t1","ovh","call","keys"}
#     p0 = tick when the line was parsed, t0 = tick before the first injection,
#     td = tick after the first key-down, t1 = tick after the last event.
#     ovh = (td-p0)/freq*1000 = parse+inject overhead WITHOUT hold; call = (t1-t0) WITH hold.
#   All ticks are Stopwatch.GetTimestamp() = QPC = machine-global, so the target
#   window can subtract them directly (see arena-beat.ps1 header swZeroQpc/qpcFreq).
#
#   ASCII only on purpose: Windows PowerShell 5.1 reads a BOM-less .ps1 as ANSI.
#   Usage: powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File injector.ps1 [-Warm]
# =============================================================================
param([switch]$Warm)

$ErrorActionPreference = 'Stop'
$env:TEMP = 'D:\dsh-tmp'; $env:TMP = 'D:\dsh-tmp'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$cs = @'
using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

[StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
[StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
[StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr extra; }
[StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx, dy; public uint mouseData, dwFlags, time; public IntPtr extra; }
[StructLayout(LayoutKind.Sequential)] public struct HARDWAREINPUT { public uint uMsg; public ushort wParamL, wParamH; }
[StructLayout(LayoutKind.Explicit)] public struct INPUTUNION { [FieldOffset(0)] public KEYBDINPUT ki; [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public HARDWAREINPUT hi; }
[StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public INPUTUNION u; }

public static class Inj
{
    [DllImport("user32.dll", SetLastError = true)] static extern uint SendInput(uint n, INPUT[] p, int cb);
    [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool PostMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
    [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint type);
    [DllImport("user32.dll")] static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
    [DllImport("user32.dll")] static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
    const uint ME_LEFTDOWN = 0x0002, ME_LEFTUP = 0x0004;

    public static long Fq = Stopwatch.Frequency;
    const uint WM_KEYDOWN = 0x100, WM_KEYUP = 0x101, WM_CHAR = 0x102;
    const uint KE_KEYUP = 0x0002, KE_UNICODE = 0x0004, KE_SCANCODE = 0x0008;

    static string N(double v) { return v.ToString("F3", CultureInfo.InvariantCulture); }
    static double Ms(long a, long b) { return (double)(b - a) * 1000.0 / (double)Fq; }

    static INPUT KI(ushort vk, ushort scan, uint flags)
    {
        INPUT i = new INPUT(); i.type = 1;
        i.u.ki.wVk = vk; i.u.ki.wScan = scan; i.u.ki.dwFlags = flags; return i;
    }

    static void SleepAccurate(int ms)
    {
        if (ms <= 0) return;
        Stopwatch sw = Stopwatch.StartNew();
        int s = ms - 2;
        if (s > 0) Thread.Sleep(s);
        while (sw.Elapsed.TotalMilliseconds < ms) Thread.SpinWait(60);
    }

    static ushort ScanOf(ushort vk, ushort scan)
    {
        if (scan != 0) return scan;
        return (ushort)(MapVirtualKey(vk, 0) & 0xFF);
    }

    static IntPtr Resolve(IntPtr h) { return h == IntPtr.Zero ? GetForegroundWindow() : h; }

    // one key-down; returns nothing, caller timestamps around it
    static void Down(string mode, IntPtr h, ushort vk, ushort scan, ushort ch)
    {
        ushort sc = ScanOf(vk, scan);
        switch (mode)
        {
            case "send":
                SendInput(1, new INPUT[] { KI(vk, 0, 0) }, Marshal.SizeOf(typeof(INPUT))); break;
            case "sendscan":
                SendInput(1, new INPUT[] { KI(0, sc, KE_SCANCODE) }, Marshal.SizeOf(typeof(INPUT))); break;
            case "kbd":
                keybd_event((byte)vk, (byte)sc, 0, UIntPtr.Zero); break;
            case "post":
                PostMessageW(h, WM_KEYDOWN, (IntPtr)vk, (IntPtr)(sc << 16 | 1));
                if (ch != 0) PostMessageW(h, WM_CHAR, (IntPtr)ch, (IntPtr)1);
                break;
            case "postk":
                PostMessageW(h, WM_KEYDOWN, (IntPtr)vk, (IntPtr)(sc << 16 | 1)); break;
            case "postc":
                PostMessageW(h, WM_CHAR, (IntPtr)(ch == 0 ? vk : ch), (IntPtr)1); break;
            default: throw new Exception("bad mode " + mode);
        }
    }

    static void Up(string mode, IntPtr h, ushort vk, ushort scan)
    {
        ushort sc = ScanOf(vk, scan);
        switch (mode)
        {
            case "send":
                SendInput(1, new INPUT[] { KI(vk, 0, KE_KEYUP) }, Marshal.SizeOf(typeof(INPUT))); break;
            case "sendscan":
                SendInput(1, new INPUT[] { KI(0, sc, KE_SCANCODE | KE_KEYUP) }, Marshal.SizeOf(typeof(INPUT))); break;
            case "kbd":
                keybd_event((byte)vk, (byte)sc, KE_KEYUP, UIntPtr.Zero); break;
            case "post":
            case "postk":
                PostMessageW(h, WM_KEYUP, (IntPtr)vk, (IntPtr)(1 << 30 | 1 << 31 | sc << 16 | 1)); break;
            case "postc":
                break;
        }
    }

    public static long[] Key(string mode, long hwnd, int vk, int scan, int holdMs, int ch)
    {
        IntPtr h = Resolve((IntPtr)hwnd);
        long p0 = Stopwatch.GetTimestamp();
        Down(mode, h, (ushort)vk, (ushort)scan, (ushort)ch);
        long td = Stopwatch.GetTimestamp();
        SleepAccurate(holdMs);
        Up(mode, h, (ushort)vk, (ushort)scan);
        long t1 = Stopwatch.GetTimestamp();
        return new long[] { p0, td, t1 };
    }

    public static string DoKey(string mode, long hwnd, int vk, int scan, int holdMs, int ch, long p0)
    {
        IntPtr want = hwnd == 0 ? GetForegroundWindow() : (IntPtr)hwnd;
        long fg = GetForegroundWindow().ToInt64();
        long t0 = Stopwatch.GetTimestamp();
        long[] k = Key(mode, hwnd, vk, scan, holdMs, ch);
        long t1 = Stopwatch.GetTimestamp();
        return "R {\"op\":\"key\",\"mode\":\"" + mode + "\",\"vk\":" + vk + ",\"scan\":" + ScanOf((ushort)vk, (ushort)scan)
             + ",\"holdMs\":" + holdMs + ",\"hwnd\":" + want.ToInt64() + ",\"fg\":" + fg
             + ",\"p0\":" + p0 + ",\"t0\":" + t0 + ",\"td\":" + k[1] + ",\"t1\":" + t1
             + ",\"pre\":" + N(Ms(p0, t0)) + ",\"ovh\":" + N(Ms(t0, k[1])) + ",\"call\":" + N(Ms(t0, t1))
             + ",\"keys\":[[" + t0 + "," + k[1] + "]]}";
    }

    public static string DoChord(string mode, long hwnd, int holdMs, string[] specs, long p0)
    {
        IntPtr want = hwnd == 0 ? GetForegroundWindow() : (IntPtr)hwnd;
        long fg = GetForegroundWindow().ToInt64();
        long t0 = Stopwatch.GetTimestamp();
        IntPtr h = want;
        int n = specs.Length;
        ushort[] vks = new ushort[n], scs = new ushort[n], chs = new ushort[n];
        long[] dn = new long[n], up = new long[n];
        for (int i = 0; i < n; i++)
        {
            string[] p = specs[i].Split(':');
            vks[i] = (ushort)int.Parse(p[0]);
            scs[i] = p.Length > 1 ? (ushort)int.Parse(p[1]) : (ushort)0;
            chs[i] = p.Length > 2 ? (ushort)int.Parse(p[2]) : (ushort)0;
        }
        for (int i = 0; i < n; i++) { long a = Stopwatch.GetTimestamp(); Down(mode, h, vks[i], scs[i], chs[i]); dn[i] = a; }
        long td = Stopwatch.GetTimestamp();
        SleepAccurate(holdMs);
        for (int i = n - 1; i >= 0; i--) { Up(mode, h, vks[i], scs[i]); up[i] = Stopwatch.GetTimestamp(); }
        long t1 = Stopwatch.GetTimestamp();
        StringBuilder keys = new StringBuilder("[");
        for (int i = 0; i < n; i++) { if (i > 0) keys.Append(','); keys.Append('[').Append(dn[i]).Append(',').Append(up[i]).Append(']'); }
        keys.Append(']');
        return "R {\"op\":\"chord\",\"mode\":\"" + mode + "\",\"n\":" + n + ",\"holdMs\":" + holdMs
             + ",\"hwnd\":" + want.ToInt64() + ",\"fg\":" + fg + ",\"p0\":" + p0 + ",\"t0\":" + t0 + ",\"td\":" + td
             + ",\"t1\":" + t1 + ",\"pre\":" + N(Ms(p0, t0)) + ",\"ovh\":" + N(Ms(t0, td)) + ",\"call\":" + N(Ms(t0, t1))
             + ",\"keys\":" + keys + "}";
    }

    public static string DoSeq(string mode, long hwnd, int gapMs, string[] specs, long p0)
    {
        IntPtr want = hwnd == 0 ? GetForegroundWindow() : (IntPtr)hwnd;
        long fg = GetForegroundWindow().ToInt64();
        long t0 = Stopwatch.GetTimestamp();
        StringBuilder keys = new StringBuilder("[");
        for (int i = 0; i < specs.Length; i++)
        {
            if (i > 0) SleepAccurate(gapMs);
            string[] p = specs[i].Split(':');
            int vk = int.Parse(p[0]);
            int sc = p.Length > 1 ? int.Parse(p[1]) : 0;
            int ch = p.Length > 2 ? int.Parse(p[2]) : 0;
            int hold = p.Length > 3 ? int.Parse(p[3]) : 0;
            IntPtr h = want;
            long a = Stopwatch.GetTimestamp();
            Down(mode, h, (ushort)vk, (ushort)sc, (ushort)ch);
            long d = Stopwatch.GetTimestamp();
            SleepAccurate(hold);
            Up(mode, h, (ushort)vk, (ushort)sc);
            if (i > 0) keys.Append(',');
            keys.Append('[').Append(a).Append(',').Append(d).Append(']');
        }
        keys.Append(']');
        long t1 = Stopwatch.GetTimestamp();
        return "R {\"op\":\"seq\",\"mode\":\"" + mode + "\",\"n\":" + specs.Length + ",\"gapMs\":" + gapMs
             + ",\"hwnd\":" + want.ToInt64() + ",\"fg\":" + fg + ",\"p0\":" + p0 + ",\"t0\":" + t0 + ",\"t1\":" + t1
             + ",\"pre\":" + N(Ms(p0, t0)) + ",\"call\":" + N(Ms(t0, t1)) + ",\"keys\":" + keys + "}";
    }

    // M <x> <y> <click?1:0> : real pointer (SetCursorPos + mouse_event LEFTDOWN/UP), same QPC stamps
    public static string DoMouse(int x, int y, int click, long p0)
    {
        POINT before; GetCursorPos(out before);
        long t0 = Stopwatch.GetTimestamp();
        SetCursorPos(x, y);
        long t1 = Stopwatch.GetTimestamp();
        long td = t1;
        if (click != 0) { mouse_event(ME_LEFTDOWN, 0, 0, 0, UIntPtr.Zero); td = Stopwatch.GetTimestamp(); }
        long t2 = Stopwatch.GetTimestamp();
        if (click != 0) { mouse_event(ME_LEFTUP, 0, 0, 0, UIntPtr.Zero); }
        long t3 = Stopwatch.GetTimestamp();
        POINT after; GetCursorPos(out after);
        return "R {\"op\":\"mouse\",\"x\":" + x + ",\"y\":" + y + ",\"click\":" + click
             + ",\"p0\":" + p0 + ",\"t0\":" + t0 + ",\"t1\":" + t1 + ",\"td\":" + td + ",\"t3\":" + t3
             + ",\"pre\":" + N(Ms(p0, t0)) + ",\"ovh\":" + N(Ms(t0, td)) + ",\"call\":" + N(Ms(t0, t3))
             + ",\"before\":\"" + before.X + "," + before.Y + "\",\"after\":\"" + after.X + "," + after.Y
             + "\",\"fg\":" + GetForegroundWindow().ToInt64()
             + ",\"keys\":[[" + t0 + "," + td + "]]}";
    }

    public static string DoProbe(long hwnd)    {
        IntPtr h = (IntPtr)hwnd;
        RECT r; GetWindowRect(h, out r);
        return "R {\"op\":\"probe\",\"hwnd\":" + hwnd + ",\"isWindow\":" + (IsWindow(h) ? "true" : "false")
             + ",\"vis\":" + (IsWindowVisible(h) ? "true" : "false")
             + ",\"rect\":[" + r.L + "," + r.T + "," + r.R + "," + r.B + "]"
             + ",\"fg\":" + GetForegroundWindow().ToInt64() + ",\"tick\":" + Stopwatch.GetTimestamp() + "}";
    }

    public static string DoFocus(long hwnd)
    {
        IntPtr h = (IntPtr)hwnd;
        if (GetForegroundWindow() != h)
        {
            IntPtr fg = GetForegroundWindow();
            uint ft = GetWindowThreadProcessId(fg, IntPtr.Zero), tt = GetWindowThreadProcessId(h, IntPtr.Zero);
            bool att = false;
            if (ft != tt && ft != 0) att = AttachThreadInput(tt, ft, true);
            try { keybd_event(0x12, 0, 0, UIntPtr.Zero); keybd_event(0x12, 0, 2, UIntPtr.Zero); BringWindowToTop(h); SetForegroundWindow(h); }
            finally { if (att) AttachThreadInput(tt, ft, false); }
        }
        return "R {\"op\":\"focus\",\"hwnd\":" + hwnd + ",\"fg\":" + GetForegroundWindow().ToInt64()
             + ",\"ok\":" + (GetForegroundWindow() == h ? "true" : "false") + ",\"tick\":" + Stopwatch.GetTimestamp() + "}";
    }

    public static void Loop(string warm)
    {
        Console.Out.WriteLine("R {\"op\":\"ready\",\"schema\":\"keylat/injector/1\",\"pid\":" + Process.GetCurrentProcess().Id
            + ",\"freq\":" + Fq + ",\"tick\":" + Stopwatch.GetTimestamp() + "}");
        Console.Out.Flush();
        if (warm == "1") { Key("send", 0, 0x12, 0, 0, 0); }   // warm the SendInput path once
        string line;
        while ((line = Console.In.ReadLine()) != null)
        {
            string rep;
            long p0 = Stopwatch.GetTimestamp();   // line already read: p0 -> parse start
            try
            {
                string s = line.Trim();
                if (s.Length == 0) continue;
                string[] a = s.Split(' ');
                string op = a[0].ToUpperInvariant();
                if (op == "Q") { rep = "R {\"op\":\"quit\",\"tick\":" + Stopwatch.GetTimestamp() + "}"; }
                else if (op == "P") { rep = "R {\"op\":\"ping\",\"pid\":" + Process.GetCurrentProcess().Id + ",\"p0\":" + p0 + ",\"t1\":" + Stopwatch.GetTimestamp() + "}"; }
                else if (op == "K") { rep = DoKey(a[1], long.Parse(a[5]), int.Parse(a[2]), int.Parse(a[3]), int.Parse(a[4]), a.Length > 6 ? int.Parse(a[6]) : 0, p0); }
                else if (op == "C") { rep = DoChord(a[1], long.Parse(a[3]), int.Parse(a[2]), Sub(a, 5), p0); }
                else if (op == "S") { rep = DoSeq(a[1], long.Parse(a[3]), int.Parse(a[2]), Sub(a, 5), p0); }
                else if (op == "E") { rep = DoProbe(long.Parse(a[1])); }
                else if (op == "M") { rep = DoMouse(int.Parse(a[1]), int.Parse(a[2]), int.Parse(a[3]), p0); }
                else if (op == "F") { rep = DoFocus(long.Parse(a[1])); }
                else if (op == "X") { PostMessageW((IntPtr)long.Parse(a[1]), 0x0010, IntPtr.Zero, IntPtr.Zero); rep = "R {\"op\":\"close\",\"hwnd\":" + a[1] + ",\"tick\":" + Stopwatch.GetTimestamp() + "}"; }
                else rep = "R {\"op\":\"err\",\"msg\":\"unknown op " + op + "\"}";
            }
            catch (Exception ex) { rep = "R {\"op\":\"err\",\"msg\":\"" + ex.Message.Replace('"', '\'') + "\"}"; }
            Console.Out.WriteLine(rep);
            Console.Out.Flush();
            if (rep.StartsWith("R {\"op\":\"quit\"")) break;
        }
    }

    static string[] Sub(string[] a, int from)
    {
        int n = a.Length - from; if (n < 0) n = 0;
        string[] r = new string[n];
        Array.Copy(a, from, r, 0, n);
        return r;
    }
}
'@

Add-Type -TypeDefinition $cs -ReferencedAssemblies 'System.dll', 'System.Core.dll' -Language CSharp
[Inj]::Loop($(if ($Warm) { '1' } else { '0' }))
