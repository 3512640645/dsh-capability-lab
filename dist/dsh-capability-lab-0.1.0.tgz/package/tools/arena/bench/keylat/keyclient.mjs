/**
 * keylat / keyclient.mjs  —  可复用的低延迟键鼠客户端包装（Node 侧）
 *
 * 内部走常驻注入器 injector.ps1：进程只启动一次，之后每条指令只是"写一行 + 收一行"，
 * 注入在常驻进程里用已编译好的 P/Invoke 直接做，没有 Add-Type / 窗口解析 / 前台切换。
 *
 * 公开接口（全部返回 Promise，resolve 出注入器回执，含 QPC 时间戳）:
 *   const inj = await startInjector();
 *   await inj.hold('w', 50);                       // 按下 w，保持 50ms，松开（默认走 SendInput 真实前台）
 *   await inj.hold('w', 50, { mode: 'post', hwnd }); // 不抢前台，PostMessage WM_KEYDOWN+WM_CHAR+WM_KEYUP（带扫描码）
 *   await inj.chord(['ctrl', 'c'], 40);            // 同时按下，保持 40ms，反序松开
 *   await inj.sequence([{ key: 'w', ms: 40 }, { key: 'a', ms: 40 }], { gapMs: 30 });
 *   await inj.key({ vk: 87, scan: 0x11, ms: 25, mode: 'sendscan' });   // 直接给键码/扫描码/时长
 *   await inj.focus(hwnd);  await inj.probe(hwnd);  await inj.ping();
 *   inj.stats();  await inj.close();
 *
 * 回执字段：{ op, mode, vk, scan, hwnd, fg, p0, t0, td, t1, pre, ovh, call, keys:[[tickBeforeDown,tickAfterDown],...] }
 *   pre = 解析开销(ms)，ovh = 注入调用开销(ms, 不含 hold)，call = 整条指令(含 hold)，全部 QPC 同机时钟。
 *   keys 里每按一次的 t0 就是外部算"投递延迟"的锚点（目标窗口 tick − t0）。
 */
import { spawn } from 'node:child_process';
import readline from 'node:readline';

const PS_DEFAULT = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const SCRIPT_DEFAULT = 'D:\\dsh-arena\\bench\\keylat\\injector.ps1';

// 键名 -> {vk, scan, ch}（扫描码 0 = 让注入器用 MapVirtualKey 现算）
export const KEYS = (() => {
  const t = {};
  const letters = 'abcdefghijklmnopqrstuvwxyz';
  for (const c of letters) {
    const vk = c.toUpperCase().charCodeAt(0);
    t[c] = { vk, scan: 0, ch: c.charCodeAt(0) };
    t[c.toUpperCase()] = { vk, scan: 0, ch: c.charCodeAt(0) };
  }
  const digits = '0123456789';
  for (const d of digits) t[d] = { vk: d.charCodeAt(0), scan: 0, ch: d.charCodeAt(0) };
  Object.assign(t, {
    space: { vk: 0x20, scan: 0x39, ch: 0x20 }, enter: { vk: 0x0d, scan: 0x1c, ch: 0x0d },
    tab: { vk: 0x09, scan: 0x0f, ch: 0x09 }, esc: { vk: 0x1b, scan: 0x01, ch: 27 },
    shift: { vk: 0x10, scan: 0x2a, ch: 0 }, ctrl: { vk: 0x11, scan: 0x1d, ch: 0 },
    alt: { vk: 0x12, scan: 0x38, ch: 0 }, win: { vk: 0x5b, scan: 0x5b, ch: 0 },
    up: { vk: 0x26, scan: 0xc8, ch: 0 }, down: { vk: 0x28, scan: 0xd0, ch: 0 },
    left: { vk: 0x25, scan: 0xcb, ch: 0 }, right: { vk: 0x27, scan: 0xcd, ch: 0 },
    backspace: { vk: 0x08, scan: 0x0e, ch: 8 }, f1: { vk: 0x70, scan: 0x3b, ch: 0 }, f2: { vk: 0x71, scan: 0x3c, ch: 0 },
  });
  return t;
})();

export function resolveKey(k) {
  if (typeof k === 'number') return { vk: k, scan: 0, ch: 0 };
  if (k && typeof k === 'object') return { vk: k.vk ?? 0, scan: k.scan ?? 0, ch: k.ch ?? 0 };
  const e = KEYS[k] ?? KEYS[String(k).toLowerCase()];
  if (!e) throw new Error('unknown key: ' + k);
  return { ...e };
}

export async function startInjector(opts = {}) {
  const ps = opts.ps ?? PS_DEFAULT;
  const script = opts.script ?? SCRIPT_DEFAULT;
  const env = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
  const args = ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', script];
  if (opts.warm !== false) args.push('-Warm');
  const proc = spawn(ps, args, { env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  const pending = [];
  const backlog = [];
  let stderr = '';
  proc.stderr.on('data', (c) => { stderr += c; });
  readline.createInterface({ input: proc.stdout }).on('line', (l) => {
    const w = pending.shift();
    if (w) w(l); else backlog.push(l);
  });
  proc.on('exit', (code) => { while (pending.length) pending.shift()(new Error('injector exited code=' + code + ' ' + stderr.slice(-200))); });

  const nextLine = (ms) => backlog.length
    ? Promise.resolve(backlog.shift())
    : new Promise((res, rej) => {
      const t = setTimeout(() => rej(new Error('injector reply timeout after ' + ms + 'ms; stderr=' + stderr.slice(-300))), ms);
      pending.push((l) => { clearTimeout(t); if (l instanceof Error) rej(l); else res(l); });
    });

  const send = async (line, timeoutMs = 20000) => {
    const h0 = process.hrtime.bigint();
    const t0 = Date.now();
    proc.stdin.write(line + '\n');
    const raw = await nextLine(timeoutMs);
    const rttUs = Number(process.hrtime.bigint() - h0) / 1000;
    const rttMs = Number((rttUs / 1000).toFixed(3));
    const txt = String(raw);
    if (!txt.startsWith('R ')) throw new Error('bad reply: ' + txt);
    const r = JSON.parse(txt.slice(2));
    if (r.op === 'err') throw new Error('injector error: ' + r.msg);
    r.rttMs = rttMs;
    r.wallMs = t0;
    r.h0 = h0.toString();
    return r;
  };

  const ctl = {
    proc, args: [ps, ...args], stderr: () => stderr,
    freq: 0, pid: 0, ready: null, log: [],
    _record(r) { this.log.push({ op: r.op, mode: r.mode ?? null, vk: r.vk ?? null, pre: r.pre ?? null, ovh: r.ovh ?? null, call: r.call ?? null, rttMs: r.rttMs, fg: r.fg ?? null, hwnd: r.hwnd ?? null, keys: r.keys ?? null }); return r; },
    async ping() { return this._record(await send('P')); },
    key(o = {}) {
      const mode = o.mode ?? 'send';
      const k = resolveKey(o.key ?? o.vk ?? 0);
      const vk = o.vk ?? k.vk, scan = o.scan ?? k.scan, ch = o.ch ?? k.ch;
      const ms = o.ms ?? 0, hwnd = o.hwnd ?? 0;
      return send(`K ${mode} ${vk} ${scan} ${ms} ${hwnd} ${ch}`).then((r) => this._record(r));
    },
    hold(key, ms = 0, o = {}) { return this.key({ ...o, key, ms }); },
    chord(keys, ms = 0, o = {}) {
      const mode = o.mode ?? 'send', hwnd = o.hwnd ?? 0;
      const specs = keys.map((k) => { const r = resolveKey(k); return `${r.vk}:${r.scan}:${r.ch}`; }).join(' ');
      return send(`C ${mode} ${ms} ${hwnd} ${keys.length} ${specs}`).then((r) => this._record(r));
    },
    sequence(steps, o = {}) {
      const mode = o.mode ?? 'send', hwnd = o.hwnd ?? 0, gapMs = o.gapMs ?? 0;
      const specs = steps.map((s) => { const r = resolveKey(s.key ?? s); return `${r.vk}:${r.scan}:${r.ch}:${s.ms ?? 0}`; }).join(' ');
      return send(`S ${mode} ${gapMs} ${hwnd} ${steps.length} ${specs}`).then((r) => this._record(r));
    },
    probe(hwnd) { return send(`E ${hwnd}`); },
    mouse(x, y, o = {}) { return send(`M ${Math.round(x)} ${Math.round(y)} ${o.click === false ? 0 : 1}`).then((r) => this._record(r)); },
    focus(hwnd) { return send(`F ${hwnd}`); },
    closeWindow(hwnd) { return send(`X ${hwnd}`); },   // PostMessage WM_CLOSE（收尾用）
    async close() {
      try { await send('Q', 4000); } catch { }
      try { proc.stdin.end(); } catch { }
      await new Promise((r) => setTimeout(r, 150));
      try { proc.stdout.destroy(); proc.stderr.destroy(); } catch { }
      try { proc.kill(); } catch { }
      try { proc.unref(); } catch { }
    },
    stats() {
      const pick = (arr, f) => (arr.length ? arr.slice().sort((a, b) => a - b)[Math.min(arr.length - 1, Math.floor(f * arr.length))] : null);
      const r3 = (v) => (v === null ? null : Math.round(v * 1000) / 1000);
      const rows = this.log.filter((r) => r.ovh !== null);
      const ovh = rows.map((r) => r.ovh), pre = rows.map((r) => r.pre), rtt = this.log.map((r) => r.rttMs);
      return {
        commands: this.log.length, injected: rows.length,
        ovhMs: { med: r3(pick(ovh, 0.5)), p90: r3(pick(ovh, 0.9)), max: r3(ovh.length ? Math.max(...ovh) : null) },
        preMs: { med: r3(pick(pre, 0.5)), p90: r3(pick(pre, 0.9)), max: r3(pre.length ? Math.max(...pre) : null) },
        rttMs: { med: r3(pick(rtt, 0.5)), p90: r3(pick(rtt, 0.9)), max: r3(rtt.length ? Math.max(...rtt) : null) },
      };
    },
  };
  const ready = await (async () => {
    const l = await nextLine(60000);
    if (!String(l).startsWith('R ')) throw new Error('injector did not become ready: ' + l + ' stderr=' + stderr.slice(-300));
    return JSON.parse(String(l).slice(2));
  })();
  ctl.ready = ready; ctl.freq = ready.freq; ctl.pid = ready.pid;
  return ctl;
}

export const msOfTicks = (ticks, freq) => (ticks / freq) * 1000;
