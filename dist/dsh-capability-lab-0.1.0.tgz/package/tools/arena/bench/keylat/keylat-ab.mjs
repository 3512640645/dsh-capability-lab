/**
 * KEYLAT · A/B：同一个插件调用，两个接收器交替测（mine 高精度 vs arena-beat 旧打点器）
 * 同时打印 list_windows 里两个接收器窗口的几何/状态，回答"窗口能不能被指针命中"。
 */
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { connect, listWindows, waitArenaWindow, closeArenaWindows, PS, runPs } from '../client.mjs';

const N = Number(process.argv[2] ?? 10);
const DIR = 'D:\\dsh-arena\\bench\\keylat';
const f = (p) => DIR + '\\' + p;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
for (const p of ['cmd.txt', 'status.json', 'native-events.json', 'beat-ab.jsonl']) { try { fs.rmSync(f(p)); } catch {} }

const rec = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f('receiver.ps1'), '-Dir', DIR, '-LifeMs', '600000'],
  { env: ENV, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
async function status() { try { return JSON.parse(fs.readFileSync(f('status.json'), 'utf8')); } catch { return null; } }
async function waitStatus(pred, ms, what) { const t0 = Date.now(); while (Date.now() - t0 < ms) { const s = await status(); if (s && pred(s)) return s; await sleep(60); } throw new Error('timeout ' + what); }
const boot = await waitStatus((s) => s.cmd === 'boot', 30000, 'boot');
const TGT = boot.target;

spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', 'D:\\dsh-arena\\arena-beat.ps1',
  '-OutJsonl', f('beat-ab.jsonl'), '-ExitAfterMs', '180000'], { stdio: 'ignore' });

const c = await connect();
const { win: bw } = await waitArenaWindow(c, { tries: 60, intervalMs: 400 });
if (!bw) throw new Error('no arena-beat');
const BH = bw.nativeWindowHandle;
await sleep(500);

const ws = await listWindows(c);
for (const w of ws) if (/KEYLAT|DSH Arena/i.test(w.name ?? '')) console.log('WINDOW ' + JSON.stringify({ name: w.name, hwnd: w.nativeWindowHandle, rect: w.boundingBox, visible: w.isVisible, pid: w.processId }));

fs.writeFileSync(f('cmd.txt'), 'fore:' + Date.now());
await waitStatus((s) => s.cmd === 'fore', 8000, 'fore');

const trials = [];
async function one(tag, hwnd, tool, args, activate) {
  if (activate) { await c.tool('activate_window', { nativeWindowHandle: hwnd }); await sleep(120); }
  const t0 = Date.now();
  const r = await c.tool(tool, args);
  const t1 = Date.now();
  trials.push({ tag, tool, t0, t1, callMs: t1 - t0, ok: !r.isError, note: (r.text ?? '').replace(/\s+/g, ' ').slice(0, 90) });
  await sleep(500);
}
try {
  for (let i = 0; i < N; i++) {
    await one('mine', TGT, 'type_text', { text: 'w', method: 'background', nativeWindowHandle: TGT });
    await one('beat', BH, 'type_text', { text: 'w', method: 'background', nativeWindowHandle: BH }, true);
    console.log('pair ' + (i + 1) + '/' + N);
  }
  await one('mine', TGT, 'click', { x: 100, y: 100, nativeWindowHandle: TGT, dispatch: 'foreground' });
  await one('mine', TGT, 'type_text', { text: 'w', method: 'sendinput', nativeWindowHandle: TGT });
} catch (e) { console.log('[fatal] ' + (e?.message ?? e)); }

fs.writeFileSync(f('cmd.txt'), 'quit:' + Date.now());
await sleep(1500);
try { rec.kill(); } catch {}
await closeArenaWindows(c);
await runPs(`Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match ('arena' + '-beat\\.ps1') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }`, { timeoutMs: 15000 });
await sleep(800);
try { await c.close(); } catch {}

const raw = JSON.parse(fs.readFileSync(f('native-events.json'), 'utf8'));
const freq = raw.freq, ms = (t) => (t / freq) * 1000;
const toTick = (w) => raw.anchorTick + (w - raw.anchorWallMs) * freq / 1000;
const evMine = raw.events.filter((e) => e[3] === raw.target);
let p = 0;
for (const tr of trials.filter((x) => x.tag === 'mine')) {
  const a = toTick(tr.t0);
  while (p < evMine.length && evMine[p][2] < a) p++;
  for (let q = p; q < evMine.length && evMine[q][2] <= a + freq * 2; q++) { tr.arrivalMs = Math.round(ms(evMine[q][2] - a) * 100) / 100; tr.msg = '0x' + evMine[q][0].toString(16); break; }
}
const bl = fs.readFileSync(f('beat-ab.jsonl'), 'utf8').split('\n').filter(Boolean).map((s) => { try { return JSON.parse(s); } catch { return null; } }).filter(Boolean);
const h = bl.find((x) => x.kind === 'header');
const evb = bl.filter((x) => x.kind && x.kind !== 'header' && x.kind !== 'marker');
let used = new Set();
if (h) for (const tr of trials.filter((x) => x.tag === 'beat')) {
  const lo = tr.t0 - h.swZeroUnixMs, hi = lo + 2000;
  const idx = evb.findIndex((e, i) => !used.has(i) && e.swMs >= lo && e.swMs <= hi);
  if (idx >= 0) { used.add(idx); tr.arrivalMs = Math.round(h.swZeroUnixMs + evb[idx].swMs - tr.t0); tr.msg = evb[idx].kind; }
}
for (const tr of trials) console.log(`${tr.tag.padEnd(5)} ${tr.tool.padEnd(10)} call=${String(tr.callMs).padStart(4)}ms arrival=${tr.arrivalMs ?? '-'}${tr.msg ? '(' + tr.msg + ')' : ''} ok=${tr.ok} ${tr.ok ? '' : tr.note}`);
const st = (arr) => { const s = arr.slice().sort((a, b) => a - b); return s.length ? { n: s.length, med: s[Math.floor(s.length / 2)], max: s[s.length - 1] } : { n: 0 }; };
console.log('MINE typetext-bg arrival=' + JSON.stringify(st(trials.filter((t) => t.tag === 'mine' && t.tool === 'type_text' && t.arrivalMs !== undefined).map((t) => t.arrivalMs))));
console.log('BEAT typetext-bg arrival=' + JSON.stringify(st(trials.filter((t) => t.tag === 'beat' && t.arrivalMs !== undefined).map((t) => t.arrivalMs))));
fs.writeFileSync(f('keylat-ab.json'), JSON.stringify({ trials, beatHeader: h ?? null, windows: null }, null, 1), 'utf8');
