/**
 * keylat / keylat-e2e.mjs —— 同源时钟（QPC）端到端按键延迟，**分两段计时**
 *
 * 复现冲突：CONTROL-BENCH 记「前台真实按键 158–188ms」（跨时钟：Node 墙钟 vs 靶场 Stopwatch），
 *           新版自报「SendInput 2.047ms」（同源 QPC）。本文件把所有环节放到**同一台机器的同一个 QPC 时基**上：
 *
 *   t_dec  = Node 侧「决定按键」的 hrtime，用 ping 标定映射到 QPC（最小延迟法，误差=实测抖动带）
 *   p0     = 注入器 C# 循环读完整行、开始解析的 tick（同进程）
 *   t0     = 注入器「即将调用注入 API」的 tick（同进程，紧邻 SendInput/PostMessage）
 *   td     = 注入 API 返回的 tick（同进程）
 *   t_app  = 目标窗口（arena-beat WPF）收到事件的 tick = swZeroQpc + swMs/1000*freq（同机 QPC）
 *
 *   注入前 = t0  - t_dec   （再拆：管道段 p0-t_dec ＋ 解析段 t0-p0，解析段是注入器同进程自报）
 *   注入   = t_app - t0    （API 入口 → 目标窗口收到）
 *   端到端 = t_app - t_dec
 *
 * 用法: node keylat-e2e.mjs [每轮拍数] [拍间隔ms]
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { startInjector, msOfTicks } from './keyclient.mjs';

const DIR = 'D:\\dsh-arena\\bench\\keylat';
const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const BEAT = 'D:\\dsh-arena\\arena-beat.ps1';
const RECV = path.join(DIR, 'receiver.ps1');
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const TS = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const BEATJSONL = path.join(DIR, `beat-e2e-${TS}.jsonl`);
const N = Number(process.argv[2] ?? 30);
const GAP = Number(process.argv[3] ?? 120);
const f = (p) => path.join(DIR, p);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const r3 = (v) => (v === null || v === undefined ? null : Math.round(v * 1000) / 1000);
const q = (a, fr) => (a.length ? a.slice().sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(fr * a.length))] : null);
const agg = (a) => { const v = a.filter((x) => typeof x === 'number' && isFinite(x)); if (!v.length) return { n: 0 }; const s = v.slice().sort((x, y) => x - y); return { n: s.length, med: r3(q(s, 0.5)), p90: r3(q(s, 0.9)), max: r3(s[s.length - 1]), min: r3(s[0]), mean: r3(s.reduce((x, y) => x + y, 0) / s.length) }; };

// ---------- 0. 清掉遗留靶场 ----------
spawnSync(PS, ['-NoProfile', '-Command',
  `Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'arena-beat\\.ps1' } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }`],
  { env: ENV, stdio: 'ignore', windowsHide: true });

// ---------- 1. 目标：arena-beat（WPF，打点用它自己的 QPC） ----------
const beat = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', BEAT,
  '-OutJsonl', BEATJSONL, '-ExitAfterMs', '900000', '-Left', '140', '-Top', '110', '-Width', '900', '-Height', '620'],
  { env: ENV, stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
let beatErr = '';
beat.stderr.on('data', (c) => { beatErr += c; });
let header = null;
for (let i = 0; i < 300; i++) {
  try {
    const first = fs.readFileSync(BEATJSONL, 'utf8').split('\n')[0];
    if (first && first.includes('"kind":"header"')) { header = JSON.parse(first); break; }
  } catch { }
  await sleep(100);
}
if (!header) { console.log('[fatal] arena-beat 未产生 header: ' + beatErr.slice(-400)); process.exit(1); }
const SW0 = Number(header.swZeroQpc), FREQ = Number(header.qpcFreq), HWND = Number(header.hwnd);
console.log(`[target] arena-beat pid=${beat.pid} hwnd=${HWND} qpcFreq=${FREQ} swZeroQpc=${SW0}`);

// ---------- 2. 常驻注入器（同机 QPC） ----------
const inj = await startInjector();
console.log(`[injector] pid=${inj.pid} qpcFreq=${inj.ready.freq} 与靶场同一时基=${inj.ready.freq === FREQ}`);

// ---------- 3. Node hrtime → QPC 标定（最小延迟法） ----------
const M = 60, offs = [];
for (let i = 0; i < M; i++) {
  const h0 = process.hrtime.bigint();
  const r = await inj.ping();
  // 单位必须统一到 QPC tick：hrtime(ns) * freq/1e9 → tick
  offs.push(Number(r.p0) - Number(h0) * FREQ / 1e9);
  await sleep(1);
}
const offMin = Math.min(...offs), offMax = Math.max(...offs);
const nodeTick = (hns) => Number(hns) * FREQ / 1e9 + offMin;   // Node hrtime(ns) → QPC tick
const toMs = (t) => t / FREQ * 1000;
console.log(`[calib] ping=${M} 偏移带=${toMs(offMax - offMin).toFixed(3)}ms  min=${toMs(offMin).toFixed(3)}ms  p50=${toMs(q(offs.slice(), 0.5)).toFixed(3)}ms  max=${toMs(offMax).toFixed(3)}ms`);

// ---------- 4. 前台仲裁 ----------
async function ensureFg() { for (let i = 0; i < 5; i++) { const r = await inj.focus(HWND); if (r.ok) return true; await sleep(150); } return false; }
console.log('[fg] 靶场当前台=' + await ensureFg());

// ---------- 5. 打点 ----------
const beats = [];
async function fire(round, mode, label, mk) {
  const tdec = process.hrtime.bigint();
  const r = await mk();
  const tret = process.hrtime.bigint();
  const k0 = Number(r.keys?.[0]?.[0] ?? r.t0);
  const item = {
    round, mode, label, op: r.op, hwnd: Number(r.hwnd), fg: Number(r.fg), vk: r.vk ?? null,
    decHns: tdec.toString(), retHns: tret.toString(),
    t_dec: nodeTick(tdec), t_ret: nodeTick(tret),
    p0: Number(r.p0), t0: k0, td: Number(r.td ?? r.keys?.[0]?.[1] ?? k0),
    preMs: r.pre ?? null, ovhMs: r.ovh ?? null, callMs: r.call ?? null, rttMs: r.rttMs ?? null,
  };
  beats.push(item);
  return item;
}
async function round(name, mode, n, mk, maker) {
  const list = [];
  for (let i = 0; i < n; i++) {
    await sleep(GAP);
    const b = await fire(name, mode, `${name}#${i + 1}`, () => mk(i));
    b.fgOk = b.fg === HWND;
    list.push(b);
  }
  const ok = list.filter((b) => b.fgOk).length;
  console.log(`[round] ${name}: ${n} 拍（前台命中 ${ok}/${n}）`);
  return list;
}

await sleep(200); await inj.key({ key: 'w', ms: 5 });   // 预热（不计入）
const R = {};
R.sendinputFg = await round('R1-fg-sendinput', 'send', N, (i) => inj.key({ key: 'wasdqerf'[i % 8], ms: 10, hwnd: HWND }));
R.postFg = await round('R2-fg-postmessage', 'post', N, (i) => inj.key({ key: 'wasdqerf'[i % 8], ms: 10, hwnd: HWND, mode: 'post' }));
R.sendsCan = await round('R3-fg-sendscan', 'sendscan', N, (i) => inj.key({ key: 'wasdqerf'[i % 8], ms: 10, hwnd: HWND, mode: 'sendscan' }));

// ---------- 6. 后台相位：把前台交给 receiver 的 cover 窗口 ----------
let bgInfo = { ran: false };
try {
  for (const p of ['cmd.txt', 'status.json', 'native-events.json']) { try { fs.rmSync(f(p)); } catch { } }
  const recv = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', RECV, '-Dir', DIR, '-LifeMs', '600000'],
    { env: ENV, stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
  let boot = null;
  for (let i = 0; i < 200; i++) { try { const s = JSON.parse(fs.readFileSync(f('status.json'), 'utf8')); if (s.cmd === 'boot') { boot = s; break; } } catch { } await sleep(100); }
  if (boot) {
    fs.writeFileSync(f('cmd.txt'), 'back:' + Date.now());
    for (let i = 0; i < 60; i++) { const s = JSON.parse(fs.readFileSync(f('status.json'), 'utf8')); if (s.cmd === 'back' && s.fg === boot.cover) break; await sleep(100); }
    const st = JSON.parse(fs.readFileSync(f('status.json'), 'utf8'));
    const pr = await inj.probe(HWND);
    bgInfo = { ran: true, cover: boot.cover, target: boot.target, fgNow: st.fg, arenaIsFg: pr.fg === HWND };
    console.log(`[bg] cover=${boot.cover} fg现在=${st.fg} 靶场还在前台=${bgInfo.arenaIsFg}`);
    if (bgInfo.arenaIsFg) { await inj.focus(boot.cover); await sleep(200); }
    R.sendinputBg = await round('R4-bg-sendinput', 'send', 20, (i) => inj.key({ key: 'wasdqerf'[i % 8], ms: 10, hwnd: HWND }));
    R.postBg = await round('R5-bg-postmessage', 'post', 20, (i) => inj.key({ key: 'wasdqerf'[i % 8], ms: 10, hwnd: HWND, mode: 'post' }));
  } else console.log('[bg] receiver 未起来，跳过后台相位');
  try { fs.writeFileSync(f('cmd.txt'), 'quit:' + Date.now()); } catch { }
  await sleep(800);
  try { recv.kill(); } catch { }
} catch (e) { console.log('[bg-fatal] ' + (e?.message ?? e)); }

// ---------- 7. 收尾 ----------
const stats = inj.stats();
await inj.closeWindow(HWND);
await new Promise((res) => { const t = setTimeout(() => res('timeout'), 8000); beat.on('exit', (c) => { clearTimeout(t); res(c); }); });
try { beat.kill(); } catch { }
await inj.close();
await sleep(400);

// ---------- 8. 归因：把靶场事件匹配到每一拍 ----------
const lines = fs.readFileSync(BEATJSONL, 'utf8').split('\n').filter((l) => l.trim());
const evs = [];
for (const l of lines) {
  let o; try { o = JSON.parse(l); } catch { continue; }
  if (o.kind === 'header' || o.kind === 'marker') continue;
  evs.push({ kind: o.kind, n: o.n ?? null, tick: SW0 + (o.swMs / 1000) * FREQ, vk: o.vk ?? null, text: o.text ?? null });
}
evs.sort((a, b) => a.tick - b.tick);
const TOL = 0.3, CAP = 80, WIDE = 500;
let cursor = 0;
function match(t0) {
  const lo = t0 - (TOL / 1000) * FREQ, hi = t0 + (CAP / 1000) * FREQ, hw = t0 + (WIDE / 1000) * FREQ;
  let i = cursor;
  while (i < evs.length && evs[i].tick < lo) i++;
  for (let j = i; j < evs.length && evs[j].tick <= hi; j++) { cursor = j + 1; return { ev: evs[j], late: false }; }
  for (let j = i; j < evs.length && evs[j].tick <= hw; j++) { cursor = j + 1; return { ev: evs[j], late: true }; }
  cursor = i; return null;
}
const detail = [];
for (const b of beats) {
  const m = match(b.t0);
  detail.push({
    ...b,
    got: !!m && !m.late, late: !!m && m.late,
    kind: m ? m.ev.kind : null,
    prePipeMs: r3(msOfTicks(b.p0 - b.t_dec, FREQ)),      // Node 决定 → 注入器读到行
    preParseMs: r3(msOfTicks(b.t0 - b.p0, FREQ)),        // 注入器读到行 → 注入 API 入口（同进程）
    preTotalMs: r3(msOfTicks(b.t0 - b.t_dec, FREQ)),     // 注入前合计
    injectMs: m ? r3(msOfTicks(m.ev.tick - b.t0, FREQ)) : null,   // 注入 API 入口 → 目标收到
    e2eMs: m ? r3(msOfTicks(m.ev.tick - b.t_dec, FREQ)) : null,   // 端到端
    apiCallMs: r3(msOfTicks(b.td - b.t0, FREQ)),         // 注入 API 调用本身（同进程）
  });
}
const rounds = Object.keys(R).map((k) => {
  const d = detail.filter((x) => x.round === R[k][0]?.round);
  const name = R[k][0]?.round ?? k;
  const got = d.filter((x) => x.got);
  return {
    key: k, name, mode: d[0]?.mode ?? null, beats: d.length, got: got.length, loss: d.length - got.length,
    late: d.filter((x) => x.late).length, kinds: [...new Set(d.map((x) => x.kind).filter(Boolean))],
    fgOk: d.filter((x) => x.fgOk).length,
    preTotal: agg(d.map((x) => x.preTotalMs)), prePipe: agg(d.map((x) => x.prePipeMs)), preParse: agg(d.map((x) => x.preParseMs)),
    inject: agg(got.map((x) => x.injectMs)), e2e: agg(got.map((x) => x.e2eMs)), apiCall: agg(d.map((x) => x.apiCallMs)),
    missSamples: d.filter((x) => !x.got).slice(0, 3).map((x) => ({ label: x.label, kind: x.kind })),
  };
});
const out = {
  generatedAt: new Date().toISOString(),
  method: '同源 QPC：Node hrtime 用 ping 最小延迟法标定到 QPC；注入器与靶场本身都用 Stopwatch.GetTimestamp()',
  target: { hwnd: HWND, beatJsonl: BEATJSONL, qpcFreq: FREQ, swZeroQpc: SW0, pid: beat.pid },
  injector: { pid: inj.pid, freq: inj.ready.freq, stats },
  calib: { pings: M, offsetMinMs: r3(toMs(offMin)), offsetP50Ms: r3(toMs(q(offs.slice(), 0.5))), offsetMaxMs: r3(toMs(offMax)), bandMs: r3(toMs(offMax - offMin)) },
  params: { beatsPerRound: N, gapMs: GAP }, background: bgInfo,
  rounds, detailCount: detail.length, detail,
};
fs.writeFileSync(f('keylat-e2e.json'), JSON.stringify(out, null, 1), 'utf8');
fs.writeFileSync(f(`keylat-e2e-${TS}.json`), JSON.stringify(out, null, 1), 'utf8');

console.log('\n=== 同源 QPC 口径（单位 ms）===');
console.log('| 轮次 | 通道 | 目标在前台 | 到达/丢 | 注入前(合计) | ├管道 | ├解析(同进程) | 注入(API→窗口) | 端到端 | API调用自身 |');
console.log('|---|---|---|---|---|---|---|---|---|---|');
for (const x of rounds) console.log(`| ${x.name} | ${x.mode} | ${x.fgOk}/${x.beats} | ${x.got}/${x.loss} | ${x.preTotal.med ?? '-'} | ${x.prePipe.med ?? '-'} | ${x.preParse.med ?? '-'} | ${x.inject.med ?? '-'} | ${x.e2e.med ?? '-'} | ${x.apiCall.med ?? '-'} |`);
console.log('\n分位（端到端 e2e / 注入前 preTotal / 注入 inject）:');
for (const x of rounds) console.log(`  ${x.name.padEnd(20)} e2e p50=${x.e2e.med ?? '-'} p90=${x.e2e.p90 ?? '-'} max=${x.e2e.max ?? '-'} | pre p50=${x.preTotal.med ?? '-'} max=${x.preTotal.max ?? '-'} | inj p50=${x.inject.med ?? '-'} p90=${x.inject.p90 ?? '-'} max=${x.inject.max ?? '-'} | 事件类型=${x.kinds.join(',') || '-'}`);
console.log(`\nJSON -> ${f('keylat-e2e.json')}`);
process.exit(0);
