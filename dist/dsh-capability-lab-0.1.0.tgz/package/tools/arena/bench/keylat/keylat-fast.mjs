/**
 * KEYLAT · 常驻注入器端到端延迟（可直接复用的低延迟方案）
 *
 * 链路：Node(控制面) --stdin--> sender.ps1（常驻，已编译好 P/Invoke）--> PostMessage/SendInput --> 目标窗口
 * 延迟 = (目标窗口收到事件的 QPC − Node 写命令前的墙钟映射到 QPC)
 * 对比对象：同一条 WM_CHAR 走插件（MCP）时的 300–650ms。
 */
import fs from 'node:fs';
import readline from 'node:readline';
import { spawn } from 'node:child_process';

const N = Number(process.argv[2] ?? 30);
const GAP = Number(process.argv[3] ?? 150);
const DIR = 'D:\\dsh-arena\\bench\\keylat';
const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const f = (p) => DIR + '\\' + p;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
for (const p of ['cmd.txt', 'status.json', 'native-events.json']) { try { fs.rmSync(f(p)); } catch {} }

const rec = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f('receiver.ps1'), '-Dir', DIR, '-LifeMs', '600000'],
  { env: ENV, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
async function status() { try { return JSON.parse(fs.readFileSync(f('status.json'), 'utf8')); } catch { return null; } }
async function waitStatus(pred, ms, what) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const s = await status(); if (s && pred(s)) return s; await sleep(60); }
  throw new Error('timeout: ' + what);
}
const boot = await waitStatus((s) => s.cmd === 'boot', 30000, 'boot');
const TGT = boot.target;

const snd = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f('sender.ps1')],
  { env: ENV, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
const pending = [], backlog = [];
readline.createInterface({ input: snd.stdout }).on('line', (l) => { const w = pending.shift(); if (w) w(l); else backlog.push(l); });
const nextLine = (ms) => backlog.length ? Promise.resolve(backlog.shift())
  : new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('sender timeout')), ms); pending.push((l) => { clearTimeout(t); res(l); }); });
await nextLine(60000);
console.log('receiver=' + rec.pid + ' sender=' + snd.pid + ' target=' + TGT);

async function setPhase(op, fg) { fs.writeFileSync(f('cmd.txt'), op + ':' + Date.now()); await waitStatus((s) => s.cmd === op && s.fg === fg, 8000, op); }

const cases = [];
async function once(label, variant, phase, hwnd, n, gapMs) {
  const t0s = [], rtts = [];
  for (let i = 0; i < n; i++) {
    await sleep(gapMs);
    const t0 = Date.now();
    t0s.push(t0);
    snd.stdin.write(JSON.stringify({ variant, hwnd, n: 1, gapMs: 0, vk: 0x57, ch: 0x77 }) + '\n');
    await nextLine(30000);
    rtts.push(Date.now() - t0);
  }
  cases.push({ label, variant, phase, hwnd, t0s, rtts });
  console.log('done ' + label);
}

try {
  await setPhase('fore', TGT);
  await once('fast/fore/postmessage-char', 'postmessage-char', 'fg', TGT, N, GAP);
  await once('fast/fore/postmessage-combo-sc', 'postmessage-combo-sc', 'fg', TGT, N, GAP);
  await once('fast/fore/sendinput-unicode', 'sendinput-unicode', 'fg', TGT, N, GAP);
  await once('fast/fore/sendinput-vk', 'sendinput-vk', 'fg', TGT, N, GAP);
  await setPhase('back', boot.cover);
  await once('fast/bg/postmessage-char', 'postmessage-char', 'bg', TGT, N, GAP);
  await once('fast/bg/postmessage-combo-sc', 'postmessage-combo-sc', 'bg', TGT, N, GAP);
} catch (e) {
  console.log('[fatal] ' + (e?.message ?? e));
} finally {
  fs.writeFileSync(f('cmd.txt'), 'quit:' + Date.now());
  await sleep(1500);
  try { snd.stdin.end(); } catch {}
  await sleep(200); try { snd.kill(); } catch {}
  await sleep(200); try { rec.kill(); } catch {}
}

const raw = JSON.parse(fs.readFileSync(f('native-events.json'), 'utf8'));
const freq = raw.freq, ms = (t) => (t / freq) * 1000;
const toTick = (w) => raw.anchorTick + (w - raw.anchorWallMs) * freq / 1000;
const evs = raw.events.filter((e) => e[3] === raw.target);
const out = { n: N, gapMs: GAP, freq, target: raw.target, cases: [] };
for (const c of cases) {
  const lat = []; const slow = []; let p = 0;
  for (let i = 0; i < c.t0s.length; i++) {
    const w = c.t0s[i];
    const a = toTick(w);
    while (p < evs.length && evs[p][2] < a) p++;
    let hit = null;
    for (let q = p; q < evs.length && evs[q][2] <= a + freq * 0.2; q++) { hit = ms(evs[q][2] - a); break; }
    if (hit === null) { slow.push({ i, lat: null, rtt: c.rtts[i] }); continue; }
    lat.push(hit);
    if (hit > 20) slow.push({ i, lat: Math.round(hit * 100) / 100, rtt: c.rtts[i] });
  }
  lat.sort((x, y) => x - y);
  const pick = (fr) => Math.round(lat[Math.min(lat.length - 1, Math.floor(fr * lat.length))] * 100) / 100;
  const rs = c.rtts.slice().sort((x, y) => x - y);
  const rp = (fr) => rs[Math.min(rs.length - 1, Math.floor(fr * rs.length))];
  out.cases.push({ label: c.label, phase: c.phase, got: lat.length, lost: c.t0s.length - lat.length, med: pick(0.5), p90: pick(0.9), max: Math.round(lat[lat.length - 1] * 100) / 100, min: Math.round(lat[0] * 100) / 100, rttMed: rp(0.5), rttP90: rp(0.9), rttMax: rs[rs.length - 1], slow });
}
fs.writeFileSync(f('keylat-fast.json'), JSON.stringify(out, null, 1), 'utf8');
console.log('\n| 常驻注入器路径 | 阶段 | 到达/丢 | 中位 | p90 | 最大 | min | 调用往返中位/p90 | 慢样本(>20ms) |');
console.log('|---|---|---|---|---|---|---|---|---|');
for (const c of out.cases) console.log(`| ${c.label} | ${c.phase} | ${c.got}/${c.lost} | ${c.med} | ${c.p90} | ${c.max} | ${c.min} | ${c.rttMed}/${c.rttP90} | ${c.slow.length} 例 ${JSON.stringify(c.slow.slice(0, 4))} |`);
