/**
 * keylat / keylat-l3-derive.mjs  —  从 keylat-l3.json 的原始逐键记录里再取一遍派生数字
 *   （不改任何测量，只做换算：客户端可见开销 = 指令往返 − hold；各通道注入开销分布）
 * 用法: node keylat-l3-derive.mjs
 */
import fs from 'node:fs';
const DIR = 'D:\\dsh-arena\\bench\\keylat\\';
const j = JSON.parse(fs.readFileSync(DIR + 'keylat-l3.json', 'utf8'));
const r3 = (v) => (v === null || v === undefined ? null : Math.round(v * 1000) / 1000);
const q = (a, fr) => (a.length ? a.slice().sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(fr * a.length))] : null);
const dist = (a) => ({ n: a.length, med: r3(q(a, 0.5)), p90: r3(q(a, 0.9)), max: r3(a.length ? Math.max(...a) : null) });

const byRound = {}, byMode = {};
for (const d of j.detail) {
  (byRound[d.round] ??= []).push(d);
  const m = d.mode ?? '?';
  (byMode[m] ??= []).push(d);
}
const fg = j.detail.filter((d) => d.fgOk);
const derived = {
  generatedAt: new Date().toISOString(),
  source: 'keylat-l3.json（2026-11-07 05:08 那一轮）',
  foreground: {
    keys: fg.length, got: fg.filter((d) => d.got).length, late: fg.filter((d) => d.late).length,
    deliveryMs: dist(fg.filter((d) => d.got).map((d) => d.latMs)),
  },
  byRound: Object.fromEntries(Object.entries(byRound).map(([k, v]) => [k, {
    keys: v.length, got: v.filter((d) => d.got).length, loss: v.filter((d) => !d.got).length, late: v.filter((d) => d.late).length,
    mode: v[0].mode, fgAll: v.every((d) => d.fgOk),
    deliveryMs: dist(v.filter((d) => d.got).map((d) => d.latMs)),
    injectMs: dist(v.map((d) => d.ovh)),
    clientOverheadMs: dist(v.map((d) => d.rttMs - (d.holdMs ?? 0))),
    clientRttMs: dist(v.map((d) => d.rttMs)),
    holds: [...new Set(v.map((d) => d.holdMs))],
  }])),
  byMode: Object.fromEntries(Object.entries(byMode).map(([k, v]) => [k, {
    keys: v.length, got: v.filter((d) => d.got).length,
    injectMs: dist(v.map((d) => d.ovh)),
    clientOverheadMs: dist(v.map((d) => d.rttMs - (d.holdMs ?? 0))),
    deliveryMs: dist(v.filter((d) => d.got).map((d) => d.latMs)),
  }])),
};
j.derived = derived;
fs.writeFileSync(DIR + 'keylat-l3.json', JSON.stringify(j, null, 1), 'utf8');
console.log('前台按键（含 chord/sequence，每键一算）: ' + JSON.stringify(derived.foreground));
console.log('\n| 轮次 | 通道 | 键数 | 到达/丢/迟到 | 投递中位/p90/最大 | 注入开销中位/p90/最大 | 客户端开销(往返−hold) 中位/p90/最大 |');
console.log('|---|---|---|---|---|---|---|');
for (const [k, v] of Object.entries(derived.byRound)) console.log(`| ${k} | ${v.mode} | ${v.keys} | ${v.got}/${v.loss}/${v.late} | ${v.deliveryMs.med}/${v.deliveryMs.p90}/${v.deliveryMs.max} | ${v.injectMs.med}/${v.injectMs.p90}/${v.injectMs.max} | ${v.clientOverheadMs.med}/${v.clientOverheadMs.p90}/${v.clientOverheadMs.max} |`);
console.log('\n按通道汇总:');
for (const [k, v] of Object.entries(derived.byMode)) console.log(`  ${k}: ${v.keys} 键 到达 ${v.got} 投递 ${JSON.stringify(v.deliveryMs)} 注入开销 ${JSON.stringify(v.injectMs)} 客户端开销 ${JSON.stringify(v.clientOverheadMs)}`);
