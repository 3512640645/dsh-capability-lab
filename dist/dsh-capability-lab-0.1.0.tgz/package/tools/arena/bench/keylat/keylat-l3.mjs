/**
 * keylat / keylat-l3.mjs  —  用真实打点靶场 arena-beat.ps1 复跑 L3「键盘判据」
 *
 * 与上一轮的区别：上一轮 §5.1 用的是我自己的 WinForms 夹具（WndProc 直接取 tick）；
 * 本轮目标就是 L3 官方靶场 arena-beat.ps1（WPF，PreviewKeyDown/PreviewTextInput 写 JSONL）。
 * 跨进程时钟对齐不再靠墙钟：arena-beat 头里新增 swZeroQpc/qpcFreq（同机全局 QPC），
 * 所以 投递延迟 = (swZeroQpc + swMs*freq/1000) − 注入器"按下之前"的 tick，误差 <0.01ms。
 *
 * 轮次：R1/R2/R3 前台真实按键 + 前台 PostMessage（各 24 拍）、R4 前台 chord/sequence（20 拍）、
 *       P1 目标类别探针（keydown-only 投递，10 拍）、R5 后台 SendInput（20 拍，负对照）、
 *       R6 后台 PostMessage（20 拍）。每拍都含按键；丢键/迟到如实统计。
 *
 * 用法: node keylat-l3.mjs [rounds-gap-ms]
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { startInjector, msOfTicks } from './keyclient.mjs';

const DIR = 'D:\\dsh-arena\\bench\\keylat';
const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const BEAT = 'D:\\dsh-arena\\arena-beat.ps1';
const RECV = path.join(DIR, 'receiver.ps1');
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const TS = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const BEATJSONL = path.join(DIR, `beat-keyL3-${TS}.jsonl`);
const GAP = Number(process.argv[2] ?? 120);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const f = (p) => path.join(DIR, p);
const r3 = (v) => (v === null || v === undefined ? null : Math.round(v * 1000) / 1000);
const q = (a, fr) => (a.length ? a.slice().sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(fr * a.length))] : null);

// ---------- 启动打点靶场 ----------
const beat = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', BEAT,
  '-OutJsonl', BEATJSONL, '-ExitAfterMs', '900000', '-Left', '140', '-Top', '110', '-Width', '900', '-Height', '620'],
  { env: ENV, stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
let beatErr = '';
beat.stderr.on('data', (c) => { beatErr += c; });

let header = null;
for (let i = 0; i < 300; i++) {
  try {
    const first = fs.readFileSync(BEATJSONL, 'utf8').split('\n')[0];
    if (first && first.includes('"kind":"header"')) { header = JSON.parse(first); break; }
  } catch { }
  await sleep(100);
}
if (!header) { console.log('[fatal] arena-beat 未产生 header: ' + beatErr.slice(-400)); process.exit(1); }
const SW0 = Number(header.swZeroQpc), FREQ = Number(header.qpcFreq), HWND = Number(header.hwnd);
console.log(`arena-beat pid=${beat.pid} hwnd=${HWND} freq=${FREQ} swZeroQpc=${SW0} jsonl=${path.basename(BEATJSONL)}`);

const inj = await startInjector();
console.log(`injector pid=${inj.pid} freq=${inj.ready.freq} (QPC 同机一致: ${inj.ready.freq === FREQ})`);
const bootP = await inj.probe(HWND);
console.log(`target vis=${bootP.vis} isWindow=${bootP.isWindow} rect=${JSON.stringify(bootP.rect)}`);
const readyWallDeltaMs = Date.now() - Date.parse(header.swZeroWallUtcIso);
console.log(`跨时钟粗校：靶场 swZero 墙钟 vs Node now = ${readyWallDeltaMs}ms（量化 ±${header.wallGrainMs}ms）`);

const beats = [];   // 每条注入指令
const beatsRound = [];
let KEYSEQ = 0;
let WARM = 0;
async function fire(round, label, fn, rec) {
  const r = await fn();
  const keys = (r.keys ?? []).map(([a, b]) => ({ t0: a, td: b }));
  const item = { round, label, op: r.op, mode: r.mode, hwnd: r.hwnd, fg: r.fg, pre: r.pre, ovh: r.ovh, call: r.call, rttMs: r.rttMs, holdMs: r.holdMs ?? null, gapMs: r.gapMs ?? null, keys };
  beats.push(item);
  for (const k of keys) k.beat = beats.indexOf(item);
  rec.push(item);
  return item;
}

// ---------- 第 1 阶段：前台（arena-beat 占据前台+焦点） ----------
async function ensureFg() {
  for (let i = 0; i < 4; i++) {
    const r = await inj.focus(HWND);
    if (r.ok) return true;
    await sleep(120);
  }
  return false;
}
const fgOk = await ensureFg();
console.log('前台仲裁: ' + fgOk);

const R = [];
async function round(name, n, maker, { expectFg = HWND } = {}) {
  const list = [];
  const t0 = new Date().toISOString();
  for (let i = 0; i < n; i++) {
    await sleep(GAP);
    const r = await fire(name, name + '#' + (i + 1), () => maker(i), list);
    r.fgOk = r.fg === expectFg;
  }
  const keys = list.flatMap((b) => b.keys);
  R.push({ name, n, beats: list, keyCount: keys.length, fgOkBeats: list.filter((b) => b.fgOk).length, t0, t1: new Date().toISOString() });
  console.log(`round ${name}: ${n} 拍 / ${keys.length} 键（fgOk ${list.filter((b) => b.fgOk).length}/${n}）`);
  return keys;
}

try {
  // 预热一条（冷启动：常驻进程已有 -Warm，这里给 WPF 侧一次热身）
  await sleep(GAP); await inj.hold('w', 5);
  WARM = beats.length;

  await round('R1-fg-sendinput-vk-hold10', 24, (i) => inj.hold(['w', 'a', 's', 'd'][i % 4], 10));
  await round('R2-fg-sendinput-varhold', 24, (i) => inj.hold('wasdqerf'[i % 8], [0, 15, 30, 60][i % 4]));
  await round('R3-fg-postmessage', 24, (i) => inj.hold('wasdqerf'[i % 8], 0, { mode: 'post', hwnd: HWND }));
  await round('P1-probe-keydown-only', 10, (i) => inj.hold('wasdqerf'[i % 8], 0, { mode: 'postk', hwnd: HWND }));

  // R4：走客户端包装的 chord / sequence 接口（每拍含 2–3 键）
  const R4 = [];
  {
    const t0 = new Date().toISOString();
    for (let i = 0; i < 8; i++) { await sleep(GAP); await fire('R4-fg-chord-seq', 'R4#c' + i, () => inj.chord(i % 2 ? ['shift', 'w'] : ['ctrl', 'a'], 30), R4); }
    for (let i = 0; i < 12; i++) { await sleep(GAP); await fire('R4-fg-chord-seq', 'R4#s' + i, () => inj.sequence([{ key: 'w', ms: 25 }, { key: 'd', ms: 25 }, { key: 'space', ms: 15 }], { gapMs: 25 }), R4); }
    const keys = R4.flatMap((b) => b.keys);
    R.push({ name: 'R4-fg-chord-seq', n: R4.length, beats: R4, keyCount: keys.length, fgOkBeats: R4.filter((b) => b.fg === HWND).length, t0, t1: new Date().toISOString() });
    console.log(`round R4-fg-chord-seq: ${R4.length} 拍 / ${keys.length} 键`);
  }
} catch (e) {
  console.log('[fatal-first-phase] ' + (e?.message ?? e));
}

// ---------- 第 2 阶段：后台（前台交给别的窗口） ----------
let recv = null, recvBoot = null;
try {
  for (const p of ['cmd.txt', 'status.json', 'native-events.json']) { try { fs.rmSync(f(p)); } catch { } }
  recv = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', RECV, '-Dir', DIR, '-LifeMs', '600000'],
    { env: ENV, stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
  for (let i = 0; i < 200; i++) {
    try { const s = JSON.parse(fs.readFileSync(f('status.json'), 'utf8')); if (s.cmd === 'boot') { recvBoot = s; break; } } catch { }
    await sleep(100);
  }
  if (recvBoot) {
    console.log(`foreground sink: receiver pid=${recv.pid} cover=${recvBoot.cover}`);
    fs.writeFileSync(f('cmd.txt'), 'back:' + Date.now());
    for (let i = 0; i < 60; i++) { const s = JSON.parse(fs.readFileSync(f('status.json'), 'utf8')); if (s.cmd === 'back' && s.fg === recvBoot.cover) break; await sleep(100); }
    const st = JSON.parse(fs.readFileSync(f('status.json'), 'utf8'));
    console.log(`sink fg now = ${st.fg}（arena=${HWND}, cover=${recvBoot.cover}）`);
    // 先确认靶场确实不在前台（否则负对照无效）
    const pr = await inj.probe(HWND);
    if (pr.fg === HWND) { const f2 = await inj.focus(recvBoot.cover); console.log('再次把前台交给 cover: ok=' + f2.ok); }
    await round('R5-bg-sendinput(负对照)', 20, (i) => inj.hold('wasdqerf'[i % 8], 5), { expectFg: recvBoot.cover });
    await round('R6-bg-postmessage', 20, (i) => inj.hold('wasdqerf'[i % 8], 0, { mode: 'post', hwnd: HWND }), { expectFg: recvBoot.cover });
  } else console.log('[warn] receiver 未起来，跳过后台对照');
} catch (e) {
  console.log('[fatal-second-phase] ' + (e?.message ?? e));
}

// ---------- 收尾：关窗口，再读日志 ----------
try { fs.writeFileSync(f('cmd.txt'), 'quit:' + Date.now()); } catch { }
await sleep(1200);
const stats = inj.stats();
await inj.closeWindow(HWND);
const beatExit = await new Promise((res) => { const t = setTimeout(() => res('timeout'), 8000); beat.on('exit', (c) => { clearTimeout(t); res(c); }); });
await sleep(500);
for (const p of [beat, recv]) { try { p?.kill(); } catch { } }
console.log(`arena-beat exit=${beatExit}  injector stats=${JSON.stringify(stats.ovhMs)}`);

// ---------- 分析 ----------
const lines = fs.readFileSync(BEATJSONL, 'utf8').split('\n').filter((l) => l.trim());
const evs = [];
for (const l of lines) {
  let o; try { o = JSON.parse(l); } catch { continue; }
  if (o.kind === 'header') continue;
  evs.push({ kind: o.kind, n: o.n ?? null, tick: SW0 + (o.swMs / 1000) * FREQ, vk: o.vk ?? null, text: o.text ?? null, wall: o.wallUtcIso ?? null });
}
evs.sort((a, b) => a.tick - b.tick);
const TOL = 0.3, CAP = 60, WIDE = 400;
let cursor = 0;
function match(t0) {
  const lo = t0 - (TOL / 1000) * FREQ, hi = t0 + (CAP / 1000) * FREQ, hw = t0 + (WIDE / 1000) * FREQ;
  let i = cursor;
  while (i < evs.length && evs[i].tick < lo) i++;
  for (let j = i; j < evs.length && evs[j].tick <= hi; j++) { cursor = j + 1; return { ev: evs[j], late: false }; }
  for (let j = i; j < evs.length && evs[j].tick <= hw; j++) { cursor = j + 1; return { ev: evs[j], late: true }; }
  cursor = i;
  return null;
}
const detail = [];
for (const b of beats) {
  for (const k of b.keys) {
    const m = match(k.t0);
    detail.push({
      round: b.round, label: b.label, op: b.op, mode: b.mode, fg: b.fg, holdMs: b.holdMs, rttMs: b.rttMs, pre: b.pre, ovh: b.ovh,
      t0: k.t0, fgOk: b.fg === HWND,
      got: !!m && !m.late, late: !!m && m.late,
      latMs: m && !m.late ? r3(msOfTicks(m.ev.tick - k.t0, FREQ)) : null,
      kind: m ? m.ev.kind : null, vk: m ? m.ev.vk : null,
    });
  }
}
const rounds = R.map((r) => {
  const d = detail.filter((x) => x.round === r.name);
  const lat = d.filter((x) => x.got).map((x) => x.latMs);
  const rtt = d.map((x) => x.rttMs);
  return {
    name: r.name, beats: r.n, keys: d.length, got: lat.length, loss: d.length - lat.length,
    late: d.filter((x) => x.late).length, fgOkBeats: r.fgOkBeats,
    med: r3(q(lat, 0.5)), p90: r3(q(lat, 0.9)), max: r3(lat.length ? Math.max(...lat) : null), min: r3(lat.length ? Math.min(...lat) : null),
    rttMed: r3(q(rtt, 0.5)), rttP90: r3(q(rtt, 0.9)), rttMax: r3(rtt.length ? Math.max(...rtt) : null),
  };
});
const fgAll = detail.filter((x) => x.fgOk === true);
const fgAllLat = fgAll.filter((x) => x.got).map((x) => x.latMs);
const fgSend = detail.filter((x) => x.fgOk && /send/.test(x.mode ?? ''));
const out = {
  generatedAt: new Date().toISOString(), target: 'arena-beat.ps1 (WPF)', hwnd: HWND, jsonl: BEATJSONL,
  qpc: { freq: FREQ, swZeroQpc: SW0, sameTimebase: FREQ === inj.ready.freq, wallGrainMs: header.wallGrainMs },
  injector: { ps: inj.args[0], script: inj.args[inj.args.length - 2], stats, ready: inj.ready },
  gapMs: GAP, warmupCommands: WARM,
  rounds, foregroundAll: { keys: fgAll.length, got: fgAllLat.length, loss: fgAll.length - fgAllLat.length, med: r3(q(fgAllLat, 0.5)), p90: r3(q(fgAllLat, 0.9)), max: r3(fgAllLat.length ? Math.max(...fgAllLat) : null) },
  foregroundSendOnly: (() => { const v = fgSend.filter((x) => x.got).map((x) => x.latMs); return { keys: fgSend.length, got: v.length, loss: fgSend.length - v.length, med: r3(q(v, 0.5)), p90: r3(q(v, 0.9)), max: r3(v.length ? Math.max(...v) : null) }; })(),
  detail, events: evs.length,
};
// 后台负对照：cover 收到了多少（证明"丢的键去哪了"）
try {
  const raw = JSON.parse(fs.readFileSync(f('native-events.json'), 'utf8'));
  const byHwnd = {};
  for (const e of raw.events) { const h = e[3]; byHwnd[h] = (byHwnd[h] ?? 0) + 1; }
  const bg = R.filter((x) => x.name.startsWith('R5') || x.name.startsWith('R6'));
  const win = {};
  for (const r2 of bg) {
    const lo = Math.min(...detail.filter((d) => d.round === r2.name).map((d) => d.t0)) - FREQ * 0.5;
    const hi = Math.max(...detail.filter((d) => d.round === r2.name).map((d) => d.t0)) + FREQ * 0.5;
    for (const e of raw.events) if (e[2] >= lo && e[2] <= hi && (e[0] === 0x100 || e[0] === 0x102)) win[e[3]] = (win[e[3]] ?? 0) + 1;
  }
  out.backgroundSink = { cover: recvBoot?.cover ?? null, target: recvBoot?.target ?? null, eventsByHwndAll: byHwnd, keyEventsInBgWindowByHwnd: win };
} catch (e) { out.backgroundSink = { error: String(e.message) }; }

fs.writeFileSync(f('keylat-l3.json'), JSON.stringify(out, null, 1), 'utf8');

console.log(`\n事件总数=${evs.length}  预热指令=${WARM}（不计入统计）`);
console.log('\n| 轮次 | 目标路径 | 键数 | 到达/丢 | 迟到 | 中位 | p90 | 最大 | 最小 | 指令往返中位/p90 |');
console.log('|---|---|---|---|---|---|---|---|---|---|');
for (const r2 of rounds) console.log(`| ${r2.name} | ${detail.find((d) => d.round === r2.name)?.mode} | ${r2.keys} | ${r2.got}/${r2.loss} | ${r2.late} | ${r2.med} | ${r2.p90} | ${r2.max} | ${r2.min} | ${r2.rttMed}/${r2.rttP90} |`);
console.log(`\n前台全部按键: 到达 ${out.foregroundAll.got}/${out.foregroundAll.keys} 中位 ${out.foregroundAll.med} p90 ${out.foregroundAll.p90} 最大 ${out.foregroundAll.max}`);
console.log(`其中 SendInput 真实按键: 到达 ${out.foregroundSendOnly.got}/${out.foregroundSendOnly.keys} 中位 ${out.foregroundSendOnly.med} p90 ${out.foregroundSendOnly.p90} 最大 ${out.foregroundSendOnly.max}`);
console.log(`注入器指令开销(不含 hold): ${JSON.stringify(stats.ovhMs)}  解析: ${JSON.stringify(stats.preMs)}  往返: ${JSON.stringify(stats.rttMs)}`);
console.log('后台对照: ' + JSON.stringify(out.backgroundSink.keyEventsInBgWindowByHwnd));
console.log('JSON -> ' + f('keylat-l3.json') + ' | beat jsonl -> ' + BEATJSONL);
process.exit(0);   // 子进程管道不再拖住事件循环
