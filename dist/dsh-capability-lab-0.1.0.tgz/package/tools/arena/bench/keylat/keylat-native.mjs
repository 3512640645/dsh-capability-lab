/**
 * KEYLAT · 原始按键投递路径延迟实测（跨进程，同一台机器同一 QPC）
 *
 * 方法：receiver.ps1 建两个 WinForms 窗口（target / cover），WndProc 里只取 QPC tick；
 *      sender.ps1 是常驻进程，收到指令后立刻注入并记录 t0(注入前)/t1(注入后)。
 *      延迟 = (target 收到事件的 QPC − sender 的 t0) / freq  —— 同机 QPC 全局一致，无需跨时钟对齐。
 *
 * 用法: node keylat-native.mjs [n] [gapMs]
 */
import fs from 'node:fs';
import readline from 'node:readline';
import { spawn } from 'node:child_process';

const N = Number(process.argv[2] ?? 100);
const GAP = Number(process.argv[3] ?? 25);
const DIR = 'D:\\dsh-arena\\bench\\keylat';
const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const f = (p) => DIR + '\\' + p;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

for (const p of ['cmd.txt', 'status.json', 'native-events.json'])
  { try { fs.rmSync(f(p)); } catch {} }

const rec = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f('receiver.ps1'), '-Dir', DIR, '-LifeMs', '600000'],
  { env: ENV, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
let recErr = '';
rec.stderr.on('data', (c) => { recErr += c; });

async function status() { try { return JSON.parse(fs.readFileSync(f('status.json'), 'utf8')); } catch { return null; } }
async function waitStatus(pred, ms, what) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const s = await status(); if (s && pred(s)) return s; await sleep(60); }
  throw new Error('timeout: ' + what + '  last=' + JSON.stringify(await status()) + ' recErr=' + recErr.slice(-300));
}
async function setPhase(op, expectFg) {
  for (let k = 0; k < 3; k++) {
    fs.writeFileSync(f('cmd.txt'), op + ':' + Date.now());
    try { const s = await waitStatus((x) => x.cmd === op && x.fg === expectFg, 5000, 'phase ' + op); return s; }
    catch { }
  }
  const s = await status();
  console.log(`[warn] phase ${op} fg=${s?.fg} expected=${expectFg}`);
  return s;
}

const boot = await waitStatus((s) => s.cmd === 'boot', 30000, 'receiver boot');
const TGT = boot.target, COV = boot.cover;
console.log(`receiver pid=${rec.pid} target=${TGT} cover=${COV}`);

const snd = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f('sender.ps1')],
  { env: ENV, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
let sndErr = '';
snd.stderr.on('data', (c) => { sndErr += c; });
const pending = []; const backlog = [];
readline.createInterface({ input: snd.stdout }).on('line', (l) => { const w = pending.shift(); if (w) w(l); else backlog.push(l); });
function nextLine(ms) {
  if (backlog.length) return Promise.resolve(backlog.shift());
  return new Promise((res, rej) => { const t = setTimeout(() => rej(new Error('sender timeout: ' + sndErr.slice(-300))), ms); pending.push((l) => { clearTimeout(t); res(l); }); });
}

const hello = await nextLine(60000);
console.log('sender:', hello);

const bursts = [];
async function probe(what) {
  snd.stdin.write(JSON.stringify({ op: 'probe', hwnd: TGT }) + '\n');
  const l = await nextLine(30000);
  console.log(`probe[${what}] ${l}`);
  return l;
}
async function burst(label, variant, opts = {}) {
  const req = { variant, hwnd: opts.hwnd ?? TGT, n: opts.n ?? N, gapMs: opts.gapMs ?? GAP, vk: opts.vk ?? 0x57, ch: opts.ch ?? 0x77 };
  snd.stdin.write(JSON.stringify(req) + '\n');
  const line = await nextLine(180000);
  if (!line.startsWith('R ')) { console.log(`[err] ${label}: ${line}`); return null; }
  const j = JSON.parse(line.slice(2));
  const t = [];
  for (let i = 0; i < j.ticks.length; i += 2) t.push(j.ticks[i]);
  const rec2 = { label, variant, phase: opts.phase, n: req.n, gapMs: req.gapMs, hwnd: req.hwnd, t0: t, t1: j.ticks.filter((_, i) => i % 2 === 1) };
  bursts.push(rec2);
  console.log(`burst ${label} n=${req.n} gap=${req.gapMs}ms phase=${opts.phase}`);
  return rec2;
}

try {
  // ---------- 阶段 1：target 在前台（真实键盘焦点） ----------
  await setPhase('fore', TGT);
  await burst('fg/sendinput-vk', 'sendinput-vk', { phase: 'fg' });
  await burst('fg/sendinput-scan', 'sendinput-scan', { phase: 'fg' });
  await burst('fg/sendinput-unicode', 'sendinput-unicode', { phase: 'fg' });
  await burst('fg/keybd_event', 'keybd_event', { phase: 'fg' });
  await burst('fg/sendkeys', 'sendkeys', { phase: 'fg' });
  await burst('fg/postmessage-keydown', 'postmessage-keydown', { phase: 'fg' });
  await burst('fg/postmessage-char', 'postmessage-char', { phase: 'fg' });
  await burst('fg/postmessage-combo', 'postmessage-combo', { phase: 'fg' });
  await burst('fg/postmessage-combo-sc', 'postmessage-combo-sc', { phase: 'fg' });
  await burst('fg/sendmessage-combo', 'sendmessage-combo', { phase: 'fg' });
  await probe('fg-before-mouse');
  await burst('fg/mouse-sendinput', 'mouse-sendinput', { phase: 'fg' });
  await probe('fg-after-mouse');
  await burst('fg/mouse-sendinput-gap200', 'mouse-sendinput', { phase: 'fg', n: 10, gapMs: 200 });
  await burst('fg/postmessage-mouse', 'postmessage-mouse', { phase: 'fg' });

  // ---------- 阶段 2：target 退到后台（cover 在前台） ----------
  await setPhase('back', COV);
  await burst('bg/postmessage-keydown', 'postmessage-keydown', { phase: 'bg' });
  await burst('bg/postmessage-char', 'postmessage-char', { phase: 'bg' });
  await burst('bg/postmessage-combo', 'postmessage-combo', { phase: 'bg' });
  await burst('bg/postmessage-combo-sc', 'postmessage-combo-sc', { phase: 'bg' });
  await burst('bg/postmessage-mouse', 'postmessage-mouse', { phase: 'bg' });
  await burst('bg/sendinput-unicode', 'sendinput-unicode', { phase: 'bg' });
  await burst('bg/sendinput-vk', 'sendinput-vk', { phase: 'bg' });
  await burst('bg/postmessage-then-sendinput', 'sendinput-then-postmessage', { phase: 'bg' });

  // ---------- 阶段 3：密集连发（后台最优路径，gap=0） ----------
  const DENSE = Math.max(N, 60);
  await burst('bg/dense-postmessage-char', 'postmessage-char', { phase: 'bg', n: DENSE, gapMs: 0 });
  await burst('bg/dense-postmessage-combo-sc', 'postmessage-combo-sc', { phase: 'bg', n: DENSE, gapMs: 0 });
  await burst('bg/dense-sendinput-unicode', 'sendinput-unicode', { phase: 'bg', n: DENSE, gapMs: 0 });
  await setPhase('fore', TGT);
  await burst('fg/dense-postmessage-combo-sc', 'postmessage-combo-sc', { phase: 'fg', n: DENSE, gapMs: 0 });
} catch (e) {
  console.log('[fatal] ' + (e?.message ?? e));
} finally {
  fs.writeFileSync(f('cmd.txt'), 'quit:' + Date.now());
  await sleep(1500);
  try { snd.stdin.end(); } catch {}
  await sleep(300);
  try { snd.kill(); } catch {}
  await sleep(300);
  try { rec.kill(); } catch {}
}

// ---------- 分析 ----------
const raw = JSON.parse(fs.readFileSync(f('native-events.json'), 'utf8'));
const freq = raw.freq;
const ms = (t) => (t / freq) * 1000;
const events = raw.events; // [msg, wp, tick, hwnd] 已按时间序

const KEYS = new Set([0x100, 0x101, 0x102, 0x104, 0x105]);
const out = { freq, target: raw.target, cover: raw.cover, anchorTick: raw.anchorTick, anchorWallMs: raw.anchorWallMs, n: N, gapMs: GAP, dir: raw.exitTick - raw.bootTick, cases: [], raw: [] };

let p = 0;
for (const b of bursts) {
  const lat = [], calls = [], kinds = {};
  let coverTotal = 0, lateWide = 0;
  const capTight = Math.min(250, Math.max(6, b.gapMs * 0.5)) * freq / 1000; // 该拍自己的投递窗口
  const capWide = 0.3 * freq;
  for (let i = 0; i < b.t0.length; i++) {
    const a = b.t0[i], hiT = a + capTight, hiW = a + capWide;
    while (p < events.length && events[p][2] < a) p++;
    let first = null;
    for (let q = p; q < events.length && events[q][2] <= hiT; q++) {
      if (events[q][3] === raw.target) { first = events[q]; break; }
    }
    if (!first) { for (let q = p; q < events.length && events[q][2] <= hiW; q++) if (events[q][3] === raw.target) { lateWide++; break; } }
    for (let r = p; r < events.length && events[r][2] <= hiT; r++) if (events[r][3] === raw.cover) coverTotal++;
    if (first) { lat.push(ms(first[2] - a)); kinds[first[0]] = (kinds[first[0]] ?? 0) + 1; }
    calls.push(ms(b.t1[i] - a));
  }
  lat.sort((x, y) => x - y);
  calls.sort((x, y) => x - y);
  const q = (arr, f) => (arr.length ? arr[Math.min(arr.length - 1, Math.floor(f * arr.length))] : null);
  const r3 = (v) => (v === null || v === undefined ? null : Math.round(v * 1000) / 1000);
  out.cases.push({
    label: b.label, variant: b.variant, phase: b.phase, n: b.n, gapMs: b.gapMs,
    got: lat.length, loss: b.n - lat.length, lateWide,
    medMs: r3(q(lat, 0.5)), p90Ms: r3(q(lat, 0.9)), maxMs: r3(lat[lat.length - 1] ?? null), minMs: r3(lat[0] ?? null),
    callMedMs: r3(q(calls, 0.5)),
    coverTotal,
    firstMsg: Object.entries(kinds).map(([k, v]) => '0x' + Number(k).toString(16) + 'x' + v).join(','),
    lat: lat.map(r3), call: calls.map(r3),
  });
}
out.raw = bursts.map((b) => ({ label: b.label, t0: b.t0, t1: b.t1 }));
fs.writeFileSync(f('keylat-native.json'), JSON.stringify(out, null, 1), 'utf8');

console.log('\n| 路径 | 阶段 | 收到/丢 | 中位 | p90 | 最大 | 调用中位 | 落到cover | 首个事件 |');
console.log('|---|---|---|---|---|---|---|---|---|');
for (const c of out.cases) console.log(`| ${c.label} | ${c.phase} | ${c.got}/${c.loss} | ${c.medMs} | ${c.p90Ms} | ${c.maxMs} | ${c.callMedMs} | ${c.coverTotal} | ${c.firstMsg} |`);
console.log('recErr=' + recErr.slice(-200) + ' sndErr=' + sndErr.slice(-200));
