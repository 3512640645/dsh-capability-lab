/**
 * keylat / keylat-plugin-e2e.mjs —— 插件（MCP windows-computer-use）按键路径的**同源 QPC** 端到端延迟
 *
 * 上一轮口径（l3-keyprobe2 / CONTROL-BENCH 的 158–188ms）用的是
 *   Node 的 Date.now() 墙钟 − 靶场 Stopwatch swMs（靠 swZeroUnixMs 对齐）
 * —— 跨时钟，且 Date.now 在 Windows 上是 15.6ms 量子。
 * 本文件把 Node 的 hrtime 用「ping 最小延迟法」标定到 QPC，靶场事件本来就是 QPC，
 * 于是「决定(工具调用前) → 目标窗口收到」全部落在同一个时基上。
 *
 * 用法: node keylat-plugin-e2e.mjs [每路径拍数] [间隔ms]
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { startInjector } from './keyclient.mjs';
import { connect } from '../client.mjs';

const DIR = 'D:\\dsh-arena\\bench\\keylat';
const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const BEAT = 'D:\\dsh-arena\\arena-beat.ps1';
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const TS = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const BEATJSONL = path.join(DIR, `beat-plugin-${TS}.jsonl`);
const N = Number(process.argv[2] ?? 20);
const GAP = Number(process.argv[3] ?? 500);
const f = (p) => path.join(DIR, p);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const r3 = (v) => (v === null || v === undefined ? null : Math.round(v * 1000) / 1000);
const q = (a, fr) => (a.length ? a.slice().sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(fr * a.length))] : null);
const agg = (a) => { const v = a.filter((x) => typeof x === 'number' && isFinite(x)); if (!v.length) return { n: 0 }; const s = v.slice().sort((x, y) => x - y); return { n: s.length, med: r3(q(s, 0.5)), p90: r3(q(s, 0.9)), max: r3(s[s.length - 1]), min: r3(s[0]) }; };

spawnSync(PS, ['-NoProfile', '-Command',
  `Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'arena-beat\\.ps1' } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }`],
  { env: ENV, stdio: 'ignore', windowsHide: true });

const beat = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', BEAT,
  '-OutJsonl', BEATJSONL, '-ExitAfterMs', '900000', '-Left', '140', '-Top', '110', '-Width', '900', '-Height', '620'],
  { env: ENV, stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
let beatErr = '';
beat.stderr.on('data', (c) => { beatErr += c; });
let header = null;
for (let i = 0; i < 300; i++) {
  try { const first = fs.readFileSync(BEATJSONL, 'utf8').split('\n')[0]; if (first && first.includes('"kind":"header"')) { header = JSON.parse(first); break; } } catch { }
  await sleep(100);
}
if (!header) { console.log('[fatal] arena-beat 未产生 header: ' + beatErr.slice(-400)); process.exit(1); }
const SW0 = Number(header.swZeroQpc), FREQ = Number(header.qpcFreq), HWND = Number(header.hwnd);
console.log(`[target] arena-beat pid=${beat.pid} hwnd=${HWND} qpcFreq=${FREQ}`);
console.log(`[旧口径对照] header.swZeroUnixMs=${header.swZeroUnixMs}  Node Date.now()=${Date.now()}  差=${Date.now() - header.swZeroUnixMs}ms（这就是上一轮的对齐方式）`);

// 只用注入器做时钟标定，不发任何按键
const inj = await startInjector();
const offs = [];
for (let i = 0; i < 60; i++) { const h0 = process.hrtime.bigint(); const r = await inj.ping(); offs.push(Number(r.p0) - Number(h0) * FREQ / 1e9); await sleep(1); }
const offMin = Math.min(...offs);
const toMs = (t) => t / FREQ * 1000;
const nodeTick = (hns) => Number(hns) * FREQ / 1e9 + offMin;
console.log(`[calib] 偏移min=${toMs(offMin).toFixed(3)}ms 抖动带=${toMs(Math.max(...offs) - offMin).toFixed(3)}ms（注入器与靶场同基=${inj.ready.freq === FREQ}）`);

const c = await connect();
const vars = [
  ['keypress-fg', 'keypress', () => ({ keys: ['w'], nativeWindowHandle: HWND, dispatch: 'foreground' })],
  ['keypress-bg', 'keypress', () => ({ keys: ['w'], nativeWindowHandle: HWND, dispatch: 'background' })],
  ['typetext-bg', 'type_text', () => ({ text: 'w', method: 'background', nativeWindowHandle: HWND })],
  ['typetext-sendinput', 'type_text', () => ({ text: 'w', method: 'sendinput', nativeWindowHandle: HWND })],
];
const trials = [];
try {
  await c.tool('activate_window', { nativeWindowHandle: HWND });
  await sleep(600);
  for (const [label, tool, mk] of vars) {
    for (let i = 0; i < N; i++) {
      await c.tool('activate_window', { nativeWindowHandle: HWND });   // 复刻上一轮口径：每次调用前激活
      await sleep(150);
      const tdec = process.hrtime.bigint();
      const r = await c.tool(tool, mk());
      const tret = process.hrtime.bigint();
      let data = r.data; if (typeof data === 'string') { try { data = JSON.parse(data); } catch { } }
      trials.push({
        label, tool, i, ok: !r.isError, method: data?.method ?? null,
        note: (r.text ?? '').replace(/\s+/g, ' ').slice(0, 160),
        t_dec: nodeTick(tdec), t_ret: nodeTick(tret), callMs: Number((Number(tret - tdec) / 1e6).toFixed(3)),
      });
      await sleep(GAP);
    }
    console.log(`[round] ${label} 完成 ${N} 拍`);
  }
} catch (e) { console.log('[fatal] ' + (e?.message ?? e)); } finally {
  try { await c.close(); } catch { }
  await inj.closeWindow(HWND);
  await new Promise((res) => { const t = setTimeout(() => res('timeout'), 8000); beat.on('exit', (x) => { clearTimeout(t); res(x); }); });
  try { beat.kill(); } catch { }
  try { await inj.close(); } catch { }
  await sleep(400);
}

const lines = fs.readFileSync(BEATJSONL, 'utf8').split('\n').filter((l) => l.trim());
const evs = [];
for (const l of lines) { let o; try { o = JSON.parse(l); } catch { continue; } if (o.kind === 'header' || o.kind === 'marker') continue; evs.push({ kind: o.kind, tick: SW0 + (o.swMs / 1000) * FREQ }); }
evs.sort((a, b) => a.tick - b.tick);
let cur = 0;
for (const t of trials) {
  const lo = t.t_dec - 0.3 * (FREQ / 1000), hi = t.t_dec + 3000 * (FREQ / 1000);
  while (cur < evs.length && evs[cur].tick < lo) cur++;
  for (let j = cur; j < evs.length && evs[j].tick <= hi; j++) {
    t.arrivalMs = r3((evs[j].tick - t.t_dec) / FREQ * 1000); t.kind = evs[j].kind;
    t.afterCallMs = r3((evs[j].tick - t.t_ret) / FREQ * 1000);   // 到达相对"调用返回"（负=调用还没返回就到了）
    t.withinCall = evs[j].tick <= t.t_ret;
    cur = j + 1; break;
  }
}
const cases = [...new Set(trials.map((t) => t.label))].map((label) => {
  const rows = trials.filter((t) => t.label === label);
  const lat = rows.filter((r) => typeof r.arrivalMs === 'number').map((r) => r.arrivalMs);
  return {
    label, tool: rows[0]?.tool, method: [...new Set(rows.map((r) => r.method))].filter(Boolean).join('/'),
    n: rows.length, delivered: lat.length, lost: rows.length - lat.length,
    call: agg(rows.map((r) => r.callMs)), e2e: agg(lat),
    arrivesBeforeCallReturns: rows.filter((r) => r.withinCall).length,
    note: rows.find((r) => !r.ok)?.note ?? null,
  };
});
const out = {
  generatedAt: new Date().toISOString(),
  method: '同源 QPC：Node hrtime 经 ping 最小延迟法标定；靶场事件 tick = swZeroQpc + swMs*freq/1000',
  caliberVsOldRound: { swZeroUnixMs: header.swZeroUnixMs, nodeDateNow: Date.now(), deltaMs: Date.now() - header.swZeroUnixMs, note: '上一轮用的就是这条墙钟对齐，且 Date.now 量子 15.6ms' },
  target: { hwnd: HWND, beatJsonl: BEATJSONL, qpcFreq: FREQ },
  calib: { offsetMinMs: r3(toMs(offMin)), bandMs: r3(toMs(Math.max(...offs) - offMin)) },
  params: { trialsPerVariant: N, gapMs: GAP }, cases, trials,
};
fs.writeFileSync(f('keylat-plugin-e2e.json'), JSON.stringify(out, null, 1), 'utf8');
fs.writeFileSync(f(`keylat-plugin-e2e-${TS}.json`), JSON.stringify(out, null, 1), 'utf8');

console.log('\n=== 插件路径 · 同源 QPC（ms）===');
console.log('| 插件路径 | 汇报 method | 到达/丢 | 端到端中位 | p90 | 最大 | 调用中位 | 到达发生在调用返回前几拍 |');
console.log('|---|---|---|---|---|---|---|---|');
for (const x of cases) console.log(`| ${x.label} | ${x.method} | ${x.delivered}/${x.lost} | ${x.e2e.med ?? '-'} | ${x.e2e.p90 ?? '-'} | ${x.e2e.max ?? '-'} | ${x.call.med ?? '-'} | ${x.arrivesBeforeCallReturns}/${x.n} |`);
console.log(`\nJSON -> ${f('keylat-plugin-e2e.json')}`);
process.exit(0);
