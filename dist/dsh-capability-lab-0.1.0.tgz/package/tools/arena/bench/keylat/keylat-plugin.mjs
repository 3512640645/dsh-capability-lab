/**
 * KEYLAT · 插件（MCP / windows-computer-use）按键投递路径端到端延迟
 *
 * 同一批调用分别打到两个接收器：
 *   A) keylat receiver.ps1 —— WndProc 只取 QPC tick（本文件用 QPC 锚点把 Node 墙钟映射过去）
 *   B) arena-beat.ps1     —— 旧打点器（每事件 AutoFlush 写盘 + 跨时钟对齐），用于 A/B 对照
 *
 * 用法: node keylat-plugin.mjs [trials]
 */
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { connect, waitArenaWindow, closeArenaWindows, PS } from '../client.mjs';

const T = Number(process.argv[2] ?? 12);
const GAP = 700;
const DIR = 'D:\\dsh-arena\\bench\\keylat';
const f = (p) => DIR + '\\' + p;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const BEAT_JSONL = f('beat-l3.jsonl');

for (const p of ['cmd.txt', 'status.json', 'native-events.json', 'beat-l3.jsonl'])
  { try { fs.rmSync(f(p)); } catch {} }

const rec = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f('receiver.ps1'), '-Dir', DIR, '-LifeMs', '600000'],
  { env: ENV, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
let recErr = '';
rec.stderr.on('data', (c) => { recErr += c; });
async function status() { try { return JSON.parse(fs.readFileSync(f('status.json'), 'utf8')); } catch { return null; } }
async function waitStatus(pred, ms, what) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const s = await status(); if (s && pred(s)) return s; await sleep(60); }
  throw new Error('timeout: ' + what + ' recErr=' + recErr.slice(-200));
}
const boot = await waitStatus((s) => s.cmd === 'boot', 30000, 'receiver boot');
const TGT = boot.target;
fs.writeFileSync(f('cmd.txt'), 'fore:' + Date.now());
await waitStatus((s) => s.cmd === 'fore', 8000, 'fore');
console.log('receiver target=' + TGT + ' recErr=' + recErr.slice(-120));

const c = await connect();
const trials = { mine: [], beat: [] };
async function runSet(host, hwnd, tag, activateEach) {
  const vars = [
    ['keypress-fg', 'keypress', () => ({ keys: ['w'], nativeWindowHandle: hwnd, dispatch: 'foreground' })],
    ['keypress-bg', 'keypress', () => ({ keys: ['w'], nativeWindowHandle: hwnd, dispatch: 'background' })],
    ['typetext-bg', 'type_text', () => ({ text: 'w', method: 'background', nativeWindowHandle: hwnd })],
    ['typetext-sendinput', 'type_text', () => ({ text: 'w', method: 'sendinput', nativeWindowHandle: hwnd })],
    ['click-fg', 'click', () => ({ x: 300, y: 260, nativeWindowHandle: hwnd, dispatch: 'foreground' })],
  ];
  const out = [];
  for (const [label, tool, args] of vars) {
    for (let i = 0; i < T; i++) {
      if (activateEach) { await c.tool('activate_window', { nativeWindowHandle: hwnd }); await sleep(120); }
      const t0 = Date.now();
      const r = await c.tool(tool, args());
      const t1 = Date.now();
      let data = r.data;
      if (typeof data === 'string') { try { data = JSON.parse(data); } catch { } }
      out.push({ host: tag, label, tool, i, t0, t1, callMs: t1 - t0, ok: !r.isError, method: data?.method ?? null, note: (r.text ?? '').replace(/\s+/g, ' ').slice(0, 120) });
      await sleep(GAP);
    }
    console.log(`${tag}/${label} done`);
  }
  return out;
}

try {
  trials.mine = await runSet('mine', TGT, 'mine', false);
  fs.writeFileSync(f('cmd.txt'), 'quit:' + Date.now());
  await sleep(1500);
} catch (e) {
  console.log('[fatal-A] ' + (e?.message ?? e));
}

// B: 旧打点器（独占跑，避免 Topmost 覆盖点；每次调用前 activate，复刻上一轮口径）
try {
  spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', 'D:\\dsh-arena\\arena-beat.ps1',
    '-OutJsonl', BEAT_JSONL, '-ExitAfterMs', '240000'], { stdio: 'ignore' });
  const { win: bw } = await waitArenaWindow(c, { tries: 60, intervalMs: 400 });
  if (!bw) throw new Error('arena-beat window not found');
  const BH = bw.nativeWindowHandle;
  console.log('arena-beat hwnd=' + BH);
  await c.tool('activate_window', { nativeWindowHandle: BH });
  await sleep(600);
  trials.beat = await runSet('beat', BH, 'beat', true);
  await closeArenaWindows(c);
} catch (e) {
  console.log('[fatal-B] ' + (e?.message ?? e));
} finally {
  try { rec.kill(); } catch {}
  try { await c.close(); } catch {}
}

// ---------- A: 我的接收器 ----------
const raw = JSON.parse(fs.readFileSync(f('native-events.json'), 'utf8'));
const freq = raw.freq, ms = (t) => (t / freq) * 1000;
const toTick = (wallMs) => raw.anchorTick + (wallMs - raw.anchorWallMs) * freq / 1000;
const evs = raw.events.filter((e) => e[3] === raw.target);
let p = 0;
for (const tr of trials.mine) {
  const a = toTick(tr.t0), b = a + 3000 * freq / 1000;
  while (p < evs.length && evs[p][2] < a) p++;
  for (let q = p; q < evs.length && evs[q][2] <= b; q++) { tr.arrivalMs = ms(evs[q][2] - a); tr.firstMsg = '0x' + evs[q][0].toString(16); break; }
  tr.totalMs = tr.arrivalMs === undefined ? null : Math.round((tr.arrivalMs + (tr.t0 - tr.t0)) * 10) / 10;
}

// ---------- B: arena-beat（旧打点器） ----------
const bl = fs.existsSync(BEAT_JSONL) ? fs.readFileSync(BEAT_JSONL, 'utf8').split('\n').filter(Boolean).map((s) => { try { return JSON.parse(s); } catch { return null; } }).filter(Boolean) : [];
const h = bl.find((x) => x.kind === 'header');
const be = bl.filter((x) => x.kind && x.kind !== 'header' && x.kind !== 'marker');
if (h) for (const tr of trials.beat) {
  const lo = tr.t0 - h.swZeroUnixMs - 3000, hi = tr.t0 - h.swZeroUnixMs + 3000;
  const e = be.find((x) => x.swMs >= lo && x.swMs <= hi);
  if (e) { tr.arrivalMs = Math.round((h.swZeroUnixMs + e.swMs - tr.t0) * 10) / 10; tr.firstMsg = e.kind; }
}

const agg = (arr) => {
  const s = arr.slice().sort((x, y) => x - y);
  if (!s.length) return { n: 0 };
  const q = (f2) => Math.round(s[Math.min(s.length - 1, Math.floor(f2 * s.length))] * 10) / 10;
  return { n: s.length, med: q(0.5), p90: q(0.9), max: Math.round(s[s.length - 1] * 10) / 10, min: Math.round(s[0] * 10) / 10 };
};
const res = { T, gapMs: GAP, recAnchor: { anchorTick: raw.anchorTick, anchorWallMs: raw.anchorWallMs, freq }, beatHeader: h ?? null, cases: [], trials: trials.mine.concat(trials.beat) };
for (const tag of ['mine', 'beat']) {
  const labels = [...new Set(trials[tag].map((t) => t.label))];
  for (const label of labels) {
    const rows = trials[tag].filter((t) => t.label === label);
    const lat = rows.filter((r) => r.arrivalMs !== undefined && r.arrivalMs >= -50).map((r) => r.arrivalMs);
    res.cases.push({
      host: tag, label, trials: rows.length, delivered: lat.length, lost: rows.length - lat.length,
      callMed: agg(rows.map((r) => r.callMs)).med,
      lat: agg(lat), methods: [...new Set(rows.map((r) => r.method))].join('/'), err: rows.filter((r) => !r.ok).length,
    });
  }
}
fs.writeFileSync(f('keylat-plugin.json'), JSON.stringify(res, null, 1), 'utf8');
console.log('\n| 接收器 | 插件路径 | 投递/丢 | 中位 | p90 | 最大 | 调用中位 | method |');
console.log('|---|---|---|---|---|---|---|---|');
for (const k of res.cases) console.log(`| ${k.host} | ${k.label} | ${k.delivered}/${k.lost} | ${k.lat.med ?? '-'} | ${k.lat.p90 ?? '-'} | ${k.lat.max ?? '-'} | ${k.callMed} | ${k.methods} |`);
console.log('recErr=' + recErr.slice(-200));
