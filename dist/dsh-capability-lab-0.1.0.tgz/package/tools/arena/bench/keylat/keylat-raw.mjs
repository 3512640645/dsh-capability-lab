/**
 * keylat / keylat-raw.mjs  —  "哪些目标类型会忽略 PostMessage" 的本地实测
 *
 * 靶子：rawsink.ps1 —— 同一个窗口上同时统计两条独立通道：
 *   ① 窗口消息通道 WM_KEYDOWN/WM_CHAR/WM_KEYUP（PostMessage 能喂到的）
 *   ② 原始输入通道 WM_INPUT（RegisterRawInputDevices + RIDEV_INPUTSINK，DirectInput/原生输入型游戏读的就是这条）
 * 判据：投 post 时 ①涨 ②不涨 ⇒ PostMessage 打不到 raw/DirectInput 类目标；
 *      投 SendInput 时两条通道各涨多少，就是"真实注入能到哪"。
 * 用法: node keylat-raw.mjs [n]
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { startInjector } from './keyclient.mjs';

const DIR = 'D:\\dsh-arena\\bench\\keylat';
const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const N = Number(process.argv[2] ?? 20);
const f = (p) => path.join(DIR, p);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const st = () => { try { return JSON.parse(fs.readFileSync(f('raw-status.json'), 'utf8')); } catch { return null; } };
const keys = 'wasdqerf'.split('');

const sink = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f('rawsink.ps1'), '-Dir', DIR, '-LifeMs', '600000'],
  { env: ENV, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
try { fs.rmSync(f('raw-status.json')); } catch { }
let sinkErr = '';
sink.stdout.on('data', (c) => { sinkErr += c; });
sink.stderr.on('data', (c) => { sinkErr += c; });
let s0 = null;
for (let i = 0; i < 200; i++) { s0 = st(); if (s0 && s0.hwnd && s0.pid === sink.pid) break; s0 = null; await sleep(100); }
if (!s0) { console.log('[fatal] rawsink 未起来: ' + sinkErr.slice(-400)); process.exit(1); }
const HWND = s0.hwnd;
console.log(`rawsink pid=${s0.pid} hwnd=${HWND} vis=${s0.vis} raw注册后计数=${s0.rawInput}`);
console.log('raw 注册自检: ' + JSON.stringify({ registerOk: s0.registerOk, devSize: s0.devSize, registered: s0.registered, registeredDesc: s0.registeredDesc }));

const inj = await startInjector();
const phases = [];
async function phase(name, fn, extra = {}) {
  const a = st();
  for (let i = 0; i < N; i++) { await sleep(60); await fn(i); }
  await sleep(300);
  const b = st();
  const row = {
    name, n: N, fgBefore: a.fg, fgAfter: b.fg, sinkIsFg: b.fg === HWND,
    msgDown: b.msgs.down - a.msgs.down,
    msgChar: b.msgs.char - a.msgs.char, msgUp: b.msgs.up - a.msgs.up,
    rawInput: b.rawInput - a.rawInput, rawDown: b.rawDown - a.rawDown, ...extra,
  };
  phases.push(row);
  console.log(`[${name}] fg=${row.sinkIsFg ? 'sink' : 'other'} msgDown+${row.msgDown} msgChar+${row.msgChar} msgUp+${row.msgUp} rawInput+${row.rawInput} rawDown+${row.rawDown}`);
  return row;
}

try {
  await phase('A-post-while-background', (i) => inj.hold(keys[i % 8], 0, { mode: 'post', hwnd: HWND }));
  const fr = await inj.focus(HWND);
  console.log('focus sink: ok=' + fr.ok + ' fg=' + fr.fg);
  await sleep(300);
  await phase('B-sendinput-real-foreground', (i) => inj.hold(keys[i % 8], 5));
  await phase('C-post-while-foreground', (i) => inj.hold(keys[i % 8], 0, { mode: 'post', hwnd: HWND }));
  await phase('D-postchar-only', (i) => inj.hold(keys[i % 8], 0, { mode: 'postc', hwnd: HWND }));
} catch (e) { console.log('[fatal] ' + (e?.message ?? e)); }

const tail = st();
const out = {
  generatedAt: new Date().toISOString(),
  method: 'rawsink.ps1 同一窗口双通道计数：消息通道 WM_KEYDOWN/CHAR/UP vs 原始通道 WM_INPUT(RIDEV_INPUTSINK)',
  hwnd: HWND, sinkPid: s0.pid, sinkFreq: tail.freq,
  injector: { pid: inj.pid, stats: inj.stats() },
  phases, tail,
};
try { await inj.close(); } catch { }
try { sink.kill(); } catch { }
fs.writeFileSync(f('keylat-raw.json'), JSON.stringify(out, null, 1), 'utf8');
console.log('\n| 阶段 | 注入方式 | sink 在前台? | WM_KEYDOWN+ | WM_CHAR+ | WM_INPUT+ | 结论 |');
console.log('|---|---|---|---|---|---|---|');
for (const p of out.phases) console.log(`| ${p.name} | ${p.name.includes('post') ? 'PostMessage' : 'SendInput'} | ${p.sinkIsFg} | ${p.msgDown} | ${p.msgChar} | ${p.rawInput} | ${p.rawInput === 0 ? '消息到了、raw 没到' : '两条通道都到'} |`);
console.log('JSON -> ' + f('keylat-raw.json'));
process.exit(0);
