/** 汇总 keylat 三组实测 -> D:\dsh-arena\bench\keylat\keylat.json */
import fs from 'node:fs';
const DIR = 'D:\\dsh-arena\\bench\\keylat';
const rd = (p) => { try { return JSON.parse(fs.readFileSync(DIR + '\\' + p, 'utf8')); } catch { return null; } };
const nat = rd('keylat-native.json'), fast = rd('keylat-fast.json'), plug = rd('keylat-plugin.json'), ab = rd('keylat-ab.json');
const slim = (c) => ({ label: c.label, phase: c.phase, n: c.n ?? c.got, gapMs: c.gapMs ?? null, got: c.got, loss: c.loss, med: c.medMs ?? c.med, p90: c.p90Ms ?? c.p90, max: c.maxMs ?? c.max, callMed: c.callMedMs ?? c.rttMed ?? null, cover: c.coverTotal ?? null, first: c.firstMsg ?? null });
const out = {
  generatedAt: new Date().toISOString(),
  machine: { host: 'DESKTOP-Q0AH8E7', screen: '1440x900', note: '与其它 worker 共享桌面；测量期间有第三方模态窗口抢前台' },
  method: {
    clock: 'QueryPerformanceCounter(Stopwatch.GetTimestamp)，同机全局一致；延迟=(目标窗口收到消息的 tick − 注入前 tick)/freq',
    receivers: { fast: 'bench/keylat/receiver.ps1（WndProc 只取 tick，不写盘）', legacy: 'D:\\dsh-arena\\arena-beat.ps1（每事件 AutoFlush 写盘 + 跨时钟对齐）' },
    trials: { native: 'n=100/路径, 间隔25ms；dense 为 gap=0 连发100', fast: 'n=30/路径, 间隔150ms（含 Node→常驻进程 往返）', plugin: 'n=12/路径, 间隔700ms', ab: 'n=8 交错 A/B' },
  },
  native: nat ? { freq: nat.freq, cases: nat.cases.map(slim) } : null,
  fast: fast ? { cases: fast.cases.map((c) => ({ label: c.label, got: c.got, loss: c.lost, med: c.med, p90: c.p90, max: c.max, rttMed: c.rttMed, rttP90: c.rttP90 })) } : null,
  plugin: plug ? { cases: plug.cases.map((c) => ({ host: c.host, label: c.label, delivered: c.delivered, lost: c.lost, med: c.lat.med ?? null, p90: c.lat.p90 ?? null, max: c.lat.max ?? null, callMed: c.callMed, method: c.methods })) } : null,
  ab: ab ? { pairs: ab.trials.filter((t) => t.host === 'beat' && t.tool === 'type_text' && t.arrivalMs !== undefined).map((t, i) => ({ pair: i + 1, mine: ab.trials.filter((x) => x.host === 'mine' && x.tool === 'type_text')[i]?.arrivalMs ?? null, beat: t.arrivalMs, mineCall: ab.trials.filter((x) => x.host === 'mine' && x.tool === 'type_text')[i]?.callMs ?? null, beatCall: t.callMs })) } : null,
};
const by = (arr, k) => arr.filter((c) => c.label === k)[0];
if (nat) for (const k of ['fg/postmessage-char', 'fg/sendinput-vk', 'fg/keybd_event', 'bg/postmessage-char', 'bg/sendinput-unicode', 'fg/mouse-sendinput']) {
  const c = by(nat.cases, k); if (c) (out.headline ??= {})[k] = { med: c.medMs, p90: c.p90Ms, max: c.maxMs, got: c.got, loss: c.loss, coverTotal: c.coverTotal };
}
fs.writeFileSync(DIR + '\\keylat.json', JSON.stringify(out, null, 1), 'utf8');
console.log('keylat.json 已生成；headline=' + JSON.stringify(out.headline, null, 1));
console.log('plugin=' + JSON.stringify(out.plugin?.cases, null, 1));
console.log('ab=' + JSON.stringify(out.ab?.pairs));
