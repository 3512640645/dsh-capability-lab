/**
 * keylat / keylat-targets.mjs  —  "同一组 PostMessage，打到不同窗口类别，谁收谁不收"
 *
 * 三类别对照，全部用同一份注入器、同一条 post 消息：
 *   T1 WinForms（receiver.ps1 的 target，WndProc 计数）  目标在后台
 *   T2 WPF（arena-beat.ps1 的窗口，PreviewKeyDown/TextInput 写 JSONL）  目标在后台
 *   T3 同 T2，但投完把窗口激活 —— 答案分岔：消息是被"丢弃"还是"延后处理"
 *   T4 WPF 前台对照（已知 R3 全收）
 * 用法: node keylat-targets.mjs [n]
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { startInjector } from './keyclient.mjs';

const DIR = 'D:\\dsh-arena\\bench\\keylat';
const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const ENV = { ...process.env, TEMP: 'D:\\dsh-tmp', TMP: 'D:\\dsh-tmp' };
const N = Number(process.argv[2] ?? 20);
const TS = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const BEATJSONL = path.join(DIR, `beat-targets-${TS}.jsonl`);
const f = (p) => path.join(DIR, p);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const keys = 'wasdqerf'.split('');
const stJson = (p) => { try { return JSON.parse(fs.readFileSync(f(p), 'utf8')); } catch { return null; } };

// WinForms 目标（receiver.ps1：target + cover 两个窗口）
for (const p of ['cmd.txt', 'status.json', 'native-events.json']) { try { fs.rmSync(f(p)); } catch { } }
const recv = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', f('receiver.ps1'), '-Dir', DIR, '-LifeMs', '600000'],
  { env: ENV, stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
let rerr = ''; recv.stderr.on('data', (c) => { rerr += c; });
let rs = null;
for (let i = 0; i < 200; i++) { rs = stJson('status.json'); if (rs && rs.cmd === 'boot') break; await sleep(100); }
if (!rs) { console.log('[fatal] receiver 未起来 ' + rerr.slice(-300)); process.exit(1); }
console.log(`WinForms receiver pid=${recv.pid} target=${rs.target} cover=${rs.cover}`);

// WPF 目标（arena-beat.ps1）
const beat = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', 'D:\\dsh-arena\\arena-beat.ps1',
  '-OutJsonl', BEATJSONL, '-ExitAfterMs', '900000', '-Left', '140', '-Top', '110'],
  { env: ENV, stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true });
let berr = ''; beat.stderr.on('data', (c) => { berr += c; });
let hd = null;
for (let i = 0; i < 300; i++) {
  try { const l = fs.readFileSync(BEATJSONL, 'utf8').split('\n')[0]; if (l && l.includes('"kind":"header"')) { hd = JSON.parse(l); break; } } catch { }
  await sleep(100);
}
if (!hd) { console.log('[fatal] arena-beat 未起来 ' + berr.slice(-300)); process.exit(1); }
const WPF = Number(hd.hwnd), SW0 = Number(hd.swZeroQpc), FREQ = Number(hd.qpcFreq);
const inj = await startInjector();
console.log(`WPF arena pid=${beat.pid} hwnd=${WPF} injector pid=${inj.pid}`);

function beatTicks() {
  const out = [];
  for (const l of fs.readFileSync(BEATJSONL, 'utf8').split('\n')) {
    if (!l.trim()) continue;
    let o; try { o = JSON.parse(l); } catch { continue; }
    if (o.kind === 'header' || o.swMs === undefined) continue;
    out.push(SW0 + (o.swMs / 1000) * FREQ);
  }
  return out.sort((a, b) => a - b);
}
const countIn = (arr, lo, hi) => arr.filter((t) => t >= lo && t <= hi).length;

const phases = [];
async function postTo(name, hwnd, n) {
  const t0 = (await inj.ping()).t1;
  for (let i = 0; i < n; i++) { await sleep(60); await inj.hold(keys[i % 8], 0, { mode: 'post', hwnd }); }
  const t1 = (await inj.ping()).t1;
  return { name, hwnd, n, t0, t1 };
}

try {
  fs.writeFileSync(f('cmd.txt'), 'back:' + Date.now());
  for (let i = 0; i < 60; i++) { const s = stJson('status.json'); if (s.cmd === 'back' && s.fg === rs.cover) break; await sleep(100); }
  const pr = await inj.probe(WPF);
  console.log(`前台 = cover(${rs.cover})；arena fg=${pr.fg}（arena=${WPF}）`);

  const T1 = await postTo('T1-WinForms-background-post', rs.target, N);
  await sleep(500);
  const T2 = await postTo('T2-WPF-background-post', WPF, N);
  const afterT2 = beatTicks();
  await sleep(1500);
  const gotT2 = countIn(beatTicks(), T2.t0, T2.t1);
  // T3：把 WPF 激活，看 T2 的消息是否"延后"冒出来
  const t3a = (await inj.ping()).t1;
  const fr = await inj.focus(WPF);
  await sleep(1500);
  const t3b = (await inj.ping()).t1;
  const deferred = countIn(beatTicks(), t3a, t3b);
  const T4 = await postTo('T4-WPF-foreground-post', WPF, 10);
  await sleep(500);
  const gotT4 = countIn(beatTicks(), T4.t0, T4.t1);

  phases.push(
    { name: T1.name, target: 'WinForms WndProc', foreground: false, posted: N, got: null, note: '收尾后从 native-events.json 取' },
    { name: T2.name, target: 'WPF PreviewKeyDown', foreground: false, posted: N, got: gotT2, note: '投完 1.5s 内收到' },
    { name: 'T3-WPF-activate-after-post', target: 'WPF PreviewKeyDown', foreground: '激活中', posted: N, got: deferred, note: 'T2 的消息在激活后是否补发' },
    { name: T4.name, target: 'WPF PreviewKeyDown', foreground: true, posted: 10, got: gotT4, note: '前台对照' },
  );
  console.log(`T2 后台 post 到 WPF：${gotT2}/${N}；激活后 1.5s 内补到：${deferred}；T4 前台：${gotT4}/10`);
  console.log(`（T3 前后事件总数 ${afterT2.length} -> ${beatTicks().length}）`);

  // 收尾：关 WPF，让 receiver dump
  await inj.closeWindow(WPF);
  await sleep(800);
  fs.writeFileSync(f('cmd.txt'), 'quit:' + Date.now());
  await sleep(1500);
  const raw = JSON.parse(fs.readFileSync(f('native-events.json'), 'utf8'));
  const tgt = raw.events.filter((e) => e[3] === rs.target);
  const t1row = phases.find((p) => p.name === T1.name);
  t1row.got = tgt.filter((e) => e[2] >= T1.t0 && e[2] <= T1.t1 + FREQ * 0.5 && (e[0] === 0x100 || e[0] === 0x102)).length;
  t1row.windowKeyEvents = tgt.filter((e) => e[2] >= T1.t0 && e[2] <= T1.t1 + FREQ * 0.5).length;
  console.log(`T1 后台 post 到 WinForms：${t1row.got}/${N}`);
  const out = { generatedAt: new Date().toISOString(), n: N, qpc: { freq: FREQ, swZeroQpc: SW0 }, wpfHwnd: WPF, winforms: rs, phases, injector: { pid: inj.pid, stats: inj.stats() }, beatJsonl: BEATJSONL };
  fs.writeFileSync(f('keylat-targets.json'), JSON.stringify(out, null, 1), 'utf8');
  console.log('\n| 阶段 | 目标类别 | 目标在前台? | 投递数 | 收到 | 结论 |');
  console.log('|---|---|---|---|---|---|');
  for (const p of phases) console.log(`| ${p.name} | ${p.target} | ${p.foreground} | ${p.posted} | ${p.got} | ${p.got === p.posted ? '收到' : p.got === 0 ? '没收到' : '部分'} |`);
  console.log('JSON -> ' + f('keylat-targets.json'));
} catch (e) {
  console.log('[fatal] ' + (e?.message ?? e));
}

try { await inj.close(); } catch { }
try { recv.kill(); } catch { }
try { beat.kill(); } catch { }
process.exit(0);
