/**
 * mk-clicklat2.mjs —— 由原始 clicklat-fixture.ps1 派生协作式夹具 clicklat2-fixture.ps1
 *
 * 唯一差别：real 模式算出目标点后，把 HWND 写到 <GateDir>\hwnd.txt，并等 <GateDir>\go.txt。
 * 等待期间照常泵消息（DoEvents）。
 * 为什么要这么改：real 模式的遮挡门要求 GetForegroundWindow()==自己，而 Windows 前台锁
 * 不许后台 PowerShell 进程自抢前台 → 原夹具 200/200 全部 real_skipped（不是慢，是根本没注入）。
 * 让**外部**用已验证可行的抢前台路径（keylat/injector.ps1 的 AttachThreadInput+Alt 轻敲）先把前台
 * 交给它，再放行，测量语义完全不变（同样是 SetCursorPos + mouse_event + 两侧 QPC 打点）。
 * 夹具自己在进程内做 AttachThreadInput 会与 WinForms 消息泵死锁（实测：进程挂住、0 样本），故不采用。
 */
import fs from 'node:fs';
const SRC = 'D:\\dsh-arena\\bench\\clicklat-fixture.ps1';
const DST = 'D:\\dsh-arena\\bench\\clicklat2-fixture.ps1';
let s = fs.readFileSync(SRC, 'utf8');
const ins = [
  [`  [int]$X = -1,
  [int]$Y = -1
)`,
    `  [int]$X = -1,
  [int]$Y = -1,
  [string]$GateDir = ''
)`],
  [`    static string jsonlPath;`,
    `    static string jsonlPath;
    static string gateDir = "";
    static bool gateGo = false;
    static double gateWaitedMs = -1;`],
  [`    public static void Run(string mode, string outDir, int trials, int x, int y)
    {
        Directory.CreateDirectory(outDir);`,
    `    public static void Run(string mode, string outDir, int trials, int x, int y, string gate)
    {
        Directory.CreateDirectory(outDir);
        gateDir = gate ?? "";`],
  [`                Point tc = form.PointToScreen(new Point(cx, cy));
                target = tc.X + "," + tc.Y;`,
    `                Point tc = form.PointToScreen(new Point(cx, cy));
                target = tc.X + "," + tc.Y;
                if (gateDir.Length > 0)
                {
                    // handshake: publish HWND, wait for the external driver to hand us the foreground
                    long tG = T();
                    File.WriteAllText(Path.Combine(gateDir, "hwnd.txt"), h.ToInt64().ToString(), new UTF8Encoding(false));
                    string goPath = Path.Combine(gateDir, "go.txt");
                    long dlw = tG + (long)(30 * Freq);
                    while (!File.Exists(goPath) && T() < dlw) { Application.DoEvents(); Thread.Sleep(20); }
                    gateGo = File.Exists(goPath);
                    gateWaitedMs = (T() - tG) * 1000.0 / Freq;
                }`],
  [`                ",\\"qpc_freq\\":" + Freq + ",\\"dpi_aware\\":true,\\"api_baseline_us\\":{\\"get_cursor_pos_min\\":"`,
    `                ",\\"qpc_freq\\":" + Freq + ",\\"dpi_aware\\":true,\\"gate_go\\":" + (gateGo ? "true" : "false") + ",\\"gate_waited_ms\\":" + gateWaitedMs.ToString("F1", CultureInfo.InvariantCulture) + ",\\"api_baseline_us\\":{\\"get_cursor_pos_min\\":"`],
  [`        string err = "";
        bool visible = false;`,
    `        if (mode == "real")
        {
            // Measured on this host: the FIRST Show()n Form inside a PowerShell 5.1 process
            // stays IsWindowVisible=false (the second one is fine). An invisible window means
            // every click lands on the desktop -> 200/200 useless samples.
            // Sacrifice one off-screen form to take the "first form" slot.
            Form dummy = new Form();
            dummy.Text = "clicklat2 dummy";
            dummy.ClientSize = new Size(120, 80);
            dummy.ShowInTaskbar = false;
            dummy.StartPosition = FormStartPosition.Manual;
            dummy.Location = new Point(-4000, -4000);
            dummy.Show();
            IntPtr dummyH = dummy.Handle;
            Application.DoEvents();
            dummy.Hide();
            Application.DoEvents();
        }
        string err = "";
        bool visible = false;`],
  [`[ClickLatFixture]::Run($Mode, $OutDir, $Trials, $X, $Y)`,
    `[ClickLatFixture]::Run($Mode, $OutDir, $Trials, $X, $Y, $GateDir)`],
];
let n = 0;
for (const [a, b] of ins) { const before = s; s = s.split(a).join(b); if (s === before) console.log('MISS: ' + a.slice(0, 50).replace(/\n/g, '\\n')); else n++; }
fs.writeFileSync(DST, s, 'utf8');
console.log(`clicklat2-fixture.ps1 written, applied ${n}/${ins.length}, lines=${s.split('\n').length}`);
