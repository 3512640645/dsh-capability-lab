# =============================================================================
# KEYLAT RAW-INPUT SINK (keylat/rawsink.ps1)
#   One WinForms window that counts TWO independent channels at the same time:
#     - window-message channel : WM_KEYDOWN / WM_CHAR / WM_KEYUP  (what PostMessage feeds)
#     - raw-input channel      : WM_INPUT from RegisterRawInputDevices(RIDEV_INPUTSINK)
#                                (the same HID-report path DirectInput/raw-input games read)
#   Counters go to raw-status.json every 150ms so a driver can poll them live.
#   Expected live proof: post WM_KEYDOWN here -> msgDown rises, rawInput stays flat.
#
#   ASCII ONLY, no exceptions: Windows PowerShell 5.1 decodes a BOM-less .ps1 as ANSI/GBK,
#   so a Chinese comment gets mangled and eats the next line of the C# here-string
#   (this file failed to compile twice because of exactly that).
#
#   Also: this host's PowerShell returns EMPTY when reading a static field of an
#   Add-Type class ([RawSink]::H reads back as nothing while C# itself sees the right
#   value), so no PowerShell<->C# state is exchanged through fields: RegisterSelf()
#   takes zero arguments and reads H inside C#.
# =============================================================================
param([string]$Dir = 'D:\dsh-arena\bench\keylat', [int]$LifeMs = 600000)
$ErrorActionPreference = 'Stop'
$env:TEMP = 'D:\dsh-tmp'; $env:TMP = 'D:\dsh-tmp'
New-Item -ItemType Directory -Force -Path $Dir | Out-Null

$cs = @'
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

public class RawSink
{
    [DllImport("user32.dll")] public static extern bool RegisterRawInputDevices(RAWINPUTDEVICE[] d, uint n, uint size);
    [DllImport("user32.dll")] public static extern uint GetRawInputData(IntPtr h, uint cmd, byte[] data, ref uint size, uint hdr);
    [DllImport("user32.dll")] public static extern uint GetRegisteredRawInputDevices(RAWINPUTDEVICE[] p, ref uint n, uint size);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();

    [StructLayout(LayoutKind.Sequential)] public struct RAWINPUTDEVICE { public ushort usUsagePage, usUsage; public uint dwFlags; public IntPtr hwndTarget; }

    public static long RawInput = 0, MsgDown = 0, MsgChar = 0, MsgUp = 0, RawDown = 0;
    public static long LastRawTick = 0, LastMsgTick = 0;
    public static int LastRawVk = 0, LastMsgVk = 0;
    public static IntPtr H;
    public static string Dir = "";
    public static string RegInfo = "";

    public static void Wnd(Message m)
    {
        if (m.Msg == 0x00FF)   // WM_INPUT
        {
            RawInput++;
            LastRawTick = Stopwatch.GetTimestamp();
            byte[] buf = new byte[64];
            uint size = (uint)buf.Length;
            uint got = GetRawInputData(m.LParam, 0x10000003, buf, ref size, (uint)(4 + 4 + 8 + 8));
            if (got > 0 && BitConverter.ToUInt32(buf, 0) == 1)
            {
                LastRawVk = BitConverter.ToUInt16(buf, 30);
                if (BitConverter.ToUInt16(buf, 24) != 0) RawDown++;
            }
        }
        else if (m.Msg == 0x100) { MsgDown++; LastMsgTick = Stopwatch.GetTimestamp(); LastMsgVk = m.WParam.ToInt32(); }
        else if (m.Msg == 0x102) { MsgChar++; LastMsgTick = Stopwatch.GetTimestamp(); }
        else if (m.Msg == 0x101) { MsgUp++; }
    }

    public static string RegisterRaw(IntPtr h)
    {
        RAWINPUTDEVICE[] d = new RAWINPUTDEVICE[1];
        d[0].usUsagePage = 1; d[0].usUsage = 6; d[0].dwFlags = 0x00000100; d[0].hwndTarget = h;
        int size = Marshal.SizeOf(typeof(RAWINPUTDEVICE));
        bool ok = RegisterRawInputDevices(d, 1, (uint)size);
        int err = Marshal.GetLastWin32Error();
        uint cnt = 0;
        GetRegisteredRawInputDevices(null, ref cnt, (uint)size);
        RAWINPUTDEVICE[] back = new RAWINPUTDEVICE[cnt];
        uint cnt2 = cnt;
        GetRegisteredRawInputDevices(back, ref cnt2, (uint)size);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cnt2; i++)
            sb.Append(i > 0 ? ";" : "").Append(back[i].usUsagePage).Append("/").Append(back[i].usUsage)
              .Append("/f=0x").Append(back[i].dwFlags.ToString("X")).Append("/hwnd=").Append(back[i].hwndTarget.ToInt64());
        return ",\"registerOk\":" + (ok ? "true" : "false") + ",\"devSize\":" + size + ",\"lastErr\":" + err
             + ",\"registered\":" + cnt2 + ",\"registeredDesc\":\"" + sb.ToString() + "\""
             + ",\"sentUsage\":\"1/6/f=0x100/hwnd=" + h.ToInt64() + "\"";
    }

    public static void RegisterSelf() { RegInfo = RegisterRaw(H); }

    public static void Status()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("{\"pid\":").Append(Process.GetCurrentProcess().Id).Append(",\"hwnd\":").Append(H.ToInt64())
          .Append(",\"vis\":").Append(IsWindowVisible(H) ? "true" : "false")
          .Append(",\"fg\":").Append(GetForegroundWindow().ToInt64())
          .Append(",\"msgs\":{\"down\":").Append(MsgDown).Append(",\"char\":").Append(MsgChar).Append(",\"up\":").Append(MsgUp).Append("}")
          .Append(",\"rawInput\":").Append(RawInput).Append(",\"rawDown\":").Append(RawDown)
          .Append(",\"lastRawVk\":").Append(LastRawVk).Append(",\"lastMsgVk\":").Append(LastMsgVk)
          .Append(",\"lastRawTick\":").Append(LastRawTick).Append(",\"tick\":").Append(Stopwatch.GetTimestamp())
          .Append(",\"freq\":").Append(Stopwatch.Frequency).Append(",\"ver\":\"v6\"").Append(RegInfo).Append("}");
        File.WriteAllText(Path.Combine(Dir, "raw-status.json"), sb.ToString());
    }

    public static void Run(string dir, int lifeMs)
    {
        Dir = dir;
        Form f = new SinkForm();
        f.Text = "KEYLAT-RAWSINK";
        f.StartPosition = FormStartPosition.Manual;
        f.Bounds = new Rectangle(300, 200, 520, 320);
        f.BackColor = Color.FromArgb(20, 28, 40);
        f.Show();
        Application.DoEvents();
        H = f.Handle;
        if (!IsWindowVisible(H)) { ShowWindow(H, 5); SetWindowPos(H, IntPtr.Zero, 300, 200, 520, 320, 0x0040); }
        RegisterSelf();
        Status();
        Timer st = new Timer(); st.Interval = 150; st.Tick += delegate { Status(); }; st.Start();
        Timer life = new Timer(); life.Interval = Math.Max(1000, lifeMs);
        life.Tick += delegate { st.Stop(); life.Stop(); Status(); Application.ExitThread(); };
        life.Start();
        Application.Run();
        Status();
    }
}

// window procedure hook lives in its own type (the earlier rewrite dropped it and every
// counter silently stayed 0 - the form was a plain Form that never called RawSink.Wnd)
public class SinkForm : Form
{
    protected override void WndProc(ref Message m) { RawSink.Wnd(m); base.WndProc(ref m); }
}
'@

Add-Type -TypeDefinition $cs -ReferencedAssemblies 'System.dll', 'System.Core.dll', 'System.Windows.Forms.dll', 'System.Drawing.dll' -Language CSharp
[RawSink]::Run($Dir, $LifeMs)
