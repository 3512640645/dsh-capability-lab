# KEYLAT 接收器：两个 WinForms 窗口（target/cover），WndProc 里只取 QPC tick（不写盘、不格式化）
# 命令走 cmd.txt（UI 线程 10ms 轮询）：fore / back / quit
param([string]$Dir = 'D:\dsh-arena\bench\keylat', [int]$LifeMs = 300000)
$ErrorActionPreference = 'Stop'
$env:TEMP = 'D:\dsh-tmp'; $env:TMP = 'D:\dsh-tmp'
New-Item -ItemType Directory -Force -Path $Dir | Out-Null

$cs = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

public class KeyLat
{
    public static List<long[]> Ev = new List<long[]>();
    public static long Freq = Stopwatch.Frequency;
    public static long AnchorTick, AnchorWallMs;
    public static IntPtr TargetH, CoverH;
    public static string Dir = "";
    static F target = null, cover = null;
    static string lastCmd = "";
    static long bootTick;

    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
    [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
    [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT p);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }

    static string Geo(IntPtr h)
    {
        RECT r; GetWindowRect(h, out r);
        POINT c; c.X = (r.L + r.R) / 2; c.Y = (r.T + r.B) / 2;
        return "{\"vis\":" + (IsWindowVisible(h) ? "true" : "false") + ",\"iconic\":" + (IsIconic(h) ? "true" : "false")
             + ",\"rect\":[" + r.L + "," + r.T + "," + r.R + "," + r.B + "],\"wfpAtCenter\":" + WindowFromPoint(c).ToInt64() + "}";
    }

    public static void Rec(long msg, long wp, long hwnd)
    {
        if (msg != 0x100 && msg != 0x101 && msg != 0x102 && msg != 0x104 && msg != 0x105
            && msg != 0x201 && msg != 0x202 && msg != 0x203 && msg != 0x205) return;
        long t = Stopwatch.GetTimestamp();
        lock (Ev) { if (Ev.Count < 400000) Ev.Add(new long[] { msg, wp, t, hwnd }); }
    }

    public static void EnsureVisible()
    {
        // WinForms 里第一个 Show() 的窗体在本机上停在 Visible=false；用 Win32 强制显示。
        if (!IsWindowVisible(TargetH)) { ShowWindow(TargetH, 5); SetWindowPos(TargetH, IntPtr.Zero, 60, 60, 720, 520, 0x0040 | 0x0010); }
        if (!IsWindowVisible(CoverH)) { ShowWindow(CoverH, 5); SetWindowPos(CoverH, IntPtr.Zero, 820, 80, 560, 420, 0x0040 | 0x0010); }
    }

    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);

    public static bool GiveForeground(IntPtr h)
    {
        if (GetForegroundWindow() == h) return true;
        IntPtr fg = GetForegroundWindow();
        uint ft = GetWindowThreadProcessId(fg, IntPtr.Zero), tt = GetWindowThreadProcessId(h, IntPtr.Zero);
        bool att = false;
        if (ft != tt && ft != 0) att = AttachThreadInput(tt, ft, true);
        try
        {
            keybd_event(0x12, 0, 0, UIntPtr.Zero);
            keybd_event(0x12, 0, 2, UIntPtr.Zero);
            BringWindowToTop(h);
            SetForegroundWindow(h);
        }
        finally { if (att) AttachThreadInput(tt, ft, false); }
        Thread.Sleep(60);
        return GetForegroundWindow() == h;
    }

    public static void Run(string dir, int lifeMs)
    {
        Dir = dir;
        AnchorTick = Stopwatch.GetTimestamp();
        AnchorWallMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        target = new F("KEYLAT-TARGET", new Rectangle(60, 60, 720, 520));
        cover = new F("KEYLAT-COVER", new Rectangle(820, 80, 560, 420));
        target.Show();
        cover.Show();
        Application.DoEvents();
        TargetH = target.Handle; CoverH = cover.Handle;
        bootTick = Stopwatch.GetTimestamp();

        var poll = new System.Windows.Forms.Timer(); poll.Interval = 10;
        poll.Tick += (s, e) => Poll();
        poll.Start();

        var life = new System.Windows.Forms.Timer(); life.Interval = Math.Max(1000, lifeMs);
        life.Tick += (s, e) => { Dump(); Application.ExitThread(); };
        life.Start();

        Status("boot");
        Application.Run();
    }

    static void Poll()
    {
        try
        {
            string cf = Path.Combine(Dir, "cmd.txt");
            if (!File.Exists(cf)) return;
            string c = File.ReadAllText(cf).Trim();
            if (c.Length == 0 || c == lastCmd) return;
            lastCmd = c;
            string op = c.Split(':')[0];
            if (op == "fore") { EnsureVisible(); GiveForeground(TargetH); }
            else if (op == "back") { EnsureVisible(); GiveForeground(CoverH); }
            else if (op == "show") { EnsureVisible(); }
            else if (op == "quit") { Dump(); Application.ExitThread(); return; }
            Status(op);
        }
        catch { }
    }

    static void Status(string cmd)
    {
        string s = "{\"cmd\":\"" + cmd + "\",\"target\":" + TargetH.ToInt64() + ",\"cover\":" + CoverH.ToInt64()
                 + ",\"fg\":" + GetForegroundWindow().ToInt64() + ",\"tick\":" + Stopwatch.GetTimestamp()
                 + ",\"targetHwnd\":" + Geo(TargetH) + ",\"coverHwnd\":" + Geo(CoverH) + "}";
        try { File.WriteAllText(Path.Combine(Dir, "status.json"), s); } catch { }
    }

    static void Dump()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("{\"freq\":").Append(Freq).Append(",\"anchorTick\":").Append(AnchorTick)
          .Append(",\"anchorWallMs\":").Append(AnchorWallMs).Append(",\"bootTick\":").Append(bootTick)
          .Append(",\"target\":").Append(TargetH.ToInt64()).Append(",\"cover\":").Append(CoverH.ToInt64())
          .Append(",\"exitTick\":").Append(Stopwatch.GetTimestamp()).Append(",\"events\":[");
        lock (Ev)
        {
            for (int i = 0; i < Ev.Count; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append('[').Append(Ev[i][0]).Append(',').Append(Ev[i][1]).Append(',')
                  .Append(Ev[i][2]).Append(',').Append(Ev[i][3]).Append(']');
            }
        }
        sb.Append("]}");
        File.WriteAllText(Path.Combine(Dir, "native-events.json"), sb.ToString());
    }

    public class F : Form
    {
        public F(string text, Rectangle r)
        {
            Text = text;
            StartPosition = FormStartPosition.Manual;
            Bounds = r;
            KeyPreview = true;
            BackColor = Color.FromArgb(24, 32, 48);
        }
        protected override void WndProc(ref Message m)
        {
            KeyLat.Rec(m.Msg, m.WParam.ToInt64(), (long)m.HWnd);
            base.WndProc(ref m);
        }
    }
}
'@

Add-Type -TypeDefinition $cs -ReferencedAssemblies 'System.dll', 'System.Core.dll', 'System.Windows.Forms.dll', 'System.Drawing.dll' -Language CSharp
[KeyLat]::Run($Dir, $LifeMs)
