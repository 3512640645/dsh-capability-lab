// revert-clicklat-fixture.mjs —— 把 clicklat-fixture.ps1 还原成 W1 接手时的原样（去掉本轮加的自抢前台补丁）
import fs from 'node:fs';
const P = 'D:\\dsh-arena\\bench\\clicklat-fixture.ps1';
let s = fs.readFileSync(P, 'utf8');
const cut = [
  [`    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
    [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
    [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
`, ''],
  [/\n    \/\/ Foreground lock workaround[\s\S]*?return GetForegroundWindow\(\) == h;\n    \}\n/, '\n'],
  [`        int focusTries = -99;
        bool focusOk = false;
        int focusFixes = 0;
`, ''],
  [`                focusTries = 0;
                for (int k = 0; k < 20 && GetForegroundWindow() != h; k++) { ForceForegroundOnce(h); Application.DoEvents(); Thread.Sleep(60); focusTries++; }
                focusOk = (GetForegroundWindow() == h);
`, ''],
  [`                    if (GetForegroundWindow() != h && focusFixes < 10)
                    { focusFixes++; focusTries = 0; for (int k = 0; k < 8 && GetForegroundWindow() != h; k++) { ForceForegroundOnce(h); Application.DoEvents(); Thread.Sleep(40); focusTries++; } focusOk = (GetForegroundWindow() == h); }
`, ''],
  [`\\"focus_tries\\":" + focusTries + ",\\"focus_ok\\":" + (focusOk ? "true" : "false") + ",\\"focus_fixes\\":" + focusFixes + ",\\"api_baseline_us\\":`, '\\"api_baseline_us\\":'],
];
let n = 0;
for (const [a, b] of cut) {
  const before = s;
  s = typeof a === 'string' ? s.split(a).join(b) : s.replace(a, b);
  if (s === before) console.log('MISS: ' + String(a).slice(0, 60).replace(/\n/g, '\\n'));
  else n++;
}
fs.writeFileSync(P, s, 'utf8');
console.log(`applied ${n}/${cut.length}, lines=${s.split('\n').length}`);
for (const bad of ['ForceForeground', 'focusTries', 'focusFixes', 'AttachThreadInput', 'keybd_event', 'BringWindowToTop']) {
  if (s.includes(bad)) console.log('LEFTOVER: ' + bad);
}
