# KEYLAT 原始注入器：常驻进程，stdin 收 JSON 指令 -> 立即注入并记录 QPC tick(注入前/注入后)
# 指令: {"variant":"sendinput-vk","hwnd":123,"n":100,"gapMs":25,"vk":87,"ch":119}
# 回复: "R {variant, ticks:[t0,t1,t0,t1,...]}"  (ticks 为 QPC)
$ErrorActionPreference = 'Stop'
$env:TEMP = 'D:\dsh-tmp'; $env:TMP = 'D:\dsh-tmp'

$cs = @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

[StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
[StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
[StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx, dy; public uint mouseData, dwFlags, time; public IntPtr extra; }
[StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr extra; }
[StructLayout(LayoutKind.Sequential)] public struct HARDWAREINPUT { public uint uMsg; public ushort wParamL, wParamH; }
[StructLayout(LayoutKind.Explicit)] public struct INPUTUNION { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; [FieldOffset(0)] public HARDWAREINPUT hi; }
[StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public INPUTUNION u; }

public class RawSend
{
    [DllImport("user32.dll", SetLastError = true)] static extern uint SendInput(uint n, INPUT[] p, int cb);
    [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool PostMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr SendMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
    [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code, uint type);
    [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
    [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(POINT p);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();

    const uint WM_KEYDOWN = 0x100, WM_KEYUP = 0x101, WM_CHAR = 0x102;
    const uint WM_LBUTTONDOWN = 0x201, WM_LBUTTONUP = 0x202;
    const uint ME_LEFTDOWN = 0x0002, ME_LEFTUP = 0x0004;
    const uint KE_KEYUP = 0x0002, KE_UNICODE = 0x0004, KE_SCANCODE = 0x0008;

    static INPUT Key(ushort vk, ushort scan, uint flags)
    {
        INPUT i = new INPUT();
        i.type = 1; i.u.ki.wVk = vk; i.u.ki.wScan = scan; i.u.ki.dwFlags = flags;
        return i;
    }
    static INPUT Mouse(uint flags, int dx, int dy)
    {
        INPUT i = new INPUT();
        i.type = 0; i.u.mi.dx = dx; i.u.mi.dy = dy; i.u.mi.dwFlags = flags;
        return i;
    }
    static void SleepAccurate(int ms)
    {
        if (ms <= 0) return;
        var sw = Stopwatch.StartNew();
        int s = ms - 2;
        if (s > 0) Thread.Sleep(s);
        while (sw.Elapsed.TotalMilliseconds < ms) Thread.SpinWait(60);
    }

    static void Do(string v, IntPtr h, ushort vk, char ch)
    {
        ushort scan = (ushort)(MapVirtualKey(vk, 0) & 0xFF);
        switch (v)
        {
            case "sendinput-vk":
                SendInput(1, new INPUT[] { Key(vk, 0, 0), Key(vk, 0, KE_KEYUP) }, Marshal.SizeOf(typeof(INPUT)));
                break;
            case "sendinput-scan":
                SendInput(1, new INPUT[] { Key(0, scan, KE_SCANCODE), Key(0, scan, KE_SCANCODE | KE_KEYUP) }, Marshal.SizeOf(typeof(INPUT)));
                break;
            case "keybd_event":
                keybd_event((byte)vk, 0, 0, UIntPtr.Zero);
                keybd_event((byte)vk, 0, KE_KEYUP, UIntPtr.Zero);
                break;
            case "sendinput-unicode":
                SendInput(1, new INPUT[] { Key(0, (ushort)ch, KE_UNICODE), Key(0, (ushort)ch, KE_UNICODE | KE_KEYUP) }, Marshal.SizeOf(typeof(INPUT)));
                break;
            case "sendkeys":
                SendKeys.SendWait(ch.ToString());
                break;
            case "postmessage-keydown":
                PostMessageW(h, WM_KEYDOWN, (IntPtr)vk, (IntPtr)(scan << 16 | 1));
                PostMessageW(h, WM_KEYUP, (IntPtr)vk, (IntPtr)(1 << 30 | 1 << 31 | scan << 16 | 1));
                break;
            case "postmessage-char":
                PostMessageW(h, WM_CHAR, (IntPtr)ch, (IntPtr)1);
                break;
            case "postmessage-combo":
                PostMessageW(h, WM_KEYDOWN, (IntPtr)vk, (IntPtr)1);
                PostMessageW(h, WM_CHAR, (IntPtr)ch, (IntPtr)1);
                PostMessageW(h, WM_KEYUP, (IntPtr)vk, (IntPtr)1);
                break;
            case "postmessage-combo-sc":
                PostMessageW(h, WM_KEYDOWN, (IntPtr)vk, (IntPtr)(scan << 16 | 1));
                PostMessageW(h, WM_CHAR, (IntPtr)ch, (IntPtr)1);
                PostMessageW(h, WM_KEYUP, (IntPtr)vk, (IntPtr)(1 << 30 | 1 << 31 | scan << 16 | 1));
                break;
            case "sendmessage-combo":
                SendMessageW(h, WM_KEYDOWN, (IntPtr)vk, (IntPtr)1);
                SendMessageW(h, WM_CHAR, (IntPtr)ch, (IntPtr)1);
                SendMessageW(h, WM_KEYUP, (IntPtr)vk, (IntPtr)1);
                break;
            case "sendinput-then-postmessage":
                SendInput(1, new INPUT[] { Key(0, (ushort)ch, KE_UNICODE), Key(0, (ushort)ch, KE_UNICODE | KE_KEYUP) }, Marshal.SizeOf(typeof(INPUT)));
                PostMessageW(h, WM_CHAR, (IntPtr)ch, (IntPtr)1);
                break;
            case "mouse-sendinput":
                {
                    RECT r; GetWindowRect(h, out r);
                    SetCursorPos((r.L + r.R) / 2, (r.T + r.B) / 2);
                    SendInput(1, new INPUT[] { Mouse(ME_LEFTDOWN, 0, 0) }, Marshal.SizeOf(typeof(INPUT)));
                    SendInput(1, new INPUT[] { Mouse(ME_LEFTUP, 0, 0) }, Marshal.SizeOf(typeof(INPUT)));
                }
                break;
            case "postmessage-mouse":
                {
                    RECT r; GetWindowRect(h, out r);
                    int cx = (r.R - r.L) / 2, cy = (r.B - r.T) / 2;
                    IntPtr lp = (IntPtr)(cx & 0xFFFF | cy << 16);
                    PostMessageW(h, WM_LBUTTONDOWN, (IntPtr)1, lp);
                    PostMessageW(h, WM_LBUTTONUP, IntPtr.Zero, lp);
                }
                break;
        }
    }

    public static string Probe(long hwnd)
    {
        RECT r; GetWindowRect((IntPtr)hwnd, out r);
        POINT p; GetCursorPos(out p);
        IntPtr w = WindowFromPoint(p);
        return "{\"rect\":[" + r.L + "," + r.T + "," + r.R + "," + r.B + "],\"cursor\":[" + p.X + "," + p.Y
             + "],\"wfp\":" + w.ToInt64() + ",\"fg\":" + GetForegroundWindow().ToInt64() + ",\"target\":" + hwnd + "}";
    }

    public static long[] Burst(string variant, long hwnd, int n, int gapMs, int vk, int ch)
    {
        long[] res = new long[n * 2];
        IntPtr h = (IntPtr)hwnd;
        for (int i = 0; i < n; i++)
        {
            if (i > 0) SleepAccurate(gapMs);
            long a = Stopwatch.GetTimestamp();
            Do(variant, h, (ushort)vk, (char)ch);
            long b = Stopwatch.GetTimestamp();
            res[i * 2] = a; res[i * 2 + 1] = b;
        }
        return res;
    }
}
'@

Add-Type -TypeDefinition $cs -ReferencedAssemblies 'System.dll', 'System.Core.dll', 'System.Windows.Forms.dll', 'System.Drawing.dll' -Language CSharp

[Console]::Out.WriteLine('READY')
[Console]::Out.Flush()
while ($null -ne ($line = [Console]::In.ReadLine())) {
  try {
    $j = $line | ConvertFrom-Json
    if ($j.op -eq 'probe') {
      [Console]::Out.WriteLine('P ' + [RawSend]::Probe([long]$j.hwnd))
      [Console]::Out.Flush()
      continue
    }
    $ticks = [RawSend]::Burst([string]$j.variant, [long]$j.hwnd, [int]$j.n, [int]$j.gapMs, [int]$j.vk, [int]$j.ch)
    $payload = '{"variant":"' + $j.variant + '","ticks":[' + ($ticks -join ',') + ']}'
    [Console]::Out.WriteLine('R ' + $payload)
  } catch {
    [Console]::Out.WriteLine('E ' + ($_.Exception.Message -replace '\s+', ' '))
  }
  [Console]::Out.Flush()
}
