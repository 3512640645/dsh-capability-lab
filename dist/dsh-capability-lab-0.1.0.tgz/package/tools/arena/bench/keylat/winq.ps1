param([int]$X = 420, [int]$Y = 320)
$env:TEMP = 'D:\dsh-tmp'; $env:TMP = 'D:\dsh-tmp'
$cs = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public class WinQ {
  [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT p);
  [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h, uint f);
  [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint c);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr h, StringBuilder t, int c);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassNameW(IntPtr h, StringBuilder t, int c);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  public static string Info(IntPtr h) {
    var t = new StringBuilder(300); GetWindowTextW(h, t, 300);
    var c = new StringBuilder(300); GetClassNameW(h, c, 300);
    uint pid; GetWindowThreadProcessId(h, out pid);
    return "h=" + h.ToInt64() + " cls=" + c + " pid=" + pid + " vis=" + IsWindowVisible(h) + " text='" + t + "'";
  }
  public static string Chain(int x, int y) {
    var sb = new StringBuilder();
    POINT p; p.X = x; p.Y = y;
    IntPtr w = WindowFromPoint(p);
    sb.AppendLine("WindowFromPoint(" + x + "," + y + ") " + Info(w) + " root=" + GetAncestor(w, 2).ToInt64());
    int n = 0;
    for (IntPtr q = w; q != IntPtr.Zero && n < 20; q = GetWindow(q, 3), n++) sb.AppendLine("  z" + (n + 1) + " " + Info(q));
    sb.AppendLine("FOREGROUND " + Info(GetForegroundWindow()));
    return sb.ToString();
  }
}
'@
Add-Type -TypeDefinition $cs -Language CSharp
[WinQ]::Chain($X, $Y)
'--- keylat 相关进程 ---'
Get-CimInstance Win32_Process -Filter "Name='powershell.exe' or Name='node.exe'" | Where-Object { $_.CommandLine -match 'keylat|receiver|sender' } | Select-Object ProcessId,Name,CommandLine | Format-List
'--- 桌面尺寸 ---'
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Screen]::PrimaryScreen.Bounds
