/**
 * l1-rerun.mjs —— 把 winctl/bench.mjs --repeat 3 的原始报告整理成 L1 真值表
 * 输入: D:\dsh-tools\winctl\reports\bench-<ts>.json（现场生成的那一份，路径由参数给）
 * 输出: D:\dsh-arena\bench\l1-rerun.json（机读）+ 控制台表格
 *
 * 判读规则（本文件写死，避免人眼看走样）：
 *   ok     = 外部判据（verified 字段）判定的真实结果 —— 唯一算分的依据
 *   okSelf = 被测实现自己的结论
 *   falseOk = okSelf && !ok  → **假达标**（自报成功、实测失败）
 *   envBlocked = note 里出现 POINT_COVERED / 被第三方窗口遮挡 → 该次**自判无效**（不是实现失败）
 */
import fs from 'node:fs';

const path = process.argv[2] ?? 'D:\\dsh-tools\\winctl\\reports\\bench-2026-11-06213611.json';
const raw = JSON.parse(fs.readFileSync(path, 'utf8').replace(/^\uFEFF/, ''));
const OUT = 'D:\\dsh-arena\\bench\\l1-rerun.json';
const r = (v) => (v == null ? null : Math.round(v * 10) / 10);
const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
const med = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };
const isEnv = (s) => /POINT_COVERED|another window|遮挡/.test(String(s ?? ''));

const classes = raw.results.map((t) => {
  const mk = (ch) => {
    const rows = t[ch] ?? [];
    return {
      n: rows.length, ok: rows.filter((x) => x.ok).length, rate: rows.length ? rows.filter((x) => x.ok).length / rows.length : null,
      ms: rows.map((x) => x.ms), msMean: r(mean(rows.map((x) => x.ms))), msMed: med(rows.map((x) => x.ms)), msMin: Math.min(...rows.map((x) => x.ms)), msMax: Math.max(...rows.map((x) => x.ms)),
      falseOk: rows.filter((x) => x.okSelf === true && x.ok === false).length,
      envBlocked: rows.filter((x) => isEnv(x.note) || isEnv(x.verified)).length,
      samples: rows.map((x) => ({ ok: x.ok, ms: x.ms, okSelf: x.okSelf, verified: (x.verified ?? '').slice(0, 60), note: (x.note ?? '').slice(0, 60) })),
    };
  };
  return { id: t.id, name: t.name, naive: mk('naive'), winctl: mk('winctl') };
});

// tree-expand 没有 results 条目（被 bench.mjs 主动跳过）
const ids = classes.map((c) => c.id);
const tasks9 = [
  'calc-sum', 'notepad-type', 'window-activate', 'dialog-control', 'clipboard-roundtrip',
  'win-move', 'notepad-scroll', 'tree-expand', 'drag-move',
];
const skipped = tasks9.filter((t) => !ids.includes(t));
const skippedReason = { 'tree-expand': '目标应用没在运行（bench.mjs 主动跳过：Explorer 左树需要 CabinetWClass）' };

// 有效分母：剔除「环境遮挡导致自判无效」的类
const classesEffective = classes.filter((c) => c.naive.envBlocked === 0 && !skipped.includes(c.id));
const allRows = classes.flatMap((c) => [...c.naive.samples.map((s) => ({ ...s, ch: 'naive', cls: c.id })), ...c.winctl.samples.map((s) => ({ ...s, ch: 'winctl', cls: c.id }))]);
const effRows = allRows.filter((s) => !skipped.includes(s.cls) && !isEnv(s.note) && !isEnv(s.verified));

const summary = {
  source: path, repeat: raw.repeat,
  classes: classes.length, tasksDeclared: tasks9.length, skipped,
  overall: {
    naive: { n: allRows.filter((s) => s.ch === 'naive').length, ok: allRows.filter((s) => s.ch === 'naive' && s.ok).length, rate: raw.summary.naive.rate, avgMs: raw.summary.naive.avgMs },
    winctl: { n: allRows.filter((s) => s.ch === 'winctl').length, ok: allRows.filter((s) => s.ch === 'winctl' && s.ok).length, rate: raw.summary.winctl.rate, avgMs: raw.summary.winctl.avgMs },
  },
  effective: {
    note: '剔除被跳过/环境遮挡的采样后的分母（这才是元素定位点击成功率的真值分母）',
    n: effRows.length, ok: effRows.filter((s) => s.ok).length,
    rate: effRows.length ? r(effRows.filter((s) => s.ok).length / effRows.length * 100) / 100 : null,
    naive: (() => { const v = effRows.filter((s) => s.ch === 'naive'); return { n: v.length, ok: v.filter((s) => s.ok).length, rate: v.length ? Math.round(v.filter((s) => s.ok).length / v.length * 1000) / 1000 : null, msMean: r(mean(v.map((s) => s.ms))), msMed: med(v.map((s) => s.ms)) }; })(),
    winctl: (() => { const v = effRows.filter((s) => s.ch === 'winctl'); return { n: v.length, ok: v.filter((s) => s.ok).length, rate: v.length ? Math.round(v.filter((s) => s.ok).length / v.length * 1000) / 1000 : null, msMean: r(mean(v.map((s) => s.ms))), msMed: med(v.map((s) => s.ms)) }; })(),
  },
  falseOkTotal: allRows.filter((s) => s.okSelf === true && s.ok === false).length,
  envBlockedTotal: allRows.filter((s) => isEnv(s.note) || isEnv(s.verified)).length,
  invalidClasses: skipped.map((s) => ({ id: s, why: skippedReason[s] ?? '未跑' })).concat(
    classes.filter((c) => c.naive.envBlocked > 0 || c.winctl.envBlocked > 0).map((c) => ({ id: c.id, why: `环境遮挡（POINT_COVERED，第三方窗口「Windows 安全中心」压住测点）naive ${c.naive.envBlocked}/3、winctl ${c.winctl.envBlocked}/3` }))),
};
fs.writeFileSync(OUT, JSON.stringify({ summary, classes, generatedAt: new Date().toISOString() }, null, 2), 'utf8');

console.log('=== L1 复跑真值（' + path + '）===');
console.log('| # | 任务 | naive 成功率 | naive 均值 | winctl 成功率 | winctl 均值 | 假达标(naive/winctl) | 自判无效 |');
console.log('|---|---|---|---|---|---|---|---|');
classes.forEach((c, i) => console.log(`| ${i + 1} | ${c.name} | ${Math.round(c.naive.rate * 100)}% | ${c.naive.msMean}ms | ${Math.round(c.winctl.rate * 100)}% | ${c.winctl.msMean}ms | ${c.naive.falseOk}/${c.winctl.falseOk} | ${c.naive.envBlocked}/${c.winctl.envBlocked} |`));
for (const s of skipped) console.log(`| - | ${s} | 跳过（${skippedReason[s]}）| - | - | - | - | 3/3 无效 |`);
console.log(`\n声明任务数=${tasks9.length}  实际跑=${classes.length}  跳过=${skipped.join(',')}`);
console.log(`总体 naive=${(raw.summary.naive.rate * 100).toFixed(1)}% / winctl=${(raw.summary.winctl.rate * 100).toFixed(1)}%`);
console.log(`有效分母（剔除跳过+遮挡）: n=${summary.effective.n} 成功=${summary.effective.ok} 成功率=${(summary.effective.rate * 100).toFixed(1)}%`);
console.log(`  naive  ${(summary.effective.naive.rate * 100).toFixed(1)}%  中位耗时 ${summary.effective.naive.msMed}ms 均值 ${summary.effective.naive.msMean}ms`);
console.log(`  winctl ${(summary.effective.winctl.rate * 100).toFixed(1)}%  中位耗时 ${summary.effective.winctl.msMed}ms 均值 ${summary.effective.winctl.msMean}ms`);
console.log(`假达标总数=${summary.falseOkTotal}  环境遮挡采样数=${summary.envBlockedTotal}`);
console.log('JSON -> ' + OUT);
