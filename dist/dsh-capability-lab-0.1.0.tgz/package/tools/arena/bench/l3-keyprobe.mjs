/** 探针：keypress 前台 vs 后台（WM_CHAR）到达到延迟 —— 只为选型，不产出报告 */
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { connect, killStaleArena, waitArenaWindow, closeArenaWindows, PS, runPs } from './client.mjs';

const OUT = 'D:\\dsh-arena\\bench\\l3-keyprobe.jsonl';
const ARENA = 'D:\\dsh-arena\\arena-beat.ps1';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function killStaleBeat() {
  const s = [`$rx='arena'+'-beat\\.ps1'`, `$k=@()`, `Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match $rx -and $_.ProcessId -ne $PID } | ForEach-Object { $k+=$_.ProcessId; try{Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop}catch{} }`, `if($k.Count){'killed='+($k -join ',')}else{'killed=none'}`].join('; ');
  return ((await runPs(s, { timeoutMs: 15000 })).out ?? '').trim();
}

const c0 = await connect();
const res = { rows: [], calendar: {} };
try {
  await killStaleArena(); await killStaleBeat();
  await closeArenaWindows(c0); await sleep(400);
  spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ARENA, '-OutJsonl', OUT, '-ExitAfterMs', '45000'], { stdio: 'ignore' });
  const { win } = await waitArenaWindow(c0);
  if (!win) throw new Error('no window');
  const hwnd = win.nativeWindowHandle;
  const W = win.boundingBox;
  await c0.tool('activate_window', { nativeWindowHandle: hwnd });
  await sleep(600);
  for (let i = 0; i < 40; i++) { if (fs.existsSync(OUT)) { try { const h = JSON.parse(fs.readFileSync(OUT, 'utf8').split('\n').filter(Boolean)[0]); if (h.kind === 'header') { res.calendar.header = h; break; } } catch { } } await sleep(150); }
  const cases = [
    ['fg', 'w'], ['bg', 'a'], ['bg', 's'], ['fg', 'd'], ['bg', 'w'], ['fg', 'a'], ['bg', 'd'], ['fg', 's'],
  ];
  for (const [mode, key] of cases) {
    const args = { keys: [key], nativeWindowHandle: hwnd, dispatch: mode === 'bg' ? 'background' : 'foreground' };
    const t0 = Date.now();
    const r = await c0.tool('keypress', args);
    const t1 = Date.now();
    res.rows.push({ mode, key, callMs: t1 - t0, wall0: t0, wall1: t1, ok: !r.isError, text: (r.text ?? '').slice(0, 200) });
    await sleep(700);
  }
  await sleep(500);
} catch (e) { res.error = String(e?.message ?? e); } finally {
  try { await closeArenaWindows(c0); } catch { }
  await sleep(600);
  res.stale = { arena: await killStaleArena(), beat: await killStaleBeat() };
  try { await c0.close(); } catch { }
}

const lines = fs.existsSync(OUT) ? fs.readFileSync(OUT, 'utf8').split('\n').filter(Boolean).map((s) => JSON.parse(s)) : [];
const h = res.calendar.header ?? lines.find((l) => l.kind === 'header');
const events = lines.filter((l) => l.kind !== 'header' && l.kind !== 'marker');
res.events = events.map((e) => ({ kind: e.kind, key: e.key ?? null, swMs: e.swMs }));
let ei = 0;
for (const row of res.rows) {
  const ev = events[ei];
  if (ev) { row.arrival = { kind: ev.kind, key: ev.key ?? null, swMs: ev.swMs, latenessMs: Math.round((h.swZeroUnixMs + ev.swMs - row.wall0) * 10) / 10 }; ei++; }
}
res.header = h;
res.rawLines = lines.length;
fs.writeFileSync('D:\\dsh-arena\\bench\\l3-keyprobe.json', JSON.stringify(res, null, 2), 'utf8');
console.log(JSON.stringify(res.rows.map((r) => ({ mode: r.mode, key: r.key, callMs: r.callMs, ok: r.ok, arr: r.arrival?.kind, latenessMs: r.arrival?.latenessMs, text: r.text?.slice(0, 60) })), null, 2));
console.log('events=' + JSON.stringify(res.events));
