/** 探针2：按键路径选型（keypress fg/bg/无窗口目标 vs type_text background），带前台窗口归属检查 */
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { connect, killStaleArena, waitArenaWindow, closeArenaWindows, PS, runPs } from './client.mjs';

const OUT = 'D:\\dsh-arena\\bench\\l3-keyprobe2.jsonl';
const ARENA = 'D:\\dsh-arena\\arena-beat.ps1';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function killStaleBeat() {
  const s = [`$rx='arena'+'-beat\\.ps1'`, `$k=@()`, `Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match $rx -and $_.ProcessId -ne $PID } | ForEach-Object { $k+=$_.ProcessId; try{Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop}catch{} }`, `if($k.Count){'killed='+($k -join ',')}else{'killed=none'}`].join('; ');
  return ((await runPs(s, { timeoutMs: 15000 })).out ?? '').trim();
}
async function fgTitle() {
  const s = `Add-Type -Namespace W -Name N -MemberDefinition '[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, System.Text.StringBuilder t, int c);' -ErrorAction SilentlyContinue; $h=[W.N]::GetForegroundWindow(); $sb=New-Object System.Text.StringBuilder 300; [void][W.N]::GetWindowText($h,$sb,300); $sb.ToString()`;
  const r = await runPs(s, { timeoutMs: 20000 });
  return (r.out ?? '').trim();
}

const c0 = await connect();
const res = { cases: [], calendar: {} };
let hwnd = null;
try {
  await killStaleArena(); await killStaleBeat();
  await closeArenaWindows(c0); await sleep(400);
  res.spawned = new Date().toISOString();
  spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ARENA, '-OutJsonl', OUT, '-ExitAfterMs', '90000'], { stdio: 'ignore' });
  const { win } = await waitArenaWindow(c0, { tries: 90, intervalMs: 400 });
  if (!win) throw new Error('no window');
  hwnd = win.nativeWindowHandle;
  const W = win.boundingBox;
  res.window = { hwnd, bbox: W };
  await c0.tool('activate_window', { nativeWindowHandle: hwnd });
  await sleep(300);
  for (let i = 0; i < 50; i++) {
    if (fs.existsSync(OUT)) { try { const h = JSON.parse(fs.readFileSync(OUT, 'utf8').split('\n').filter(Boolean)[0]); if (h.kind === 'header') { res.calendar.header = h; break; } } catch { } }
    await sleep(150);
  }
  await c0.tool('move', { x: Math.round(W.x + 300), y: Math.round(W.y + 300), nativeWindowHandle: hwnd });
  const variants = [
    ['keypress-fg', 'keypress', { keys: ['w'], nativeWindowHandle: hwnd, dispatch: 'foreground' }],
    ['keypress-bg', 'keypress', { keys: ['a'], nativeWindowHandle: hwnd, dispatch: 'background' }],
    ['keypress-bg-nowin', 'keypress', { keys: ['s'], dispatch: 'background' }],
    ['typetext-bg', 'type_text', { text: 'd', method: 'background', nativeWindowHandle: hwnd }],
    ['typetext-sendinput', 'type_text', { text: 'f', method: 'sendinput', nativeWindowHandle: hwnd }],
    ['keypress-fg-2', 'keypress', { keys: ['g'], nativeWindowHandle: hwnd, dispatch: 'foreground' }],
    ['keypress-bg-2', 'keypress', { keys: ['h'], nativeWindowHandle: hwnd, dispatch: 'background' }],
  ];
  for (const [label, tool, args] of variants) {
    const fg = await fgTitle();
    await c0.tool('activate_window', { nativeWindowHandle: hwnd });
    const fg2 = await fgTitle();
    await sleep(300);
    const t0 = Date.now();
    const r = await c0.tool(tool, args);
    const t1 = Date.now();
    res.cases.push({ label, tool, fgBefore: fg, fgAfterActivate: fg2, callMs: t1 - t0, wall0: t0, wall1: t1, ok: !r.isError, text: (r.text ?? '').replace(/\s+/g, ' ').slice(0, 220) });
    await sleep(700);
  }
  await sleep(500);
} catch (e) { res.error = String(e?.message ?? e); } finally {
  try { await closeArenaWindows(c0); } catch { }
  await sleep(600);
  res.stale = { arena: await killStaleArena(), beat: await killStaleBeat() };
  try { await c0.close(); } catch { }
}

const lines = fs.existsSync(OUT) ? fs.readFileSync(OUT, 'utf8').split('\n').filter(Boolean).map((s) => JSON.parse(s)) : [];
const h = res.calendar.header ?? lines.find((l) => l.kind === 'header');
const events = lines.filter((l) => l.kind !== 'header' && l.kind !== 'marker');
if (h) {
  // 每个 case 的到达事件 = 调用墙钟之后第一个未被占用的、swMs 落在 [callStart-50, callEnd+600] 内的事件
  let used = new Set();
  for (const c of res.cases) {
    const lo = c.wall0 - h.swZeroUnixMs - 60, hi = c.wall1 - h.swZeroUnixMs + 700;
    const idx = events.findIndex((e, i) => !used.has(i) && e.swMs >= lo && e.swMs <= hi);
    if (idx >= 0) { used.add(idx); const e = events[idx]; c.arrival = { kind: e.kind, key: e.key ?? e.text ?? null, swMs: e.swMs, latencyMs: Math.round((h.swZeroUnixMs + e.swMs - c.wall0) * 10) / 10 }; }
  }
  res.unmatched = events.map((e, i) => (used.has(i) ? null : { kind: e.kind, swMs: e.swMs })).filter(Boolean);
}
res.header = h;
fs.writeFileSync('D:\\dsh-arena\\bench\\l3-keyprobe2.json', JSON.stringify(res, null, 2), 'utf8');
for (const c of res.cases) console.log(`${c.label.padEnd(20)} call=${String(c.callMs).padStart(5)}ms arr=${c.arrival?.kind ?? 'NONE'}${c.arrival?.key ? '(' + c.arrival.key + ')' : ''} latency=${c.arrival?.latencyMs ?? '-'}ms  fgActivate=${(c.fgAfterActivate || '').slice(0, 22)}  err=${c.ok ? '' : (c.text || '').slice(0, 90)}`);
console.log('error=' + (res.error ?? '-') + '  stale=' + JSON.stringify(res.stale) + '  unmatched=' + JSON.stringify(res.unmatched ?? []));
