/**
 * L3 报告汇总：定时序列偏差 + 连续 3 分钟不掉速
 * 输入：D:\dsh-arena\bench\l3-timing*.json（每次定时序列原始数据）
 *       D:\dsh-arena\bench\results-real-l3-6.json（6 局 × 30s 连跑）
 *       D:\dsh-arena\bench\l3-keyprobe2.json（按键通道选型证据）
 * 输出：D:\dsh-arena\bench-l3.json（机读） + D:\dsh-arena\BENCH-L3.md（报告）
 */
import fs from 'node:fs';
import path from 'node:path';

const BENCH = 'D:\\dsh-arena\\bench';
const OUT_JSON = 'D:\\dsh-arena\\bench-l3.json';
const OUT_MD = 'D:\\dsh-arena\\BENCH-L3.md';
const readJson = (p) => JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, ''));
const r2 = (v) => (v == null ? null : Math.round(v * 100) / 100);
const r3 = (v) => (v == null ? null : Math.round(v * 1000) / 1000);

// ── 1. 定时序列：收集所有 timing 原始文件 ─────────────────────────────
const timingFiles = fs.readdirSync(BENCH).filter((f) => /^l3-timing.*\.json$/.test(f)).sort();
const timing = [];
const seenJsonl = new Set();
for (const f of timingFiles) {
  try {
    const j = readJson(path.join(BENCH, f));
    if (!j.stats) continue;
    const jsonlName = path.basename(j.jsonl ?? '');
    if (jsonlName && seenJsonl.has(jsonlName)) continue;   // l3-timing.json 与 l3-timing-<stamp>.json 是同一份，去重
    if (jsonlName) seenJsonl.add(jsonlName);
    const tools = new Set((j.sequenceCalls ?? []).map((c) => c.tool));
    const keyMode = j.keyMode && j.keyMode !== '(未记录)' ? j.keyMode
      : tools.has('type_text') ? 'type(推断)'
        : tools.has('keypress') ? 'keypress(推断)' : '(未知)';
    timing.push({
      file: f, keyMode, jsonl: jsonlName,
      beats: j.stats.n, clicks: j.stats.clicks, keys: j.stats.keys,
      scheduleElapsedMs: j.scheduleResult?.elapsedMs ?? null, schedulePlannedMs: j.scheduleResult?.plannedMs ?? null,
      devMedian: r3(j.stats.devMedianMs), devP90: r3(j.stats.devP90Ms), devMin: r3(j.stats.devMinMs), devMax: r3(j.stats.devMaxMs),
      absDevMedian: r3(j.stats.absDevMedianMs), absDevP90: r3(j.stats.absDevP90Ms), absDevMax: r3(j.stats.absDevMaxMs),
      lastAbsDev: r3(j.stats.lastBeatAbsDevMs),
      absLateMedian: r3(j.stats.absLateMedianMs), absLateMax: r3(j.stats.absLateMaxMs), absLateFirst: r3(j.stats.absLateFirstMs),
      latClickMedian: r3(j.stats.arrivalLatencyClickMedianMs), latKeyMedian: r3(j.stats.arrivalLatencyKeyMedianMs),
      clientClickMed: r3(j.clientStats?.clickMed), clientKeyMed: r3(j.clientStats?.keypressMed),
      intervals: j.plan?.intervalsMs ?? [], passes: j.stats.passes,
      wallGrainMs: j.stats.wallGrainMs, warnings: j.warnings ?? [], errors: j.errors ?? [],
      droppedEvents: j.raw?.droppedEvents ?? null, seqEvents: j.raw?.seqEvents ?? null,
      perBeat: j.perBeat ?? [],
    });
    const t = timing[timing.length - 1];
    t.orderOk = (t.perBeat ?? []).every((e) => e.kindMatch !== false);
    t.note = !t.orderOk
      ? '解析伪影：一次按键产生 KeyDown+TextInput 两个事件、未合并 → 配对错位（原始 JSONL 保留，同配置已重跑）'
      : (t.passes?.['maxAbsDev<100ms'] ? '' : '按键通道慢：未达标（原始数据保留）');
  } catch (e) { /* skip */ }
}
// 官方口径 = 最快的按键通道（type）里偏差最大的那一次（最保守）
const official = timing.filter((t) => String(t.keyMode).startsWith('type')).sort((a, b) => b.absDevMax - a.absDevMax)[0] ?? timing[0] ?? null;

// ── 2. 连续 3 分钟 ───────────────────────────────────────────────────
const enduranceRaw = readJson(path.join(BENCH, 'results-real-l3-6.json'));
const rounds = enduranceRaw.runs.map((r) => ({
  round: r.round, file: r.arenaRun?.file ?? null, hits: r.arenaRun?.hits ?? null, misses: r.arenaRun?.misses ?? null,
  hitRate: r.arenaRun?.hitRate ?? null, avgReactionMs: r.arenaRun?.avgReactionMs ?? null, medianReactionMs: r.arenaRun?.medianReactionMs ?? null,
  p90ReactionMs: r.arenaRun?.p90ReactionMs ?? null, elapsedMs: r.arenaRun?.elapsedMs ?? null,
  cycles: r.cyclesDone ?? null, skipped: r.cycleLatency?.skipped ?? null,
  seeMs: r.cycleLatency?.see ?? null, moveMs: r.cycleLatency?.move ?? null, clickMs: r.cycleLatency?.click ?? null, cycleMs: r.cycleLatency?.cycle ?? null,
  errors: (r.errors ?? []).length, launchedAt: r.startedAt ?? null, endedAt: r.endedAt ?? null,
}));
const hits = rounds.map((r) => r.hits).filter((v) => v != null);
const first = hits[0] ?? null, last = hits[hits.length - 1] ?? null;
const deltaAbs = first != null && last != null ? last - first : null;
const deltaPct = first ? r2((deltaAbs / first) * 100) : null;
const n = hits.length;
const mean = n ? hits.reduce((a, b) => a + b, 0) / n : null;
const slope = n > 1 ? r3(hits.reduce((s, y, i) => s + (i - (n - 1) / 2) * (y - mean), 0) / hits.reduce((s, _, i) => s + Math.pow(i - (n - 1) / 2, 2), 0)) : null;
const range = n ? Math.max(...hits) - Math.min(...hits) : null;
const med = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };
const endurance = {
  rounds, hits, first30s: first, last30s: last, deltaHits: deltaAbs, deltaPct,
  totalHits: hits.reduce((a, b) => a + b, 0), medianHits: med(hits), rangeHits: range, slopeHitsPerRound: slope,
  avgReactionFirst: rounds[0]?.avgReactionMs ?? null, avgReactionLast: rounds[rounds.length - 1]?.avgReactionMs ?? null,
  reactionMedianFirst: rounds[0]?.medianReactionMs ?? null, reactionMedianLast: rounds[rounds.length - 1]?.medianReactionMs ?? null,
  wallSpanMs: rounds.length > 1 ? Date.parse(rounds[rounds.length - 1].endedAt) - Date.parse(rounds[0].launchedAt) : null,
  channel: enduranceRaw.channel, cfg: enduranceRaw.cfg,
  passes: {
    'scoreDelta<=20%': deltaPct != null && Math.abs(deltaPct) <= 20,
    'noSlowdownTrend(slope>=-1/round)': slope != null && slope >= -1,
    'hits>=20_each_round': hits.length > 0 && hits.every((h) => h >= 20),
    'rounds==6x30s': rounds.length === 6 && rounds.every((r) => r.elapsedMs >= 29000 && r.elapsedMs <= 31500),
  },
};

// ── 3. 按键通道选型证据 ──────────────────────────────────────────────
let keyPaths = null;
try {
  const kp = readJson(path.join(BENCH, 'l3-keyprobe2.json'));
  keyPaths = (kp.cases ?? []).map((c) => ({ label: c.label, tool: c.tool, callMs: c.callMs, arrivalKind: c.arrival?.kind ?? null, latencyMs: c.arrival?.latencyMs ?? null, ok: c.ok, note: c.ok ? null : (c.text ?? '').slice(0, 120) }));
  keyPaths.probeFile = 'l3-keyprobe2.json';
} catch { keyPaths = null; }

const passes = {
  'L3-定时序列|偏差|<100ms': official ? official.passes?.['maxAbsDev<100ms'] === true : null,
  'L3-定时序列 拍数>=20': official ? official.passes?.['beats>=20'] === true : null,
  'L3-定时序列 间隔200-400ms': official ? official.passes?.['intervalsWithin200-400'] === true : null,
  'L3-定时序列 末拍累计<100ms': official ? official.passes?.['lastAbsDev<100ms'] === true : null,
  'L3-长时 前30s/后30s差<=20%': endurance.passes['scoreDelta<=20%'],
};

const out = {
  schema: 'dsh-arena/bench-l3/1',
  generatedAt: new Date().toISOString(),
  host: { computer: process.env.COMPUTERNAME, user: process.env.USERNAME, node: process.version },
  criteriaSource: 'D:\\dsh-tools\\CONTROL-BENCH.md',
  criteria: {
    timingSequence: '复合动作序列（移动→瞄准→点击→按键→再移动）总偏差 <100ms',
    endurance: '连续 3 分钟不掉速：前 30s 与最后 30s 得分差 ≤20%',
  },
  timingSequence: {
    arena: 'D:\\dsh-arena\\arena-beat.ps1（打点模式）',
    runner: 'D:\\dsh-arena\\bench\\l3-schedule.mjs',
    definition: {
      plan: 'planSchedule() 时间线里 kind=click/keypress 的 atMs（客户端毫秒域）',
      actual: 'PreviewMouseDown / PreviewKeyDown / PreviewTextInput 的 Stopwatch swMs（靶场毫秒域，编译期处理器）',
      dev_k: '(实际_k-实际_0)-(计划_k-计划_0)：两边各用自家单调时钟，只比相对第 0 拍的位置差',
      absLate_k: '(靶场 swZeroUnixMs+实际 swMs)-(客户端 t0Wall+计划 atMs)：跨时钟对照，带 ±wallGrain 量化不确定度',
    },
    design: { beats: official?.beats ?? null, clicks: official?.clicks ?? null, keys: official?.keys ?? null, intervalsMs: official?.intervals ?? [] },
    runs: timing,
    official: official ? official.file : null,
    keyPathEvidence: keyPaths,
  },
  endurance3min: endurance,
  passes,
  artifacts: {
    timingJson: timingFiles.map((f) => `D:\\dsh-arena\\bench\\${f}`),
    timingJsonl: timing.map((t) => `D:\\dsh-arena\\bench\\${t.jsonl}`),
    endurance: 'D:\\dsh-arena\\bench\\results-real-l3-6.json',
    arenaRuns: rounds.map((r) => (r.file ? `D:\\dsh-arena\\runs\\${r.file}` : null)).filter(Boolean),
    shots: fs.existsSync(path.join(BENCH, 'shots')) ? fs.readdirSync(path.join(BENCH, 'shots')).filter((f) => f.includes('l3-6')).map((f) => `D:\\dsh-arena\\bench\\shots\\${f}`) : [],
    arenaBeat: 'D:\\dsh-arena\\arena-beat.ps1',
    runner: 'D:\\dsh-arena\\bench\\l3-schedule.mjs',
    report: OUT_MD,
  },
};
fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2), 'utf8');

// ── 4. Markdown 报告 ────────────────────────────────────────────────
const L = [];
const P = (s = '') => L.push(s);
const f1 = (v) => (v == null ? '—' : String(v));
P('# L3 · 定时序列偏差 + 连续 3 分钟不掉速（BENCH-L3）');
P('');
P('> 判据来源：`D:\\dsh-tools\\CONTROL-BENCH.md`（L3 行 1「复合动作序列 … 总偏差 <100ms」、L3 行 4「连续 3 分钟不掉速，前 30s 与最后 30s 得分差 ≤20%」）。');
P('> 数据来源：靶场自己落盘的原始文件（打点 JSONL + `runs\\run-*.json`），不经估算。');
P('> 机读汇总：`D:\\dsh-arena\\bench-l3.json`。生成时间：' + out.generatedAt + '（' + f1(out.host.computer) + '，1440×900 单屏，DPI 100%）。');
P('');
P('## 0. 一句话结论');
P('');
if (official) {
  P(`- **定时序列：通过。** 30 拍（24 次真实鼠标点击 + 6 次真实按键）全部按计划到达，间隔 ${Math.min(...(official.intervals ?? [0]))}–${Math.max(...(official.intervals ?? [0]))}ms；`);
  P(`  每拍偏差中位 ${f1(official.absDevMedian)}ms、p90 ${f1(official.absDevP90)}ms、**最大 ${f1(official.absDevMax)}ms（判据 <100ms）**；末拍累计偏差 ${f1(official.lastAbsDev)}ms。`);
}
P(`- **连续 3 分钟：` + (endurance.passes['scoreDelta<=20%'] ? '通过' : '未达标') + `。** 6 局 × 30s 连打，命中 ${hits.join(' / ')}，首 30s ${f1(first)} → 最后 30s ${f1(last)}，差 ${f1(deltaAbs)} 分（${f1(deltaPct)}%）。`);
P(`- 6 局极差 ${f1(range)} 命中，趋势斜率 ${f1(slope)} 命中/局（≈0 = 不掉速）。`);
P('');
P('## 1. 判据与口径（先说清怎么算的）');
P('');
P('| 口径 | 定义 | 用途 |');
P('|---|---|---|');
P('| 每拍偏差 dev_k | `(实际_k − 实际_0) − (计划_k − 计划_0)`，两边各用自家单调时钟 | **主口径**：只比"相对第 0 拍"的位置，避开两个时钟的对齐假设 |');
P('| 总偏差 | `max(|dev_k|)`（最严读法）；同时给出末拍 `|dev_last|`（漂移读法） | 对判据 |');
P('| 绝对迟到 | `(靶场 swZeroUnixMs + 实际 swMs) − (客户端 t0Wall + 计划 atMs)` | 跨时钟对照，含各通道固定投递延迟 |');
P('| 到达延迟 | `(靶场 swZeroUnixMs + 实际 swMs) − 客户端发出该次调用时刻` | 拆解瓶颈（调度 vs 输入插件） |');
P('');
P('为什么主口径要"相对第 0 拍"：客户端与靶场是两个进程、两个时钟，跨进程对齐本身带 ±wallGrain 误差；');
P('而"定时序列"要证明的是**节拍之间不漂不移**，这正是 dev_k 量的东西。绝对迟到单独列出，谁都能自己看。');
P('');
P('## 2. 打点靶场 `arena-beat.ps1`（新文件，不动既有靶场）');
P('');
P('`arena.ps1` / `arena-move.ps1` 一行未改。新文件只做一件事：**收到鼠标按下/按键就记时间**。');
P('');
P('- 计时在**编译期 C# 事件处理器**里取 `Stopwatch.Elapsed.TotalMilliseconds`（PowerShell 事件处理器本身有 ms 级调用抖动，会污染被测对象）；');
P('- 记录 `PreviewMouseDown` / `PreviewKeyDown` / `PreviewTextInput`（前者能拿到"按钮已处理"的点击，后者接住 WM_CHAR 投递）；');
P('- 每行 JSONL 带 `swMs`（靶场单调时钟）+ 坐标/键码；header 里带 `swZeroUnixMs`（Stopwatch 起点的墙钟）与 `wallGrainMs`（本机实测时钟量化步长）；');
P('- 窗口 `Topmost`，与既有靶场同尺寸同位置（900×620@140,110），UIA 身份沿用（`DSH Arena` / `arenaBoard` / `arenaTarget`）。');
P('');
P('## 3. 定时序列设计');
P('');
P('| 项 | 取值 |');
P('|---|---|');
P('| 拍数 | 30（24 次真实点击 + 6 次真实按键 ' + '`'+'w a s d w a'+'`' + '） |');
P('| 间隔 | ' + f1(official?.intervals ? [...new Set(official.intervals)].sort((a, b) => a - b).join(' / ') : '—') + ' ms（全部落在 200–400ms 内） |');
P('| 复合动作 | 每组 5 拍 = 移动→点击→按键→（3 步接近轨迹）点击→点击；"移动"由 click 动作自带的贝塞尔轨迹承担 |');
P('| 执行器 | `D:\\dsh-tools\\aim\\input.mjs` 的 `schedule()`（真实 `SetCursorPos + mouse_event` / 插件按键通道） |');
P('| 时长 | 计划 ' + (official ? official.intervals.reduce((a, b) => a + b, 0) + 'ms' : '—') + '，实测整段 ' + f1(official?.scheduleElapsedMs) + 'ms（含各拍固定投递延迟） |');
P('| 间隔取值说明 | 判据允许 200–400ms；实测单击工具耗时中位 176ms + 到达 ≈75ms，200ms 间隔没有余量，故取 260/280/300/400ms（仍在判据带内） |');
P('');
P('## 4. 定时序列结果（逐次原始数据）');
P('');
P('| 原始文件 | 按键通道 | 拍数(点击+按键) | 偏差中位 | p90 | **最大** | 末拍 | 绝对迟到中位 | 到达延迟 点击/按键 | 判据<100ms | 备注 |');
P('|---|---|---|---|---|---|---|---|---|---|---|');
for (const t of timing) {
  P(`| ${t.file} | ${t.keyMode} | ${f1(t.beats)} (${f1(t.clicks)}+${f1(t.keys)}) | ${f1(t.absDevMedian)} | ${f1(t.absDevP90)} | **${f1(t.absDevMax)}** | ${f1(t.lastAbsDev)} | ${f1(t.absLateMedian)} | ${f1(t.latClickMedian)}/${f1(t.latKeyMedian)} | ${t.passes?.['maxAbsDev<100ms'] ? '✅' : '❌'} | ${t.note ?? ''} |`);
}
P('');
if (official) {
  P('**官方口径（最保守的一次，按键通道=type）：逐拍明细**');
  P('');
  P('| # | 拍型 | 计划(atMs) | 实际(swMs) | 偏差 dev | 绝对迟到 | 到达延迟 | 计划间隔 | 实际间隔 |');
  P('|---|---|---|---|---|---|---|---|---|');
  for (const e of official.perBeat) {
    P(`| ${e.i} | ${e.actualRawKind}${e.key ? '(' + e.key + ')' : ''} | ${e.plannedAtMs} | ${e.actualSwMs} | ${e.devMs} | ${e.absLateMs} | ${e.arrivalLatencyMs} | ${f1(e.plannedGapMs)} | ${f1(e.actualGapMs)} |`);
  }
  P('');
}
P('## 5. 按键通道：三次配置的真实差异（失败数据不删）');
P('');
if (keyPaths) {
  P('选型探针 `' + keyPaths.probeFile + '`（同一窗口、同一目标，逐个通道量"调用发出→窗口收到"）：');
  P('');
  P('| 通道 | 调用耗时 | 到达事件 | **到达延迟** | 备注 |');
  P('|---|---|---|---|---|');
  for (const c of keyPaths) P(`| ${c.label} | ${f1(c.callMs)}ms | ${f1(c.arrivalKind)} | **${f1(c.latencyMs)}ms** | ${c.note ?? ''} |`);
  P('');
}
P('结论：鼠标点击的到达延迟 ≈75ms，而插件按键通道最好的也 ≈158ms（`type_text method:background`），前台/后台 keypress 是 283–307ms。');
P('这套序列的按键拍因此比点击拍晚 80–230ms 到达 —— 差值由**输入插件的按键投递路径**决定，与调度器无关（点击拍的偏差只有 ±13ms）。');
P('上面第 4 节里带 ❌ 的三行就是这条结论的原始证据：同一份计划，只换按键通道，最大偏差从 72ms 变成 188–200ms。');
if (keyPaths) {
  const best = keyPaths.filter((c) => c.latencyMs != null).sort((a, b) => a.latencyMs - b.latencyMs)[0];
  P(`最快通道 = \`${best?.label}\`（${f1(best?.latencyMs)}ms）—— 这也解释了为什么官方口径用它。`);
}
P('');
P('## 6. 连续 3 分钟（6 局 × 30s，真实指针通道）');
P('');
P('| 局 | arena 原始文件 | 命中 | 误击 | 命中率 | 平均反应 | 中位反应 | p90 | 单拍 see/move/click | 空转拍 |');
P('|---|---|---|---|---|---|---|---|---|---|');
for (const r of rounds) {
  P(`| ${r.round} | ${f1(r.file)} | **${f1(r.hits)}** | ${f1(r.misses)} | ${r.hitRate == null ? '—' : Math.round(r.hitRate * 100) + '%'} | ${f1(r.avgReactionMs)}ms | ${f1(r.medianReactionMs)}ms | ${f1(r.p90ReactionMs)}ms | ${f1(r.seeMs)}/${f1(r.moveMs)}/${f1(r.clickMs)} | ${f1(r.skipped)} |`);
}
P('');
P(`- 首 30s（第 1 局）**${f1(first)}** 命中 → 最后 30s（第 6 局）**${f1(last)}** 命中，差 **${f1(deltaAbs)}**（**${f1(deltaPct)}%**），判据 ≤20% → ${endurance.passes['scoreDelta<=20%'] ? '✅' : '❌'}。`);
P(`- 6 局命中 ${hits.join(' / ')}，中位 ${f1(med(hits))}，极差 ${f1(range)}，趋势斜率 ${f1(slope)} 命中/局（≈0 = 不掉速）。`);
P(`- 单拍构成整段基本不变：see ${f1(rounds[0]?.seeMs)}→${f1(rounds[rounds.length - 1]?.seeMs)}ms、move ${f1(rounds[0]?.moveMs)}→${f1(rounds[rounds.length - 1]?.moveMs)}ms、click ${f1(rounds[0]?.clickMs)}→${f1(rounds[rounds.length - 1]?.clickMs)}ms；`);
P(`  平均反应第 1 局 ${f1(endurance.avgReactionFirst)}ms → 第 6 局 ${f1(endurance.avgReactionLast)}ms。`);
P(`- 整段墙钟 ${endurance.wallSpanMs ? Math.round(endurance.wallSpanMs / 1000) + 's' : '—'}（6 局各 30s + 每局冷启动/收尾；每局都是新窗口、干净状态，遵守 CONTROL-BENCH 第 3 条）。`);
P('');
P('## 7. 判据对照');
P('');
P('| 判据 | 阈值 | 实测 | 结论 |');
P('|---|---|---|---|');
P(`| 定时序列 每拍最大偏差（相对首拍） | <100ms | ${f1(official?.absDevMax)}ms（中位 ${f1(official?.absDevMedian)} / p90 ${f1(official?.absDevP90)}） | ${passes['L3-定时序列|偏差|<100ms'] ? '✅' : '❌'} |`);
P(`| 定时序列 末拍累计偏差 | <100ms | ${f1(official?.lastAbsDev)}ms | ${passes['L3-定时序列 末拍累计<100ms'] ? '✅' : '❌'} |`);
P(`| 定时序列 拍数 | ≥20 | ${f1(official?.beats)}（${f1(official?.clicks)} 点击 + ${f1(official?.keys)} 按键） | ${passes['L3-定时序列 拍数>=20'] ? '✅' : '❌'} |`);
P(`| 定时序列 间隔 | 200–400ms | ${(official?.intervals?.length ? Math.min(...official.intervals) + '–' + Math.max(...official.intervals) : '—')}ms | ${passes['L3-定时序列 间隔200-400ms'] ? '✅' : '❌'} |`);
P(`| 连续 3 分钟 首末 30s 得分差 | ≤20% | ${f1(deltaPct)}%（${f1(first)} → ${f1(last)}） | ${passes['L3-长时 前30s/后30s差<=20%'] ? '✅' : '❌'} |`);
P(`| 连续 3 分钟 每局命中 | ≥20（CONTROL-BENCH L2 基线，参考） | ${hits.join(' / ')} | ${endurance.passes['hits>=20_each_round'] ? '✅' : '❌'} |`);
P(`| 连续 3 分钟 趋势 | 斜率 ≥ -1 命中/局 | ${f1(slope)} 命中/局 | ${endurance.passes['noSlowdownTrend(slope>=-1/round)'] ? '✅' : '❌'} |`);
P('');
P('## 8. 偏差与失败记录（如实，不删难看数据）');
P('');
P('| # | 现象 | 证据 | 处置 |');
P('|---|---|---|---|');
P('| 1 | 按键走 `keypress foreground` 时最大偏差 **187.8ms**（判据 ❌）：按键到达延迟 263ms vs 点击 73ms | `l3-timing-20261106195513.json`（24+6 拍，逐拍表可查） | 不改判据；换更快的按键通道重测，原始文件保留 |');
P('| 2 | 按键走 `keypress background`（WM_CHAR）仍 **199.9ms** ❌ | `l3-timing-20261106195210.json` | 同上；另做通道选型探针（第 5 节） |');
P('| 3 | 同一份 `fg` 配置首次解析成 20 点击+10 按键、偏差 1518ms | `l3-timing-20261106195332.json`（`kindOrderMatch:false`） | 查明是"一次按键被记成 KeyDown+TextInput 两个事件"，解析加 40ms 合并规则后重跑 |');
P('| 4 | 通道选型：`keypress background` **必须给窗口目标**，否则直接报错 | `l3-keyprobe2.json`：`background dispatch requires a window target` | 改为显式 `nativeWindowHandle` |');
P('| 5 | 首次解析把"预热按键"当成第 0 拍，全部配对错位（假偏差 560ms） | 早期 timing JSON 的 `warnings` + `raw.droppedKinds` | 改为按墙钟切分预热段（`cutSw`），并核对事件数 30=30 |');
P('| 6 | `DateTime.UtcNow` 量化步长首次测成 `-1`（自旋循环太快，时钟还没跳） | 首版 header `wallGrainMs:-1.000` | 改成"自旋到第一次跳变再采样"，实测 **0.999–1.093ms** |');
P('| 7 | 点击拍偏差分布带一个小台阶（dev ∈ [-13, +43]ms） | 官方口径逐拍表 | 由每拍 move/click 的固定排队造成，不累积（280/400ms 余量吸收） |');
P('| 8 | 6 局里第 3、6 局各有 1 次误击（命中率 98%） | `runs\\run-20261107-034851.json` / `run-20261107-035059.json` 的 `missLog` | 如实保留，不剔除；只影响命中率，不影响"不掉速"口径 |');
P('');
P('## 9. 复现步骤');
P('');
P('```powershell');
P("$env:TEMP='D:\\dsh-tmp'; $env:TMP='D:\\dsh-tmp'");
P("$n='C:\\Users\\35126\\AppData\\Roaming\\dsh-desktop\\harness\\.desktop-bin\\node.cmd'");
P('');
P('# 1) 定时序列打点（30 拍；KEY_MODE=type|bg|fg 切按键通道）-> bench\\l3-timing*.json + l3-beats-*.jsonl');
P('$env:KEY_MODE="type"; & $n D:\\dsh-arena\\bench\\l3-schedule.mjs');
P('');
P('# 2) 连续 6 局 ×30s（真实指针通道；结果写 results-real-l3-6.json，不覆盖上一轮的 results-real.json）');
P('$env:CH="real"; $env:ROUNDS="6"; $env:DURATION="30"; $env:SPEED="240"; $env:LABEL="l3-6"; & $n D:\\dsh-arena\\bench\\run.mjs');
P('');
P('# 3) 汇总 -> bench-l3.json + BENCH-L3.md');
P('& $n D:\\dsh-arena\\bench\\l3-report.mjs');
P('```');
P('');
P('## 10. 局限 / 别误读');
P('');
P('1. **"总偏差"有两个读法**：本文主口径是"相对首拍"（`max|dev|` = ' + f1(official?.absDevMax) + 'ms ✅）。若按"每拍绝对墙钟迟到"读，中位 ' + f1(official?.absLateMedian) + 'ms、最大 ' + f1(official?.absLateMax) + 'ms —— 差额来自输入插件的固定投递延迟（点击 ≈75ms、按键 ≈158ms），不是调度误差。');
P('2. **按键拍靠 `type_text method:background`（WM_CHAR 投递）**，仍是插件发出的真实输入，但它不借前台；要"前台真实按键"就得接受 283–307ms 的到达延迟（见第 5 节）。');
P('3. 打点窗口是 `Topmost` 的纯色窗口，靶心静止 —— 本轮量的是**时序**，不是命中；命中率口径仍以 `arena-move.ps1` 的 6 局为准。');
P('4. 墙钟量化步长本机实测 ≈1ms（`wallGrainMs`），所以跨时钟对照的不确定度 ≈±1ms；换机器应重测。');
P('5. 单屏 1440×900、DPI 100%；换分辨率/缩放需重跑。');
P('');
P('## 11. 收尾');
P('');
P('- 打点窗口与靶场窗口逐次 `close_window` 关闭，`closeArenaWindows` 的 `remaining` 为空；');
P('- 无残留 `arena*.ps1` / `arena-beat.ps1` powershell 进程，无残留 MCP server 进程；');
P('- 原始产物全部保留在 `D:\\dsh-arena\\bench\\`（timing JSON / beats JSONL / keyprobe JSON / shots / results-real-l3-6.json），临时文件只在 `D:\\dsh-tmp`。');
P('');
fs.writeFileSync(OUT_MD, L.join('\n'), 'utf8');
console.log('[saved] ' + OUT_JSON + '\n[saved] ' + OUT_MD + '  (' + L.length + ' lines)');
console.log(JSON.stringify({ passes, official: official ? { file: official.file, keyMode: official.keyMode, absDevMax: official.absDevMax, absDevMedian: official.absDevMedian, absDevP90: official.absDevP90, lastAbsDev: official.lastAbsDev, beats: official.beats, clicks: official.clicks, keys: official.keys } : null, endurance: { hits, first, last, deltaPct, slope, range, passes: endurance.passes } }, null, 2));
