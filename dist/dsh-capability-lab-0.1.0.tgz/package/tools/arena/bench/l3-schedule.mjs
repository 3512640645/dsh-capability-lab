/**
 * L3 · 定时序列偏差测量（真实指针 + 真实按键）
 *
 * 判据来源：D:\dsh-tools\CONTROL-BENCH.md（L3 行 1：复合动作定时序列，总偏差 <100ms）
 * 打点靶场：D:\dsh-arena\arena-beat.ps1（编译期事件处理器，Stopwatch 亚毫秒时间戳）
 *
 * 口径：
 *   计划到达时刻 = planSchedule() 的时间线里 kind=click / kind=keypress 的 atMs（客户端毫秒域）
 *   实际到达时刻 = 打点靶场收到的 PreviewMouseDown / PreviewKeyDown 的 swMs（靶场毫秒域）
 *   每拍偏差 dev_k = (实际_k - 实际_0) - (计划_k - 计划_0)
 *     —— 两边各用自己的单调时钟，只比"相对第 0 拍的位置差"，不依赖跨时钟对齐假设
 *   绝对迟到 = (靶场 header 的 swZeroUnixMs + 实际 swMs) - (客户端 t0Wall + 计划 atMs)
 *     —— 跨时钟对照，带 ±wallGrainMs 量化不确定度
 *
 * 产出：D:\dsh-arena\bench\l3-timing.json（原始数据：计划/实际/逐拍偏差/客户端调用耗时）
 * 不用 dryRun：全部是真实鼠标点击与真实按键。
 */
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { connect, killStaleArena, waitArenaWindow, closeArenaWindows, PS, runPs } from './client.mjs';
import { createEngine, readPointerPosition, planSchedule, timelineStats } from 'file:///D:/dsh-tools/aim/input.mjs';

const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const OUT_JSONL = `D:\\dsh-arena\\bench\\l3-beats-${stamp}.jsonl`;
const OUT_JSON = 'D:\\dsh-arena\\bench\\l3-timing.json';
const ARENA = 'D:\\dsh-arena\\arena-beat.ps1';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const med = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };
const pct = (a, p) => { const s = [...a].sort((x, y) => x - y); if (!s.length) return null; const i = Math.min(s.length - 1, Math.max(0, Math.ceil(s.length * p) - 1)); return s[i]; };
const r3 = (v) => (v == null ? null : Math.round(v * 1000) / 1000);

const out = {
  schema: 'dsh-arena/l3-timing/1',
  generatedAt: new Date().toISOString(),
  arena: ARENA,
  keyMode: process.env.KEY_MODE ?? 'type',
  jsonl: OUT_JSONL,
  warnings: [],
  errors: [],
};

async function killStaleBeat() {
  const script = [
    `$rx = 'arena' + '-beat\\.ps1'`,
    `$k = @()`,
    `Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match $rx -and $_.ProcessId -ne $PID } | ForEach-Object { $k += $_.ProcessId; try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop } catch {} }`,
    `if ($k.Count) { 'killed=' + ($k -join ',') } else { 'killed=none' }`,
  ].join('; ');
  const r = await runPs(script, { timeoutMs: 15000 });
  return ((r.out ?? '').trim() || 'no-output');
}

// ── 计划：30 拍（24 次真实点击 + 6 次真实按键），间隔全部落在 200-400ms 内 ──
// 每组 5 拍：[点击][点击][按键][点击·3 步接近轨迹][点击]，组间间隔 280ms
const IV = [280, 260, 300, 400, 280];
const GROUP = [['c', 1], ['c', 1], ['k', 0], ['c', 3], ['c', 1]];
const KEYS = ['w', 'a', 's', 'd', 'w', 'a'];
const GROUPS = 6;

function buildBeats(rect) {
  const beats = [];
  let at = 0;
  let keyIdx = 0;
  for (let g = 0; g < GROUPS; g++) {
    for (const [kind, steps] of GROUP) {
      if (beats.length) at += IV[(beats.length - 1) % IV.length];
      const i = beats.length;
      const col = i % 6, row = (i * 3) % 5;
      beats.push({
        kind, steps, at,
        key: kind === 'k' ? KEYS[keyIdx++ % KEYS.length] : null,
        x: Math.round(rect.x + col * (rect.width / 5.4)),
        y: Math.round(rect.y + row * (rect.height / 4.6)),
      });
    }
  }
  return beats;
}

function toActions(beats) {
  return beats.map((b) => (b.kind === 'c'
    ? { name: 'click', x: b.x, y: b.y, at: b.at, durationMs: 1, stepMs: 15, minSteps: b.steps, maxSteps: b.steps, settleMs: 0, curvature: 0.12 }
    : { name: 'keypress', keys: [b.key], at: b.at }));
}

async function main() {
  out.staleBefore = { arena: await killStaleArena(), beat: await killStaleBeat() };
  const c0 = await connect();
  let child = null;
  try {
    const pre = await closeArenaWindows(c0);
    out.preClosed = pre;
    await sleep(400);

    child = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ARENA,
      '-OutJsonl', OUT_JSONL, '-ExitAfterMs', '120000'], { stdio: 'ignore' });
    out.launch = { pid: child.pid, cmd: `${ARENA} -OutJsonl ${OUT_JSONL} -ExitAfterMs 120000` };

    const { win, list } = await waitArenaWindow(c0, { tries: 90, intervalMs: 400 });
    if (!win) throw new Error('打点窗口没出现：' + JSON.stringify((list ?? []).map((w) => w.name)));
    const W = win.boundingBox;
    const hwnd = win.nativeWindowHandle;
    out.window = { hwnd, bbox: W, className: win.className, title: win.name };

    const act = await c0.tool('activate_window', { nativeWindowHandle: hwnd });
    out.activate = { ok: !act.isError, text: (act.text ?? '').slice(0, 200), ms: act.ms };
    await sleep(300);

    // 等 header 落盘（Attach 在 Loaded 里，先于一切点击）
    let header = null;
    for (let i = 0; i < 40; i++) {
      if (fs.existsSync(OUT_JSONL)) {
        const first = fs.readFileSync(OUT_JSONL, 'utf8').split('\n').filter(Boolean)[0];
        try { header = JSON.parse(first); } catch { /* 半个 header，等下一轮 */ }
        if (header?.kind === 'header') break;
      }
      await sleep(200);
    }
    if (!header) throw new Error('header 没落盘: ' + OUT_JSONL);
    out.header = header;

    // ── 预热 + 单动作成本标定（这些点击也会被记录，分析时按数量剔除）──
    const warm = [];
    const tW = Date.now();
    for (let i = 0; i < 2; i++) {
      const t = Date.now();
      const m = await engine_move(c0, hwnd, W.x + 120 + i * 40, W.y + 160);
      warm.push({ op: 'move', ms: Date.now() - t, ok: m.ok });
    }
    let warmClicks = 0;
    for (let i = 0; i < 2; i++) {
      const t = Date.now();
      const cl = await c0.tool('click', { x: Math.round(W.x + 150 + i * 60), y: Math.round(W.y + 200 + i * 30), nativeWindowHandle: hwnd, dispatch: 'foreground' });
      warmClicks++;
      warm.push({ op: 'click', ms: Date.now() - t, ok: !cl.isError, text: (cl.text ?? '').slice(0, 120) });
    }
    {
      const t = Date.now();
      const kp = await c0.tool('keypress', { keys: ['w'], nativeWindowHandle: hwnd, dispatch: 'foreground' });
      warm.push({ op: 'keypress-fg', ms: Date.now() - t, ok: !kp.isError, text: (kp.text ?? '').slice(0, 160) });
    }
    {
      const t = Date.now();
      const kp = await c0.tool('type_text', { text: 'd', method: 'background', nativeWindowHandle: hwnd });
      warm.push({ op: 'type_text-bg', ms: Date.now() - t, ok: !kp.isError, text: (kp.text ?? '').slice(0, 160) });
    }
    out.warmup = { wallMs: Date.now() - tW, ops: warm, mouseEvents: warmClicks };

    const p0 = await readPointerPosition();
    out.pointerStart = p0;

    const rect = { x: W.x + 80, y: W.y + 70, width: W.width - 220, height: W.height - 250 };
    const beats = buildBeats(rect);
    const actions = toActions(beats);
    const plan = planSchedule(actions, { anchor: { x: p0.x, y: p0.y } });
    const planned = plan.timeline
      .filter((s) => s.kind === 'click' || s.kind === 'keypress')
      .map((s) => ({ kind: s.kind, atMs: s.atMs, x: s.x ?? null, y: s.y ?? null, key: s.keys?.[0] ?? null }));
    out.plan = {
      beats: beats.length, clicks: beats.filter((b) => b.kind === 'c').length, keys: beats.filter((b) => b.kind === 'k').length,
      intervalsMs: beats.map((b, i) => (i ? b.at - beats[i - 1].at : null)).slice(1),
      totalMs: beats[beats.length - 1].at,
      timeline: timelineStats(plan.timeline),
      plannedArrivals: planned,
      actions: beats,
      stepCounts: beats.filter((b) => b.kind === 'c').map((b) => b.steps),
      rect,
    };
    if (planned.length !== beats.length) throw new Error(`计划拍数不一致: ${planned.length} vs ${beats.length}`);

    // ── 客户端侧：包装 sender，记录每次真实输入调用耗时（并给 keypress 指定窗口）──
    const calls = [];
    const sender = {
      lastRaw: null,
      async call(tool, args = {}) {
        // 按键拍走 type_text(method:'background')：实测到达延迟 158ms，
        // 比 keypress foreground(307ms)/background(283ms) 都低一半（见 l3-keyprobe2.json）。
        // 它仍是插件发出的真实 WM_CHAR 投递（不借前台），不是自己造消息。
        // 按键拍通道（KEY_MODE 可切：type=type_text(background) 158ms ← 最快；bg=keypress 后台 283ms；fg=keypress 前台 307ms）
        const key = tool === 'keypress' ? (args.keys?.[0] ?? 'w') : null;
        const mode = process.env.KEY_MODE ?? 'type';
        let used = tool, a = args;
        if (tool === 'keypress') {
          if (mode === 'bg') { used = 'keypress'; a = { keys: [key], dispatch: 'background', nativeWindowHandle: hwnd }; }
          else if (mode === 'fg') { used = 'keypress'; a = { keys: [key], dispatch: 'foreground', nativeWindowHandle: hwnd }; }
          else { used = 'type_text'; a = { text: key, method: 'background', nativeWindowHandle: hwnd }; }
        }
        const t0 = Date.now();
        const r = await c0.tool(used, a);
        const t1 = Date.now();
        this.lastRaw = r;
        calls.push({ tool: used, key, ok: !r.isError, ms: t1 - t0, wall0: t0, wall1: t1, text: (r.text ?? '').slice(0, 160) });
        return { ok: !r.isError, text: r.text, isError: r.isError };
      },
      async close() {},
    };
    const engine = createEngine({
      sender, pointer: { x: p0.x, y: p0.y }, rawKey: null,
      stepMs: 15, maxSteps: 120, minSteps: 1, curvature: 0.12, easing: 'easeInOutSine',
      retry: { attempts: 2, backoffMs: [0, 20], timeoutMs: 15000 },
    });

    const callsBefore = calls.length;
    const t0Wall = Date.now();
    out.scheduleCalledAt = new Date().toISOString();
    const res = await engine.schedule(actions, { anchorFrom: { x: p0.x, y: p0.y } });
    const t1Wall = Date.now();
    out.scheduleResult = { ok: res.ok, failed: res.failed, error: res.error, elapsedMs: res.elapsedMs, plannedMs: res.plannedMs, driftMs: res.driftMs, steps: res.steps, avgStepMs: res.avgStepMs, timelineMs: res.timelineMs, endAnchor: res.endAnchor };
    out.clientWall = { t0Wall, t1Wall, wallSpanMs: t1Wall - t0Wall };
    out.sequenceCalls = calls.slice(callsBefore);
    out.clientStats = {
      calls: out.sequenceCalls.length,
      clickMs: out.sequenceCalls.filter((c) => c.tool === 'click').map((c) => c.ms),
      keypressMs: out.sequenceCalls.filter((c) => c.tool === 'type_text' || c.tool === 'keypress').map((c) => c.ms),
      moveMs: out.sequenceCalls.filter((c) => c.tool === 'move').map((c) => c.ms),
    };
    out.clientStats.clickMed = med(out.clientStats.clickMs);
    out.clientStats.clickMax = out.clientStats.clickMs.length ? Math.max(...out.clientStats.clickMs) : null;
    out.clientStats.keypressMed = med(out.clientStats.keypressMs);

    await sleep(700);
  } catch (e) {
    out.errors.push(String(e?.message ?? e));
  } finally {
    try { await closeArenaWindows(c0); } catch (e) { out.errors.push('close: ' + e.message); }
    if (child) { try { process.kill(child.pid); } catch { } }
    await sleep(500);
    out.staleAfter = { arena: await killStaleArena(), beat: await killStaleBeat() };
    try { await c0.close(); } catch { }
  }

  // ── 分析 ─────────────────────────────────────────────────────────────
  try {
    const lines = fs.readFileSync(OUT_JSONL, 'utf8').split('\n').filter((s) => s.trim()).map((s) => JSON.parse(s));
    const hdr = lines.find((l) => l.kind === 'header') ?? out.header;
    const rawLines = lines.filter((l) => l.kind === 'mouse' || l.kind === 'key' || l.kind === 'text');
    // 一次物理按键在 WPF 里会依次触发 PreviewKeyDown + PreviewTextInput（同一击，两个事件）；
    // 前台 keypress 模式下两者都被记录，必须合并成"一拍"，否则整条序列配对错位。
    const all = [];
    let merged = 0;
    for (const e of rawLines) {
      const prev = all[all.length - 1];
      if (e.kind === 'text' && prev && prev.kind === 'key' && e.swMs - prev.swMs <= 40) { merged++; continue; }
      all.push(e);
    }
    // 序列起点打在靶场时钟域里的位置：cutSw = 客户端 schedule 起跑墙钟 - 靶场 Stopwatch 零点墙钟
    const cutSw = (out.clientWall?.t0Wall ?? Number.MAX_SAFE_INTEGER) - hdr.swZeroUnixMs;
    const seq = all.filter((e) => e.swMs >= cutSw - 15);
    const dropped = all.filter((e) => e.swMs < cutSw - 15);
    out.raw = {
      lines: lines.length, events: all.length, keyTextMerged: merged, cutSw: r3(cutSw), droppedEvents: dropped.length,
      droppedKinds: dropped.map((d) => d.kind + '@' + r3(d.swMs)), seqEvents: seq.length,
      markers: lines.filter((l) => l.kind === 'marker').map((m) => ({ name: m.name, swMs: m.swMs })),
    };
    out.actualArrivals = seq.map((e) => ({ kind: e.kind, swMs: e.swMs, x: e.x ?? null, y: e.y ?? null, key: e.key ?? e.text ?? null, n: e.n }));

    const planned = out.plan.plannedArrivals;
    const callList = (out.sequenceCalls ?? []).filter((c) => c.tool === 'click' || c.tool === 'type_text' || c.tool === 'keypress');
    const n = Math.min(seq.length, planned.length);
    if (seq.length !== planned.length) out.warnings.push(`序列事件数 ${seq.length} ≠ 计划拍数 ${planned.length}（丢拍或重复派发；按序配对前 ${n} 个）`);
    const per = [];
    for (let i = 0; i < n; i++) {
      const a = seq[i], p = planned[i], call = callList[i] ?? null;
      const actualKind = a.kind === 'mouse' ? 'click' : 'keypress';
      per.push({
        i, plannedKind: p.kind, actualKind, actualRawKind: a.kind, kindMatch: p.kind === actualKind,
        plannedAtMs: p.atMs, actualSwMs: a.swMs,
        rawDeltaMs: r3(a.swMs - p.atMs),
        absLateMs: r3((hdr.swZeroUnixMs + a.swMs) - (out.clientWall.t0Wall + p.atMs)),
        arrivalLatencyMs: call ? r3((hdr.swZeroUnixMs + a.swMs) - call.wall0) : null,
        clientCallMs: call?.ms ?? null,
        plannedGapMs: i ? p.atMs - planned[i - 1].atMs : null,
        actualGapMs: i ? r3(a.swMs - seq[i - 1].swMs) : null,
        key: a.key ?? null, x: a.x ?? null, y: a.y ?? null,
      });
    }
    const base = per[0];
    for (const e of per) {
      e.devMs = r3((e.actualSwMs - base.actualSwMs) - (e.plannedAtMs - base.plannedAtMs));
    }
    const devs = per.map((e) => e.devMs);
    const absDevs = devs.map(Math.abs);
    const late = per.map((e) => e.absLateMs);
    out.perBeat = per;
    const lat = per.map((e) => e.arrivalLatencyMs).filter((v) => v != null);
    out.stats = {
      n: per.length,
      clicks: per.filter((e) => e.actualKind === 'click').length,
      keys: per.filter((e) => e.actualKind === 'keypress').length,
      devMedianMs: r3(med(devs)), devP90Ms: r3(pct(devs, 0.9)), devMinMs: r3(Math.min(...devs)), devMaxMs: r3(Math.max(...devs)),
      absDevMedianMs: r3(med(absDevs)), absDevP90Ms: r3(pct(absDevs, 0.9)), absDevMaxMs: r3(Math.max(...absDevs)),
      absDevSumMs: r3(absDevs.reduce((a, b) => a + b, 0)),
      lastBeatAbsDevMs: r3(Math.abs(devs[devs.length - 1])),
      absLateMedianMs: r3(med(late)), absLateMaxMs: r3(Math.max(...late)), absLateFirstMs: r3(late[0]),
      arrivalLatencyMedianMs: r3(med(lat)), arrivalLatencyMaxMs: lat.length ? r3(Math.max(...lat)) : null,
      arrivalLatencyClickMedianMs: r3(med(per.filter((e) => e.actualKind === 'click' && e.arrivalLatencyMs != null).map((e) => e.arrivalLatencyMs))),
      arrivalLatencyKeyMedianMs: r3(med(per.filter((e) => e.actualKind === 'keypress' && e.arrivalLatencyMs != null).map((e) => e.arrivalLatencyMs))),
      wallGrainMs: hdr.wallGrainMs,
      passes: {
        'maxAbsDev<100ms': Math.max(...absDevs) < 100,
        'lastAbsDev<100ms': Math.abs(devs[devs.length - 1]) < 100,
        'beats>=20': per.length >= 20,
        'intervalsWithin200-400': out.plan.intervalsMs.every((v) => v >= 200 && v <= 400),
        'clicks+keys+mixed': per.filter((e) => e.actualKind === 'click').length >= 20 && per.filter((e) => e.actualKind === 'keypress').length >= 1,
        'kindOrderMatch': per.every((e) => e.kindMatch),
      },
    };
  } catch (e) {
    out.errors.push('analyze: ' + String(e?.message ?? e));
  }

  fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2), 'utf8');
  fs.writeFileSync(`D:\\dsh-arena\\bench\\l3-timing-${stamp}.json`, JSON.stringify(out, null, 2), 'utf8');
  console.log('[saved] ' + OUT_JSON + '  (+l3-timing-' + stamp + '.json)');
  console.log(JSON.stringify({ stats: out.stats, raw: out.raw, errors: out.errors, warnings: out.warnings }, null, 2));
}

/** 预热用的一次真实 move（不经过 engine，避免污染 engine 的 calibration） */
async function engine_move(c0, hwnd, x, y) {
  const r = await c0.tool('move', { x: Math.round(x), y: Math.round(y), nativeWindowHandle: hwnd });
  return { ok: !r.isError };
}

main().catch((e) => { console.error('FATAL: ' + (e?.stack ?? e)); out.errors.push('fatal: ' + String(e?.message ?? e)); try { fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2), 'utf8'); } catch { } process.exitCode = 1; });
