/**
 * L3 · 定时序列复跑（v2）—— 目标：把「最大偏差」压进 100ms
 *
 * 与 l3-schedule.mjs（v1）的唯一实质差别：**按键拍不再走插件**，改走常驻注入器（SendInput，同机 QPC）。
 * 依据（现场复算 l3-timing.json 逐拍）：v1 里点击拍 dev 0–40ms、arrival≈57–78ms；
 *   按键拍 dev 175–188ms、arrival≈262–270ms、插件调用 284–297ms —— 唯一把 max|dev| 推过 100ms 的就是这条通道。
 *
 * 另外新增一个**同源绝对迟到口径**（取代 v1 的跨时钟墙钟口径）：
 *   Node hrtime 用 ping 最小延迟法标定到 QPC，anchor = min(issueQpc − atMs)，
 *   同源迟到 = 靶场 tick − (anchor + atMs)。全程只有一个时钟，没有 Date.now 的 15.6ms 量子。
 *
 * 产出：D:\dsh-arena\bench\l3-timing2.json + l3-beats2-<ts>.jsonl（不覆盖 v1 的原始数据）
 */
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { connect, killStaleArena, waitArenaWindow, closeArenaWindows, PS, runPs } from './client.mjs';
import { createEngine, readPointerPosition, planSchedule, timelineStats } from 'file:///D:/dsh-tools/aim/input.mjs';
import { startInjector, msOfTicks } from './keylat/keyclient.mjs';

const CLICK_MODE = process.env.CLICK_MODE ?? 'injector';   // injector | plugin

const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
const OUT_JSONL = `D:\\dsh-arena\\bench\\l3-beats3-${stamp}.jsonl`;
const OUT_JSON = 'D:\\dsh-arena\\bench\\l3-timing3.json';
const ARENA = 'D:\\dsh-arena\\arena-beat.ps1';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const med = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };
const pct = (a, p) => { const s = [...a].sort((x, y) => x - y); if (!s.length) return null; const i = Math.min(s.length - 1, Math.max(0, Math.ceil(s.length * p) - 1)); return s[i]; };
const r3 = (v) => (v == null ? null : Math.round(v * 1000) / 1000);

const out = { schema: 'dsh-arena/l3-timing/2', variant: 'v2-injector-key+click(' + (process.env.CLICK_MODE ?? 'injector') + ')', generatedAt: new Date().toISOString(), arena: ARENA, jsonl: OUT_JSONL, warnings: [], errors: [] };

async function killStaleBeat() {
  const script = [
    `$rx = 'arena' + '-beat\\.ps1'`, `$k = @()`,
    `Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match $rx -and $_.ProcessId -ne $PID } | ForEach-Object { $k += $_.ProcessId; try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop } catch {} }`,
    `if ($k.Count) { 'killed=' + ($k -join ',') } else { 'killed=none' }`,
  ].join('; ');
  const r = await runPs(script, { timeoutMs: 15000 });
  return ((r.out ?? '').trim() || 'no-output');
}

const IV = [280, 260, 300, 400, 280];
const GROUP = [['c', 1], ['c', 1], ['k', 0], ['c', 3], ['c', 1]];
const KEYS = ['w', 'a', 's', 'd', 'w', 'a'];
const GROUPS = 6;

function buildBeats(rect) {
  const beats = []; let at = 0, keyIdx = 0;
  for (let g = 0; g < GROUPS; g++) {
    for (const [kind, steps] of GROUP) {
      if (beats.length) at += IV[(beats.length - 1) % IV.length];
      const i = beats.length, col = i % 6, row = (i * 3) % 5;
      beats.push({ kind, steps, at, key: kind === 'k' ? KEYS[keyIdx++ % KEYS.length] : null, x: Math.round(rect.x + col * (rect.width / 5.4)), y: Math.round(rect.y + row * (rect.height / 4.6)) });
    }
  }
  return beats;
}
const toActions = (b) => b.map((x) => (x.kind === 'c'
  ? { name: 'click', x: x.x, y: x.y, at: x.at, durationMs: 1, stepMs: 15, minSteps: x.steps, maxSteps: x.steps, settleMs: 0, curvature: 0.12 }
  : { name: 'keypress', keys: [x.key], at: x.at }));

async function main() {
  out.staleBefore = { arena: await killStaleArena(), beat: await killStaleBeat() };
  const c0 = await connect();
  const inj = await startInjector();
  // Node hrtime → QPC 标定
  const offs = [];
  for (let i = 0; i < 60; i++) { const h0 = process.hrtime.bigint(); const r = await inj.ping(); offs.push(Number(r.p0) - Number(h0) * inj.freq / 1e9); await sleep(1); }
  const offMin = Math.min(...offs);
  const nodeTick = (hns) => Number(hns) * inj.freq / 1e9 + offMin;
  out.calib = { offsetMinMs: r3(offMin / inj.freq * 1000), bandMs: r3((Math.max(...offs) - offMin) / inj.freq * 1000), freq: inj.freq };
  let child = null;
  try {
    const pre = await closeArenaWindows(c0);
    out.preClosed = pre;
    await sleep(400);
    child = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ARENA, '-OutJsonl', OUT_JSONL, '-ExitAfterMs', '120000'], { stdio: 'ignore' });
    const { win, list } = await waitArenaWindow(c0, { tries: 90, intervalMs: 400 });
    if (!win) throw new Error('打点窗口没出现：' + JSON.stringify((list ?? []).map((w) => w.name)));
    const W = win.boundingBox, hwnd = win.nativeWindowHandle;
    out.window = { hwnd, bbox: W, className: win.className, title: win.name };
    out.activate = { ok: true, ms: (await c0.tool('activate_window', { nativeWindowHandle: hwnd })).ms };
    await sleep(300);
    let header = null;
    for (let i = 0; i < 40; i++) {
      if (fs.existsSync(OUT_JSONL)) {
        const first = fs.readFileSync(OUT_JSONL, 'utf8').split('\n').filter(Boolean)[0];
        try { header = JSON.parse(first); } catch { }
        if (header?.kind === 'header') break;
      }
      await sleep(200);
    }
    if (!header) throw new Error('header 没落盘: ' + OUT_JSONL);
    out.header = header;
    await inj.focus(hwnd);

    // 预热：插件侧 move/click/activate ＋ 注入器首条（冷启动不计入）
    const warm = []; const tW = Date.now(); let warmClicks = 0;
    for (let i = 0; i < 2; i++) { const t = Date.now(); await c0.tool('move', { x: Math.round(W.x + 120 + i * 40), y: W.y + 160, nativeWindowHandle: hwnd }); warm.push({ op: 'move', ms: Date.now() - t }); }
    for (let i = 0; i < 2; i++) { const t = Date.now(); const cl = await c0.tool('click', { x: Math.round(W.x + 150 + i * 60), y: Math.round(W.y + 200 + i * 30), nativeWindowHandle: hwnd, dispatch: 'foreground' }); warmClicks++; warm.push({ op: 'click', ms: Date.now() - t, ok: !cl.isError }); }
    { const t = Date.now(); const kp = await c0.tool('keypress', { keys: ['w'], nativeWindowHandle: hwnd, dispatch: 'foreground' }); warm.push({ op: 'keypress-fg(插件,仅热身)', ms: Date.now() - t, ok: !kp.isError }); }
    { const t = Date.now(); const r = await inj.key({ key: 'd', ms: 5, hwnd }); warm.push({ op: 'injector-sendinput(热身)', ms: Date.now() - t, ok: true }); }
    out.warmup = { wallMs: Date.now() - tW, ops: warm, mouseEvents: warmClicks };

    // 前台自检：常驻注入器用 AttachThreadInput+Alt 轻敲抢前台（插件自己的 Set-WindowForeground 常被系统挡回）
    let fgOk = false;
    for (let i = 0; i < 5; i++) { const fr = await inj.focus(hwnd); if (fr.ok) { fgOk = true; break; } await sleep(200); }
    const prb = await inj.probe(hwnd);
    out.foregroundCheck = { ok: fgOk, fg: Number(prb.fg), vis: prb.vis, isWindow: prb.isWindow };
    if (!fgOk) out.warnings.push('前台仲裁失败：靶场窗口不是前台，点击拍会被插件的 foreground 守卫拒绝');
    await sleep(200);

    const p0 = await readPointerPosition();
    const rect = { x: W.x + 80, y: W.y + 70, width: W.width - 220, height: W.height - 250 };
    const beats = buildBeats(rect);
    const actions = toActions(beats);
    const plan = planSchedule(actions, { anchor: { x: p0.x, y: p0.y } });
    const planned = plan.timeline.filter((s) => s.kind === 'click' || s.kind === 'keypress').map((s) => ({ kind: s.kind, atMs: s.atMs, x: s.x ?? null, y: s.y ?? null, key: s.keys?.[0] ?? null }));
    out.plan = { beats: beats.length, clicks: beats.filter((b) => b.kind === 'c').length, keys: beats.filter((b) => b.kind === 'k').length, intervalsMs: beats.map((b, i) => (i ? b.at - beats[i - 1].at : null)).slice(1), totalMs: beats[beats.length - 1].at, timeline: timelineStats(plan.timeline), plannedArrivals: planned, rect };
    if (planned.length !== beats.length) throw new Error(`计划拍数不一致: ${planned.length} vs ${beats.length}`);

    const calls = [];
    const sender = {
      lastRaw: null,
      async call(tool, args = {}) {
        if (tool === 'keypress') {
          const key = args.keys?.[0] ?? 'w';
          const h0 = process.hrtime.bigint();
          let r = null, err = null;
          try { r = await inj.key({ key, ms: 10, hwnd }); } catch (e) { err = String(e?.message ?? e); }
          const h1 = process.hrtime.bigint();
          calls.push({ tool: 'injector-sendinput', key, ok: !err, err, ms: r3(Number(h1 - h0) / 1e6), issueQpc: nodeTick(h0), t0: r ? Number(r.keys[0][0]) : null, td: r ? Number(r.keys[0][1]) : null, fg: r ? Number(r.fg) : null, text: 'SendInput 前台真实按键' });
          return { ok: !err, text: err ?? 'injector sendinput', isError: !!err };
        }
        const h0 = process.hrtime.bigint();
        const t = Date.now();
        if (tool === 'click' && CLICK_MODE === 'injector') {
          let r = null, err = null;
          try { r = await inj.mouse(args.x, args.y); } catch (e) { err = String(e?.message ?? e); }
          const h1 = process.hrtime.bigint();
          calls.push({ tool: 'injector-mouse', ok: !err, err, ms: r3(Number(h1 - h0) / 1e6), issueQpc: nodeTick(h0), t0: r ? Number(r.keys[0][0]) : null, td: r ? Number(r.keys[0][1]) : null, fg: r ? Number(r.fg) : null, wall0: t, text: 'SendInput/SetCursorPos 真实点击' });
          return { ok: !err, text: err ?? 'injector mouse', isError: !!err };
        }
        const r = await c0.tool(tool, args);
        const h1 = process.hrtime.bigint();
        this.lastRaw = r;
        calls.push({ tool, ok: !r.isError, ms: r3(Number(h1 - h0) / 1e6), issueQpc: nodeTick(h0), wall0: t, wall1: Date.now(), text: (r.text ?? '').slice(0, 160) });
        return { ok: !r.isError, text: r.text, isError: r.isError };
      },
      async close() { },
    };
    const engine = createEngine({ sender, pointer: { x: p0.x, y: p0.y }, rawKey: null, stepMs: 15, maxSteps: 120, minSteps: 1, curvature: 0.12, easing: 'easeInOutSine', retry: { attempts: 2, backoffMs: [0, 20], timeoutMs: 15000 } });

    const callsBefore = calls.length;
    const t0Wall = Date.now();
    const res = await engine.schedule(actions, { anchorFrom: { x: p0.x, y: p0.y } });
    const t1Wall = Date.now();
    out.scheduleResult = { ok: res.ok, failed: res.failed, error: res.error, elapsedMs: res.elapsedMs, plannedMs: res.plannedMs, driftMs: res.driftMs, steps: res.steps, avgStepMs: res.avgStepMs, timelineMs: res.timelineMs, endAnchor: res.endAnchor };
    out.clientWall = { t0Wall, t1Wall, wallSpanMs: t1Wall - t0Wall };
    out.sequenceCalls = calls.slice(callsBefore);
    const cl = out.sequenceCalls;
    out.clientStats = {
      calls: cl.length,
      clickMs: cl.filter((c) => c.tool === 'click').map((c) => c.ms),
      injectorMs: cl.filter((c) => c.tool === 'injector-sendinput').map((c) => c.ms),
      moveMs: cl.filter((c) => c.tool === 'move').map((c) => c.ms),
    };
    out.clientStats.clickMed = med(out.clientStats.clickMs);
    out.clientStats.clickMax = out.clientStats.clickMs.length ? Math.max(...out.clientStats.clickMs) : null;
    out.clientStats.injectorMed = med(out.clientStats.injectorMs);
    out.clientStats.injectorMax = out.clientStats.injectorMs.length ? Math.max(...out.clientStats.injectorMs) : null;
    await sleep(700);
  } catch (e) {
    out.errors.push(String(e?.message ?? e));
  } finally {
    try { await closeArenaWindows(c0); } catch (e) { out.errors.push('close: ' + e.message); }
    if (child) { try { process.kill(child.pid); } catch { } }
    await sleep(500);
    await inj.close();
    out.staleAfter = { arena: await killStaleArena(), beat: await killStaleBeat() };
    try { await c0.close(); } catch { }
  }

  try {
    const lines = fs.readFileSync(OUT_JSONL, 'utf8').split('\n').filter((s) => s.trim()).map((s) => JSON.parse(s));
    const hdr = lines.find((l) => l.kind === 'header') ?? out.header;
    const rawLines = lines.filter((l) => l.kind === 'mouse' || l.kind === 'key' || l.kind === 'text');
    const all = []; let merged = 0;
    for (const e of rawLines) {
      const prev = all[all.length - 1];
      if (e.kind === 'text' && prev && prev.kind === 'key' && e.swMs - prev.swMs <= 40) { merged++; continue; }
      all.push(e);
    }
    const cutSw = (out.clientWall?.t0Wall ?? Number.MAX_SAFE_INTEGER) - hdr.swZeroUnixMs;
    const seq = all.filter((e) => e.swMs >= cutSw - 15);
    const dropped = all.filter((e) => e.swMs < cutSw - 15);
    out.raw = { lines: lines.length, events: all.length, keyTextMerged: merged, cutSw: r3(cutSw), droppedEvents: dropped.length, droppedKinds: dropped.map((d) => d.kind + '@' + r3(d.swMs)), seqEvents: seq.length, markers: lines.filter((l) => l.kind === 'marker').map((m) => ({ name: m.name, swMs: m.swMs })) };
    const planned = out.plan.plannedArrivals;
    const callList = (out.sequenceCalls ?? []).filter((c) => c.tool === 'click' || c.tool === 'injector-sendinput' || c.tool === 'injector-mouse');
    const n = Math.min(seq.length, planned.length);
    if (seq.length !== planned.length) out.warnings.push(`序列事件数 ${seq.length} ≠ 计划拍数 ${planned.length}`);
    const FREQ = Number(hdr.qpcFreq ?? 10000000), SW0 = Number(hdr.swZeroQpc);
    const per = [];
    for (let i = 0; i < n; i++) {
      const a = seq[i], p = planned[i], call = callList[i] ?? null;
      const actualKind = a.kind === 'mouse' ? 'click' : 'keypress';
      per.push({
        i, plannedKind: p.kind, actualKind, actualRawKind: a.kind, kindMatch: p.kind === actualKind,
        plannedAtMs: p.atMs, actualSwMs: a.swMs, appTick: SW0 + a.swMs / 1000 * FREQ,
        rawDeltaMs: r3(a.swMs - p.atMs),
        absLateWallMs: r3((hdr.swZeroUnixMs + a.swMs) - (out.clientWall.t0Wall + p.atMs)),
        arrivalLatencyMs: call
          ? (call.t0 != null ? r3(msOfTicks(SW0 + a.swMs / 1000 * FREQ - call.t0, FREQ)) : r3((hdr.swZeroUnixMs + a.swMs) - call.wall0))
          : null,
        clientCallMs: call?.ms ?? null, callTool: call?.tool ?? null, issueQpc: call?.issueQpc ?? null,
        key: a.key ?? null, x: a.x ?? null, y: a.y ?? null,
        plannedGapMs: i ? p.atMs - planned[i - 1].atMs : null, actualGapMs: i ? r3(a.swMs - seq[i - 1].swMs) : null,
      });
    }
    // 同源锚点：min(issueQpc − atMs)
    const resid = per.filter((e) => e.issueQpc != null).map((e) => e.issueQpc - e.plannedAtMs * FREQ / 1000);
    const anchorSs = resid.length ? Math.min(...resid) : null;
    for (const e of per) {
      if (anchorSs != null) e.absLateSameSourceMs = r3(msOfTicks(e.appTick - (anchorSs + e.plannedAtMs * FREQ / 1000), FREQ));
      if (e.callTool === 'injector-sendinput' && e.issueQpc != null) e.injectAfterIssueMs = null;
    }
    const base = per[0];
    for (const e of per) e.devMs = r3((e.actualSwMs - base.actualSwMs) - (e.plannedAtMs - base.plannedAtMs));
    const devs = per.map((e) => e.devMs), absDevs = devs.map(Math.abs);
    const ss = per.map((e) => e.absLateSameSourceMs).filter((v) => v != null);
    const wl = per.map((e) => e.absLateWallMs);
    out.perBeat = per;
    out.anchor = { sameSourceQpc: anchorSs, sameSourceResidualMinMs: resid.length ? r3(Math.min(...resid) / FREQ * 1000) : null, wallCaliberT0: out.clientWall.t0Wall };
    out.stats = {
      n: per.length, clicks: per.filter((e) => e.actualKind === 'click').length, keys: per.filter((e) => e.actualKind === 'keypress').length,
      devMedianMs: r3(med(devs)), devP90Ms: r3(pct(devs, 0.9)), devMaxMs: r3(Math.max(...devs)), devMinMs: r3(Math.min(...devs)),
      absDevMedianMs: r3(med(absDevs)), absDevP90Ms: r3(pct(absDevs, 0.9)), absDevMaxMs: r3(Math.max(...absDevs)), absDevSumMs: r3(absDevs.reduce((a, b) => a + b, 0)),
      ssLateMedianMs: r3(med(ss)), ssLateP90Ms: r3(pct(ss, 0.9)), ssLateMaxMs: ss.length ? r3(Math.max(...ss)) : null, ssLateMinMs: ss.length ? r3(Math.min(...ss)) : null,
      wallLateMedianMs: r3(med(wl)), wallLateMaxMs: r3(Math.max(...wl)),
      clickDevMaxMs: r3(Math.max(...per.filter((e) => e.actualKind === 'click').map((e) => Math.abs(e.devMs)))),
      keyDevMaxMs: r3(Math.max(...per.filter((e) => e.actualKind === 'keypress').map((e) => Math.abs(e.devMs)))),
      arrivalLatMedianMs: r3(med(per.map((e) => e.arrivalLatencyMs).filter((v) => v != null))),
      arrivalLatClickMedMs: r3(med(per.filter((e) => e.actualKind === 'click').map((e) => e.arrivalLatencyMs).filter((v) => v != null))),
      arrivalLatKeyMedMs: r3(med(per.filter((e) => e.actualKind === 'keypress').map((e) => e.arrivalLatencyMs).filter((v) => v != null))),
      passes: {
        'maxAbsDev<100ms': Math.max(...absDevs) < 100,
        'maxAbsLateSameSource<100ms': ss.length ? Math.max(...ss) < 100 : false,
        'beats>=20': per.length >= 20,
        'intervalsWithin200-400': out.plan.intervalsMs.every((v) => v >= 200 && v <= 400),
        'kindOrderMatch': per.every((e) => e.kindMatch),
      },
    };
  } catch (e) { out.errors.push('analyze: ' + String(e?.message ?? e)); }

  fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2), 'utf8');
  fs.writeFileSync(`D:\\dsh-arena\\bench\\l3-timing2-${stamp}.json`, JSON.stringify(out, null, 2), 'utf8');
  console.log('[saved] ' + OUT_JSON);
  console.log(JSON.stringify({ stats: out.stats, anchor: out.anchor, clientStats: out.clientStats, errors: out.errors, warnings: out.warnings }, null, 2));
}
main().catch((e) => { console.error('FATAL: ' + (e?.stack ?? e)); out.errors.push('fatal: ' + String(e?.message ?? e)); try { fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2), 'utf8'); } catch { } process.exitCode = 1; });
