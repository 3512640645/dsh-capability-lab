#!/usr/bin/env node
/**
 * W4 新增（不改 qa.mjs）：音画包络的**滞后扫描**，用来判定 qa.mjs 的 r 是"真不同步"还是"算错位"。
 *
 * 背景：qa.mjs 原本的音频窗口是 0.2297s（=11025/48000），视频桶是 0.5s，两路不同时间基底，
 * 修好后 r 从 +0.284 翻成 -0.153。这个脚本回答一个问题：把两路都对齐到 0.5s 之后，
 * 是否在某个整数桶滞后上存在明显正的 r？若滞后 0 处就是最大值且很弱 → 内容本身没有音画关联，
 * 不是对齐算法的问题。
 *
 * 用法：node qa-av-lag-scan.mjs <video> [bin=0.5] [maxLag=4]
 */
import { spawnSync } from 'node:child_process';

const FFMPEG = 'D:\\dsh-video\\tools\\ffmpeg\\ffmpeg.exe';
const [video, binArg, lagArg] = process.argv.slice(2);
if (!video) { console.error('用法: node qa-av-lag-scan.mjs <video> [bin] [maxLag]'); process.exit(2); }
const BIN = Number(binArg || 0.5);
const MAXLAG = Number(lagArg || 4);
const ENV_SR = 22050;

const run = (args) => spawnSync(FFMPEG, args, { encoding: 'utf8', windowsHide: true, maxBuffer: 256 * 1024 * 1024 });
const dbToLin = (db) => (Number.isFinite(db) ? Math.pow(10, db / 10) : 0);

// 音频包络：与 qa.mjs 修好后的链路一致（aresample 在链内 → 窗口恒等于 BIN）
const audioSeries = () => {
  const n = Math.round(ENV_SR * BIN);
  const r = run(['-hide_banner', '-nostats', '-i', video, '-map', '0:a:0',
    '-af', `aresample=${ENV_SR},asetnsamples=n=${n}:p=0,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-`,
    '-f', 'null', '-']);
  const out = [];
  for (const m of ((r.stdout || '') + (r.stderr || '')).matchAll(/RMS_level=(-?[\d.]+|inf|-inf)/g)) {
    out.push(+dbToLin(m[1] === 'inf' ? 0 : m[1] === '-inf' ? -120 : Number(m[1])).toFixed(9));
  }
  return out;
};

// 视频帧差包络：同样 0.5s 分桶
const videoSeries = () => {
  const sub = Math.max(1, Math.round(4 / BIN));
  const per = Math.max(1, Math.round(sub * BIN));
  const r = run(['-hide_banner', '-nostats', '-i', video, '-an',
    '-vf', `fps=${sub},scale=160:90:flags=area,format=gray,tblend=all_mode=difference,showinfo`, '-f', 'null', '-']);
  const raw = [];
  for (const m of ((r.stderr || '') + (r.stdout || '')).matchAll(/mean:\[([\d.-]+)\]/g)) raw.push(Number(m[1]));
  const usable = raw.slice(raw.length ? 2 : 0);
  const bins = [];
  for (let i = 0; i + per <= usable.length; i += per) bins.push(usable.slice(i, i + per).reduce((s, v) => s + v, 0) / per);
  return bins;
};

const pearson = (x, y) => {
  const n = Math.min(x.length, y.length);
  if (n < 8) return null;
  const mx = x.slice(0, n).reduce((s, v) => s + v, 0) / n, my = y.slice(0, n).reduce((s, v) => s + v, 0) / n;
  let sxy = 0, sxx = 0, syy = 0;
  for (let i = 0; i < n; i++) { const a = x[i] - mx, b = y[i] - my; sxy += a * b; sxx += a * a; syy += b * b; }
  if (sxx === 0 || syy === 0) return null;
  return { r: +(sxy / Math.sqrt(sxx * syy)).toFixed(4), n };
};

const a = audioSeries(), v = videoSeries();
console.log(`视频: ${video}`);
console.log(`音频包络 ${a.length} 点（每点 ${BIN}s @${ENV_SR}Hz）· 视频包络 ${v.length} 桶（每桶 ${BIN}s）· 理论点数 ${Math.round(a.length * BIN)}s / ${Math.round(v.length * BIN)}s`);
let best = null;
for (let lag = -MAXLAG; lag <= MAXLAG; lag++) {
  // lag>0：音频整体后移 lag 桶（等于视频提前）
  const A = lag >= 0 ? a.slice(lag) : a;
  const V = lag >= 0 ? v : v.slice(-lag);
  const p = pearson(A, V);
  if (!p) { console.log(`  lag=${String(lag).padStart(3)} : r 不可定义`); continue; }
  const mark = lag === 0 ? ' ← 当前 qa 使用的配对' : '';
  console.log(`  lag=${String(lag).padStart(3)} : r=${String(p.r).padStart(8)} n=${p.n}${mark}`);
  if (!best || Math.abs(p.r) > Math.abs(best.r)) best = { lag, r: p.r, n: p.n };
}
console.log(`最大 |r| 出现在 lag=${best.lag}（r=${best.r}）；qa 用 lag=0 的 r=${pearson(a, v)?.r}`);
