/**
 * 汇总报告：读 bench 结果 JSON → D:\dsh-arena\bench-real.json
 *   node report.mjs
 */
import fs from 'node:fs';

const BASE = 'D:\\dsh-arena\\bench\\';
const load = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const real = load(BASE + 'results-real.json');
const element = load(BASE + 'results-element.json');
const slow = load(BASE + 'results-real-slow120.json');
const calib = load(BASE + 'calib.json');
const realPre = load(BASE + 'results-real-prefix.json');

const med = (a) => { const s = [...a].filter((n) => Number.isFinite(n)).sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };
const round3 = (x) => Math.round(x * 1000) / 1000;

function summarize(R, { aimFromArena = true } = {}) {
  const runs = R.runs.map((r) => {
    const ar = r.arenaRun ?? {};
    const aims = aimFromArena ? (ar.targets ?? []).map((t) => t.aimPx).filter((x) => Number.isFinite(x)) : [];
    const skip = {};
    for (const c of r.cycles) if (c.skipped) { const k = String(c.skipped).split('/')[0].split('=')[0]; skip[k] = (skip[k] || 0) + 1; }
    const src = {};
    for (const c of r.cycles) if (c.lead) src[c.lead.source] = (src[c.lead.source] || 0) + 1;
    return {
      arenaRunFile: ar.file, motion: ar.motion, elapsedMs: ar.elapsedMs,
      hits: ar.hits, misses: ar.misses, hitRate: ar.hitRate,
      avgReactionMs: ar.avgReactionMs, medianReactionMs: ar.medianReactionMs, minReactionMs: ar.minReactionMs, maxReactionMs: ar.maxReactionMs, p90ReactionMs: ar.p90ReactionMs,
      reactionMs: ar.reactionMs,
      cycles: r.cycles.length, clicked: r.cycles.filter((c) => c.aim).length, skipped: r.cycles.filter((c) => c.skipped).length,
      skipReasons: skip, aimSource: src,
      cycleLatencyMs: r.cycleLatency,
      aimPx: aims.length ? { n: aims.length, median: med(aims), mean: round3(aims.reduce((a, b) => a + b, 0) / aims.length), max: Math.max(...aims) } : null,
      targetRadiusPx: (ar.targets ?? []).length ? { first: (ar.targets[0] ?? {}).r, last: (ar.targets[ar.targets.length - 1] ?? {}).r } : null,
      window: r.window, cleanup: r.cleanup, errors: r.errors,
    };
  });
  const hits = runs.map((r) => r.hits), avg = runs.map((r) => r.avgReactionMs), rate = runs.map((r) => r.hitRate);
  const cyc = med(runs.map((r) => r.cycleLatencyMs?.cycle));
  return {
    channel: R.channel, cfg: R.cfg, inputPath: R.channel === 'real' ? 'vision+real-pointer' : 'uia-element',
    runs,
    median: { hits: med(hits), avgReactionMs: med(avg), hitRate: med(rate), medianReactionMs: med(runs.map((r) => r.medianReactionMs)) },
    range: { hits: Math.max(...hits) - Math.min(...hits), avgReactionMs: round3(Math.max(...avg) - Math.min(...avg)) },
    cycleLatencyMs: { see: med(runs.map((r) => r.cycleLatencyMs?.see)), find: med(runs.map((r) => r.cycleLatencyMs?.findMs)), move: med(runs.map((r) => r.cycleLatencyMs?.move)), click: med(runs.map((r) => r.cycleLatencyMs?.click)), cycle: cyc },
    passes: {
      'hits>=20': med(hits) >= 20,
      'hitRate>=90%': med(rate) >= 0.9,
      'avgReaction<=700': med(avg) <= 700,
      'range<=5': (Math.max(...hits) - Math.min(...hits)) <= 5,
      'L3:目标会动/会缩时命中率>=70%': med(rate) >= 0.7,
      'L3:视觉闭环>=2Hz': cyc != null && cyc <= 500,
    },
  };
}

const realS = summarize(real, { aimFromArena: true });
const elemS = summarize(element, { aimFromArena: false });
const slowS = summarize(slow, { aimFromArena: true });
const preS = summarize(realPre, { aimFromArena: true });

const out = {
  schema: 'dsh-arena/bench-real/1',
  level: 'L2（移动靶变体）/ L3 部分项',
  spec: 'D:\\dsh-tools\\CONTROL-BENCH.md',
  arena: {
    script: 'D:\\dsh-arena\\arena-move.ps1', mode: 'move',
    window: 'DSH Arena 900x620@(140,110)', runsDir: 'D:\\dsh-arena\\runs',
    uia: { targetName: 'target', targetAutomationId: 'arenaTarget', controlType: 'Button' },
    motion: { axis: 'x', shape: 'triangle', speedPxPerSec: 240, radiusPx: '40 -> 18（按局内时间线性收缩）', verticalRespawnJumpPx: 80 },
    note: '靶场自己落的 run-*.json 是唯一成绩来源；本文件只做汇总。',
  },
  // ↓ 与 CONTROL-BENCH.md 的报告格式同形：主口径 = 真实指针通道
  inputPath: realS.inputPath,
  runs: realS.runs.map((r) => ({ hits: r.hits, misses: r.misses, hitRate: r.hitRate, avgReactionMs: r.avgReactionMs, medianReactionMs: r.medianReactionMs, arenaRunFile: r.arenaRunFile })),
  median: realS.median,
  range: realS.range,
  passes: realS.passes,
  // ↓ 两条通道分开摆，且标明不可比
  channels: {
    'real-pointer': realS,
    element: elemS,
  },
  comparability: {
    statement: '两条通道的分数不可比：真实指针通道要"瞄准"，元素通道不需要瞄准（UIA Invoke 打在元素上，元素在动也照样命中）。',
    evidence: [
      '真实指针通道每拍 = 截图(≈250ms) + 贝塞尔轨迹 move(≈170ms) + 真实 click(≈202ms)，靠坐标命中，命中与否取决于提前量估计。',
      '元素通道每拍 = UIA find(≈419ms) + invoke(≈164ms)，全程不碰指针；靶场记录的 aimPx（指针到靶心距离）最高 709px 仍然 100% 命中 → 证明它根本不是靠坐标打的。',
      '所以"移动靶命中率"对元素通道是一个偏宽容的指标，对真实指针通道才是真实难度。',
    ],
  },
  controls: {
    'real-pointer@120pxPerSec': slowS,
    'real-pointer@240pxPerSec(pre-fix)': preS,
  },
  latency: {
    pointerReadMs: calib.lat.readPointerMs,
    screenshotMs: calib.lat.screenshot,
    moveMs: calib.lat.moveMs, clickMs: calib.lat.clickMs,
    realPointerEvidence: calib.evidence.realPointer,
    visionEvidence: calib.evidence.vision,
    elementEvidence: calib.evidence.elementChannel, elementInvoke: calib.evidence.elementInvoke,
  },
  artifacts: { results: ['results-real.json', 'results-element.json', 'results-real-slow120.json', 'results-real-prefix.json', 'calib.json'].map((f) => BASE + f), shots: 'D:\\dsh-arena\\bench\\shots\\' },
  generatedAt: new Date().toISOString(),
};
fs.writeFileSync('D:\\dsh-arena\\bench-real.json', JSON.stringify(out, null, 2), 'utf8');
console.log('saved D:\\dsh-arena\\bench-real.json');
for (const [k, v] of Object.entries({ 'real-pointer': realS, element: elemS, 'slow120': slowS, 'pre-fix': preS })) {
  console.log(`${k}: hits=${JSON.stringify(v.runs.map((r) => r.hits))} rate=${JSON.stringify(v.runs.map((r) => r.hitRate))} avg=${JSON.stringify(v.runs.map((r) => r.avgReactionMs))} median=${JSON.stringify(v.median)} range=${JSON.stringify(v.range)} cycle=${v.cycleLatencyMs.cycle}`);
  console.log(`   passes=${JSON.stringify(v.passes)}`);
}
