# run-all-w1.ps1 -- W1 serial desktop-owning measurements (ASCII only)
$env:TEMP='D:\dsh-tmp'; $env:TMP='D:\dsh-tmp'
$n = 'C:\Users\35126\AppData\Roaming\dsh-desktop\harness\.desktop-bin\node.cmd'
$log = 'D:\dsh-arena\bench\w1-run-all.log'
function Say($m) { $s = (Get-Date).ToString('HH:mm:ss') + ' ' + $m; Write-Output $s; Add-Content -Path $log -Value $s -Encoding UTF8 }

Say '=== START run-all-w1 ==='
Say '[cleanup] kill stale arena/keylat powershells'
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'arena-beat\.ps1|keylat|rawsink|clicklat-fixture' } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }
Start-Sleep -Seconds 2

Say '[1/5] keylat-e2e.mjs  (same-source QPC end-to-end, pre-injection/injection split)'
& $n D:\dsh-arena\bench\keylat\keylat-e2e.mjs 30 120 *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\keylat\keylat-e2e.stdout.txt
Say "[1/5] exit=$LASTEXITCODE"
Start-Sleep -Seconds 3

Say '[2/5] keylat-plugin-e2e.mjs  (MCP plugin paths, same-source QPC)'
& $n D:\dsh-arena\bench\keylat\keylat-plugin-e2e.mjs 20 500 *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\keylat\keylat-plugin-e2e.stdout.txt
Say "[2/5] exit=$LASTEXITCODE"
Start-Sleep -Seconds 3

Say '[3/5] l3-schedule2.mjs  (L3 timed sequence, keys via resident injector)'
& $n D:\dsh-arena\bench\l3-schedule2.mjs *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\l3-schedule2.stdout.txt
Say "[3/5] exit=$LASTEXITCODE"
Start-Sleep -Seconds 3

Say '[4/5] clicklat.mjs --mode real --trials 200 --x 40 --y 40'
& $n D:\dsh-arena\bench\clicklat.mjs --mode real --trials 200 --x 40 --y 40 *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\clicklat-real.stdout.txt
Say "[4/5] exit=$LASTEXITCODE"
Start-Sleep -Seconds 3

Say '[5/5] keylat-raw.mjs 20  (raw input / WM_INPUT discrimination)'
& $n D:\dsh-arena\bench\keylat\keylat-raw.mjs 20 *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\keylat\keylat-raw.stdout.txt
Say "[5/5] exit=$LASTEXITCODE"

Say '[cleanup] final kill'
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'arena-beat\.ps1|keylat|rawsink|clicklat-fixture|receiver\.ps1' } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }
Say '=== END run-all-w1 ==='
