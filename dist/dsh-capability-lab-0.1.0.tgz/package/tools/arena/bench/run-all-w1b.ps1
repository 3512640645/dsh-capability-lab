# run-all-w1b.ps1 -- W1 second pass (units fixed, desktop cleaned). ASCII only.
$env:TEMP='D:\dsh-tmp'; $env:TMP='D:\dsh-tmp'
$n = 'C:\Users\35126\AppData\Roaming\dsh-desktop\harness\.desktop-bin\node.cmd'
$log = 'D:\dsh-arena\bench\w1-run-all-b.log'
function Say($m) { $s = (Get-Date).ToString('HH:mm:ss') + ' ' + $m; Write-Output $s; Add-Content -Path $log -Value $s -Encoding UTF8 }

Say '=== START run-all-w1b ==='
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'arena-beat\.ps1|keylat|rawsink|clicklat-fixture|receiver\.ps1' } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }
Start-Sleep -Seconds 2

Say '[1/4] l3-schedule2.mjs  (L3 timed sequence, keys via resident injector)'
& $n D:\dsh-arena\bench\l3-schedule2.mjs *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\l3-schedule2.stdout.txt
Say "[1/4] exit=$LASTEXITCODE"
Start-Sleep -Seconds 3

Say '[2/4] keylat-e2e.mjs  (same-source QPC, pre-injection/injection split)'
& $n D:\dsh-arena\bench\keylat\keylat-e2e.mjs 30 120 *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\keylat\keylat-e2e.stdout.txt
Say "[2/4] exit=$LASTEXITCODE"
Start-Sleep -Seconds 3

Say '[3/4] keylat-plugin-e2e.mjs  (MCP plugin paths, same-source QPC)'
& $n D:\dsh-arena\bench\keylat\keylat-plugin-e2e.mjs 20 500 *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\keylat\keylat-plugin-e2e.stdout.txt
Say "[3/4] exit=$LASTEXITCODE"
Start-Sleep -Seconds 3

Say '[4/4] clicklat.mjs --mode real --trials 200 --x 40 --y 40'
& $n D:\dsh-arena\bench\clicklat.mjs --mode real --trials 200 --x 40 --y 40 *>&1 | Tee-Object -FilePath D:\dsh-arena\bench\clicklat-real.stdout.txt
Say "[4/4] exit=$LASTEXITCODE"

Say '[cleanup] final kill'
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'arena-beat\.ps1|keylat|rawsink|clicklat-fixture|receiver\.ps1' } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }
Say '=== END run-all-w1b ==='
