/**
 * DSH Arena 移动靶基准 · 正式跑分
 *
 * 两个通道，同一套靶场、同一套落盘口径，但**通道不可比**：
 *   · channel=real    → input.mjs 的真实指针通道：move/贝塞尔轨迹 + click（SetCursorPos + mouse_event）
 *   · channel=element → winctl 的元素通道：UIA find + invoke（不碰指针，元素在原地也能点）
 *
 * 真实指针通道的瞄准律（全部来自视觉，不读靶场内部状态）：
 *   1. 截图中点 → frame 时刻取"抓帧时刻" tFrame = 截图调用开始 + FRAME_MS
 *   2. 速度 vx：由最近两个视觉样本差分（窗口内出现方向反转就判为不可靠，本拍不点，只重拍）
 *   3. 提前量 lead = (now - tFrame) + 移动耗时中位数 + CLICK_DOWN_MS（点击调用开始→鼠标按下）
 *   4. 边界：棋盘矩形由图像颜色自定位 → 靶心圆心活动范围 = 棋盘内缩 StartRadiusPx+2
 *      再用"观测到的拐点"修正；预测点越过边界就本拍不点（拐点附近线性预测必错）
 *
 * 环境变量：CH=real|element  ROUNDS=3  DURATION=30  SPEED=240  LABEL=  STEPS=3
 *          FRAME_MS=40  CLICK_DOWN_MS=70  DRYRUN=0
 * 产出：D:\dsh-arena\bench\results-<ch><-label>.json（+ 每局 2 张截图存证）
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { connect, engineSender, killStaleArena, waitArenaWindow, closeArenaWindows, PS } from './client.mjs';
import { createEngine, readPointerPosition } from 'file:///D:/dsh-tools/aim/input.mjs';
import { decodePng, detectTargets, resolveCapture, imageToScreen } from 'file:///D:/dsh-tools/aim/vision.mjs';

const CFG = {
  channel: process.env.CH ?? 'real',
  rounds: Number(process.env.ROUNDS ?? 3),
  duration: Number(process.env.DURATION ?? 30),
  speed: Number(process.env.SPEED ?? 240),
  steps: Number(process.env.STEPS ?? 3),
  label: process.env.LABEL ?? '',
  startDelayMs: Number(process.env.START_DELAY ?? 5200),
  dryRun: process.env.DRYRUN === '1',
  color: process.env.COLOR ?? 'E8452C',
  frameMs: Number(process.env.FRAME_MS ?? 165),   // 截图调用开始 → 真正抓帧 的时刻（试跑标定：missLog 系统性多 30px ≈ 125ms）
  clickDownMs: Number(process.env.CLICK_DOWN_MS ?? 70),
  pad: 42,          // 圆心活动范围内缩量 = StartRadiusPx(40) + 2（靶场 XAML 同心几何，静态常量）
};
const ARENA = 'D:\\dsh-arena\\arena-move.ps1';
const RUNS = 'D:\\dsh-arena\\runs';
const SHOTS = 'D:\\dsh-arena\\bench\\shots';
const OUT = `D:\\dsh-arena\\bench\\results-${CFG.channel}${CFG.label ? '-' + CFG.label : ''}.json`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const med = (a) => { const s = [...(a ?? [])].filter((n) => Number.isFinite(n)).sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };

fs.mkdirSync(SHOTS, { recursive: true });
const result = { schema: 'dsh-arena/bench-runs/1', channel: CFG.channel, cfg: CFG, startedAt: new Date().toISOString(), runs: [], notes: [] };
const T0 = Date.now();
function note(k, v) { result.notes.push({ atMs: Date.now() - T0, k, v }); console.log(`[${((Date.now() - T0) / 1000).toFixed(1)}s] ${k}: ${JSON.stringify(v)?.slice(0, 700)}`); }

// ── 视觉自定位：棋盘矩形（纯颜色，不依赖窗口几何假设） ────────────────────
function findBoardRect(img) {
  const { width, height, data } = img;
  const isBoard = (i) => Math.abs(data[i] - 14) <= 8 && Math.abs(data[i + 1] - 23) <= 8 && Math.abs(data[i + 2] - 32) <= 8;
  const colHit = new Uint8Array(width), rowHit = new Uint8Array(height);
  const rowsTop = [Math.round(height * 0.08), Math.round(height * 0.2), Math.round(height * 0.35), Math.round(height * 0.5), Math.round(height * 0.65), Math.round(height * 0.8), Math.round(height * 0.92)];
  for (const y of rowsTop) for (let x = 0; x < width; x++) if (isBoard((y * width + x) * 4)) colHit[x]++;
  const colsTop = [Math.round(width * 0.08), Math.round(width * 0.3), Math.round(width * 0.5), Math.round(width * 0.7), Math.round(width * 0.92)];
  for (const x of colsTop) for (let y = 0; y < height; y++) if (isBoard((y * width + x) * 4)) rowHit[y]++;
  const run = (arr, need) => {   // 包含中点的最长连续段
    let best = null, i = 0;
    while (i < arr.length) {
      if (arr[i] < need) { i++; continue; }
      let j = i; while (j < arr.length && arr[j] >= need) j++;
      const cand = { a: i, b: j - 1 };
      const mid = Math.floor(arr.length / 2);
      if (cand.a <= mid && cand.b >= mid) best = cand;
      i = j;
    }
    return best;
  };
  const cx = run(colHit, rowsTop.length * 0.5), cy = run(rowHit, colsTop.length * 0.5);
  if (!cx || !cy) return null;
  return { x: cx.a, y: cy.a, width: cx.b - cx.a + 1, height: cy.b - cy.a + 1 };
}

// ── 运动模型：只用视觉样本（不读靶场内部状态） ──────────────────────────
class Tracker {
  constructor(boardScreen) {
    this.s = []; this.lastX = null; this.lastDir = 0;
    this.loEst = null; this.hiEst = null;
    this.board = boardScreen;   // { x, width } 屏幕坐标
  }
  /** 模式声明：圆心活动范围 = 棋盘内缩 pad */
  staticBounds() {
    if (!this.board) return { lo: null, hi: null };
    return { lo: this.board.x + CFG.pad, hi: this.board.x + this.board.width - CFG.pad };
  }
  reset() { this.s = []; this.lastX = null; this.lastDir = 0; this.loEst = null; this.hiEst = null; }
  add(t, x) {
    if (this.lastX != null) {
      const d = Math.sign(x - this.lastX);
      if (d !== 0) {
        if (this.lastDir !== 0 && d !== this.lastDir) {              // 刚跨过拐点
          if (this.lastDir > 0) this.hiEst = Math.max(this.hiEst ?? -1e9, this.lastX);
          else this.loEst = Math.min(this.loEst ?? 1e9, this.lastX);
        }
        this.lastDir = d;
      }
    }
    this.lastX = x;
    this.s.push({ t, x });
    if (this.s.length > 40) this.s.shift();
  }
  velocity() {
    if (this.s.length < 3) return { ok: false, reason: 'samples<3' };
    // 局部：最近 3 个样本最小二乘拟合；拐点落在窗口里时拟合残差会炸 → 判不可靠
    const use = this.s.slice(-3);
    const t0 = use[0].t, n = use.length;
    let st = 0, sx = 0, stt = 0, stx = 0;
    for (const p of use) { const dt = p.t - t0; st += dt; sx += p.x; stt += dt * dt; stx += dt * p.x; }
    const den = n * stt - st * st;
    if (!den) return { ok: false, reason: 'degenerate' };
    const slope = (n * stx - st * sx) / den;          // px/ms
    const vx = slope * 1000;
    let maxRes = 0;
    for (const p of use) maxRes = Math.max(maxRes, Math.abs(p.x - (sx / n + slope * ((p.t - t0) - st / n))));
    if (maxRes > 14) return { ok: false, reason: `fitResid=${maxRes.toFixed(1)}px(拐点)` };
    if (Math.abs(vx) < 120 || Math.abs(vx) > 400) return { ok: false, reason: `vx=${Math.round(vx)}不合理` };
    return { ok: true, vx, spanMs: Math.round(use[n - 1].t - use[0].t), maxRes: Number(maxRes.toFixed(1)), n };
  }
  /** 全局：三角波模型（速度+相位）最小二乘暴力拟合，拐点附近也能预测 */
  model() {
    if (this.s.length < 6) return null;
    const b = this.bounds();
    if (b.lo == null || b.hi == null || b.hi - b.lo < 200) return null;
    const use = this.s.slice(-14);
    const tRef = use[use.length - 1].t;
    const span = b.hi - b.lo;
    let best = null;
    for (let v = 140; v <= 340; v += 4) {
      const period = (2 * span / v) * 1000;
      for (let ph = 0; ph < period; ph += 25) {
        let se = 0, worst = 0;
        for (const p of use) {
          let rel = ((p.t - tRef + ph) % period + period) % period;
          const x = rel <= period / 2 ? b.lo + (rel / (period / 2)) * span : b.hi - ((rel - period / 2) / (period / 2)) * span;
          const e = Math.abs(x - p.x);
          se += e * e; if (e > worst) worst = e;
        }
        const rms = Math.sqrt(se / use.length);
        if (!best || rms < best.rms) best = { v, ph, rms, worst, period, tRef, lo: b.lo, hi: b.hi, n: use.length };
      }
    }
    if (!best || best.rms > 8) return null;
    return best;
  }
  static modelX(m, t) {
    let rel = ((t - m.tRef + m.ph) % m.period + m.period) % m.period;
    const span = m.hi - m.lo;
    return rel <= m.period / 2 ? m.lo + (rel / (m.period / 2)) * span : m.hi - ((rel - m.period / 2) / (m.period / 2)) * span;
  }
  bounds() {
    // 静态（视觉自定位棋盘 + 模式声明内缩）是准确值；拐点观测只在样本间隔内偏内侧，
    // 所以只能"放宽"不能"收紧"——收紧会把合法预测判成越界（第一轮 20 次空转就是这么来的）
    const sb = this.staticBounds();
    const lo = Math.min(sb.lo ?? 1e9, this.loEst ?? 1e9);
    const hi = Math.max(sb.hi ?? -1e9, this.hiEst ?? -1e9);
    return Number.isFinite(lo) && Number.isFinite(hi) && hi > lo
      ? { lo, hi, src: { static: sb, turn: { loEst: this.loEst, hiEst: this.hiEst }, rule: 'loose-only' } }
      : { lo: sb.lo, hi: sb.hi, src: { static: sb, turn: null } };
  }
}

async function see(c0, hwnd, savePath) {
  const t0 = Date.now();
  const shot = await c0.tool('screenshot', { nativeWindowHandle: hwnd, maxWidth: 0 });
  const tCap = Date.now();
  let img;
  try { img = decodePng(shot.png); } catch (e) { return { error: 'decode: ' + e.message, ms: { total: Date.now() - t0 }, t0 }; }
  const tDec = Date.now();
  const cap = resolveCapture({ bounds: shot.data.screenshot.bounds, imageScale: shot.data.screenshot.imageScale });
  const targets = detectTargets(img, { color: CFG.color, tolerance: 70, minArea: 150, sort: 'area' });
  const tDet = Date.now();
  const best = targets[0] ?? null;
  if (savePath && shot.png) fs.writeFileSync(savePath, shot.png);
  return {
    best, cap, png: shot.png, img, t0, tFrame: t0 + CFG.frameMs,
    shotMeta: shot.data?.screenshot ? { method: shot.data.screenshot.method, bounds: shot.data.screenshot.bounds, imageScale: shot.data.screenshot.imageScale } : null,
    ms: { capture: tCap - t0, decode: tDec - tCap, detect: tDet - tDec, total: tDet - t0 },
    screen: best ? imageToScreen(best.center, cap) : null,
  };
}

// ── 每局 ────────────────────────────────────────────────────────────────
async function runRound(i) {
  const rec = { round: i + 1, channel: CFG.channel, startedAt: new Date().toISOString(), cycles: [], errors: [], moveMsList: [], shotCount: 0 };
  await killStaleArena();
  const c0 = await connect();
  const pre = await closeArenaWindows(c0);
  if (pre.closed.length) rec.closedStale = pre.closed;
  await sleep(500);

  const runsBefore = new Set(fs.existsSync(RUNS) ? fs.readdirSync(RUNS) : []);
  const args = ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ARENA,
    '-Duration', String(CFG.duration), '-SpeedPxPerSec', String(CFG.speed), '-StartDelayMs', String(CFG.startDelayMs)];
  const child = spawn(PS, args, { stdio: 'ignore' });
  rec.launch = { cmd: `powershell.exe ${args.join(' ')}`, pid: child.pid };

  const { win } = await waitArenaWindow(c0);
  if (!win) { rec.errors.push('no arena window'); try { process.kill(child.pid); } catch { } await c0.close(); return rec; }
  const hwnd = win.nativeWindowHandle;
  const W = win.boundingBox;
  rec.window = { hwnd, boundingBox: W, className: win.className };

  let engine = null, sender = null, boardScreen = null;
  if (CFG.channel === 'real') {
    sender = engineSender(c0);
    const p0 = await readPointerPosition();
    engine = createEngine({
      sender, pointer: { x: p0.x, y: p0.y }, rawKey: null,
      stepMs: 15, maxSteps: 120, minSteps: 6, curvature: 0.18, easing: 'easeInOutSine',
      retry: { attempts: 2, backoffMs: [0, 30], timeoutMs: 15000 },
    });
    // 预热（一局未开始时靶 Hidden、画布点击不记分）：把冷启动耗时吃在开局之前
    const warm = [], tw = Date.now();
    const s = await c0.tool('screenshot', { nativeWindowHandle: hwnd, maxWidth: 0 });
    warm.push({ op: 'screenshot', ms: s.ms });
    if (s.png) { try { const im = decodePng(s.png); const br = findBoardRect(im); if (br) { boardScreen = { x: s.data.screenshot.bounds.x + br.x, y: s.data.screenshot.bounds.y + br.y, width: br.width, height: br.height }; } } catch { } }
    const a = await c0.tool('move', { x: Math.round(W.x + 60), y: Math.round(W.y + W.height - 90), nativeWindowHandle: hwnd });
    warm.push({ op: 'move', ms: a.ms, ok: !a.isError });
    const b = await c0.tool('move', { x: Math.round(W.x + W.width - 60), y: Math.round(W.y + 90), nativeWindowHandle: hwnd });
    warm.push({ op: 'move2', ms: b.ms, ok: !b.isError });
    const c = await c0.tool('click', { x: Math.round(W.x + 20), y: Math.round(W.y + W.height - 20), nativeWindowHandle: hwnd, dispatch: 'foreground' });
    warm.push({ op: 'click', ms: c.ms, ok: !c.isError });
    rec.warmup = { wallMs: Date.now() - tw, warm, boardRectVision: boardScreen };
    const ptr = await readPointerPosition();
    engine.setPointer(ptr.x, ptr.y);
    rec.pointerStart = ptr;
  }

  const tracker = new Tracker(boardScreen);
  let tRound0 = null;
  for (let k = 0; k < 40; k++) {
    if (CFG.channel === 'element') {
      const r = await c0.tool('find', { query: 'target', nativeWindowHandle: hwnd, maxResults: 8, ocrFallback: false, maxDepth: 8, maxNodes: 900, treeTimeoutMs: 3000 });
      const hit = (r.data?.results ?? []).find((h) => String(h.name ?? '').trim() === 'target');
      if (hit) { tRound0 = Date.now(); rec.firstElement = { ms: r.ms, boundingBox: hit.boundingBox }; break; }
    } else {
      const s = await see(c0, hwnd);
      if (s.best) {
        // 用"第一次看到靶心时的横坐标"反推这一局已经走了多久（速度是模式声明常量）→ 对齐局时钟
        const tInto = Math.min(1500, Math.max(0, ((s.screen.x - ((boardScreen?.x ?? (W.x + 22)) + CFG.pad)) / CFG.speed) * 1000));
        tRound0 = s.tFrame - tInto;
        rec.clockAlign = { firstXScreen: Math.round(s.screen.x), tIntoMs: Math.round(tInto) };
        tracker.add(s.tFrame, s.screen.x);
        break;
      }
    }
    await sleep(100);
  }
  if (!tRound0) rec.errors.push('target never appeared');
  const t0r = tRound0 ?? Date.now();
  const deadline = t0r + CFG.duration * 1000 - 900;
  const hardStop = t0r + CFG.duration * 1000 + 6000;

  let idx = 0;
  while (Date.now() < deadline) {
    idx++;
    const cyc = { n: idx, atMs: Date.now() - t0r };
    try {
      if (CFG.channel === 'element') {
        const t1 = Date.now();
        const r = await c0.tool('find', { query: 'target', nativeWindowHandle: hwnd, maxResults: 8, ocrFallback: false, maxDepth: 8, maxNodes: 900, treeTimeoutMs: 3000 });
        cyc.findMs = Date.now() - t1;
        const hit = (r.data?.results ?? []).find((h) => String(h.name ?? '').trim() === 'target');
        if (!hit) { cyc.error = 'target gone'; rec.cycles.push(cyc); break; }
        cyc.element = { id: hit.id, bbox: hit.boundingBox };
        const t2 = Date.now();
        const cl = await c0.tool('click', { elementId: hit.id, nativeWindowHandle: hwnd });
        cyc.clickMs = Date.now() - t2;
        cyc.isError = cl.isError;
        cyc.cycleMs = Date.now() - t1;
        cyc.reply = (cl.text ?? '').replace(/\s+/g, ' ').slice(0, 200);
      } else {
        const shotPath = (rec.shotCount < 2) ? path.join(SHOTS, `${CFG.channel}${CFG.label ? '-' + CFG.label : ''}-r${i + 1}-c${idx}.png`) : null;
        const s = await see(c0, hwnd, shotPath);
        cyc.see = s.ms;
        if (shotPath) { cyc.shot = path.basename(shotPath); rec.shotCount++; }
        if (!s.best) { cyc.error = 'no target in view'; rec.cycles.push(cyc); break; }
        cyc.detected = { screen: { x: Math.round(s.screen.x), y: Math.round(s.screen.y) }, radius: Number(s.best.radius.toFixed(2)), area: s.best.area, circularity: Number(s.best.circularity.toFixed(3)) };
        tracker.add(s.tFrame, s.screen.x);
        const est = tracker.velocity();
        const moveMed = med(rec.moveMsList) ?? 175;
        const futureMs = (Date.now() - s.tFrame) + moveMed + CFG.clickDownMs;
        const tClick = Date.now() + moveMed + CFG.clickDownMs;
        let model = null, p = null, src = null;
        const bnd = tracker.bounds();
        if (est.ok) {
          const pc = s.screen.x + est.vx * (futureMs / 1000);
          const out = bnd.lo != null && bnd.hi != null && (pc > bnd.hi || pc < bnd.lo);
          if (!out) { p = pc; src = 'local'; }
          else { model = tracker.model(); if (model) { p = Tracker.modelX(model, tClick); src = 'triangle-model(拐点)'; } }
        } else {
          model = tracker.model();
          if (model) { p = Tracker.modelX(model, tClick); src = 'triangle-model(局部拟合失效)'; }
        }
        cyc.est = est;
        if (model) cyc.model = { v: model.v, rms: Number(model.rms.toFixed(2)), worst: Number(model.worst.toFixed(1)), n: model.n, periodMs: Math.round(model.period) };
        if (p == null) { cyc.skipped = 'velocity:' + est.reason + (model ? '' : '/模型不可用'); rec.cycles.push(cyc); await sleep(60); continue; }
        cyc.lead = { futureMs: Math.round(futureMs), vx: est.ok ? Math.round(est.vx) : null, source: src, predictedX: Math.round(p), bounds: { lo: bnd.lo == null ? null : Math.round(bnd.lo), hi: bnd.hi == null ? null : Math.round(bnd.hi) }, boundsSrc: { loFromTurn: bnd.src?.turn?.loEst != null, hiFromTurn: bnd.src?.turn?.hiEst != null } };
        const aimRaw = { x: Math.round(p), y: Math.round(s.screen.y) };
        const aim = { x: Math.min(Math.max(aimRaw.x, W.x + 8), W.x + W.width - 8), y: Math.min(Math.max(aimRaw.y, W.y + 8), W.y + W.height - 8) };
        cyc.aim = aim;
        cyc.clamped = { dx: aim.x - aimRaw.x, dy: aim.y - aimRaw.y };
        if (CFG.dryRun) { cyc.dryRun = true; rec.cycles.push(cyc); await sleep(200); continue; }
        const t3 = Date.now();
        const m = await engine.moveTo(aim.x, aim.y, 150, { stepMs: 50, minSteps: 2, maxSteps: CFG.steps, nativeWindowHandle: hwnd, curvature: 0.15 });
        cyc.moveMs = Date.now() - t3;
        cyc.move = { steps: m.steps, plannedMs: m.plannedMs, elapsedMs: m.elapsedMs, driftMs: m.driftMs, ok: m.ok, error: m.error ?? null, avgStepMs: m.avgStepMs, lastPoint: m.to };
        rec.moveMsList.push(cyc.moveMs);
        const t4 = Date.now();
        const c = await engine.click(aim.x, aim.y, { durationMs: 1, stepMs: 15, minSteps: 1, maxSteps: 1, settleMs: 0, nativeWindowHandle: hwnd, dispatch: 'foreground' });
        cyc.clickMs = Date.now() - t4;
        cyc.click = { ok: c.ok, elapsedMs: c.elapsedMs, error: c.error ?? null };
        cyc.cycleMs = Date.now() - s.tFrame;
        cyc.reply = (sender.lastRaw?.text ?? '').replace(/\s+/g, ' ').slice(0, 200);
      }
      rec.cycles.push(cyc);
    } catch (e) {
      cyc.error = String(e?.message ?? e); rec.errors.push(cyc.error); rec.cycles.push(cyc);
      if (rec.errors.length > 6) break;
    }
    if (Date.now() > hardStop) break;
    await sleep(15);
  }
  rec.loopDoneAtMs = Date.now() - t0r;

  let runFile = null, runJson = null;
  for (let k = 0; k < 70; k++) {
    const after = fs.existsSync(RUNS) ? fs.readdirSync(RUNS) : [];
    const nf = after.filter((f) => !runsBefore.has(f)).map((f) => path.join(RUNS, f)).sort().pop();
    if (nf) { runFile = nf; break; }
    await sleep(500);
  }
  if (runFile) { try { runJson = JSON.parse(fs.readFileSync(runFile, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { rec.errors.push('json parse: ' + e.message); } }
  rec.arenaRun = runJson ? {
    file: path.basename(runFile), mode: runJson.mode, elapsedMs: runJson.elapsedMs,
    hits: runJson.hits, misses: runJson.misses, hitRate: runJson.hitRate,
    avgReactionMs: runJson.avgReactionMs, medianReactionMs: runJson.medianReactionMs,
    minReactionMs: runJson.minReactionMs, maxReactionMs: runJson.maxReactionMs, p90ReactionMs: runJson.p90ReactionMs,
    reactionMs: runJson.reactionMs, motion: runJson.motion, board: runJson.board,
    targets: (runJson.targets ?? []).map((t) => ({ id: t.id, cx: t.cx, cy: t.cy, r: t.r, screenX: t.screenX, screenY: t.screenY, tHitMs: t.tHitMs, reactionMs: t.reactionMs, aimPx: t.aim?.pxFromCenter ?? null })),
    missLog: runJson.missLog ?? [],
  } : null;
  rec.cyclesDone = rec.cycles.length;
  rec.cycleLatency = {
    see: med(rec.cycles.map((c) => c.see?.total)), findMs: med(rec.cycles.map((c) => c.findMs)),
    move: med(rec.cycles.map((c) => c.moveMs)), click: med(rec.cycles.map((c) => c.clickMs)),
    cycle: med(rec.cycles.map((c) => c.cycleMs)), skipped: rec.cycles.filter((c) => c.skipped).length,
  };

  const cl = await closeArenaWindows(c0);
  try { process.kill(child.pid); } catch { }
  await sleep(400);
  rec.cleanup = { ...cl, stale: await killStaleArena() };
  await c0.close();
  rec.endedAt = new Date().toISOString();
  return rec;
}

for (let i = 0; i < CFG.rounds; i++) {
  note(`round${i + 1}.start`, { channel: CFG.channel, speed: CFG.speed, duration: CFG.duration });
  const rec = await runRound(i);
  result.runs.push(rec);
  note(`round${i + 1}.done`, {
    hits: rec.arenaRun?.hits, misses: rec.arenaRun?.misses, hitRate: rec.arenaRun?.hitRate,
    avgReactionMs: rec.arenaRun?.avgReactionMs, cycles: rec.cyclesDone, skipped: rec.cycleLatency?.skipped,
    boardVision: rec.warmup?.boardRectVision, cycleLatency: rec.cycleLatency, errors: rec.errors,
  });
}
result.endedAt = new Date().toISOString();
fs.writeFileSync(OUT, JSON.stringify(result, null, 2), 'utf8');
console.log('\n[saved] ' + OUT);
