/**
 * stagecost.mjs — 拍内各阶段的现场成本分解（只测量，不改任何东西）
 *
 * 目的：证明"每拍 480ms 花在哪"，并给出优化后各阶段的落差。
 * 测 6 条路径（各自 n=N）：
 *   plugin.screenshot / plugin.move / plugin.click
 *   inj.ping / inj.mouse(click=1) / inj.mouse(click=0)
 * 靶场用 Duration=3 开一局，等它打完（结果面板显示、running=false），
 * 之后所有点击打在面板上 → 不给靶场记分、不污染多局成绩。
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { connect, killStaleArena, waitArenaWindow, closeArenaWindows, PS } from './client.mjs';
import { startInjector } from './keylat/keyclient.mjs';

const N = Number(process.env.N ?? 30);
const DEL = process.env.DEL === '1';           // 每拍截图后立刻删掉插件的临时 PNG（消除目录膨胀）
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const tmpShotCount = () => { try { return fs.readdirSync('D:\\dsh-tmp').filter((f) => /^windows-computer-use-.*\.png$/.test(f)).length; } catch { return null; } };
const slope = (ys) => {                       // 逐样本线性斜率（ms/样本）
  const n = ys.length, xs = ys.map((_, i) => i);
  const mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n;
  const num = xs.reduce((a, x, i) => a + (x - mx) * (ys[i] - my), 0), den = xs.reduce((a, x) => a + (x - mx) ** 2, 0);
  return den ? +(num / den).toFixed(3) : null;
};
const stat = (a) => {
  const s = [...a].filter(Number.isFinite).sort((x, y) => x - y);
  if (!s.length) return null;
  const p = (q) => s[Math.min(s.length - 1, Math.max(0, Math.ceil(s.length * q) - 1))];
  return { n: s.length, p50: +p(0.5).toFixed(2), p90: +p(0.9).toFixed(2), max: +s.at(-1).toFixed(2), min: +s[0].toFixed(2) };
};

const out = { schema: 'dsh-arena/stagecost/1', generatedAt: new Date().toISOString(), n: N, ops: {}, errors: [] };

await killStaleArena();
const c0 = await connect();
const inj = await startInjector();
const child = spawn(PS, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', 'D:\\dsh-arena\\arena-move.ps1',
  '-Duration', '3', '-SpeedPxPerSec', '240', '-StartDelayMs', '0'], { stdio: 'ignore' });
try {
  const { win } = await waitArenaWindow(c0, { tries: 60, intervalMs: 400 });
  if (!win) throw new Error('arena window 没出现');
  const hwnd = win.nativeWindowHandle, W = win.boundingBox;
  out.window = { hwnd, bbox: W, title: win.name };
  await sleep(5000);   // 等这一局(3s)打完 → 面板可见、running=false
  await inj.focus(hwnd);

  const shot = [], mv = [], cl = [], ping = [], imc = [], imm = [], injOvh = [];
  const shotSeries = []; let deleted = 0;
  out.preShots = { count: tmpShotCount(), del: DEL };
  // 预热（不计入）
  await c0.tool('screenshot', { nativeWindowHandle: hwnd, maxWidth: 0 });
  await c0.tool('move', { x: Math.round(W.x + 40), y: Math.round(W.y + 40), nativeWindowHandle: hwnd });
  await c0.tool('click', { x: Math.round(W.x + 60), y: Math.round(W.y + 60), nativeWindowHandle: hwnd, dispatch: 'foreground' });
  await inj.mouse(W.x + 80, W.y + 80);
  await sleep(200);

  for (let i = 0; i < N; i++) {
    const x = Math.round(W.x + 60 + (i * 7) % 300), y = Math.round(W.y + 60 + (i * 11) % 260);
    let t = Date.now(); const sh = await c0.tool('screenshot', { nativeWindowHandle: hwnd, maxWidth: 0 }); const dt = Date.now() - t;
    shot.push(dt); shotSeries.push(dt);
    if (DEL) { const p = sh.data?.screenshot?.path; if (p) { try { fs.unlinkSync(p); deleted++; } catch { } } }
    t = Date.now(); await c0.tool('move', { x, y, nativeWindowHandle: hwnd }); mv.push(Date.now() - t);
    t = Date.now(); await c0.tool('click', { x, y, nativeWindowHandle: hwnd, dispatch: 'foreground' }); cl.push(Date.now() - t);
    t = Date.now(); await inj.ping(); ping.push(Date.now() - t);
    t = Date.now(); const r1 = await inj.mouse(x, y); imc.push(Date.now() - t); if (r1.ovh != null) injOvh.push(r1.ovh);
    t = Date.now(); await inj.mouse(x + 3, y + 3, { click: false }); imm.push(Date.now() - t);
    await sleep(5);
  }
  Object.assign(out.ops, {
    'plugin.screenshot(maxWidth=0)': stat(shot),
    'plugin.move': stat(mv),
    'plugin.click(fg)': stat(cl),
    'injector.ping': stat(ping),
    'injector.mouse(click=1)': stat(imc),
    'injector.mouse(click=0)': stat(imm),
    'injector.SetCursorPos→LEFTDOWN(ovh)': stat(injOvh),
  });
  out.shotSeries = shotSeries;
  out.shotSlopeMsPerSample = slope(shotSeries);
  out.postShots = { count: tmpShotCount(), deleted };
  out.injectorStats = inj.stats();
} catch (e) {
  out.errors.push(String(e?.message ?? e));
} finally {
  try { await closeArenaWindows(c0); } catch { }
  try { process.kill(child.pid); } catch { }
  await sleep(300);
  try { await inj.close(); } catch { }
  try { await killStaleArena(); } catch { }
  try { await c0.close(); } catch { }
}
const OUT = 'D:\\dsh-arena\\bench\\stagecost.json';
fs.writeFileSync(OUT, JSON.stringify(out, null, 2), 'utf8');
console.log(JSON.stringify(out, null, 2));
console.log('[saved] ' + OUT);
