/**
 * w1-aggregate.mjs —— W1 本轮四项复跑的机读汇总
 * 输入（全部现场生成）：l3-timing2.json / keylat-e2e.json / keylat-plugin-e2e.json /
 *                        keylat-raw.json / clicklat real2-<ts> summary.json / l1-rerun.json
 * 输出：D:\dsh-arena\bench-l3-rerun.json
 */
import fs from 'node:fs';
import path from 'node:path';

const A = 'D:\\dsh-arena', K = path.join(A, 'bench', 'keylat');
const rd = (p) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { return { __error: String(e.message), __path: p }; } };
const r3 = (v) => (v == null || !isFinite(v) ? null : Math.round(v * 1000) / 1000);
const agg = (a) => { const v = a.filter((x) => typeof x === 'number' && isFinite(x)); if (!v.length) return { n: 0 }; const s = [...v].sort((x, y) => x - y); const q = (f) => s[Math.min(s.length - 1, Math.floor(f * s.length))]; return { n: s.length, min: r3(s[0]), med: r3(q(0.5)), p90: r3(q(0.9)), p99: r3(q(0.99)), max: r3(s[s.length - 1]), mean: r3(s.reduce((x, y) => x + y, 0) / s.length) }; };

const l3 = rd(path.join(A, 'bench', 'l3-timing3.json'));            // v3：点击+按键都走常驻注入器（主口径）
const l3prev = rd(path.join(A, 'bench', 'l3-timing2.json'));        // v2：只有按键走注入器（过程留证）
const e2e = rd(path.join(K, 'keylat-e2e.json'));
const plug = rd(path.join(K, 'keylat-plugin-e2e.json'));
const raw = rd(path.join(K, 'keylat-raw.json'));
const l1 = rd(path.join(A, 'bench', 'l1-rerun.json'));

// clicklat real（取最新一次 real*/ 目录；real2-* 是协作式夹具跑通的）
const clDir = (() => {
  const base = path.join(A, 'bench', 'clicklat');
  const ds = fs.existsSync(base) ? fs.readdirSync(base).filter((d) => d.startsWith('real')) : [];
  const good = ds.filter((d) => d.startsWith('real2-')).sort();
  const all = ds.sort();
  return (good.length ? good[good.length - 1] : (all.length ? all[all.length - 1] : null)) && path.join(base, good.length ? good[good.length - 1] : all[all.length - 1]);
})();
const cl = clDir ? rd(path.join(clDir, 'summary.json')) : { __error: 'no real run' };
const clRows = clDir && fs.existsSync(path.join(clDir, 'trials.jsonl'))
  ? fs.readFileSync(path.join(clDir, 'trials.jsonl'), 'utf8').split(/\r?\n/).filter(Boolean).map((l) => JSON.parse(l)) : [];
const clReal = clRows.filter((r) => r.mode === 'real_inject');
const clSkip = clRows.filter((r) => r.mode === 'real_skipped');

const out = {
  schema: 'dsh-arena/bench-l3-rerun/1',
  generatedAt: new Date().toISOString(),
  host: { machine: process.env.COMPUTERNAME, qpcNote: 'Stopwatch.GetTimestamp() = QPC，同机全局一致；本机 freq=10000000（1 tick = 0.1µs）' },
  // ── 证据链 ──────────────────────────────────────────────
  evidence: {
    l3Timing: 'D:\\dsh-arena\\bench\\l3-timing2.json',
    keylatE2e: 'D:\\dsh-arena\\bench\\keylat\\keylat-e2e.json',
    keylatPluginE2e: 'D:\\dsh-arena\\bench\\keylat\\keylat-plugin-e2e.json',
    keylatRaw: 'D:\\dsh-arena\\bench\\keylat\\keylat-raw.json',
    clicklatReal: clDir, l1: 'D:\\dsh-arena\\bench\\l1-rerun.json',
    l1Report: l1.summary?.source ?? null,
  },

  // ── Q1 按键端到端延迟（同源 QPC，分注入前/注入两段）─────────
  q1_keys: {
    clock: { freq: e2e.qpc?.freq ?? null, calib: e2e.calib ?? null, note: '注入器与靶场各自用 Stopwatch.GetTimestamp()；Node 决定点用 ping 最小延迟法标到同一 QPC。全链路无 Date.now' },
    paths: (e2e.rounds ?? []).map((x) => ({
      key: x.key, round: x.name, mode: x.mode, delivered: x.got, lost: x.loss, late: x.late,
      preTotalMs: x.preTotal, prePipeMs: x.prePipe, preParseMs: x.preParse,
      injectMs: x.inject, e2eMs: x.e2e, apiCallMs: x.apiCall, eventKinds: x.kinds,
    })),
    pluginPaths: (plug.cases ?? []).map((c) => ({ label: c.label, method: c.method, delivered: c.delivered, lost: c.lost, callMs: c.call, e2eMs: c.e2e, arrivesBeforeCallReturns: c.arrivesBeforeCallReturns })),
    rawInputDiscrimination: (raw.phases ?? []).map((p) => ({ name: p.name, sinkIsFg: p.sinkIsFg, msgDown: p.msgDown, msgChar: p.msgChar, rawInput: p.rawInput, rawDown: p.rawDown })),
    priorRound: { pluginCallMedMs: [316.117, 289.749, 173.524, 299.282], note: '本轮插件实测调用中位（同源口径），用于拆解上一轮 296–604ms' },
  },

  // ── Q2 L1 真值 ─────────────────────────────────────────
  q2_l1: l1.summary ? {
    declaredTasks: l1.summary.tasksDeclared, ranTasks: l1.summary.classes, skipped: l1.summary.skipped,
    overall: l1.summary.overall, effective: l1.summary.effective,
    falseOkTotal: l1.summary.falseOkTotal, envBlockedTotal: l1.summary.envBlockedTotal,
    invalidClasses: l1.summary.invalidClasses,
    perClass: l1.classes.map((c) => ({ id: c.id, name: c.name, naiveRate: c.naive.rate, naiveMeanMs: c.naive.msMean, winctlRate: c.winctl.rate, winctlMeanMs: c.winctl.msMean, falseOk: [c.naive.falseOk, c.winctl.falseOk], envBlocked: [c.naive.envBlocked, c.winctl.envBlocked] })),
  } : l1,

  // ── Q3 指针点击真机基线 ────────────────────────────────
  q3_pointerReal: {
    dir: clDir, mode: cl.mode, rows: cl.rows, occlusionSkips: cl.occlusion_skips,
    targetScreen: cl.target_screen, windowVisible: cl.window_visible, fixtureError: cl.error ?? null,
    qpcFreq: cl.qpc_freq, apiBaselineUs: cl.api_baseline_us,
    delivered: clReal.length, skipped: clSkip.length,
    setPosMs: agg(clReal.map((r) => r.setpos_ms)),
    downCallMs: agg(clReal.map((r) => r.downcall_ms)),
    appDownEndToEndMs: agg(clReal.map((r) => r.app_down_ms)),
    appUpMs: agg(clReal.map((r) => r.app_up_ms)),
    hitRate: clReal.length ? r3(clReal.filter((r) => r.handler_seen).length / clReal.length) : null,
    targetInsideForm: clReal.length ? r3(clReal.filter((r) => String(r.hit_client ?? '').length > 0 && r.hit_client !== '0,0').length / clReal.length) : null,
    skipReason: clSkip.length ? { visibleFalse: clSkip.filter((r) => !r.visible).length, underNotOurs: clSkip.filter((r) => !r.under_is_ours).length, fgNotOurs: clSkip.filter((r) => !r.foreground_is_ours).length, sampleUnderHwnd: clSkip[0]?.under_hwnd ?? null, oursHwnd: clSkip[0]?.ours_hwnd ?? null } : null,
    triedAndFailed: [
      { dir: 'real-20261106214023 / real-20261106214717 / real-20261106214840', why: '原始夹具独立启动时 real_skipped=200/200' },
      { dir: 'real2-20261106220029 / real2-20261106220145', why: '协作式夹具：前台拿到了，但 IsWindowVisible=false → 指针命中桌面' },
    ],
    fix: '夹具改为「先报 HWND 等放行」+ 驱动外部 ShowWindow(SW_SHOW)+SetWindowPos(TOPMOST|NOSIZE|NOMOVE|SHOWWINDOW) 强制可见 + 常驻注入器 AttachThreadInput+Alt 轻敲抢前台；测量语义未变（仍是 SetCursorPos+mouse_event、两侧同源 QPC 打点）',
  },

  // ── Q4 L3 定时序列复跑 ─────────────────────────────────
  q4_l3: l3.stats ? {
    variant: l3.variant, n: l3.stats.n, clicks: l3.stats.clicks, keys: l3.stats.keys,
    caliber1_relativeToFirst: { med: l3.stats.devMedianMs, p90: l3.stats.devP90Ms, max: l3.stats.devMaxMs, min: l3.stats.devMinMs },
    caliber2_wallClockLate: { med: l3.stats.wallLateMedianMs, max: l3.stats.wallLateMaxMs },
    caliber3_sameSourceLate: (() => {
      const SW0 = Number(l3.header?.swZeroQpc ?? NaN), FQ = Number(l3.header?.qpcFreq ?? 1e7);
      const anchor = l3.anchor?.sameSourceQpc ?? null;
      return {
        med: l3.stats.ssLateMedianMs, p90: l3.stats.ssLateP90Ms, max: l3.stats.ssLateMaxMs, min: l3.stats.ssLateMinMs,
        anchorQpc: anchor,
        anchorMinusSwZeroMs: anchor != null ? r3((anchor - SW0) / FQ * 1000) : null,
        wallCutSwMs: l3.raw?.cutSw ?? null,
        anchorCrossCheckMs: anchor != null && l3.raw?.cutSw != null ? r3((anchor - SW0) / FQ * 1000 - l3.raw.cutSw) : null,
        note: '同源锚点 = min(issueQpc − atMs)；与墙钟切点 cutSw 的差就是同一件事两个时钟读法的差（应 ≈ 0）',
      };
    })(),
    clickDevMaxMs: l3.stats.clickDevMaxMs, keyDevMaxMs: l3.stats.keyDevMaxMs,
    arrivalLatency: { all: l3.stats.arrivalLatMedianMs, click: l3.stats.arrivalLatClickMedMs, key: l3.stats.arrivalLatKeyMedMs },
    clientStats: l3.clientStats, foregroundCheck: l3.foregroundCheck ?? null,
    passes: l3.stats.passes, errors: l3.errors, warnings: l3.warnings,
    intermediateStep: l3prev.stats ? {
      variant: l3prev.variant, note: '只把按键换成常驻注入器、点击仍走插件',
      caliber1Max: l3prev.stats.devMaxMs, caliber3: { med: l3prev.stats.ssLateMedianMs, max: l3prev.stats.ssLateMaxMs },
      arrivalLatClick: l3prev.stats.arrivalLatClickMedMs, arrivalLatKey: l3prev.stats.arrivalLatKeyMedMs,
      passes: l3prev.stats.passes,
    } : null,
    perBeat: (l3.perBeat ?? []).map((e) => ({ i: e.i, kind: e.actualKind, plan: e.plannedAtMs, actual: e.actualSwMs, dev: e.devMs, ssLate: e.absLateSameSourceMs ?? null, wallLate: e.absLateWallMs, arrLat: e.arrivalLatencyMs, callMs: e.clientCallMs, tool: e.callTool })),
  } : l3,
};
fs.writeFileSync('D:\\dsh-arena\\bench-l3-rerun.json', JSON.stringify(out, null, 2), 'utf8');

const j = (o) => JSON.stringify(o);
console.log('=== Q1 按键同源 QPC（ms）===');
for (const p of out.q1_keys.paths) console.log(`${p.round.padEnd(20)} ${String(p.mode).padEnd(9)} 到达 ${p.delivered}/${p.delivered + p.lost} | 注入前 p50=${p.preTotalMs.med} (管道 ${p.prePipeMs.med} + 解析 ${p.preParseMs.med}) | 注入 p50=${p.injectMs.med} p90=${p.injectMs.p90} max=${p.injectMs.max} | 端到端 p50=${p.e2eMs.med}`);
console.log('插件路径: ' + out.q1_keys.pluginPaths.map((p) => `${p.label} ${p.method} 到达 ${p.delivered}/${p.delivered + p.lost} 端到端中位 ${p.e2eMs.med} 调用中位 ${p.callMs.med}`).join(' | '));
console.log('raw 判别: ' + out.q1_keys.rawInputDiscrimination.map((p) => `${p.name}: msg+${p.msgDown}/+${p.msgChar} raw+${p.rawInput}`).join(' | '));
console.log('\n=== Q2 L1 ===');
console.log(`声明9类/实跑${out.q2_l1.ranTasks}/跳过${j(out.q2_l1.skipped)} | 总体 naive ${(out.q2_l1.overall.naive.rate * 100).toFixed(1)}% winctl ${(out.q2_l1.overall.winctl.rate * 100).toFixed(1)}% | 有效分母 n=${out.q2_l1.effective.n} 成功率 ${(out.q2_l1.effective.rate * 100).toFixed(1)}% | 假达标 ${out.q2_l1.falseOkTotal} | 遮挡 ${out.q2_l1.envBlockedTotal}`);
console.log('\n=== Q3 指针真机 ===');
console.log(`目录 ${out.q3_pointerReal.dir} 注入 ${out.q3_pointerReal.delivered} 跳过 ${out.q3_pointerReal.skipped} 目标点 ${out.q3_pointerReal.targetScreen} 错误 ${out.q3_pointerReal.fixtureError}`);
console.log(`setpos ${j(out.q3_pointerReal.setPosMs)}`);
console.log(`端到端 app_down ${j(out.q3_pointerReal.appDownEndToEndMs)}  命中率 ${out.q3_pointerReal.hitRate}  跳过原因 ${j(out.q3_pointerReal.skipReason)}`);
console.log('\n=== Q4 L3 ===');
console.log(`口径①相对首拍 max=${out.q4_l3.caliber1_relativeToFirst?.max} | 口径②墙钟迟到 med=${out.q4_l3.caliber2_wallClockLate?.med} max=${out.q4_l3.caliber2_wallClockLate?.max} | 口径③同源迟到 med=${out.q4_l3.caliber3_sameSourceLate?.med} max=${out.q4_l3.caliber3_sameSourceLate?.max}`);
console.log(`点击拍 max|dev|=${out.q4_l3.clickDevMaxMs} 按键拍 max|dev|=${out.q4_l3.keyDevMaxMs} 到达延迟 点击=${out.q4_l3.arrivalLatency?.click} 按键=${out.q4_l3.arrivalLatency?.key} 前台自检=${j(out.q4_l3.foregroundCheck)}`);
console.log(`passes ${j(out.q4_l3.passes)} errors ${j(out.q4_l3.errors)} warnings ${j(out.q4_l3.warnings)}`);
console.log('\nJSON -> D:\\dsh-arena\\bench-l3-rerun.json');
