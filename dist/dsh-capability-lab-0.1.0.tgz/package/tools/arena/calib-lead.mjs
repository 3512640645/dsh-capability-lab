import fs from 'node:fs';
const cal = JSON.parse(fs.readFileSync('D:\\dsh-arena\\bench\\results-real-cal.json', 'utf8')).runs[0];
const v1 = JSON.parse(fs.readFileSync('D:\\dsh-arena\\bench\\results-real-l3-6.json', 'utf8')).runs;
const med = (a) => { const s = [...a].filter(Number.isFinite).sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };
const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);

// v2：命中拍的 |误差| 与 vx → 求"帧龄被低估"的毫秒数 δ = |err|/|vx|*1000
const t = cal.arenaRun.targets;
const cl = cal.cycles.filter((c) => c.click);
const errs = t.map((x) => x.aimPx);
const vxs = cl.map((c) => Math.abs(c.lead?.vx ?? 0));
const deltas = errs.map((e, i) => (e / vxs[i]) * 1000);
console.log('=== v2(注入器通道) 标定 ===');
console.log('  命中拍 n =', errs.length, ' |误差| mean =', mean(errs).toFixed(1), 'px  p50 =', med(errs), 'px  max =', Math.max(...errs));
console.log('  对应 vx mean =', mean(vxs).toFixed(1), 'px/s');
console.log('  推得帧龄低估 δ = |err|/vx : mean =', mean(deltas).toFixed(1), 'ms  p50 =', med(deltas).toFixed(1), 'ms  p90 =', [...deltas].sort((a, b) => a - b)[Math.floor(deltas.length * 0.9)].toFixed(1));
console.log('  有效提前量 lead(futureMs) p50 =', med(cl.map((c) => c.lead?.futureMs)), 'ms');
console.log('  → 建议 frameMs = 165 + δ ≈', Math.round(165 + mean(deltas)), 'ms');
// 误差 vs 半径：证明"半径收缩到阈值以下就成片空点"
const r = t.map((x) => x.r);
const pairs = errs.map((e, i) => ({ e, r: r[i] }));
const early = pairs.filter((p) => p.r > 30), late = pairs.filter((p) => p.r <= 25);
console.log('  半径>30px 拍: n =', early.length, '|误差| mean =', mean(early.map((p) => p.e)).toFixed(1));
console.log('  半径≤25px 拍: n =', late.length, '|误差| mean =', mean(late.map((p) => p.e)).toFixed(1));
console.log('  空点 n =', cal.arenaRun.misses, ' 空点 |dx| 分布 =', cal.arenaRun.missLog.map((m) => Math.abs(m.dx).toFixed(1)).join(', '));
console.log('  空点半径 =', cal.arenaRun.missLog.map((m) => m.r).join(', '));

console.log('\n=== v1(插件通道) 同口径对照（6 局合并）===');
const a1 = [], r1 = [], d1 = [];
for (const run of v1) {
  const tt = run.arenaRun.targets; const cc = run.cycles.filter((c) => c.click);
  for (let i = 0; i < tt.length; i++) { if (tt[i]?.aimPx == null) continue; a1.push(tt[i].aimPx); r1.push(tt[i].r); const vx = Math.abs(cc[i]?.lead?.vx ?? 0); if (vx) d1.push((tt[i].aimPx / vx) * 1000); }
}
console.log('  命中拍 n =', a1.length, ' |误差| mean =', mean(a1).toFixed(1), 'px  p50 =', med(a1), '  max =', Math.max(...a1));
console.log('  推得帧龄低估 δ mean =', mean(d1).toFixed(1), 'ms  p50 =', med(d1).toFixed(1), 'ms');
console.log('  v1 每局空点 =', v1.map((x) => x.arenaRun.misses).join(', '), '｜每局尾包(>900) =', v1.map((x) => x.arenaRun.reactionMs.filter((v) => v > 900).length).join(', '));
console.log('  v1 尾包半径（出现尾包那一拍）:');
for (const run of v1) { const tt = run.arenaRun.targets; const rr = run.arenaRun.reactionMs; const tail = rr.map((v, i) => ({ v, i })).filter((x) => x.v > 900); console.log('    ' + run.arenaRun.file + ': ' + tail.map((x) => `#${x.i + 1} r=${tt[x.i]?.r ?? '?'}`).join(' | ')); }
