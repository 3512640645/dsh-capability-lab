import fs from 'node:fs';
import path from 'node:path';

const res = JSON.parse(fs.readFileSync('D:\\dsh-arena\\bench\\results-real-l3-6.json', 'utf8'));
const RUNS = 'D:\\dsh-arena\\runs';
const q = (a, p) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.min(s.length - 1, Math.max(0, Math.ceil(s.length * p) - 1))] : null; };
const med = (a) => { const s = [...a].filter(Number.isFinite).sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };
const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);

const agg = { tailPreamble: [], tailSee: [], basePreamble: [], baseSee: [], tailDCross: [] };
const lines = [];

for (const r of res.runs) {
  const rn = JSON.parse(fs.readFileSync(path.join(RUNS, r.arenaRun.file), 'utf8'));
  const react = rn.reactionMs;
  const cyc = r.cycles;
  // 拍序列：非 skip 的 cycle 才真正点击（element 通道另论）；real 通道：有 cyc.click 的才点
  const clicks = cyc.filter((c) => c.click);
  const rMed = med(react);
  lines.push(`\n════ 第 ${r.round} 局 ${r.arenaRun.file}  命中 ${rn.hits} 拍  avg=${rn.avgReactionMs}  拍中位=${rMed}  cycles=${cyc.length}  非点击拍=${cyc.length - clicks.length}`);
  const rows = [];
  for (let i = 0; i < react.length; i++) {
    const c = clicks[i];
    if (!c) { lines.push(`  hit#${i + 1} ${react[i]}ms  ← 找不到对应点击拍`); continue; }
    const ci = cyc.indexOf(c);
    // 前一拍（含 skip）到本拍的间隙：本拍 atMs − 上一拍 atMs
    const prev = cyc[ci - 1];
    const prevClick = clicks[i - 1];
    const preGap = c.atMs - (prev?.atMs ?? 0);
    // 从"上一次命中"到"本拍截图开始"的空转：本拍 atMs − 上一点击拍的 cycleMs 结束
    const idleMs = prevClick ? (c.atMs - (prevClick.atMs + (prevClick.cycleMs ?? 0))) : c.atMs;
    const skippedBetween = c.skippedBetween ?? 0;
    rows.push({ i: i + 1, reaction: react[i], seeTotal: c.see?.total, seeCap: c.see?.capture, det: c.see?.detect, moveMs: c.moveMs, clickMs: c.clickMs, cycleMs: c.cycleMs, idleMs: Math.round(idleMs), preGap: Math.round(preGap), estOk: c.est?.ok, src: c.lead?.source, aimPx: rn.targets?.[i]?.aim?.pxFromCenter });
  }
  // 相对前一拍的"额外空转" = 本拍反应 − 上一拍反应 − 本拍 cycleMs 之外的成分
  for (const x of rows) {
    const isTail = x.reaction > 900;
    (isTail ? agg.tailPreamble : agg.basePreamble).push(x.idleMs);
    (isTail ? agg.tailSee : agg.baseSee).push(x.seeTotal);
    if (isTail) lines.push(`  ⚠ hit#${x.i} reaction=${x.reaction}ms  see=${x.seeTotal}(cap${x.seeCap}/det${x.det}) move=${x.moveMs} click=${x.clickMs} cycle=${x.cycleMs} 帧间空转=${x.idleMs}ms 前一拍间隔=${x.preGap}ms vOk=${x.estOk} src=${x.src} aimPx=${x.aimPx}`);
  }
  lines.push('  --- 逐拍 reaction / 帧间空转 / see合计 / move / click ---');
  for (const x of rows) lines.push(`   #${String(x.i).padStart(2)} r=${String(x.reaction).padStart(4)} idle=${String(x.idleMs).padStart(4)} see=${String(x.seeTotal).padStart(3)} move=${String(x.moveMs).padStart(3)} click=${String(x.clickMs).padStart(3)} cycle=${String(x.cycleMs).padStart(3)} ${x.src ?? '-'}`);
}

console.log(lines.join('\n'));
const s = (a) => `n=${a.length} mean=${mean(a)?.toFixed(1)} p50=${med(a)} p90=${q(a, 0.9)} max=${a.length ? Math.max(...a) : null}`;
console.log('\n===== 相关性汇总 =====');
console.log('尾包(>900ms) 帧间空转 idle :', s(agg.tailPreamble));
console.log('基线(<900ms) 帧间空转 idle :', s(agg.basePreamble));
console.log('尾包 see.total           :', s(agg.tailSee));
console.log('基线 see.total           :', s(agg.baseSee));
