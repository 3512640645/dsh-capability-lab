import fs from 'node:fs';
const f = process.argv[2];
const j = JSON.parse(fs.readFileSync(f, 'utf8'));
const r = j.runs[0];
const react = r.arenaRun.reactionMs;
const cyc = r.cycles;
const clicks = cyc.filter((c) => c.click);
const q = (a, p) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[Math.min(s.length - 1, Math.max(0, Math.ceil(s.length * p) - 1))] : null; };
const med = (a) => { const s = [...a].filter(Number.isFinite).sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : null; };
console.log('局:', r.arenaRun.file, 'hits', r.arenaRun.hits, 'misses', r.arenaRun.misses, 'avg', r.arenaRun.avgReactionMs, 'cycles', cyc.length, '非点击拍', cyc.length - clicks.length);
console.log('reaction 分布: p50', q(react, 0.5), 'p90', q(react, 0.9), 'p99', q(react, 0.99), 'max', Math.max(...react), '>700', react.filter((v) => v > 700).length, '>900', react.filter((v) => v > 900).length);
console.log('reactions:', react.join(', '));
const aims = r.arenaRun.targets.map((t) => t.aimPx);
console.log('命中拍 aimPx 分布: mean', (aims.reduce((a, b) => a + b, 0) / aims.length).toFixed(1), 'p50', med(aims), 'p90', q(aims, 0.9), 'max', Math.max(...aims));
console.log('missLog:', JSON.stringify(r.arenaRun.missLog));
console.log('\n--- 每拍: reaction / idle / see / cycle / lead / vx / src / aimPx ---');
for (let i = 0; i < react.length; i++) {
  const c = clicks[i];
  if (!c) { console.log(` #${i + 1} r=${react[i]} (找不到点击拍)`); continue; }
  const ci = cyc.indexOf(c);
  const prev = clicks[i - 1];
  const idle = prev ? Math.round(c.atMs - (prev.atMs + (prev.cycleMs ?? 0))) : Math.round(c.atMs);
  const flag = react[i] > 700 ? ' ⚠' : '';
  console.log(` #${String(i + 1).padStart(2)} r=${String(react[i]).padStart(4)} idle=${String(idle).padStart(4)} see=${String(c.see?.total).padStart(3)} cyc=${String(c.cycleMs).padStart(3)} lead=${String(c.lead?.futureMs).padStart(3)} vx=${String(c.lead?.vx).padStart(4)} src=${String(c.lead?.source).padEnd(28)} aimPx=${String(r.arenaRun.targets[i]?.aimPx).padStart(5)} r=${r.arenaRun.targets[i]?.r}${flag}`);
}
console.log('\n--- 非点击拍(空转) ---');
for (const c of cyc.filter((x) => !x.click)) console.log(` n=${c.n} atMs=${Math.round(c.atMs)} skipped=${c.skipped} error=${c.error ?? ''} see=${c.see?.total}`);
