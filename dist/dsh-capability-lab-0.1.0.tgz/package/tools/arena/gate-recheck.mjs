// 复刻第 11 项闸门的候选选择逻辑，确认它现在（以及新写入报告后）仍选中优化后的多局数据
import fs from 'node:fs';
import path from 'node:path';
const ARENA = 'D:\\dsh-arena';
const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
function extractSeries(j) {
  const tries = [
    ['endurance3min.rounds[].avgReactionMs', () => (j.endurance3min?.rounds ?? []).map((r) => num(r?.avgReactionMs))],
    ['runs[].arenaRun.avgReactionMs', () => (j.runs ?? []).map((r) => num(r?.arenaRun?.avgReactionMs))],
    ['runs[].avgReactionMs', () => (j.runs ?? []).map((r) => num(r?.avgReactionMs ?? r?.arenaRun?.avgReactionMs))],
    ['channels.*.runs[].avgReactionMs', () => Object.values(j.channels ?? {}).flatMap((c) => (c?.runs ?? []).map((r) => num(r?.avgReactionMs)))],
  ];
  for (const [label, get] of tries) {
    let s = [];
    try { s = get(); } catch { s = []; }
    s = s.filter((x) => x !== null);
    if (s.length >= 2) return { label, series: s };
  }
  return null;
}
const cands = [];
(function walk(dir) {
  let ents = [];
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const d of ents) {
    const p = path.join(dir, d.name);
    if (d.isDirectory()) { walk(p); continue; }
    if (!/\.json$/i.test(d.name)) continue;
    let j = null, st = null;
    try { st = fs.statSync(p); j = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { continue; }
    const ex = extractSeries(j);
    if (!ex) continue;
    cands.push({ rel: path.relative(ARENA, p), mtimeMs: st.mtimeMs, label: ex.label, series: ex.series });
  }
})(ARENA);
cands.sort((a, b) => b.mtimeMs - a.mtimeMs);
const benchReal = cands.find((c) => /^bench-real\.json$/i.test(c.rel)) ?? null;
const pick = cands.find((c) => !/^bench-real\.json$/i.test(c.rel)) ?? benchReal;
const s = pick.series, first = s[0], last = s.at(-1);
const ageH = (Date.now() - pick.mtimeMs) / 3600000;
console.log('候选（按 mtime 倒序，仅列前 6）:');
for (const c of cands.slice(0, 6)) console.log(`  ${c.rel}  ${c.series.length}局  ${new Date(c.mtimeMs).toISOString()}  抽取=${c.label}`);
console.log('\n闸门会选：', pick.rel, '|', s.length, '局 | 新鲜度', ageH.toFixed(2) + 'h');
console.log('  逐局', s.join(' → '), 'ms');
console.log('  a) 首→末', (((last - first) / first) * 100).toFixed(2) + '%', '≤10% →', (last - first) / first <= 0.1);
console.log('  b) 末局', last, '≤700 →', last <= 700);
console.log('  c) 越线局数', s.filter((v) => v > 700).length, '= 0 →', s.filter((v) => v > 700).length === 0);
console.log('  结论 →', ((last - first) / first <= 0.1 && last <= 700 && s.filter((v) => v > 700).length === 0) ? 'PASS' : 'FAIL');
