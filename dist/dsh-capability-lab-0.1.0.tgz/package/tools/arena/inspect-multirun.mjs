import fs from 'node:fs';
const files = process.argv.slice(2);
for (const f of files) {
  let j = null;
  try { j = JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { console.log('===', f, 'PARSE-FAIL', e.message); continue; }
  console.log('===', f, 'mtime', fs.statSync(f).mtime.toISOString());
  console.log('  topkeys:', Object.keys(j).join(','));
  if (j.endurance3min) {
    const e = j.endurance3min;
    console.log('  endurance3min keys:', Object.keys(e).join(','), '| rounds=', (e.rounds || []).length);
    for (const r of e.rounds || []) console.log('   round', r.round, 'avg', r.avgReactionMs, 'p90', r.p90ReactionMs, 'max', r.maxReactionMs, 'hits', r.hits, 'file', r.file);
  }
  if (Array.isArray(j.runs)) {
    console.log('  runs=', j.runs.length);
    for (const r of j.runs) console.log('   r', r.round, 'avg', r.avgReactionMs, '| ar.avg', r.arenaRun?.avgReactionMs, '| ar.file', r.arenaRun?.file, '| keys', Object.keys(r).join('|'));
  }
}
