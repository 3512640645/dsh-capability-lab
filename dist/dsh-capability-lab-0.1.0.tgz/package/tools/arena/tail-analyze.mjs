import fs from 'node:fs';
import path from 'node:path';

const runsDir = 'D:\\dsh-arena\\runs';
const files = process.argv.slice(2);
const q = (a, p) => {
  if (!a.length) return null;
  const s = [...a].sort((x, y) => x - y);
  const i = Math.min(s.length - 1, Math.max(0, Math.ceil(s.length * p) - 1));
  return s[i];
};
const st = (a) => {
  const n = a.length;
  if (!n) return {};
  const mean = a.reduce((x, y) => x + y, 0) / n;
  const sd = Math.sqrt(a.reduce((x, y) => x + (y - mean) ** 2, 0) / n);
  const s = [...a].sort((x, y) => x - y);
  return {
    n, mean: +mean.toFixed(1), sd: +sd.toFixed(1),
    p50: q(a, 0.5), p90: q(a, 0.9), p99: q(a, 0.99), max: s.at(-1), min: s[0],
    over700: a.filter((v) => v > 700).length,
    over900: a.filter((v) => v > 900).length,
    over1000: a.filter((v) => v > 1000).length,
  };
};

const allTail = [];
console.log('file'.padEnd(30), 'n  mean    p50  p90  p99  max  >700 >900');
for (const name of files) {
  const p = path.join(runsDir, name);
  const j = JSON.parse(fs.readFileSync(p, 'utf8'));
  const r = j.reactionMs ?? [];
  const s = st(r);
  console.log(name.padEnd(30), String(s.n).padEnd(3), String(s.mean).padEnd(7), String(s.p50).padEnd(4), String(s.p90).padEnd(4), String(s.p99).padEnd(4), String(s.max).padEnd(4), String(s.over700).padEnd(4), s.over900);
  for (const v of r) if (v > 900) allTail.push({ name, v, idx: r.indexOf(v) });
  // per-hit detail: hits log with reactionMs ordered
  console.log('   reactions:', r.join(', '));
}
console.log('\n=== 尾包（>900ms）清单 ===');
for (const t of allTail) console.log(`  ${t.name} 第${t.idx + 1}次命中 reactionMs=${t.v}`);
console.log('尾包总数', allTail.length);
