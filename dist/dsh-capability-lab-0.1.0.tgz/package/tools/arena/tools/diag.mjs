/** DSH Arena · UIA 诊断：看 WPF 窗口到底暴露了哪些元素 */
import { connect, findWindows } from 'file:///D:/dsh-tools/winctl/mcp.mjs';

const client = await connect();
const wins = await findWindows(client, { maxWindows: 120 });
const arenas = wins.filter((w) => /DSH\s*Arena/i.test(w.name ?? ''));
console.log('DSH Arena windows:', arenas.map((w) => ({ h: w.nativeWindowHandle, pid: w.processId, box: w.boundingBox, cls: w.className })));
const win = arenas[0];
if (!win) { console.log('no window'); await client.close(); process.exit(0); }

for (const q of ['target', 'arenaTarget', 'arena-board', '重开', '得分', '剩余', '本局结束']) {
  const r = await client.tool('find', { query: q, nativeWindowHandle: win.nativeWindowHandle, maxResults: 10, ocrFallback: false, maxDepth: 10, maxNodes: 1500, treeTimeoutMs: 4000 });
  const hits = (r.data?.results ?? []).map((h) => ({ id: h.id, name: h.name, ct: h.controlType, aid: h.automationId, box: h.boundingBox && [h.boundingBox.x, h.boundingBox.y, h.boundingBox.width, h.boundingBox.height] }));
  console.log(`\n--- find "${q}" -> ${hits.length}`); console.log(JSON.stringify(hits, null, 1));
}

const tree = await client.tool('accessibility_tree', { nativeWindowHandle: win.nativeWindowHandle, maxDepth: 8, maxNodes: 400 });
console.log('\n--- accessibility_tree (raw, truncated 6000) ---');
console.log((tree.text ?? '').slice(0, 6000));
await client.close();
