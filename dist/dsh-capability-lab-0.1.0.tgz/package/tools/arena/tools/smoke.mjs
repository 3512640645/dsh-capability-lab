/**
 * DSH Arena 冒烟自检（走 winctl 元素通道，不用像素坐标）
 *
 *  1) 拉起 arena.ps1（WPF 窗口；先把可能残留的旧窗口关掉）
 *  2) list_windows        → 能枚举到 "DSH Arena"
 *  3) find "target"       → 能通过 UIA 拿到目标元素（name/automationId/controlType/boundingBox）
 *  4) 反复 find + click   → 元素通道打靶（同时证明靶心每次都在换位置）
 *  5) 等一局自然结束       → 读新落盘的 runs\run-*.json
 *  6) close_window        → 关窗确认
 *
 * 运行： & "<node.cmd>" D:\dsh-arena\tools\smoke.mjs
 */
import { connect, findWindows } from 'file:///D:/dsh-tools/winctl/mcp.mjs';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const PS = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
const ARENA = 'D:\\dsh-arena\\arena.ps1';
const RUNS = 'D:\\dsh-arena\\runs';
const DURATION = Number(process.env.ARENA_DURATION ?? 25);
const CLICKS = Number(process.env.ARENA_CLICKS ?? 8);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const J = (o) => JSON.stringify(o, null, 1);

const FindArgs = { maxResults: 12, ocrFallback: false, maxDepth: 8, maxNodes: 900, treeTimeoutMs: 3000 };
const report = { schema: 'dsh-arena/smoke/1', startedAt: new Date().toISOString(), steps: [] };
function step(name, data) { report.steps.push({ step: name, at: new Date().toISOString(), ...data }); console.log(`\n===== ${name} =====\n${J(data)}`); }

const client = await connect();
step('2.connect', { mcp: 'dsh-computer-use-win（长连接会话）', mode: process.env.WCU_MODE ?? 'full' });

// 清掉可能残留的旧窗口，保证本次自检只面对一个新窗口
let pre = await findWindows(client, { maxWindows: 120 });
const stale = pre.filter((w) => /DSH\s*Arena/i.test(w.name ?? ''));
for (const w of stale) await client.tool('close_window', { nativeWindowHandle: w.nativeWindowHandle });
if (stale.length) { await sleep(1200); step('1.preclean', { closedStaleArenaWindows: stale.map((w) => w.nativeWindowHandle) }); }

const runsBefore = new Set(fs.existsSync(RUNS) ? fs.readdirSync(RUNS) : []);
const arenaArgs = ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', ARENA, '-Duration', String(DURATION), '-StartDelayMs', '3000'];
const child = spawn(PS, arenaArgs, { stdio: 'ignore' });
step('1.launch', { cmd: `powershell.exe ${arenaArgs.join(' ')}`, pid: child.pid, durationSec: DURATION });

// ── 窗口枚举 ────────────────────────────────────────────────────────────
let wins = [], win = null;
for (let i = 0; i < 40 && !win; i++) {
  wins = await findWindows(client, { maxWindows: 120 });
  win = wins.find((w) => /DSH\s*Arena/i.test(w.name ?? '')) ?? null;
  if (!win) await sleep(500);
}
step('3.list_windows', {
  totalWindowCount: wins.length,
  matched: win ? { title: win.name, nativeWindowHandle: win.nativeWindowHandle, className: win.className, processId: win.processId, boundingBox: win.boundingBox } : null,
  otherTitles: wins.filter((w) => w !== win).slice(0, 10).map((w) => w.name),
});
if (!win) { console.error('FAIL: 没枚举到 DSH Arena 窗口'); await client.close(); process.exit(2); }
const hwnd = win.nativeWindowHandle;

async function findTarget() {
  const t0 = Date.now();
  const r = await client.tool('find', { query: 'target', nativeWindowHandle: hwnd, ...FindArgs });
  const hits = r.data?.results ?? [];
  const hit = hits.find((h) => h.id && String(h.name ?? '').trim() === 'target') ?? null;
  return { hit, hits, ms: Date.now() - t0, raw: (r.text ?? '').replace(/\s+/g, ' ').slice(0, 260) };
}

let first = null;
for (let i = 0; i < 30 && !first; i++) {
  const f = await findTarget();
  if (f.hit) { first = f; break; }
  await sleep(500);
}
step('4.find "target"', {
  found: Boolean(first?.hit), queryMs: first?.ms ?? null,
  element: first?.hit ? { id: first.hit.id, name: first.hit.name, controlType: first.hit.controlType, automationId: first.hit.automationId, boundingBox: first.hit.boundingBox } : null,
  rawResultSample: first?.raw ?? null,
});
if (!first?.hit) { console.error('FAIL: UIA 找不到 name="target" 的元素'); await client.close(); process.exit(3); }

// ── 元素通道打靶 ────────────────────────────────────────────────────────
const rows = [];
for (let i = 1; i <= CLICKS; i++) {
  const f = await findTarget();
  if (!f.hit) { rows.push({ round: i, error: 'target 不在树里（本局已结束）' }); break; }
  const t1 = Date.now();
  const c = await client.tool('click', { elementId: f.hit.id, nativeWindowHandle: hwnd });
  const clickMs = Date.now() - t1;
  await sleep(150);
  const s = await client.tool('find', { query: '得分', nativeWindowHandle: hwnd, maxResults: 6, ocrFallback: false, treeTimeoutMs: 2000 });
  const scoreEl = (s.data?.results ?? []).find((x) => /得分/.test(x.name ?? ''));
  const h = await client.tool('find', { query: '命中', nativeWindowHandle: hwnd, maxResults: 6, ocrFallback: false, treeTimeoutMs: 2000 });
  const hitEl = (h.data?.results ?? []).find((x) => /命中/.test(x.name ?? ''));
  rows.push({
    round: i, findMs: f.ms, clickMs, clickError: c.isError === true,
    targetCenter: f.hit.boundingBox ? { x: f.hit.boundingBox.centerX, y: f.hit.boundingBox.centerY } : null,
    clickReply: (c.text ?? '').replace(/\s+/g, ' ').slice(0, 150),
    scoreShown: scoreEl?.name ?? null, hitsShown: hitEl?.name ?? null,
  });
}
step('5.element-channel clicks', { clicks: rows.length, rows });

// ── 等本局自然结束 ─────────────────────────────────────────────────────
let ended = false;
for (let i = 0; i < 60 && !ended; i++) {
  const r = await client.tool('wait_for', { condition: 'element', query: '本局结束', nativeWindowHandle: hwnd, scope: 'desktop', timeoutMs: 3000, intervalMs: 250 });
  ended = !r.isError && (r.data?.verification === 'observed' || r.data?.found === true || r.data?.observed === true);
  if (!ended) {
    const list = await findWindows(client, { maxWindows: 120 });
    if (!list.find((w) => w.nativeWindowHandle === hwnd)) break;
  }
}
step('6.round-end panel', { resultPanelVisible: ended });
await sleep(1500);

const runsAfter = fs.existsSync(RUNS) ? fs.readdirSync(RUNS) : [];
const newRuns = runsAfter.filter((f) => !runsBefore.has(f));
const latest = newRuns.map((f) => path.join(RUNS, f)).sort().pop();
let runJson = null;
if (latest) { try { runJson = JSON.parse(fs.readFileSync(latest, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { runJson = { parseError: String(e).slice(0, 120) }; } }
step('7.run json', {
  newFiles: newRuns, latest, summary: runJson && {
    score: runJson.score, hits: runJson.hits, misses: runJson.misses, hitRate: runJson.hitRate,
    avgReactionMs: runJson.avgReactionMs, minReactionMs: runJson.minReactionMs, maxReactionMs: runJson.maxReactionMs,
    p90ReactionMs: runJson.p90ReactionMs, reactionMs: runJson.reactionMs,
    elapsedMs: runJson.elapsedMs, aborted: runJson.aborted, uia: runJson.uia,
  },
});

// ── 关窗 ───────────────────────────────────────────────────────────────
const cw = await client.tool('close_window', { nativeWindowHandle: hwnd });
await sleep(1500);
const after = await findWindows(client, { maxWindows: 120 });
const stillThere = after.find((w) => w.nativeWindowHandle === hwnd || /DSH\s*Arena/i.test(w.name ?? ''));
step('8.close_window', { isError: cw.isError === true, reply: (cw.text ?? '').replace(/\s+/g, ' ').slice(0, 160), windowGone: !stillThere, arenaProcStillAlive: (() => { try { process.kill(child.pid, 0); return true; } catch { return false; } })() });

report.endedAt = new Date().toISOString();
fs.writeFileSync('D:\\dsh-arena\\smoke-report.json', JSON.stringify(report, null, 2), 'utf8');
console.log('\n[saved] D:\\dsh-arena\\smoke-report.json');
await client.close();
