#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""规格驱动的配乐生成器（v4）。

与 v3 的唯一结构性差别：**时间轴不再写在代码里**。
和弦进行、音效事件全部读自场景 JSON 的 `audio` 块 —— 与画面同一份数据。

v5 增补（仅本文件，spec 只读）：
  结构  段落角色（引子/主歌/副歌/尾奏）→ 层数 + 宏增益两层能量差，ARRANGE 常量区可调
  动态  目标 LRA ≥ 5 LU（副歌更满 / 主歌留白），原有 7 项质检不得回退
  转场  段落切换处按角色表自动排布 riser / impact / 落音，并与 spec 已有事件去重

  node engine/render.mjs --spec scenes/x.json ...     # 画面
  python tools/make-audio.py --spec scenes/x.json      # 声音
                                                      ↑ 同一份 spec

事件类型（写进 spec 的 audio.events）：
  whoosh  {t,dur,amp,f0,f1,up,seed}       过场气流
  bell    {t,freq,amp,pan}                铃音
  click   {t,tone,amp,pan}                界面点按
  impact  {t,amp}                         低频下坠
  riser   {t,dur,amp,f0,f1,seed}          上行张力
  series  {t,count,gap,tone,step,amp,panFrom,panTo}   等间隔一串短音
  ramp    {t,count,span,tone0,tone1,amp0,amp1,panFrom,panTo}  音高上行的一串
"""
import argparse
import json
import math
import os
import subprocess
import wave

import numpy as np

SR = 48000
OUT_DIR = r"D:\dsh-video\out"
FFMPEG = r"D:\dsh-video\tools\ffmpeg\ffmpeg.exe"

# ═══════════════════════ 转场门控（transition gate）常量区 ═══════════════════════
# 问题：母带链里 air(7.5k+) / shimmer(4-11k) / midlayer(1-4k) 三层噪声**常驻**，
#       跟随 prog 连续起伏 → 频谱被一直填满，听感"糊"。
# 方案：三层只在「转场时刻」附近开窗出现，窗外衰减到接近 0。
#       时刻取自 spec.audio.events 里 whoosh / impact / bell 的 t。
# 全部参数集中在这里，改完直接重跑即可，不用动下面的 DSP。
GATE_ENABLE = True          # False = 回到 v4 的常驻噪声行为（便于 A/B）
GATE_TYPES = ("whoosh", "impact", "bell")   # 哪些事件类型负责开窗
GATE_HALF_WINDOW_S = 0.60   # 以事件时刻 t 为中心的半窗宽（秒）
GATE_LEAD_S = 0.0           # 窗口整体提前量（秒）：>0 让噪声层略早于冲击点进入
GATE_COVER_EVENT_DUR = True # whoosh/riser 这类带 dur 的，窗口右侧至少盖住事件时长
GATE_DUR_PAD_S = 0.10       # 覆盖事件时长时右侧多留的余量（秒）
GATE_ATTACK_S = 0.07        # 窗内爬升时间（秒）
GATE_RELEASE_S = 0.45       # 出窗衰减时间（秒）——越长越"化开"，越短越"点状"
GATE_FLOOR = 0.04           # 窗外残留增益（0 = 完全静音，0.04 ≈ -28dB 近 0 底噪）
GATE_CURVE = 1.0            # 窗形指数，>1 更点状、<1 更铺开
GATE_MERGE_GAP_S = 0.25     # 相邻窗间隔小于此值就合并，避免门抖动
GATE_MIN_WINDOW_S = 0.10    # 单窗最短长度（秒）
# 三层噪声在「窗内」的相对增益（窗外一律乘 gate）
# 注意：原值 0.030/0.020/0.028 是常驻写法；改成门控后窗内可适当抬高，
#       用"转场更亮 / 铺底更干净"的反差换 LRA（抬高会同时抬高 10k+ 占比，别超 12%）。
GATE_AIR_GAIN = 0.045       # 常驻原值 0.030
GATE_SHIMMER_GAIN = 0.030   # 常驻原值 0.020
GATE_MIDLAYER_GAIN = 0.036  # 常驻原值 0.028
GATE_INCLUDE_RISER_TAIL = True   # riser 只开"尾窗"（张力堆到段落边界那一刻最亮）
GATE_RISER_TAIL_FRAC = 0.55      # 尾窗从 riser 时长的这个比例处开始

# ═══════════════════════ 结构编排常量区（v5：引子/主歌/副歌/尾奏） ═══════════════════════
# 问题：v4 每个段落用完全相同的层数与力度 → 45s 一条平线，LRA≈4.0 LU。
# 方案：两层能量差叠加
#   1) 层数差：引子 2 声部 / 主歌 3 / 副歌 4+高八度 / 尾奏收束（自然能量差）
#   2) 宏增益：段落级 gain_db 连续自动化（段间平滑，避免台阶感）
# 转场音（riser/impact/落音）不再手写：按角色表在段落边界自动排布，与 spec 已有事件去重。
ARRANGE_ENABLE = True
ROLE_FALLBACK = ("intro", "verse", "chorus", "verse", "chorus", "chorus", "outro")
ROLE_PLAN = {
    #           声部数   pad    bass   arp   琶音网格  arp音长(重拍,弱拍) texture  air(高频层) 宏增益
    "intro":  dict(pad_voices=2, pad=0.60, bass=0.56, arp=0.42, arp_step=0.93, arp_hit=(1.30, 0.80),
                   texture=0.42, air=0.55, gain_db=-3.2, octave=False),
    "verse":  dict(pad_voices=3, pad=0.80, bass=0.78, arp=0.66, arp_step=0.62, arp_hit=(1.50, 0.85),
                   texture=0.55, air=0.85, gain_db=-1.8, octave=False),
    "chorus": dict(pad_voices=4, pad=1.00, bass=1.00, arp=1.00, arp_step=0.41, arp_hit=(1.50, 0.62),
                   texture=0.88, air=1.15, gain_db=0.0, octave=True),
    "outro":  dict(pad_voices=3, pad=0.72, bass=0.62, arp=0.40, arp_step=1.24, arp_hit=(2.20, 1.20),
                   texture=0.38, air=0.55, gain_db=-4.0, octave=False),
}
ARR_SMOOTH_S = 0.45       # 段落宏增益/高频层力的段间平滑时间（秒）
ARR_MIN_GAIN_DB = -6.0    # 宏衰减下限（防止某段被压成空洞）
AUTO_TRANS_ENABLE = True  # 段落切换处自动排布转场音
TRANS_PLAN = {
    #            riser=(时长, 幅度, f0, f1) 结束点压在段落边界   impact 幅度   落音=(结尾前秒数, 幅度)
    "intro":  dict(riser=None,                      impact=0.0,  fall=None),
    "verse":  dict(riser=(1.10, 0.034, 190, 720),   impact=0.0,  fall=None),
    "chorus": dict(riser=(1.45, 0.062, 200, 1150),  impact=0.17, fall=None),
    "outro":  dict(riser=(1.20, 0.032, 150, 520),   impact=0.0,  fall=(1.10, 0.13)),
}
TRANS_DEDUPE_S = 0.80     # 边界窗口内已有同类 spec 事件就不再自动补，避免叠成双响
TRANS_ARP_LEAD_S = 0.35   # 引子先留白，让开场 whoosh/bell 单独站住

ap = argparse.ArgumentParser()
ap.add_argument('--spec', default=r'D:\dsh-video\engine\scenes\dsh-phone-access.json')
ap.add_argument('--out', default=os.path.join(OUT_DIR, 'audio-spec.wav'))
args = ap.parse_args()

SPEC = json.load(open(args.spec, encoding='utf-8'))
DUR = float(SPEC.get('duration', 45.0))
AUDIO = SPEC.get('audio', {})
TARGET_LUFS = float(AUDIO.get('target_lufs', -15))
TARGET_PEAK = 0.79
N = int(SR * DUR) + SR
rng = np.random.default_rng(20261101)

print(f"场景: {SPEC.get('title')}  {DUR}s  调性 {AUDIO.get('key','-')}")
print(f"和弦段 {len(AUDIO.get('sections', []))} · 音效事件 {len(AUDIO.get('events', []))}")


# ═══════════════════════ DSP（与 v3 相同，已验证） ═══════════════════════
def t_of(n): return np.arange(n) / SR


def adsr(n, a=0.01, d=0.1, s=0.8, r=0.3, curve=2.0):
    e = np.zeros(n)
    ai, di, ri = int(a * SR), int(d * SR), int(r * SR)
    si = max(0, n - ai - di - ri)
    idx = 0
    if ai: e[idx:idx + ai] = np.linspace(0, 1, ai) ** 0.7; idx += ai
    if di: e[idx:idx + di] = np.linspace(1, s, di) ** (1 / curve); idx += di
    if si: e[idx:idx + si] = s; idx += si
    if ri and idx < n: e[idx:] = np.linspace(s, 0, n - idx) ** curve
    return e


def lowpass(x, cutoff, order=1):
    if cutoff >= SR / 2: return x
    y = x
    for _ in range(order):
        a = math.exp(-2 * math.pi * cutoff / SR); acc = 0.0
        out = np.empty_like(y)
        for i in range(len(y)):
            acc = (1 - a) * y[i] + a * acc; out[i] = acc
        y = out
    return y


def highpass(x, cutoff, order=1): return x - lowpass(x, cutoff, order)


def saw(freq, n, harmonics=9):
    t = t_of(n); out = np.zeros(n)
    for h in range(1, harmonics + 1): out += np.sin(2 * np.pi * freq * h * t) / h
    return out * 0.6


def triangle(freq, n, harmonics=7):
    t = t_of(n); out = np.zeros(n)
    for h in range(1, harmonics + 1, 2):
        out += ((-1) ** ((h - 1) // 2)) * np.sin(2 * np.pi * freq * h * t) / (h * h)
    return out * 1.2


def sine(freq, n): return np.sin(2 * np.pi * freq * t_of(n))


def make_ir(seconds=2.4, decay=3.2, damp=3800):
    n = int(SR * seconds)
    ir = rng.normal(0, 1, n) * np.exp(-np.arange(n) / SR * decay)
    ir = lowpass(ir, damp)
    ir[: int(0.004 * SR)] *= np.linspace(0, 1, int(0.004 * SR))
    return ir / (np.sqrt(np.sum(ir ** 2)) + 1e-9)


IR = make_ir()
FFT_N = 1 << int(math.ceil(math.log2(N + len(IR))))


def reverb(x, wet=0.35, pre=0.012):
    pad = np.zeros(len(x) + int(pre * SR)); pad[int(pre * SR):] = x
    y = np.fft.irfft(np.fft.rfft(pad, FFT_N) * np.fft.rfft(IR, FFT_N), FFT_N)[:len(x)]
    y /= np.max(np.abs(y)) + 1e-9
    return x * (1 - wet) + y * wet * (np.max(np.abs(x)) + 1e-9)


def pad_note(freq, dur, amp=0.12, detune=0.004, cutoff=2600):
    n = int(SR * dur); out = np.zeros(n)
    for d in (-detune, 0.0, detune): out += saw(freq * (1 + d), n, 7)
    out += saw(freq * 2, n, 5) * 0.38
    return amp * lowpass(out / 3.4, cutoff) * adsr(n, dur * 0.30, dur * 0.18, 0.72, dur * 0.34, 1.6)


def sub_note(freq, dur, amp=0.16):
    n = int(SR * dur)
    return amp * (sine(freq, n) * 0.8 + sine(freq * 2, n) * 0.2) * adsr(n, dur * 0.12, dur * 0.2, 0.8, dur * 0.5, 1.4)


def pluck(freq, dur=0.9, amp=0.085):
    n = int(SR * dur)
    body = triangle(freq, n, 9) * 0.6 + sine(freq * 2.01, n) * 0.22 + sine(freq * 3.02, n) * 0.18
    return amp * highpass(lowpass(body, 9000), 300) * adsr(n, 0.006, dur * 0.35, 0.15, dur * 0.6, 2.2)


def bell(freq, dur=2.2, amp=0.11):
    n = int(SR * dur); out = np.zeros(n)
    for mult, g, dec in ((1.0, 1.0, 1.0), (2.0, 0.42, 0.7), (3.01, 0.17, 0.5), (4.98, 0.08, 0.35)):
        out += g * sine(freq * mult, n) * np.exp(-t_of(n) / (dur * 0.36 * dec))
    return amp * out * adsr(n, 0.004, dur * 0.05, 0.95, dur * 0.2, 1.4)


def soft_click(amp=0.06, tone=1500):
    n = int(SR * 0.075)
    return amp * lowpass(sine(tone, n) * 0.7 + triangle(tone * 1.5, n, 5) * 0.3, 4200) * adsr(n, 0.004, 0.05, 0.1, 0.02, 2.6)


def whoosh(dur=0.75, amp=0.10, f0=420, f1=2100, up=True, seed=0):
    r = np.random.default_rng(seed); n = int(SR * dur)
    noise = r.normal(0, 1, n); t = t_of(n); prog = t / dur
    centre = f0 + (f1 - f0) * (prog ** 0.75 if up else 1 - prog ** 0.75)
    body = highpass(lowpass(noise * (np.sin(2 * np.pi * centre * t) * 0.35 + 1.0), 6500), 180)
    sig = body * np.sin(np.pi * prog) ** 1.4
    return amp * sig / (np.max(np.abs(sig)) + 1e-9)


def riser(dur=2.2, amp=0.075, f0=180, f1=900, seed=1):
    r = np.random.default_rng(seed); n = int(SR * dur); prog = t_of(n) / dur
    tone = np.sin(2 * np.pi * (f0 + (f1 - f0) * prog ** 1.6) * t_of(n))
    return amp * (tone * 0.55 + lowpass(r.normal(0, 1, n), 3800) * 0.45) * (prog ** 1.8)


def impact(amp=0.22):
    n = int(SR * 1.1); t = t_of(n)
    f = 110 * np.exp(-t * 2.2) + 38
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR)
    return amp * (tone * 0.8 + lowpass(rng.normal(0, 1, n), 900) * 0.25) * adsr(n, 0.008, 0.35, 0.25, 0.55, 1.8)


def texture(dur, amp=0.010, seed=2):
    r = np.random.default_rng(seed); n = int(SR * dur)
    x = highpass(lowpass(r.normal(0, 1, n), 900), 140)
    x /= np.max(np.abs(x)) + 1e-9
    return amp * x * np.sin(np.pi * np.clip(t_of(n) / dur, 0, 1)) ** 0.7


# ═══════════════════════ 总线 ═══════════════════════
TRACKS = ("pad", "bass", "arp", "texture", "fx", "ui", "bell")
bus = {k: np.zeros(N) for k in TRACKS}
busL = {k: np.zeros(N) for k in TRACKS}
busR = {k: np.zeros(N) for k in TRACKS}
MUSIC = ("pad", "bass", "arp", "texture")
TRIGGER = ("fx", "bell", "ui")
SEND = {"pad": 0.30, "bass": 0.05, "arp": 0.34, "fx": 0.42, "ui": 0.30, "bell": 0.48, "texture": 0.22}
BUS_GAIN = {'pad': 1.0, 'bass': 1.0, 'arp': 1.0, 'texture': 1.0, 'fx': 1.30, 'ui': 2.40, 'bell': 1.15}


def put_st(track, sig, at, gain=1.0, pan=0.0):
    s = int(at * SR)
    if s < 0: sig = sig[-s:]; s = 0
    e = min(N, s + len(sig))
    if e <= s: return
    seg = sig[: e - s]
    l = math.sqrt((1 - pan) / 2); r = math.sqrt((1 + pan) / 2)
    busL[track][s:e] += seg * gain * l
    busR[track][s:e] += seg * gain * r
    bus[track][s:e] += seg * gain * 0.5


# ═══════════════════════ 铺底（读自 spec.audio.sections） ═══════════════════════
SECTIONS = AUDIO.get('sections', [])


# ── 段落角色：spec 可显式写 role，否则按位置模板推断（7 段模板见 ROLE_FALLBACK） ──
def role_of(sec, i, n):
    explicit = str(sec.get('role', ''))
    if explicit in ROLE_PLAN:
        return explicit
    if not ARRANGE_ENABLE:
        return "flat"          # = v4 行为：所有段落同一配置
    if n == len(ROLE_FALLBACK):
        return ROLE_FALLBACK[i]
    if i == 0:
        return "intro"
    if i == n - 1:
        return "outro"
    return "chorus" if i % 2 == 0 else "verse"


ROLES = [role_of(s, i, len(SECTIONS)) for i, s in enumerate(SECTIONS)]
FLAT_PLAN = dict(pad_voices=3, pad=1.0, bass=1.0, arp=1.0, arp_step=0.62, arp_hit=(1.50, 0.85),
                 texture=1.0, air=1.0, gain_db=0.0, octave=False)


def plan_of(role):
    if role in ROLE_PLAN:
        return ROLE_PLAN[role]
    return FLAT_PLAN if role in ("flat",) else ROLE_PLAN["chorus"]


def _role_windows():
    """→ [(i, role, start, end, plan), ...]；段落既有 dur 也按下一段起点截断。"""
    out = []
    for i, sec in enumerate(SECTIONS):
        st = float(sec['start'])
        end = min(DUR, float(SECTIONS[i + 1]['start']) if i + 1 < len(SECTIONS) else st + float(sec['dur']))
        out.append((i, ROLES[i], st, end, plan_of(ROLES[i])))
    return out


def smooth_env(env, sec):
    """边缘延拓 + FFT 卷积平滑（核长 0.45s，直接卷积在 2.2M 采样上会拖到分钟级）。"""
    k = max(2, int(sec * SR))
    ker = np.hanning(k + 2)[1:-1]; ker /= ker.sum()
    half = k // 2
    nfft = 1 << int(math.ceil(math.log2(len(env) + k)))
    pad = np.pad(env, (half, nfft - len(env) - half), mode='edge')
    y = np.fft.irfft(np.fft.rfft(pad, nfft) * np.fft.rfft(ker, nfft), nfft)
    return y[half: half + len(env)]


ARR_GAIN = np.ones(N)      # 段落宏增益（连续自动化，已平滑）
ARR_AIR = np.ones(N)       # 高频噪声层的段落力度
if SECTIONS:
    print("段落布局: " + " → ".join(f"{i}:{r}@{st:.1f}s" for i, r, st, _e, _p in _role_windows()))
    for i, role, st, end, p in _role_windows():
        i0, i1 = max(0, int(st * SR)), min(N, int(end * SR))
        if i1 <= i0:
            continue
        ARR_GAIN[i0:i1] = 10 ** (max(p['gain_db'], ARR_MIN_GAIN_DB) / 20.0)
        ARR_AIR[i0:i1] = float(p['air'])
    ARR_GAIN = smooth_env(ARR_GAIN, ARR_SMOOTH_S)
    ARR_AIR = smooth_env(ARR_AIR, ARR_SMOOTH_S)

for i, role, start, end, p in _role_windows():
    sec = SECTIONS[i]
    dur = float(sec['dur']); chord = list(sec['chord'])
    # pad：声部数由角色决定（引子 2 / 主歌 3 / 副歌 4 含高八度叠层）
    voices = []
    while len(voices) < p['pad_voices']:
        k = len(voices)
        voices.append(chord[k] if k < len(chord) else chord[k % len(chord)] * 2.0)
    for k, f in enumerate(voices):
        pan = (-0.45 + 0.9 * k / max(1, len(voices) - 1)) if len(voices) > 1 else 0.0
        cut = 3200 + (k % len(chord)) * 300 + (700 if k >= len(chord) else 0)
        put_st("pad", pad_note(f, dur + 1.2, amp=0.11 / len(chord) * 2.2 * p['pad'], cutoff=cut),
               start, 1.0, pan)
    put_st("bass", sub_note(sec['root'], dur + 0.6, amp=0.085 * p['bass']), start + 0.05, 1.0, 0.0)
    if p['octave']:   # 副歌：低音加八度，撑厚度
        put_st("bass", sub_note(sec['root'] * 2, dur + 0.5, amp=0.030), start + 0.10, 1.0, 0.0)
    put_st("texture", texture(dur + 0.8, amp=0.010 * p['texture'], seed=int(start * 10) + 1),
           start + 0.2, 1.0, 0.0)

# 琶音：全局时间游标连续走（不因换段重置相位），步长由段落角色决定 —— 主歌疏、副歌密
if SECTIONS:
    at, idx, si = float(SECTIONS[0]['start']) + TRANS_ARP_LEAD_S, 0, 0
    while at < DUR - 0.5:
        while si + 1 < len(SECTIONS) and at >= float(SECTIONS[si + 1]['start']):
            si += 1
        p = plan_of(ROLES[si]); notes = SECTIONS[si]['arp']
        f = notes[idx % len(notes)]
        beat = (idx % 4 == 0)
        d = (p['arp_hit'][0] if beat else p['arp_hit'][1])
        amp = (0.078 if beat else 0.058) * p['arp']
        pan = (-0.55 if idx % 2 == 0 else 0.55) * 0.8
        put_st("arp", pluck(f, d, amp), at, 1.0, pan)
        if p['octave']:   # 副歌：高八度微叠，抬 1–4k 亮度
            put_st("arp", pluck(f * 2, d * 0.7, amp * 0.34), at + 0.02, 1.0, -pan * 0.6)
        at += p['arp_step']; idx += 1


# ═══════════════════════ 段落转场自动排布（v5：不手写每一个转场音） ═══════════════════════
def _has_near(seq, kinds, t, tol):
    return any(ev.get('type') in kinds and abs(float(ev['t']) - t) <= tol for ev in seq)


SPEC_EVENTS = list(AUDIO.get('events', []))
AUTO_EVENTS = []
if ARRANGE_ENABLE and AUTO_TRANS_ENABLE:
    for i, role, start, end, _p in _role_windows():
        if i == 0:
            continue
        tp = TRANS_PLAN.get(role, {})
        # 上升音：结束点压在段落边界（张力在切段那一刻到顶）
        rs = tp.get('riser')
        if rs and start - rs[0] > 0.2:
            # 去重：同类 riser 一律不叠；主歌/尾奏边界上已有 whoosh 也算已有转场，副歌边界例外（副歌要张力）
            kinds = ('riser',) if role == 'chorus' else ('riser', 'whoosh')
            if not _has_near(SPEC_EVENTS + AUTO_EVENTS, kinds, start, TRANS_DEDUPE_S):
                dur, amp, f0, f1 = rs
                AUTO_EVENTS.append({'t': round(start - dur, 3), 'type': 'riser', 'dur': dur, 'amp': amp,
                                    'f0': f0, 'f1': f1, 'seed': 900 + i, 'auto': f'{role}@riser'})
        # 落点：副歌边界给低频冲击
        im = float(tp.get('impact') or 0.0)
        if im > 0 and not _has_near(SPEC_EVENTS + AUTO_EVENTS, ('impact',), start, TRANS_DEDUPE_S):
            AUTO_EVENTS.append({'t': round(start, 3), 'type': 'impact', 'amp': im, 'auto': f'{role}@impact'})
        # 落音：尾奏段收尾处反向扫频 + 软冲击
        fa = tp.get('fall')
        if fa and abs(end - DUR) < 0.6:
            lead, famp = fa
            tfall = max(1.0, DUR - lead)
            if not _has_near(SPEC_EVENTS + AUTO_EVENTS, ('whoosh',), tfall, TRANS_DEDUPE_S):
                AUTO_EVENTS.append({'t': round(tfall, 3), 'type': 'whoosh', 'dur': 0.95, 'amp': famp,
                                    'f0': 900, 'f1': 190, 'up': False, 'seed': 970, 'auto': 'outro@fall'})
            if not _has_near(SPEC_EVENTS + AUTO_EVENTS, ('impact',), tfall + 0.5, TRANS_DEDUPE_S) and tfall + 0.5 < DUR:
                AUTO_EVENTS.append({'t': round(tfall + 0.5, 3), 'type': 'impact', 'amp': famp * 0.85,
                                    'auto': 'outro@settle'})

EVENTS = sorted(SPEC_EVENTS + AUTO_EVENTS, key=lambda e: float(e['t']))
if AUTO_EVENTS:
    print(f"自动转场排布 {len(AUTO_EVENTS)} 个（spec 原事件 {len(SPEC_EVENTS)} → 合计 {len(EVENTS)}）")
    for ev in AUTO_EVENTS:
        extra = f"dur={ev.get('dur')} amp={ev.get('amp')}" if ev['type'] in ('riser', 'whoosh') else f"amp={ev.get('amp')}"
        print(f"  [auto] {float(ev['t']):>6.2f}s {ev['type']:<7} {extra:<24} ← {ev['auto']}")

# ═══════════════════════ 音效事件（读自 spec.audio.events） ═══════════════════════
counts = {}
for ev in EVENTS:
    kind = ev['type']; t = float(ev['t'])
    counts[kind] = counts.get(kind, 0) + 1
    if kind == 'whoosh':
        put_st("fx", whoosh(dur=float(ev.get('dur', 0.75)), amp=float(ev.get('amp', 0.09)),
                            f0=float(ev.get('f0', 420)), f1=float(ev.get('f1', 2100)),
                            up=bool(ev.get('up', True)), seed=int(ev.get('seed', 0))), t, 1.0, 0.0)
    elif kind == 'bell':
        put_st("bell", bell(float(ev['freq']), float(ev.get('dur', 2.2)), float(ev.get('amp', 0.1))),
               t, 1.0, float(ev.get('pan', 0.0)))
    elif kind == 'click':
        put_st("ui", soft_click(float(ev.get('amp', 0.05)), float(ev.get('tone', 1500))), t, 1.0, float(ev.get('pan', 0.0)))
    elif kind == 'impact':
        put_st("fx", impact(float(ev.get('amp', 0.2))), t)
    elif kind == 'riser':
        put_st("fx", riser(float(ev.get('dur', 2.0)), float(ev.get('amp', 0.065)),
                           float(ev.get('f0', 200)), float(ev.get('f1', 820)), int(ev.get('seed', 1))), t)
    elif kind == 'series':
        for i in range(int(ev['count'])):
            pan = float(ev.get('panFrom', 0)) + (float(ev.get('panTo', 0)) - float(ev.get('panFrom', 0))) * i / max(1, int(ev['count']) - 1)
            put_st("ui", soft_click(float(ev.get('amp', 0.03)), float(ev.get('tone', 1500)) + i * float(ev.get('step', 0))),
                   t + i * float(ev.get('gap', 0.4)), 1.0, pan)
    elif kind == 'ramp':
        for i, k in enumerate(np.linspace(0, 1, int(ev['count']))):
            tone = float(ev['tone0']) + (float(ev['tone1']) - float(ev['tone0'])) * k
            amp = float(ev['amp0']) + (float(ev['amp1']) - float(ev['amp0'])) * k
            pan = float(ev.get('panFrom', 0)) + (float(ev.get('panTo', 0)) - float(ev.get('panFrom', 0))) * k
            put_st("ui", soft_click(amp, tone), t + float(ev['span']) * k, 1.0, pan)
    else:
        raise SystemExit(f"未知事件类型: {kind}")

print("事件统计:", ", ".join(f"{k}×{v}" for k, v in sorted(counts.items())))


# ═══════════════════════ 转场门控：把常驻噪声层收进转场窗 ═══════════════════════
def event_windows():
    """从事件表（spec + 自动排布）抽转场窗：whoosh/impact/bell 全窗，riser 只取尾窗。"""
    hw = GATE_HALF_WINDOW_S
    ws = []
    for ev in EVENTS:
        kind = ev.get('type'); t = float(ev['t']); dur = float(ev.get('dur', 0.0))
        if kind in GATE_TYPES:
            a = t - hw - GATE_LEAD_S
            b = t + hw
            if GATE_COVER_EVENT_DUR and dur > hw:
                b = max(b, t + dur + GATE_DUR_PAD_S)
        elif kind == 'riser' and GATE_INCLUDE_RISER_TAIL:
            a = t + dur * (1.0 - GATE_RISER_TAIL_FRAC)
            b = t + dur + GATE_DUR_PAD_S
        else:
            continue
        ws.append([a, max(b, a + GATE_MIN_WINDOW_S)])
    ws.sort()
    merged = []
    for a, b in ws:
        if merged and a - merged[-1][1] <= GATE_MERGE_GAP_S:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return merged


def transition_gate(n):
    """长度为 n 的门控包络：窗内 ≈1（带 attack 爬升），窗外衰减到 GATE_FLOOR。"""
    if not GATE_ENABLE:
        return np.ones(n)
    g = np.full(n, float(GATE_FLOOR))
    for a, b in GATE_WINDOWS:
        i0 = max(0, int(round(a * SR)))
        i1 = min(n, int(round(b * SR)))
        if i1 <= i0:
            continue
        L = i1 - i0
        seg = np.ones(L)
        na = min(int(GATE_ATTACK_S * SR), L)
        if na:
            seg[:na] = np.linspace(GATE_FLOOR, 1.0, na) ** GATE_CURVE
        nr = min(int(GATE_RELEASE_S * SR), L)
        if nr:
            tail = np.linspace(1.0, GATE_FLOOR, nr) ** GATE_CURVE
            seg[L - nr:] = np.minimum(seg[L - nr:], tail)
        g[i0:i1] = np.maximum(g[i0:i1], seg)
    return g


GATE_WINDOWS = event_windows()
_gated_hits = sum(1 for ev in EVENTS if ev.get('type') in GATE_TYPES)
_riser_tails = sum(1 for ev in EVENTS if ev.get('type') == 'riser') if GATE_INCLUDE_RISER_TAIL else 0
print(f"转场门控: {_gated_hits} 个 whoosh/impact/bell + {_riser_tails} 个 riser 尾窗"
      f" → 合并成 {len(GATE_WINDOWS)} 个窗（±{GATE_HALF_WINDOW_S}s，floor {GATE_FLOOR}）")
if GATE_WINDOWS:
    _cov = sum(min(b, DUR) - max(a, 0.0) for a, b in GATE_WINDOWS)
    print(f"  窗口覆盖 {_cov:.2f}s / {DUR:.1f}s = {100 * _cov / DUR:.1f}% 时间")


# ═══════════════════════ 侧链避让 ═══════════════════════
def envelope(x, attack_ms=8.0, release_ms=260.0):
    a_a = math.exp(-1.0 / (SR * attack_ms / 1000.0))
    a_r = math.exp(-1.0 / (SR * release_ms / 1000.0))
    env = np.zeros_like(x); prev = 0.0; ax = np.abs(x)
    for i in range(len(ax)):
        coef = a_a if ax[i] > prev else a_r
        prev = coef * prev + (1 - coef) * ax[i]; env[i] = prev
    return env


trig = np.zeros(N)
for k in TRIGGER: trig += np.abs(bus[k])
trig_env = envelope(trig, 6.0, 300.0); trig_env /= (np.max(trig_env) + 1e-9)
duck_db = -5.5 * np.clip((trig_env - 0.05) / (0.30 + 1e-9), 0, 1)
duck = 10 ** (duck_db / 20.0)
duck = np.convolve(duck, np.ones(int(0.02 * SR)) / int(0.02 * SR), mode='same')

L = np.zeros(N); R = np.zeros(N)
for k in TRACKS:
    wet = reverb(bus[k], wet=SEND[k]) if k in ("fx", "bell", "ui", "arp") else bus[k]
    g = (duck if k in MUSIC else 1.0) * BUS_GAIN[k] * (ARR_GAIN if k in MUSIC else 1.0)
    if k in MUSIC:
        L += busL[k] * g; R += busR[k] * g
    else:
        L += (wet * 0.5 + busL[k] * 0.5) * g
        R += (wet * 0.5 + busR[k] * 0.5) * g

stereo = np.stack([L, R], axis=1)[: int(SR * DUR)]


# ═══════════════════════ 母带链 ═══════════════════════
def master_chain(st, rep):
    st = st - st.mean(axis=0, keepdims=True)
    mid = st.mean(axis=1); low = lowpass(mid, 120)
    st = st - np.stack([lowpass(st[:, 0], 120), lowpass(st[:, 1], 120)], axis=1) + np.stack([low, low], axis=1)
    rep['mono_below_120hz'] = True

    for ch in range(2):
        st[:, ch] = st[:, ch] + 1.0 * highpass(st[:, ch], 4000)

    prog = np.abs(st).mean(axis=1)
    kk = int(0.18 * SR)
    prog = np.convolve(prog, np.ones(kk) / kk, mode='same')
    prog = np.clip(prog / (np.percentile(prog, 95) + 1e-9), 0, 1.4) ** 0.85
    gate = transition_gate(len(st))
    rep['gate_enabled'] = bool(GATE_ENABLE)
    rep['gate_windows'] = len(GATE_WINDOWS)
    rep['gate_open_ratio'] = round(float(np.mean(gate > 0.5)), 3)
    rep['gate_mean'] = round(float(np.mean(gate)), 3)
    air = highpass(rng.normal(0, 1, len(st)), 7500) * GATE_AIR_GAIN * prog * gate * ARR_AIR[:len(st)]
    shimmer = highpass(lowpass(rng.normal(0, 1, len(st)), 11000), 4000) * GATE_SHIMMER_GAIN * prog * gate * ARR_AIR[:len(st)]
    midlayer = highpass(lowpass(rng.normal(0, 1, len(st)), 4200), 1000) * GATE_MIDLAYER_GAIN * prog * gate * ARR_AIR[:len(st)]
    rep['arrange_enabled'] = bool(ARRANGE_ENABLE)
    rep['auto_transitions'] = len(AUTO_EVENTS)
    rep['arr_gain_db_span'] = round(float(20 * np.log10(np.max(ARR_GAIN) / (np.min(ARR_GAIN) + 1e-9))), 2)
    st[:, 0] += air + shimmer + midlayer
    st[:, 1] += air + np.roll(shimmer, 120) + np.roll(midlayer, 90)

    m = st.mean(axis=1); s = (st[:, 0] - st[:, 1]) / 2 * 1.18
    st = np.stack([m + s, m - s], axis=1)
    rep['mid_side_width'] = 1.18

    win = int(0.09 * SR)
    env = np.sqrt(np.convolve((st ** 2).mean(axis=1), np.ones(win) / win, mode='same'))
    thr = np.percentile(env, 85) + 1e-9
    over = np.clip(env / thr - 1.0, 0, None)
    gain = 1.0 / (1.0 + 0.28 * over)
    gain = np.convolve(gain, np.ones(int(0.03 * SR)) / int(0.03 * SR), mode='same')
    st = st * gain[:, None]
    rep['glue_reduction_db'] = round(float(20 * np.log10(np.min(gain) + 1e-9)), 2)

    peak = np.max(np.abs(st), axis=1)
    need = np.clip(peak / 0.94, 1.0, None)
    look = int(0.002 * SR)
    lim = np.maximum.accumulate(np.concatenate([need, np.ones(look)]))[:len(need)]
    lim = np.convolve(lim, np.ones(look * 2) / (look * 2), mode='same')
    st = st / np.maximum(lim, 1.0)[:, None]
    rep['limiter_action_db'] = round(float(20 * np.log10(1.0 / max(np.max(lim), 1e-9))), 2)

    return st * (TARGET_PEAK / (np.max(np.abs(st)) + 1e-9))


qa = {'duck_max_db': round(float(np.min(duck_db)), 2),
      'duck_active_ratio': round(float(np.mean(duck < 0.99)), 3),
      'duration_s': DUR}
stereo = master_chain(stereo, qa)

pcm = (np.clip(stereo, -1, 1) * 32767).astype('<i2')
os.makedirs(OUT_DIR, exist_ok=True)
with wave.open(args.out, 'wb') as f:
    f.setnchannels(2); f.setsampwidth(2); f.setframerate(SR); f.writeframes(pcm.tobytes())

rms = float(np.sqrt(np.mean(stereo ** 2)))
qa['peak'] = round(float(np.max(np.abs(stereo))), 4)
qa['rms_dbfs'] = round(20 * math.log10(rms + 1e-9), 2)

win_len = int(0.05 * SR)
frames = np.array([np.sqrt(np.mean(stereo[i:i + win_len] ** 2)) for i in range(0, len(stereo) - win_len, win_len)])
quiet = frames < 10 ** (-60 / 20)
gap = 0; max_gap = 0
for q in quiet:
    gap = gap + 1 if q else 0
    max_gap = max(max_gap, gap)
qa['max_silence_ms'] = int(max_gap * 50)

print("── 母带链 ──")
for k, v in qa.items(): print(f"  {k}: {v}")


# ═══════════════════════ 质检 ═══════════════════════
def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore')


print("\n── 质检 ──")
r = run([FFMPEG, '-hide_banner', '-nostats', '-i', args.out, '-af', 'ebur128=peak=true:framelog=quiet', '-f', 'null', '-'])
txt = (r.stderr or '') + (r.stdout or '')
lufs = lra = tp = None
for line in txt.splitlines():
    l = line.strip()
    if l.startswith('I:') and lufs is None:
        try: lufs = float(l.split()[1])
        except Exception: pass
    if l.startswith('LRA:') and lra is None:
        try: lra = float(l.split()[1])
        except Exception: pass
    if l.startswith('Peak:') and tp is None:
        try: tp = float(l.split()[1])
        except Exception: pass
qa['lufs_integrated'] = lufs; qa['lra_lu'] = lra; qa['true_peak_dbtp'] = tp

mono = stereo.mean(axis=1)
X = np.fft.rfft(mono); fr = np.fft.rfftfreq(len(mono), 1 / SR); P = np.abs(X) ** 2
bands = {'sub_20_80': (20, 80), 'bass_80_250': (80, 250), 'lowmid_250_1k': (250, 1000),
         'mid_1k_4k': (1000, 4000), 'high_4k_10k': (4000, 10000), 'air_10k_24k': (10000, 24000)}
tot = P.sum()
qa['bands_pct'] = {k: round(float(100 * P[(fr >= a) & (fr < b)].sum() / tot), 2) for k, (a, b) in bands.items()}

# ── 段落能量表（量结构是否真的有起伏；最终立体声，段首尾各留 0.25s 边缘）──
sec_levels, role_levels = [], {}
for i, role, st, end, _p in _role_windows():
    i0, i1 = max(0, int((st + 0.25) * SR)), min(len(stereo), int((end - 0.25) * SR))
    if i1 <= i0:
        continue
    db = round(float(20 * math.log10(np.sqrt(np.mean(stereo[i0:i1] ** 2)) + 1e-9)), 2)
    sec_levels.append({'i': i, 'role': role, 'start': round(st, 2), 'end': round(end, 2), 'db': db})
    role_levels.setdefault(role, []).append(db)
qa['section_energy_db'] = sec_levels
role_mean = {r: round(float(np.mean(v)), 2) for r, v in role_levels.items()}
qa['role_energy_db'] = role_mean
cv = round(role_mean['chorus'] - role_mean['verse'], 2) if 'chorus' in role_mean and 'verse' in role_mean else None
qa['chorus_minus_verse_db'] = cv
print("\n── 段落能量（最终立体声 RMS） ──")
print("  " + " | ".join(f"{s['i']}:{s['role']} {s['db']}dB@{s['start']}s" for s in sec_levels))
print("  角色均值: " + " | ".join(f"{r} {v}dB" for r, v in sorted(role_mean.items()))
      + (f"   → 副歌-主歌 {cv}dB" if cv is not None else ""))

spec_png = os.path.join(OUT_DIR, 'qa-spec-spectrogram.png')
run([FFMPEG, '-y', '-hide_banner', '-loglevel', 'error', '-i', args.out,
     '-lavfi', 'showspectrumpic=s=1200x460:legend=1:scale=log', spec_png])

checks = []
def check(name, ok, detail): checks.append({'check': name, 'ok': bool(ok), 'detail': detail})

lo, hi = TARGET_LUFS - 1.5, TARGET_LUFS + 1.5
check(f'响度在 {lo:.1f}~{hi:.1f} LUFS（spec 目标 {TARGET_LUFS}）', lufs is not None and lo <= lufs <= hi, f'I={lufs} LUFS')
check('真峰 ≤ -1 dBTP', tp is not None and tp <= -1.0, f'{tp} dBTP')
check('低频 20~50%', 20 <= qa['bands_pct']['bass_80_250'] <= 50, f"{qa['bands_pct']['bass_80_250']}%")
check('中频 1k-4k 10~30%', 10 <= qa['bands_pct']['mid_1k_4k'] <= 30, f"{qa['bands_pct']['mid_1k_4k']}%")
check('空气感 10k+ ≥1.5%', qa['bands_pct']['air_10k_24k'] >= 1.5, f"{qa['bands_pct']['air_10k_24k']}%")
check('无空洞（<400ms）', qa['max_silence_ms'] < 400, f"{qa['max_silence_ms']}ms")
check('侧链避让 ≥3dB', qa['duck_max_db'] <= -3.0, f"最深 {qa['duck_max_db']}dB / 覆盖 {qa['duck_active_ratio']}")
# ── v5 新增：结构/动态/转场三项（前 7 项为原有基线）──
check('动态 LRA ≥ 5.0 LU', lra is not None and lra >= 5.0, f'{lra} LU（v4 基线 4.0）')
check('段落能量分层 副歌-主歌 ≥ 2.0 dB', cv is not None and cv >= 2.0,
      f"{cv} dB（副歌 {role_mean.get('chorus')}dB / 主歌 {role_mean.get('verse')}dB）")
check('段落转场自动排布 ≥ 3 个', len(AUTO_EVENTS) >= 3, f"{len(AUTO_EVENTS)} 个 riser/impact/落音")

qa['checks'] = checks
passed = sum(1 for c in checks if c['ok'])
print(f"  通过 {passed}/{len(checks)} 项（前 7 项为 v4 基线原有项）:")
for c in checks: print(f"    [{'PASS' if c['ok'] else 'FAIL'}] {c['check']}  ({c['detail']})")

stem = os.path.splitext(os.path.basename(args.out))[0]
report = os.path.join(OUT_DIR, 'qa-audio-spec.json')
payload = {**qa, 'spec': args.spec, 'wav': args.out}
json.dump(payload, open(report, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print(f"\n音频: {args.out}\n报告: {report}")
if stem != 'audio-spec':
    alt = os.path.join(OUT_DIR, f'qa-{stem}.json')
    json.dump(payload, open(alt, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print(f"报告副本: {alt}")
print(f"频谱图: {spec_png}")
