# 场景化视频渲染引擎

把"做一部片子"从**手写每个元素的动画数学**，变成**写一份场景描述 + 跑一条命令**。

```
engine/
  lib.mjs                     组件库 + 通用运行时（把场景编译成 HTML）
  scenes/dsh-phone-access.json 场景描述（唯一时间轴来源）
  render.mjs                  渲染 CLI：场景 → HTML → 逐帧 → 编码
  qa.mjs                      视频质检：流信息 / 黑帧 / 接触表 / 响度
  .build/                     生成的 HTML（可单独打开调试）
  .backup/                    lib.mjs 的时间戳备份（风格改动前原件，一键回滚用）
  preview/  preview-v/        关键帧预览（16:9 与 9:16）
```

## 一条命令出片

```bash
node engine/build.mjs --spec engine/scenes/dsh-phone-access.json --aspect 16:9 --aspect 9:16
```

它按顺序做五件事，**全部从同一份场景 JSON 驱动**：

| 步骤 | 输入 | 产物 | 自检 |
|---|---|---|---|
| 1 配乐 | `spec.audio`（和弦段 + 事件表） | `out/<name>-audio.wav` | 响度/真峰/频段/空洞/侧链 **7 项** |
| 2 字幕 | spec 里的文字元素 | `out/<name>.srt` / `.vtt` | 条数/覆盖率/最长一条 |
| 3 渲染 | `spec.sections` | `<name>-<tag>-silent.mp4` | 逐帧由 `seek(t)` 计算 |
| 4 混流 | 画面 + 配乐 | `<name>-<tag>.mp4` | — |
| 5 质检 | 成片 | `<name>-<tag>-qa.json` + 接触表 | **6 项** |

单独使用各步骤：

```bash
node engine/render.mjs --spec ... --aspect 16:9 --html-only   # 只出 HTML，调画面用
node engine/render.mjs --spec ... --aspect 9:16               # 只渲染某画幅
python tools/make-audio.py --spec ... --out out/x.wav         # 只出配乐
node engine/subs.mjs   --spec ... --out out/x                 # 只出字幕
node engine/qa.mjs     --video out/x.mp4 --expect-duration 45 # 只质检
node engine/build.mjs  --spec ... --aspect 16:9 --burn-subs   # 额外产出烧录字幕版
node engine/compare.mjs --a old.mp4 --b new.mp4 --label-a A --label-b B --out cmp.mp4
```

## 性能与并行（实测）

| 做法 | 双画幅总耗时 |
|---|---|
| 串行渲染 | 8.9 分钟 |
| **并行渲染**（各画幅一个无头实例） | **6.0 分钟** |

瓶颈是逐帧渲染（1350 帧 × 2 ≈ 5 分钟），编码只占很小一部分。

**并行化踩的坑值得单独记**：两个渲染进程共用 CDP 端口 9555 与配置目录，第二个实例**静默失败**
—— 产出文件缺失、但退出码不一定报错，而且上一轮的旧文件还在，肉眼完全看不出来。
修法有两处：
1. 端口与配置目录按画幅派生（`render.mjs` 传 `CDP_PORT`，`render-video.mjs` 用 `.edge-profile-<PORT>`）；
2. **build.mjs 增加产物校验**：既查文件存在、又查帧目录帧数（≥98% 预期）、还要确认文件是本次新写的
   （`mtime >= 本次开始时间`，防止"沿用旧文件"这种假成功）。


## 画声同源（本项目的核心约束）

**画面和声音是同一份数据。** `audio` 块和 `sections` 块写在同一个 JSON 里：

```jsonc
{
  "duration": 45.0,
  "audio": {
    "key": "A minor", "target_lufs": -15,
    "sections": [ { "start": 4.2, "dur": 7.4, "chord": [174.61,220,261.63], "root": 174.61, "arp": [...] } ],
    "events": [
      { "t": 8.20, "type": "impact", "amp": 0.20 },
      { "t": 8.22, "type": "bell", "freq": 146.83, "pan": -0.3 },
      { "t": 13.40, "type": "ramp", "count": 9, "span": 2.15, "tone0": 1000, "tone1": 2300, "amp0": 0.028, "amp1": 0.05 }
    ]
  },
  "sections": [ /* 画面 */ ]
}
```

支持的事件类型：`whoosh`（过场气流）· `bell`（铃音）· `click`（界面点按）· `impact`（低频下坠）·
`riser`（上行张力）· `series`（等间隔一串）· `ramp`（音高上行一串）。

这样做的收益很直接：**改画面节奏时音频不会掉队**。上一版把音效时间点写在 Python 里，
画面一改就得回去数秒数对齐 —— 那是流水线里最后一个手工环节，现在没了。


## 场景描述怎么写

```jsonc
{
  "title": "片名", "duration": 45.0, "fps": 30,
  "sections": [
    {
      "id": "problem", "name": "问题",      // name 会出现在左上角段落名
      "start": 4.2, "end": 11.4,             // 段落门控：只在这段时间可见
      "layers": [                            // 一个段落可叠多个组件
        { "type": "pipeline", "props": { ... } },
        { "type": "caption", "props": { "items": [ { "in": 8.8, "text": "..." } ] } }
      ]
    }
  ]
}
```

**每个元素只需要给"进入时刻"**，其余交给运行时：

| data 属性 | 含义 | 默认 |
|---|---|---|
| `data-in` | 进入时刻（秒） | 必填 |
| `data-out` | 退出时刻（秒） | 99（不退出） |
| `data-fade` / `data-fade-out` | 渐变时长 | 0.5 / 0.4 |
| `data-dy` | 入场位移（px，负值向上） | 18 |
| `data-scale` | 入场缩放起点 | 1 |
| `data-rotate` | 入场起始旋转（deg，缓动归零） | 0 |
| `data-ease` | 缓动名：`outCubic`/`outExpo`/`inOutCubic`/`spring`/`linear` | outCubic |
| `data-trail` | 入场拖尾：`ghost`（卡片残影）/ `ink`（文字彗尾） | 无 |
| `data-trail-axis` | 拖尾方向轴：`x` / `y` | x |
| `data-trail-amp` | 拖尾强度倍率 | 1 |

组件只是"按参数生成带这些标记的 HTML"，没有自己的动画代码——所以改节奏不用碰代码。

## 内置组件

| 组件 | 用途 | 关键参数 |
|---|---|---|
| `hud` | 左上段落名 + 底部进度条（标 `"persist": true` 可跨段落常驻） | `sections[]` |
| `title` | 标题页（v4：默认逐字错峰入场，中英混排不破字） | `title` `accent` `subtitle` `tags[]` `kinetic` `stagger` `span` `ease` |
| `cards` | 卡片行（竖屏自动改纵排） | `columns` `items[]`（`label/title/body/foot/in`） |
| `pipeline` | 链路图：A→B（或 A→网关→B）+ 流动光点 + 徽标 + 代码条 | `from` `mid` `to` `packets[]` `badges[]` `code` |
| `bullets` | 条目列表（逐条出现） | `items[]` `left` `top` `gap` |
| `phone` | 手机模型（可带抽屉开合） | `drawer{open,close}` `rows[]` |
| `outro` | 收尾：盾牌 + 仓库卡片 | `lines[]` `repo{}` |
| `caption` | 底部说明（可多行交替） | `items[]`（`text` 支持内联 HTML） |
| `timeline` | 时间线 / 进度轴：节点按 `t` 依次点亮，填充条 + 游标随 `t` 前进 | `nodes[]`（`t` `label` `sub`）`in` `even` |
| `stats` | 数据卡片组：大数字 + 单位 + 说明逐张出现，数字滚动计数 | `items[]`（`value` `unit` `label` `in` `color`）`in` `step` `count` `from` |

### 后加的两个组件（timeline / stats）

```jsonc
{ "type": "timeline", "props": { "in": 6.3, "nodes": [
    { "t": 6.4, "label": "写 spec" }, { "t": 9.0, "label": "逐帧渲染" }, { "t": 11.4, "label": "质检" } ] } }

{ "type": "stats", "props": { "in": 0.4, "step": 0.5, "count": 0.9, "items": [
    { "value": 4.2,  "unit": "s",  "label": "单帧渲染平均耗时" },
    { "value": 1350, "unit": "帧", "label": "双画幅总帧数" },
    { "value": "99.9%", "label": "非纯数字不计数，直接静态显示" } ] } }
```

- 仍不引入任何外部依赖：只有内联样式 + 现有 CSS 变量（`--accent/--ok/--dim/--fs-*/--pad`）。
- `timeline` 默认**按真实时间比例**定位节点（`even: true` 改成等距刻度）；`in` 是整条轴的出现时刻，
  游标走完的区间就是 `[第一个节点.t, 最后一个节点.t]`。
- `stats` 把 `value` 拆成「前缀 + 数字 + 后缀」，只让数字那段参与滚动计数，
  所以 `"99.9%"`、`"1,234.5 ms"` 这类写法不会被计数覆盖；单位取 `unit`，没有就取数字后缀。
- 两个组件都用到了运行时新加的插槽：`window.__hooks`（逐帧回调）。
  `seek(t)` 末尾统一调用，组件因此可以「不改 data-\* 语义」地做数字滚动、节点变亮这类连续性效果。
  注册器自身幂等（`__litHook` / `__statHook`），同一页面放多个同类组件只注册一次。

## 画面质感升级（v4）

这一版动的是**观感**，不是流水线：组件签名、`data-*` 语义、"画声同源"、渲染与质检链路都没变。
旧场景 JSON 一行不改也能跑——新属性都带默认值，且默认值要么等于旧行为，要么是纯叠加（残留只在入场窗口内非零）。

### ① 缓动库：`data-ease`

运行时内置五条曲线，元素上用 `data-ease` 选，默认仍是 `outCubic`（= 旧版行为）：

| 名字 | 形状 | 适合 |
|---|---|---|
| `outCubic` | 默认：快速起步、缓慢收尾 | 通用淡入 |
| `outExpo` | 起步更猛、收尾更急 | 卡片/位移，干脆 |
| `inOutCubic` | 两头慢、中间快 | 段落级、对称运动 |
| `spring` | 阻尼弹簧，过冲约 10.6% 后收敛 | 徽标、时间线节点、逐字块 |
| `linear` | 线性 | 轨道、计数 |

- 全部是**纯函数**（同 `t` 必得同帧），逐帧渲染才可复现。实测 `f(0)=0`、`f(1)=1`，`spring` 值域 `[0, 1.106]`。
- 透明度会把弹簧过冲**夹回** `[0,1]`，位移/旋转不夹——"弹"只体现在位置上，不会写出 `opacity:1.1` 这种无效值。
- 组件侧的默认值只在"弹"有意义的地方才上 `spring`：徽标、时间线节点、`stats` 卡片、`phone`、标题逐字块。

### ② 运动拖尾：`data-trail`

入场带一点残影/拖尾，**视觉全写在一段 CSS 里**，运行时只喂一个标量 `--tr`（1 → 0）：

```css
.tr-ghost::after { content:''; inset:-3px; border-radius:inherit;
  background:inherit;                                  /* 复制卡片自己的渐变背景 */
  transform:translate(calc(var(--tr)*16px*var(--trdx)), calc(var(--tr)*16px*var(--trdy)))
            scale(calc(1 + var(--tr)*.04));
  opacity:calc(var(--tr)*.42); filter:blur(8px); z-index:-1; }
.tr-ink { text-shadow: calc(var(--tr)*5px*var(--trdx)) … }   /* 多层 text-shadow 拉成彗尾 */
```

- 两种形态：`ghost`（卡片残影，`::after` + `background:inherit` 复制父元素背景）与 `ink`（文字彗尾，多层 `text-shadow`）。
- 方向轴 `data-trail-axis="x|y"`：元素从哪边来，残影就往反方向拖（`--trdx/--trdy` 决定）。
- **只挂在本就有入场位移的元素上**（带 `data-dy` 的卡片/徽标/代码条/标题字块）。`data-dy="0"` 的元素没有运动，加拖尾只会糊出一圈脏光晕——时间线节点就没加。
- 强度在 `1.6 × data-fade` 内线性收干，之后恒为 0：**静止帧与旧版逐像素一致**，时间轴上绝大多数帧不受影响。
- 想彻底关掉：给元素 `"trail": false`（组件支持时）或删掉 `data-trail`。

### ③ 背景升级：`spec.bg`

```jsonc
{ "bg": "both" }   // "mesh" | "noise" | "both"（默认） | "none"（退回旧的双径向渐变）
```

- `#bg-mesh`：5 层彩色 blob 径向渐变（accent / info / 紫 / 绿）叠出"网格化渐变"，比原来的双径向渐变更有层次；
  运行时只给它一个极慢视差 `translate(t*3.2px, t*1.7px) scale(1.03+)`，和 `#grid` 的漂移反向，产生纵深。
- `#bg-noise`：细噪点用**内联 SVG `feTurbulence`**（`data:` URI，不引入任何素材文件）当可平铺纹理，
  `background-size:170px` + `mix-blend-mode:overlay` + `opacity:.062`；颗粒每帧按 `t` 取整错位，像胶片颗粒。
- 噪点只铺在背景层（`#grid` 与所有内容都排在它上面），**不会糊到字**；`#stage` 加了 `isolation:isolate`，
  让 blend 只在自己这一层里生效，不会渗到页面之外。

### ④ 动态排版：标题逐字错峰（kinetic typography）

`title` 组件默认改成逐字错峰入场，中英混排不破字：

```jsonc
{ "type": "title", "props": { "title": "动态排版升级", "accent": "Kinetic Type",
  "kinetic": true, "stagger": 0.045, "span": 1.05, "ease": "spring" } }
```

- 切分规则：**中文逐字 / 拉丁按词**（`Kinetic` 是一个单位，绝不会断成 `Kin` + `etic`）/ 空白原样保留 / 代理对（emoji）不被拆开。
  实测输出：`动|态|排|版|升|级 Kinetic| |Type`（`|` = 插入的零宽空格）。
- 单位之间插 `U+200B` 零宽空格：中文逐字块之间因此**保留换行机会**，长标题该换行还是换行；
  标点（`，。！？：）`等）前面不留换行点，不会掉到下一行行首。
- 错峰间隔会被 `span / (字数-1)` 自动压缩（下限 0.012s），字数多也不会拖成一条长队；
  每个字块 `spring` 入场 + `4°` 回正 + 文字彗尾，`--ki`（字序）让靠后的字彗尾略长，读起来像加速的波浪。
- 回滚：`"kinetic": false` 退回原来的整块淡入（`data-in` 也退回挂在同一个 div 上，不留双份淡入）。

### 验证方式（本机实测）

```bash
node --check engine/lib.mjs                                                     # exit=0

# 冒烟：临时场景（16:9 与 9:16 各编一次，验完即删）
node engine/render.mjs --spec engine/scenes/_t5.json --aspect 16:9 --html-only   # exit=0
node engine/render.mjs --spec engine/scenes/_t5.json --aspect 9:16 --html-only   # exit=0

# 回归：真实场景（45s / 7 段）也照样出 HTML，验证完把 .build 原件按 sha256 还原
node engine/render.mjs --spec engine/scenes/dsh-phone-access.json --aspect 16:9 --html-only   # exit=0
node engine/render.mjs --spec engine/scenes/dsh-phone-access.json --aspect 9:16 --html-only   # exit=0
```

- 临时冒烟场景是一个 10s / 3 段的 spec（`"bg": "both"` + kinetic 标题 + 三张卡片 + `stats` + `timeline`），
  用来把四个新特性一次全打出来；**验完已删除**，`.build/_t5-*.html` 也一并清掉，工作区只留 `lib.mjs` 与 `README.md` 两处改动。
- 两个画幅都出 HTML：`_t5-16x9.html` 23844 字节 / `_t5-9x16.html` 23815 字节；真实场景 16:9 为 35446 字节（含 29 处拖尾、14 处 `data-ease`）。
- 把生成页里的运行时脚本单独抽出来再 `node --check` 一遍：冒烟两画幅与真实场景全部 `exit=0`（证明注入的 JS 语法有效）。
- 从成片 HTML 里**原样取出**缓动库求值：五条曲线 `f(0)=0 / f(1)=1`，`spring` 峰值 1.106。
- 标记落点计数（`_t5-16x9.html`）：`data-ease` 16 处（`spring` 15 + `outExpo` 1）、
  `data-trail` 17 处（`ghost` 7 / `ink` 10）、逐字块 8 个、`U+200B` 7 个、`#bg-mesh` 1、`#bg-noise` 1。
- 真实场景的标题实测切分为 `手|机|上|使|用 DeepSeek| |Harness`（`|` = 零宽空格），
  入场时刻 `0.50,0.55,0.59,0.64,0.68,0.72,0.77` —— 中英混排既没破词，也没丢换行点。
- 未做的是**整片渲染**（帧渲染太慢），所以"观感"目前只有 CSS/标记层面的证据，没有成片对比——
  这是下一步要补的（同一场景出 A/B 版）。


## 风格 token 与总开关（v5：`docs/style-spec.md` 第 4 节落地）

观感参数从"散落在 `buildHtml` 的模板字符串里"收敛成一张表：`lib.mjs` 顶部的 `STYLE_TOKENS`。
两档 `classic` / `anthropic`，**取值逐条抄自 `docs/style-spec.md` 第 4 节 diff**，不自己发挥。

### 总开关（唯一入口）

```jsonc
// 场景 JSON 顶层
"style": "classic"     // 整份 HTML 回到旧观感（A/B 对照、出问题一键退回）
// 不写 / 写别的       → 走 anthropic（规范落地档，默认）
```

产物里留了两行可 grep 的标记，任何一次 `--html-only` 都能当场核对当前生效的值：

```
<!-- style-active anthropic | bg=#141413 fg=#faf9f5 dim=#a09d96 grid=.16 noise=.025 pad=5/3/2.4 radius=16px shadow=0 18px 44px -30px #000c ease=outExpo dy=26/40 stagger=0.14 density=3 -->
<!-- style-inactive classic | bg=#0a0a0c fg=#e8e8ea grid=.30 pad=4/2.7/2 radius=18px stagger=0.45 -->
<!-- density: OVER max=5 cap=3 at=5.85s groups=50 -->
```

### 落地对照表（classic = 改动前 → anthropic = 规范值）

| # | token | classic（旧） | anthropic（规范） | 规范出处 |
|---|---|---|---|---|
| 1 | 暗底 | `#0a0a0c` | **`#141413`**（暖黑 = Anthropic ink） | §4 diff / §3.3 |
| 2 | 背景双 radial | `#1b1b21` / `#17171d` | `#1e1d1b` / `#1a1917`（亮度差 3.6% ≤ 4%） | §3.3 |
| 3 | `--fg` / `--dim` | `#e8e8ea` / `#9a9aa6` | **`#faf9f5`** / **`#a09d96`** | §4 diff |
| 4 | 语义色 ok/bad | `#4ade80` / `#f87171` | `#5db872` / `#c64545` | §4 diff |
| 5 | 网格透明度 / 步进 | `.30` / `3×base = 66px` | **`.16`** / 8 对齐 `64px`（竖屏 88px） | §3.3、§3.4 |
| 6 | 噪点强度 | `.062` | **`.025`**（规范区间 `.02~.03` 取中） | §3.3 |
| 7 | vignette | `inset 0 0 320px 90px #06060799` | `inset 0 0 240px 60px #06060780` | §3.3 |
| 8 | `--pad` 比例（×base） | `4 / 2.7 / 2` = 88px | **`5 / 3 / 2.4`** = 110px（5.7% 安全区） | §3.4、§4 diff |
| 9 | 字号阶梯 | 无显式阶梯 | **`--fs-ratio:1.3333` + `--fs-d1..d4 = 28/36/48/64`**（+body16/caption13/micro12） | §3.1 |
| 10 | `.lbl`（大写标签） | `17.2px` | **`12px`**（= 阶梯 micro 档） | §3.1 |
| 11 | 显示级字重/字距 | `700` / `-.01em`；组件标题 `600` | **`400` / `-.02em`**；中文场景 `500` + 字距 `0` | §3.1、§4 diff |
| 12 | 圆角 / 阴影 | `.card` `18px` / `0 26px 60px -28px` | **`16px`** / **`0 18px 44px -30px`** | §3.4、§4 diff |
| 13 | 卡片描边/底色 | `rgba(255,255,255,.085)` / 冷灰渐变 | `rgba(250,249,245,.10)`（暖）/ 暖黑渐变 | §3.4 |
| 14 | 默认缓动 | 显示级 `outCubic` | 显示级 **`outExpo`**（普通元素仍 `outCubic`） | §3.2、§4 diff |
| 15 | 位移 `data-dy` | 默认 `18` | **默认 `26`**；显示级 `40` | §3.2、§4 diff |
| 16 | 入场时长分档 | 全部 `.5s` | 显示 `.60` / 卡片 `.45` / 小元素 `.28` | §3.2 |
| 17 | stagger | `stats.step 0.45`、bullets 不交错 | **`0.14`**、bullets 逐条 `+0.10s` | §3.2 |
| 18 | 光点 | 线性 `outCubic` 直达 | 终点前 **`0.2s` 停顿** + `spring` 轻微 overshoot | §3.2 |
| 19 | 单帧内容密度上限 | 不检查（`0`） | **同一帧同时运动元素 ≤ 3**，编译期审计并告警 | §3.2、§3.4 |
| 20 | 附带（§3.1 映射列） | — | `stats` 数字补 `tabular-nums`；标题副标题行高 `1.6 → 1.75` | §3.1 |

派生项（规范没逐条列内联色，按 §3.3「换 surface mode」同步暖化）：手机抽屉 `#1b1b21 → #1e1d1b`、
手机屏底 `#0e0e11 → #121211`、时间线节点描边 `#0b0b0d → #141413`。设备框圆角 34px、品牌 mark 42px **不动**
（规范明说品牌 mark 可例外，且规范 diff 只改 `.card` 的 18px）。

### 怎么验证 / 怎么回滚

```bash
node --check engine/lib.mjs                                                              # exit=0
node engine/render.mjs --spec engine/scenes/dsh-phone-access.json --aspect 16:9 --html-only
node engine/render.mjs --spec engine/scenes/dsh-phone-access.json --aspect 9:16 --html-only
# 对照组：把场景 JSON 复制一份、加 "style": "classic"，同画幅再编一次
```

实测（`style-active` 标记 + HTML 取值）：

| 产物 | mode | html bg | grid | noise | fg | --pad | --fs-d3 | .lbl | .card 圆角 | outExpo |
|---|---|---|---|---|---|---|---|---|---|---|
| 16:9 | anthropic | `#141413` | `.16` | `.025` | `#faf9f5` | 110px | 48px | 12.0px | 16px | 1 |
| 9:16 | anthropic | `#141413` | `.16` | `.025` | `#faf9f5` | 150px | 65px | 16.4px | 16px | 1 |
| 16:9（classic 对照） | classic | `#0a0a0c` | `.30` | `.062` | `#e8e8ea` | 88px | — | 17.2px | 18px | 0 |

密度审计在真实场景上报 `OVER max=5 cap=3 at=5.85s`：第 2 段 4.3~5.8s 有 5 个元素同窗口入场，
按规范属于"5+ 元素同 0.5s 内齐动"。**只告警不改时间轴**——排期属于内容决策，改法是把 `data-in` 错开。

```powershell
# 一键回滚（回到改动前的 lib.mjs）
Copy-Item (Get-ChildItem D:\dsh-video\engine\.backup\lib.mjs.*.bak | Sort-Object Name | Select-Object -Last 1).FullName `
          D:\dsh-video\engine\lib.mjs -Force
# 指定那次备份：D:\dsh-video\engine\.backup\lib.mjs.20261107-022621.bak（sha256 a6e1630e…）
```

临时态回退（不换文件）：场景里加 `"style": "classic"` 即可，代价为零。


## 引擎工作流里抓到的两个真 bug

**① 只做元素级进出场，管不住段落**：第一版渲染出来"所有段落同时挂在画面上"——因为每个元素的 `data-out` 默认 99（不退出）。加**段落门控**（`section.start/end` → 透明度再乘一层）才解决。而且光点、抽屉这类"轨道元素"走的是另一条代码路径，第一版漏乘了段落系数，出现"游离的蓝点"。**教训：门控要做在渲染管线的最外层，而不是散落在各元素的更新里。**

**② 成功执行的 `execFileSync` 不返回 stderr**：ffmpeg 的分析结果（响度、黑帧区间）全写在 stderr，所以质检里"响度拿到 null"、"黑帧检测在空输入上假通过"。改用 `spawnSync` 同时收两路输出。
**教训：一个"总是通过"的检查项，比没有检查更危险**——它让人以为已经验证过了。

## 已实现 / 未完成

已实现（**一条命令出双画幅，配乐 7/7 + 成片 6/6 全过**）：
- 声明式场景 → 组件编译 → 通用运行时 → 逐帧渲染 → 混流 → 字幕 → 质检
- **画声同源**：`audio` 事件表与画面同在一份 JSON，配乐生成器读它（51 个事件全部数据驱动）
- **双画幅**：`--aspect 9:16` 时组件自动改竖排（链路纵排、卡片纵排、手机居中、标题收字号）
- **组件库 10 个**：新增 `timeline`（时间线/进度轴，竖屏改纵轴）与 `stats`（数据卡片组，数字滚动计数）
- **画面质感 v4**：缓动库 5 条曲线（`data-ease`）、入场拖尾/残影（`data-trail`，纯 CSS）、
  背景渐变网格 + 细噪点（`spec.bg`）、标题逐字错峰（中英混排不破字）——见上节，只改 `lib.mjs` 与 `README.md`
- **字幕轨**：从 spec 的文字元素抽出 24 条，导出 SRT/VTT（覆盖 71% 时长）
- 质检：音频 7 项 + 视频 6 项，全部落报告

产物：
| 画幅 | 文件 | 大小 | 质检 |
|---|---|---|---|
| 1920×1080 | `out/dsh-phone-access-16x9.mp4` | 4.14 MB | 6/6 |
| 1080×1920 | `out/dsh-phone-access-9x16.mp4` | 3.68 MB | 6/6 |
| 配乐 | `out/dsh-phone-access-audio.wav` | — | 7/7（-14.0 LUFS） |
| 字幕 | `out/dsh-phone-access.srt` / `.vtt` | — | 24 条 |

一次完整构建（两个画幅）实测 **8.9 分钟**：帧渲染占大头（1350 帧 × 2 ≈ 7 分钟）。

未完成（下一步优先）：
1. **交付**：把引擎产出的成片传到云盘与 GitHub（替换之前手写的那版）。
2. 组件库还缺：数据图表（真正的折线/柱状）、代码块逐行高亮、对比滑动。
   （`timeline` 时间线/进度轴与 `stats` 数据卡片组已补齐，见上表。）
3. 烧录字幕版与画面内说明**文字重复**（因为字幕就是从画面说明抽出来的）——
   若要消除，需给 spec 加"字幕变体"（渲染时丢掉 caption 层）。当前定位是
   "外挂 SRT 为主、烧录版为辅"，所以保留重复。

## 对比样片

```bash
node engine/compare.mjs --a out/old.mp4 --b out/new.mp4 \
     --label-a "手写动画版 · v2 配乐" --label-b "声明式引擎版 · v3 配乐" \
     --out out/compare-handwritten-vs-engine.mp4 --audio b
```

产出：
| 对比 | 文件 | 用途 |
|---|---|---|
| 手写版 vs 引擎版 | `out/compare-handwritten-vs-engine.mp4` | 证明"引擎化"没有降低画面质量 |
| 16:9 vs 9:16 | `out/compare-16x9-vs-9x16.mp4` | 检查竖屏适配有没有裁切/变形 |
| 配乐 v2 vs v3 | `out/compare-v2-v3-spectrum.png` | 频谱对比（低频配比、空气感、避让） |

标签里的 `:` `,` `'` 在 ffmpeg 滤镜图里是语法字符，会被当成选项分隔符导致整条链解析失败
（`16:9 横屏` 这种标签必炸）——`compare.mjs` 里做了转义。



## 双画幅适配的做法

组件不写死坐标，而是接收 `ctx.aspect` 后分支：

```js
function pipeline({ from, mid, to, ... }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const geo = vertical
    ? cells.map((c, i) => ({ left: 8, top: 14 + i * 22, width: 84 }))   // 竖排：一行一个
    : cells.map((c, i) => ({ left: lefts[i], top: 34, width: 26 }));    // 横排：一列一个
}
```

光点也要跟着换轴：横屏沿 X 走、竖屏沿 Y 走（`data-axis="y"`），运行时按轴选择 `translateX/Y`。

