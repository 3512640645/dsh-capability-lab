# 音画同轴夹具（A/V SYNC FIXTURES）

`engine/qa.mjs --fixtures` 用的可回归夹具。**全部由 ffmpeg lavfi 现生成**（不存在手搓二进制），
因此任何机器上都能一键复现；三个文件合计约 55KB，每支都远低于 300KB 上限。

| 夹具 | 时长 | 画面 | 音频 | 期望判定 | 期望趋势 |
| --- | --- | --- | --- | --- | --- |
| `sync-inphase.mp4` | 6s | 每 1s 在 **0.5s 处**亮一帧 | 1Hz 方波通断的 880Hz 音（[0,0.5) 有声） | **PASS** | 同相 |
| `sync-antiphase.mp4` | 6s | 每 1s 在 **0s 处**亮一帧（即音频静音那半秒） | 同上 | **FAIL** | 反相 |
| `av-degenerate.mp4` | 6s | 亮暗各半秒（每帧都在变） | 同上 | **FAIL** | 未知 |

## 一键复现

```powershell
# 1) 只生成夹具（校验"存在且 <300KB"）
node D:\dsh-video\engine\qa.mjs --fixtures --make-only

# 2) 生成并跑断言：期望输出 "夹具回归: PASS（同相 PASS、反相与退化 FAIL）"
node D:\dsh-video\engine\qa.mjs --fixtures

# 3) 单独看某个夹具的完整指标
node D:\dsh-video\engine\qa.mjs --video D:\dsh-video\engine\fixtures\sync-inphase.mp4
```

退出码：`0` = 全部断言成立；`1` = 有不符；`--fixtures --make-only` 时 `1` = 有夹具缺失或超 300KB。

## 实测结果（本机复现）

```
[PASS] 同相夹具期望 PASS/趋势同相，实得 PASS/趋势同相 · r=1   p_t=0 n=11 桶 · sync-inphase.mp4 19.1KB
[PASS] 反相夹具期望 FAIL/趋势反相，实得 FAIL/趋势反相 · r=-1  p_t=0 n=11 桶 · sync-antiphase.mp4 18.1KB
[PASS] 退化(帧差恒定)夹具期望 FAIL/趋势未知，实得 FAIL/趋势未知 · r=null n=11 桶 · av-degenerate.mp4 18.1KB
夹具回归: PASS（同相 PASS、反相与退化 FAIL）
```

三支夹具覆盖了判据的三条分支：**正相关通过**、**负相关（反相）失败**、**相关不可定义失败**。

## 判据（qa.mjs 内实现）

PASS 需同时满足三条，阈值均可配：

1. `|r| ≥ --min-r`（默认 `0.15`）
2. `p < --alpha`（默认 `0.05`），用 **t 检验**：`t = r*sqrt(n-2)/sqrt(1-r²)`，**自由度 = 有效桶数 − 2**
3. **方向为正**（`r > 0`）。这一条是必需的：音画反相时 `|r|` 同样可能等于 1、`p` 也≈0，
   只按 `|r|` 判会把"画面动时音乐正处低谷"的错位误判成通过。

另外每次都会跑**置换检验**（默认 2000 次，`--perm` 可调但下限 2000）：打乱一路包络后统计
`|r_perm| ≥ |r_obs|` 的比例，经验 p 值 = `(#≥ + 1)/(N + 1)`；随机种子固定（xorshift32），
同输入永远得到同一 p 值，可回归。

## 生成参数（脚本化，不写死二进制）

音频：
```
-f lavfi -i "aevalsrc='sin(880*PI*t)*if(gt(sin(PI*t*2),0),1,0)':s=22050:d=6"
```
画面（`pulseAt` 为脉冲起点；`pulseAt=null` 时退化为亮暗各半秒）：
```
-vf "drawbox=x=0:y=0:w=256:h=144:c=white@1:t=fill:enable='between(mod(t,1),<pulseAt>,<pulseAt>+0.125)',format=gray"
```
编码：`libx264 -preset ultrafast -crf 30 -g 8 -pix_fmt yuv420p` + `aac 32k/1ch/22050Hz`，
`-shortest -movflags +faststart`，源为 `color=s=256x144:r=8:d=6:c=0x303030`。

## 踩过的坑（改动夹具前请先读）

1. **`asetnsamples` 单帧上限 11025 样本**。传更大的 `n` 不是"包更粗"，而是"每 n 个样本才出一个值"，
   0.5s 桶永远凑不满 → 包络静默失真。qa.mjs 因此把音频先重采样到 **22050Hz** 再取
   `n = 22050*BIN`（BIN=0.5s 时正好 11025）。
2. **画面不能"亮半秒"**。亮半秒会让每一帧都发生等幅跳变，`tblend` 帧差恒定 →
   包络标准差为 0 → Pearson 不可定义。必须让画面在每个周期**只变一帧**（单帧脉冲），
   帧差包络才会真的随周期起伏（实测 0,103.5,0,103.5,…）。
3. **脉冲相位决定符号**（实测）：`pulseAt=0.5` → `r=+1`（同相）；`pulseAt=0` → `r=-1`（反相）；
   `pulseAt=0.25` → 帧差恒定 → `r=null`。
4. **两路包络同拍**：qa 的音频桶与视频桶在 6s/0.5s 下天然对齐（`alignSeries` 目前位移为 0）。
   若改动 BIN 或帧率，先确认这一点，否则会出现"整个符号翻掉"的假象。

## 归属

- 生成与断言逻辑：`D:\dsh-video\engine\qa.mjs`（`makeFixtures` / `--fixtures`）
- 本文件与三个 `.mp4`：`D:\dsh-video\engine\fixtures\`
- 顺带落盘的 `*-qa.json` / `*-contact.png` 是运行产物，可随时删除后重新生成。
