/**
 * 场景化渲染引擎 · 组件库与文档生成
 *
 * 核心思路：不再为每个元素手写 seek(t) 的数学，而是
 *   场景 JSON（声明式） → 组件库渲染成带 data-* 标记的 HTML → 通用运行时按 t 套用样式
 *
 * 运行时只认这几个 data 属性，所以新增场景/调整节奏都不用改代码：
 *   data-in / data-out    进入/退出时刻（秒）
 *   data-fade             渐变时长（秒，默认 .5 / .4；显示级 .60 / 卡片 .45 / 小元素 .28，由 token 分档）
 *   data-dy              入场位移（px，默认取 token：规范档 26 / classic 档 18，负值向上）
 *   data-scale           入场缩放起点（默认 1）
 *   data-rotate          入场起始旋转（deg，默认 0，缓动归零）
 *   data-ease            缓动名：outCubic(默认) / outExpo / inOutCubic / spring / linear
 *   data-trail           入场拖尾：ghost(卡片残影) / ink(文字彗尾)，视觉全在 CSS 里
 *   data-trail-axis     拖尾方向轴：x | y（默认 x）
 *   data-trail-amp      拖尾强度倍率（默认 1）
 *   data-delay            同组元素依次延迟（由组件内部展开）
 *   data-track="progress" 沿轴推进的轨道元素（timeline 的填充条与游标）：
 *                         data-mode="grow|move"、data-axis="x|y"、data-a/data-b（轴向端点 %）、
 *                         data-from/data-to（映射的时间区间，秒）
 *
 * 组件还可以往 window.__hooks 里注册逐帧回调（数字滚动计数、节点点亮等），
 * 运行时在 seek(t) 末尾统一调用；注册器自身要幂等（见 __litHook / __statHook）。
 *
 * ── 风格 token（v5）─────────────────────────────────────────────────────────
 * 所有观感参数（底色/文字色/网格/噪点/圆角/阴影/字号阶梯/缓动/stagger/密度上限…）
 * 都收敛到下面的 STYLE_TOKENS 表，取值来自 docs/style-spec.md 第 4 节。
 * 总开关：场景 JSON 顶层 `"style": "classic"` → 整份 HTML 回到旧观感（默认 = 规范落地档）。
 */

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/** 组件内生成的元素 id 后缀（同一个页面里可多次使用同一组件而不撞 id） */
let UID = 0;
const uid = (p) => `${p}${++UID}`;

// ── 静态排版工具（只影响生成的 HTML，动画仍然交给运行时按 data-* 推导）──

/** 可选属性小工具：只有场景显式给了值才落属性，避免改动旧场景的既有观感 */
const easeAttr = (e) => (e ? ` data-ease="${esc(e)}"` : '');
const trailAttr = (mode, axis = 'x') => (mode ? ` data-trail="${esc(mode)}" data-trail-axis="${esc(axis)}"` : '');

/**
 * 动态排版切分器：中文/日文逐字、拉丁按词（不破词）、空白原样保留。
 * 顺序有讲究：空白在最前（U+3000 也走这条），否则会被 CJK 区间吃掉；
 * 代理对（emoji）单独成单位，避免被拆成两个半个字符。
 */
const KINETIC_RE = /(\s+|[A-Za-z0-9][A-Za-z0-9'’._+\-]*|[\u2E80-\u9FFF\uF900-\uFAFF\u3000-\u303F\uFF00-\uFFEF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|.)/g;
/** 不该出现在行首的标点（贴住前一个单位，不在前面留换行点） */
const NO_LINE_START = /^[\uFF0C\u3002\uFF01\uFF1F\uFF1B\uFF1A\uFF09\u300B\u300D\u201D\u2019.,!?;:%)·、。，！？；：」』…]+$/;
const kinUnits = (s) => [...String(s ?? '').matchAll(KINETIC_RE)].map((m) => m[1]);
const kinCount = (s) => kinUnits(s).filter((u) => !/^\s+$/.test(u)).length;

/**
 * 把一段文字变成逐字错峰入场的 span 流。
 * - 拉丁按词切（"Harness" 是一个单位，不会断成 "Har" "ness"）
 * - 单位之间补 U+200B（零宽空格）：中文逐字块之间因此保留换行机会
 * - 从单位本身不产生换行（标点不会掉到下一行行首）
 */
function kineticStream(text, { base = 0, stagger = 0.045, ease = 'spring', color = null, trail = true, cls = '', fade = null } = {}) {
  const parts = [];
  let idx = -1;
  for (const u of kinUnits(text)) {
    if (/^\s+$/.test(u)) { parts.push({ html: u.replace(/\s+/g, ' '), brk: true }); continue; }
    idx++;
    const at = (base + idx * stagger).toFixed(2);
    parts.push({
      html: `<span class="k${cls ? ` ${cls}` : ''}" data-in="${at}" data-out="99" data-dy="26" data-scale=".94" data-rotate="4"${fade ? ` data-fade="${fade}"` : ''}${easeAttr(ease)}${trailAttr(trail ? 'ink' : null, 'y')}`
        + ` style="--ki:${idx}${color ? `;color:${color}` : ''}">${esc(u)}</span>`,
      brk: !NO_LINE_START.test(u),
    });
  }
  return parts.map((p, i) => (i > 0 && p.brk ? '\u200b' + p.html : p.html)).join('');
}

/** 组件：分镜标题（左上角 HUD 的按钮式段落名 + 进度条） */
function hud({ sections }, ctx = {}) {
  const T = ctx.T ?? STYLE_TOKENS.anthropic;
  const marks = sections.map((s) => `[${s.start},"${esc(s.name)}"]`).join(',');
  return {
    html: `
  <div id="hud" style="position:absolute;left:var(--pad);top:var(--padTop);display:flex;align-items:center;gap:16px">
    <div class="bar" style="width:46px;height:3px;border-radius:2px;background:var(--accent)"></div>
    <div id="hudName" style="font-size:var(--fs-sm);letter-spacing:${T.hudTracking};color:var(--dim)">开始</div>
  </div>
  <div style="position:absolute;left:var(--pad);right:var(--pad);bottom:var(--padBottom);height:2px;background:#ffffff10">
    <div id="prog" style="position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,var(--accent),#f0a385)"></div>
  </div>`,
    script: `const marks=[${marks}]; window.__hudName=document.getElementById('hudName'); window.__prog=document.getElementById('prog'); window.__marks=marks;`,
  };
}

/**
 * 组件：标题页；竖屏时字号收小、整体上移，避免标题换行后与副标题叠在一起。
 * v4：标题默认走动态排版（中文逐字 / 拉丁按词错峰入场，spring 缓动 + 文字彗尾），
 *     kinetic:false 可退回原来的整块淡入；stagger 是单字间隔，span 是错峰总时长上限。
 */
function title({ title, accent, subtitle, tags = [], kinetic = true, stagger = 0.045, span = 1.05,
                 ease = 'spring', easeMark = null }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const T = ctx.T ?? STYLE_TOKENS.anthropic;
  // 规范 3.2：显示级元素（标题 mark / 整块 h1）入场曲线 easeOut → easeExpo（classic 档等值于旧行为）
  const eMark = easeMark ?? T.easeDisplay;
  // 逐字错峰：字数多时自动压小间隔，保证整串标题在 span 秒内走完
  const nA = kinCount(title);
  const nB = accent ? kinCount(accent) : 0;
  const total = Math.max(nA + nB, 1);
  const st = Math.max(0.012, Math.min(Number(stagger) || 0.045, Number(span) / Math.max(total - 1, 1)));
  const head = kinetic
    ? kineticStream(title, { base: 0.5, stagger: st, ease, fade: T.fadeDisplay })
      + (accent ? ' ' + kineticStream(accent, { base: 0.5 + nA * st, stagger: st, ease, color: 'var(--accent)', fade: T.fadeDisplay }) : '')
    : `${esc(title)} <span style="color:var(--accent)">${esc(accent)}</span>`;
  return {
    html: `
  <div style="position:absolute;inset:0">
    <div id="t-mark" class="card" data-in="0.15" data-out="99" data-dy="${T.dyDisplay}" data-scale=".86"${easeAttr(eMark)}${trailAttr('ghost', 'y')} style="left:50%;top:${vertical ? 22 : 30}%;transform-origin:center;margin-left:-84px;width:168px;height:168px;border-radius:42px;display:flex;align-items:center;justify-content:center">
      <svg width="92" height="92" viewBox="0 0 92 92" fill="none">
        <rect x="10" y="14" width="52" height="38" rx="6" stroke="var(--accent)" stroke-width="4"/>
        <rect x="44" y="36" width="34" height="46" rx="8" stroke="var(--fg)" stroke-width="4"/>
        <path d="M56 70h10" stroke="var(--ok)" stroke-width="4" stroke-linecap="round"/>
      </svg>
    </div>
    <div class="h1"${kinetic ? '' : ` data-in="0.5" data-out="99" data-dy="${T.dyDisplay}" data-fade="${T.fadeDisplay}"${easeAttr(T.easeDisplay)}`} style="position:absolute;left:0;right:0;top:${vertical ? 42 : 47}%;text-align:center">
      ${head}
    </div>
    <div data-in="0.9" data-out="99" data-fade="${T.fadeSmall}" style="position:absolute;left:${vertical ? 6 : 0}%;right:${vertical ? 6 : 0}%;top:${vertical ? 60 : 59}%;text-align:center;font-size:var(--fs-sm);color:var(--dim);line-height:${T.cjkLineHeight}">${subtitle}</div>
    <div data-in="1.4" data-out="99" data-fade="${T.fadeSmall}" style="position:absolute;left:0;right:0;top:${vertical ? 68 : 66}%;text-align:center">
      ${tags.map((t) => `<span class="tag mono" style="margin:0 4px">${esc(t)}</span>`).join('')}
    </div>
  </div>`,
  };
}

/** 组件：卡片行（可带状态标签）；竖屏时自动改为纵向堆叠 */
function cards({ items, columns = 3 }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const T = ctx.T ?? STYLE_TOKENS.anthropic;
  const gap = 40;
  // 竖屏：一行一张，整体纵向排布；横屏：按列横排
  const layout = vertical
    ? items.map((it, i) => ({ left: 8, top: 22 + i * (it.height ?? 22) * 1.12, width: 84 }))
    : (() => {
      const total = columns * 27 + (columns - 1) * 3.4;
      const left0 = (100 - total) / 2;
      return items.map((it, i) => ({ left: left0 + i * (27 + 3.4), top: it.top ?? 28, width: 27 }));
    })();
  return {
    html: items.map((it, i) => {
      const L = layout[i];
      return `
    <div class="card" data-in="${it.in}" data-out="${it.out ?? 99}" data-dy="44" data-scale=".97"${easeAttr(it.ease)}${trailAttr(it.trail === false ? null : (it.trail ?? 'ghost'), 'y')} data-fade="${T.fadeCard}"
         style="left:${L.left}%;top:${L.top}%;width:${L.width}%;height:${vertical ? 20 : (it.height ?? 39)}%;padding:calc(var(--fs-md)*1.3)">
      <div class="lbl" style="color:${it.lblColor ?? 'var(--bad)'}">${esc(it.label)}</div>
      <div style="margin-top:calc(var(--fs-md)*.5);font-size:${T.titleSize};font-weight:${T.titleWeight}">${esc(it.title)}</div>
      <div style="margin-top:calc(var(--fs-md)*.8);font-size:var(--fs-sm);color:var(--dim);line-height:1.7">${it.body}</div>
      ${it.foot ? `<div class="mono" style="margin-top:auto;font-size:var(--fs-sm);color:var(--ok)">${esc(it.foot)}</div>` : ''}
    </div>`;
    }).join(''),
  };
}

/** 组件：链路图（A → B，带流动光点与结果徽标）；竖屏时改为纵向链路 */
function pipeline({ from, to, mid = null, badges = [], packets = [], code = null }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const T = ctx.T ?? STYLE_TOKENS.anthropic;
  const cells = mid ? [from, mid, to] : [from, to];
  // 横屏：三列横排；竖屏：三行纵排（连接线变垂直，光点改沿 Y 轴走）
  const geo = vertical
    ? cells.map((c, i) => ({ left: 8, top: 14 + i * 22, width: 84, height: 18 }))
    : (() => {
      const w = mid ? 26 : 34;
      const lefts = mid ? [8, 37, 70] : [10, 56];
      return cells.map((c, i) => ({ left: lefts[i], top: c.top ?? 34, width: w, height: c.height ?? 30 }));
    })();
  const barPos = vertical
    ? `left:50%;top:${14 + cells.length * 22}%;height:2px`
    : `left:${(geo[0].left + geo[0].width)}%;right:${100 - geo[geo.length - 1].left}%;top:50%;height:2px`;
  return {
    html: `
  ${cells.map((c, i) => {
    const g = geo[i];
    return `
    <div class="card" data-in="${c.in}" data-out="${c.out ?? 99}" data-dy="40"${easeAttr(c.ease)}${trailAttr('ghost', 'y')} data-fade="${T.fadeCard}"
         style="left:${g.left}%;top:${g.top}%;width:${g.width}%;height:${g.height}%;
                ${c.accent ? `border-color:#d9775744;box-shadow:${T.cardShadowAccent}` : ''}">
      <div class="lbl" style="padding:calc(var(--fs-md)*1.1) calc(var(--fs-md)*1.1) 0;${c.accent ? 'color:var(--accent)' : ''}">${esc(c.label)}</div>
      <div style="padding:calc(var(--fs-md)*.4) calc(var(--fs-md)*1.1) 0;font-size:${T.titleSize};font-weight:${T.titleWeight}">${esc(c.title)}</div>
      <div class="mono" style="padding:calc(var(--fs-md)*.5) calc(var(--fs-md)*1.1) 0;font-size:var(--fs-sm);color:var(--dim);line-height:1.8">
        ${(c.lines ?? []).map((l) => `<div data-in="${l.in}" data-out="99">${esc(l.text)}</div>`).join('')}
      </div>
    </div>`;
  }).join('')}
  ${vertical
    ? `<div data-in="${packets[0]?.in ?? 99}" data-out="99" style="position:absolute;left:50%;top:${14 + 18}%;width:2px;height:${(cells.length - 1) * 22 - 18}%;background:linear-gradient(180deg,#ffffff10,#ffffff34,#ffffff10)"></div>`
    : `<div data-in="${packets[0]?.in ?? 99}" data-out="99" style="position:absolute;${barPos};background:linear-gradient(90deg,#ffffff10,#ffffff34,#ffffff10)"></div>`}
  ${packets.map((p) => `
    <div class="dot" data-track="packet" ${vertical ? 'data-axis="y"' : ''} data-from="${p.from}" data-to="${p.to}" data-in="${p.in}" data-out="${p.out}"
         style="${vertical ? `left:calc(50% - 9px);top:${14 + 18}%;` : `left:${geo[0].left + geo[0].width}%;top:calc(50% - 9px);`}width:18px;height:18px;border-radius:50%;background:${p.color ?? 'var(--info)'};box-shadow:0 0 24px ${p.color ?? 'var(--info)'}cc"></div>`).join('')}
  ${badges.map((b) => `
    <div data-in="${b.in}" data-out="${b.out ?? 99}" data-scale=".9"${easeAttr(b.ease ?? 'spring')} style="position:absolute;left:${vertical ? 20 : b.left}%;top:${vertical ? (b.vtop ?? 6) : b.top}%;text-align:center">
      <span class="tag ${b.kind ?? ''} mono" style="font-size:var(--fs-md);padding:.5em .9em">${esc(b.text)}</span>
    </div>`).join('')}
  ${code ? `
    <div class="card mono" data-in="${code.in}" data-out="${code.out ?? 99}" data-dy="14"${easeAttr(code.ease)}${trailAttr('ghost', 'y')}
         style="left:${vertical ? 8 : (code.left ?? 30)}%;top:${vertical ? 78 : (code.top ?? 62)}%;width:${vertical ? 84 : (code.width ?? 40)}%;height:${code.height ?? 9}%;
                display:flex;align-items:center;justify-content:center;font-size:var(--fs-sm);color:var(--dim)">${code.text}</div>` : ''}`,
  };
}

/** 组件：条目列表（逐条出现）；竖屏时整体下移到手机下方 */
function bullets({ items, left = 62, top = 30, gap = 7.6, in: inT = null, step = null }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const T = ctx.T ?? STYLE_TOKENS.anthropic;
  const L = vertical ? 8 : left;
  const T0 = vertical ? 66 : top;
  const G = vertical ? 4.6 : gap;
  const t0 = Number(inT) || 0;
  // 规范 3.2：同组列表逐条 +0.10s 交错（classic 档为 0，且场景显式给 in 时以场景为准）
  const st = Number(step ?? T.bulletStep) || 0;
  return {
    html: items.map((b, i) => {
      const at = b.in ?? (t0 + i * st);
      return `
    <div data-in="${at}" data-out="${b.out ?? 99}" data-dy="0" data-fade="${T.fadeSmall}"
         style="position:absolute;left:${L}%;right:${vertical ? 8 : 0}%;top:${T0 + i * G}%;font-size:${vertical ? 'calc(var(--fs-sm)*1.05)' : 'var(--fs-md)'};color:var(--fg)">${b.text}</div>`;
    }).join(''),
  };
}

/** 组件：手机模型（可选抽屉展开/收起）；竖屏时居中放大、条目列表让到下方 */
function phone({ left = 10, top = 20, width = 19, height = 78, drawer = null, rows = [] }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const TK = ctx.T ?? STYLE_TOKENS.anthropic;   // 注意：本组件里 T 已是 top 百分比，token 表另起名
  const L = vertical ? 24 : left;
  const T = vertical ? 13 : top;
  const W = vertical ? 52 : width;
  const H = vertical ? 50 : height;
  return {
    html: `
  <div class="card" data-in="${drawer?.frameIn ?? 0}" data-out="99" data-dy="30" data-scale=".96"${easeAttr('spring')}${trailAttr('ghost', 'y')} data-fade="${TK.fadeCard}"
       style="left:${L}%;top:${T}%;width:${W}%;height:${H}%;border-radius:34px;padding:14px;overflow:hidden">
    <div style="position:absolute;inset:14px;border-radius:24px;background:${TK.surfaceDeep};overflow:hidden">
      <div style="position:absolute;left:0;top:0;bottom:0;width:44px;background:${TK.surface};border-right:1px solid #ffffff10"></div>
      <div style="position:absolute;left:44px;top:0;right:0;bottom:0;padding:16px">
        <div style="width:120px;height:12px;border-radius:6px;background:#ffffff22"></div>
        <div style="margin-top:22px;width:70%;height:22px;border-radius:8px;background:#ffffff30"></div>
        <div style="margin-top:14px;width:50%;height:12px;border-radius:6px;background:#ffffff18"></div>
        <div style="margin-top:34px;height:64px;border-radius:14px;border:1px dashed #ffffff26"></div>
      </div>
      ${drawer ? `
      <div id="phone-shade" style="position:absolute;left:44px;top:0;right:0;bottom:0;background:#000000aa"></div>
      <div data-track="drawer" data-open="${drawer.open}" data-close="${drawer.close ?? 99}" data-width="268"
           style="position:absolute;left:44px;top:0;bottom:0;width:268px;background:${TK.surface};border-right:1px solid #ffffff1a;padding:18px 16px;box-shadow:34px 0 60px -20px #000d">
        <div style="font-size:15px;font-weight:700;letter-spacing:.06em;white-space:nowrap">deepseek <span style="color:var(--accent)">HARNESS</span></div>
        <div style="margin-top:16px;height:34px;border-radius:10px;background:#ffffff12;display:flex;align-items:center;justify-content:center;font-size:13px">＋ 新会话</div>
        <div style="margin-top:16px;font-size:13.5px;color:#c9c9d2;line-height:2.1">工作台　插件<br>插件市场　自动化任务<br>上下文洞察　更多</div>
        <div style="margin-top:14px;font-size:12px;color:var(--dim)">工作区</div>
        ${rows.map((r, i) => `<div data-row="${i}" style="margin-top:${i ? 6 : 8}px;height:32px;border-radius:9px;background:${i === 0 ? '#ffffff14' : 'transparent'};display:flex;align-items:center;padding:0 10px;font-size:13px;white-space:nowrap;color:${i === 0 ? 'var(--fg)' : 'var(--dim)'}">${esc(r)}</div>`).join('')}
      </div>` : ''}
    </div>
  </div>`,
  };
}

/** 组件：收尾（盾牌 + 仓库卡片）；竖屏时整体纵排 */
function outro({ lines = [], repo = {} }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const T = ctx.T ?? STYLE_TOKENS.anthropic;
  return {
    html: `
  <div data-in="${repo.in ?? 0}" data-out="99" data-scale=".9"${easeAttr('spring')}${trailAttr('ghost', 'y')} style="position:absolute;left:${vertical ? 38 : 14}%;top:${vertical ? 12 : 33}%;width:${vertical ? 24 : 16}%;height:${vertical ? 17 : 34}%;display:flex;align-items:center;justify-content:center">
    <svg width="100%" height="100%" viewBox="0 0 100 100" fill="none">
      <path d="M50 8l32 12v30c0 22-14 34-32 42C32 84 18 72 18 50V20L50 8z" stroke="var(--ok)" stroke-width="3.4"/>
      <path d="M36 52l10 10 20-22" stroke="var(--ok)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </div>
  <div style="position:absolute;left:${vertical ? 0 : 33}%;right:${vertical ? 0 : 'auto'};${vertical ? 'text-align:center;' : ''}top:${vertical ? 32 : 36}%">
    ${lines.map((l, i) => `
      <div data-in="${l.in}" data-out="99" data-dy="0"
           style="margin-top:${i ? 1.6 : 0}rem;${i === 0 ? `font-size:${T.titleSize};font-weight:${T.titleWeight}` : 'font-size:var(--fs-sm);color:var(--dim)'}">${esc(l.text)}</div>`).join('')}
  </div>
  <div class="card" data-in="${repo.in}" data-out="99" data-dy="26"${easeAttr('spring')}${trailAttr('ghost', 'y')} data-fade="${T.fadeCard}"
       style="left:${vertical ? 8 : 33}%;top:${vertical ? 50 : 60}%;width:${vertical ? 84 : 50}%;height:${vertical ? 10 : 12}%;border-radius:16px;display:flex;align-items:center;padding:0 calc(var(--fs-md)*1.4);gap:calc(var(--fs-md)*1.1)">
    <svg width="54" height="54" viewBox="0 0 16 16" fill="var(--fg)"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38v-1.33c-2.23.48-2.7-1.07-2.7-1.07-.37-.94-.9-1.19-.9-1.19-.73-.5.06-.49.06-.49.81.06 1.24.83 1.24.83.72 1.24 1.88.88 2.34.67.07-.52.28-.88.51-1.08-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82a7.6 7.6 0 012-.27c.68 0 1.36.09 2 .27 1.53-1.03 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.28.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48v2.2c0 .21.15.46.55.38A8 8 0 0016 8c0-4.42-3.58-8-8-8z"/></svg>
    <div>
      <div style="font-size:var(--fs-md);font-weight:${T.titleWeight}">${esc(repo.text)}</div>
      <div class="mono" style="margin-top:8px;font-size:var(--fs-sm);color:var(--info)">${esc(repo.url)}</div>
    </div>
  </div>
  ${repo.foot ? `<div data-in="${repo.footIn ?? repo.in}" data-out="99" style="position:absolute;left:0;right:0;top:${vertical ? 64 : 78}%;text-align:center;font-size:var(--fs-sm);color:var(--dim)">${esc(repo.foot)}</div>` : ''}`,
  };
}

/** 组件：底部字幕（贯穿式说明）；竖屏时上移，避免与底部代码卡/内容碰撞 */
function caption({ items }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const T = ctx.T ?? STYLE_TOKENS.anthropic;
  return {
    html: items.map((c, i) => `
    <div data-in="${c.in}" data-out="${c.out ?? 99}" data-dy="12" data-fade="${T.fadeSmall}"${easeAttr(c.ease)}${trailAttr('ink', 'y')}
         style="position:absolute;left:8%;right:8%;top:${c.top ?? (vertical ? 68 + i * 4.5 : 76)}%;text-align:center;font-size:var(--fs-md);color:${c.dim ? 'var(--dim)' : 'var(--fg)'}">${c.text}</div>`).join(''),
  };
}

/**
 * 组件：时间线 / 进度轴。
 * 节点按自身 t 落在轴上（默认按真实时间比例定位，even:true 则是等距刻度），
 * 到 t 就点亮一个；轴上另有一条填充条 + 一个游标，随 t 从第一个节点走到最后一个节点。
 * 画幅：横屏沿 X（端点在 left/right，top = 轴线纵坐标）；
 *       竖屏改纵轴沿 Y（端点在 top/bottom，left = 轴线横坐标，标签排到轴线右侧）。
 */
function timeline({ nodes = [], left = null, top = null, right = null, bottom = null,
                    in: inT = null, out = 99, even = false }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const TK = ctx.T ?? STYLE_TOKENS.anthropic;
  const times = nodes.map((n) => Number(n.t));
  const t0 = inT ?? (times.length ? Math.min(...times) : 0);
  const t1 = times.length ? Math.max(...times) : t0 + 1;
  const span = (t1 - t0) || 1;
  const A = vertical ? (top ?? 32) : (left ?? 12);                  // 轴向起点 %
  const B = vertical ? (100 - (bottom ?? 12)) : (100 - (right ?? 12)); // 轴向终点 %
  const cross = vertical ? (left ?? 16) : (top ?? 74);              // 另一轴上的轴线位置 %
  // 节点在轴上的百分比位置
  const at = (i) => A + (even
    ? (nodes.length > 1 ? i / (nodes.length - 1) : 0)
    : (times[i] - t0) / span) * (B - A);
  // 轴线（横屏是一条水平线，竖屏是一条竖线）
  const axis = (thick) => vertical
    ? `left:calc(${cross}% - ${thick / 2}px);top:${A}%;width:${thick}px;height:${B - A}%`
    : `left:${A}%;top:calc(${cross}% - ${thick / 2}px);width:${B - A}%;height:${thick}px`;
  // 轴上的点（s = 元素边长，居中压在轴线上）
  const onAxis = (p, s) => vertical
    ? `left:calc(${cross}% - ${s / 2}px);top:calc(${p}% - ${s / 2}px)`
    : `left:calc(${p}% - ${s / 2}px);top:calc(${cross}% - ${s / 2}px)`;
  // 标签：横屏居中挂在下方，竖屏左对齐挂在右侧
  const labelAt = (p) => vertical
    ? `left:calc(${cross}% + 18px);right:6%;top:calc(${p}% - 11px);text-align:left`
    : `left:${p}%;top:calc(${cross}% + 15px);transform:translateX(-50%);text-align:center;max-width:22%`;
  return {
    html: `
  <div data-in="${t0 - 0.12}" data-out="${out}" data-dy="0"
       style="position:absolute;${axis(2)};background:#ffffff1f"></div>
  <div data-track="progress" data-mode="grow" data-axis="${vertical ? 'y' : 'x'}" data-a="${A}" data-b="${B}"
       data-from="${t0}" data-to="${t1}" data-in="${t0 - 0.12}" data-out="${out}" data-dy="0"
       style="position:absolute;${axis(3)};${vertical ? 'height:0' : 'width:0'};background:linear-gradient(${vertical ? '180deg' : '90deg'},var(--accent),#f0a385);box-shadow:0 0 20px #d9775744"></div>
  ${nodes.map((n, i) => `
    <div data-in="${n.t}" data-out="${out}" data-dy="0" data-scale=".55"${easeAttr(n.ease ?? 'spring')}
         style="position:absolute;${onAxis(at(i), 16)};width:16px;height:16px;border-radius:50%;background:var(--accent);box-shadow:0 0 24px #d97757aa"></div>
    <div data-in="${n.t + 0.12}" data-out="${out}" data-dy="0" data-lit data-at="${n.t}"
         style="position:absolute;${labelAt(at(i))};font-size:var(--fs-sm);color:var(--dim);line-height:1.5">
      ${esc(n.label)}${n.sub ? `<div class="mono" style="opacity:.72">${esc(n.sub)}</div>` : ''}
    </div>`).join('')}
  <div data-track="progress" data-mode="move" data-axis="${vertical ? 'y' : 'x'}" data-a="${A}" data-b="${B}"
       data-from="${t0}" data-to="${t1}" data-in="${t0 - 0.12}" data-out="${out}" data-dy="0"
       style="position:absolute;${onAxis(A, 20)};width:20px;height:20px;border-radius:50%;background:var(--accent);border:3px solid ${TK.nodeRing};box-shadow:0 0 30px #d97757cc"></div>`,
    // 点亮的节点标签由 --dim 变 --fg（运行时本来只管透明度，颜色要自己翻）
    script: `if(!window.__litHook){ window.__litHook=1; let lit=null;
  window.__hooks.push(function(t){ if(!lit) lit=[...document.querySelectorAll('[data-lit]')];
    for(const el of lit) el.style.color = t>=parseFloat(el.dataset.at) ? 'var(--fg)' : 'var(--dim)'; }); }`,
  };
}

/**
 * 组件：数据卡片组。
 * 每张卡片一个大数字 + 单位 + 说明；数字从 from 滚动计数到目标值（计数时长 count 秒）。
 * 画幅：横屏按列横排（columns 由数量自动均分）；竖屏改纵排，数字字号略放大。
 */
function stats({ items = [], left = null, right = null, top = null, in: inT = null, out = 99,
                 step = null, count = 0.9, from = 0 }, ctx = {}) {
  const vertical = ctx.aspect === '9:16';
  const TK = ctx.T ?? STYLE_TOKENS.anthropic;   // 本组件里 T 已是 top 百分比，token 表另起名
  const n = Math.max(items.length, 1);
  const L = left ?? (vertical ? 8 : 12);
  const R = right ?? (vertical ? 8 : 12);
  const gap = vertical ? 5 : 3.4;
  const t0 = inT ?? 0;
  const T = top ?? (vertical ? 20 : 34);
  const st = Number(step ?? TK.statsStep);     // 规范 3.2：同组卡片交错 0.45s → 0.14s
  const H = vertical ? (68 - gap * (n - 1)) / n : 26;      // 竖屏：在 top~88% 之间等分
  const W = (100 - L - R - gap * (n - 1)) / n;             // 横屏：在 left~right 之间等分
  const geo = items.map((it, i) => (vertical
    ? { left: L, top: T + i * (H + gap), width: 100 - L - R, height: H }
    : { left: L + i * (W + gap), top: T, width: W, height: H }));
  const parts = items.map((it, i) => {
    const raw = String(it.value ?? '');
    // 拆成「前缀 + 数字 + 后缀」：只有中间那段参与滚动计数，单位/百分号不能被计数覆盖
    const m = raw.match(/^([^\d+-]*)([+-]?\d[\d,]*(?:\.\d+)?)(.*)$/);
    const numStr = m ? m[2].replace(/,/g, '') : '';
    const to = m ? parseFloat(numStr) : NaN;
    const dec = m ? ((numStr.split('.')[1] ?? '').length) : 0;
    const unit = [it.unit, m ? m[3] : ''].filter(Boolean).join('');
    const id = uid('st');
    const at = Number(it.in ?? (t0 + i * st));
    return {
      html: `
    <div class="card" data-in="${at}" data-out="${out}" data-dy="30" data-scale=".98" data-fade="${TK.fadeCard}"${easeAttr(it.ease ?? 'spring')}${trailAttr('ghost', 'y')}
         style="left:${geo[i].left}%;top:${geo[i].top}%;width:${geo[i].width}%;height:${geo[i].height}%;
                padding:calc(var(--fs-md)*1.15);justify-content:flex-end">
      <div style="display:flex;align-items:baseline;gap:.26em">
        ${m && m[1] ? `<span style="font-size:var(--fs-md);color:var(--dim)">${esc(m[1])}</span>` : ''}
        <span id="${id}" class="mono" style="font-size:${vertical ? `calc(${TK.statSize}*1.15)` : TK.statSize};font-weight:${TK.h1Weight};line-height:1.05;letter-spacing:-.02em;color:${it.color ?? 'var(--accent)'}">${esc(m ? m[2] : raw)}</span>
        ${unit ? `<span style="font-size:var(--fs-md);color:var(--dim)">${esc(unit)}</span>` : ''}
      </div>
      <div data-in="${at + 0.22}" data-out="${out}" data-dy="0"
           style="margin-top:calc(var(--fs-md)*.7);font-size:var(--fs-sm);color:var(--dim);line-height:1.65">${esc(it.label)}</div>
    </div>`,
      script: m && Number.isFinite(to)
        ? `window.__statCounts.push({id:'${id}',at:${at},dur:${count},from:${from},to:${to},dec:${dec},grouped:${m[2].includes(',')}});`
        : '',
    };
  });
  return {
    html: parts.map((p) => p.html).join(''),
    script: `window.__statCounts=window.__statCounts||[];
if(!window.__statHook){ window.__statHook=1; const S=window.__statCounts;
  window.__hooks.push(function(t){ for(const s of S){ const el=document.getElementById(s.id); if(!el) continue;
    const k=easeOut(clamp((t-s.at)/(s.dur||0.9),0,1)), v=s.from+(s.to-s.from)*k, str=v.toFixed(s.dec);
    el.textContent=s.grouped?Number(str).toLocaleString('en-US',{minimumFractionDigits:s.dec,maximumFractionDigits:s.dec}):str; } }); }
${parts.map((p) => p.script).join('')}`,
  };
}

const REGISTRY = { hud, title, cards, pipeline, bullets, phone, outro, caption, timeline, stats };

/**
 * ── 风格 token 表（v5）───────────────────────────────────────────────────────
 * 取值逐条抄自 `D:\dsh-video\docs\style-spec.md` 第 4 节「引擎落地补丁（可直接改代码）」的 diff，
 * 不做任何自由发挥；`classic` 一档就是改动前的旧数值，用来 A/B 对照与回滚。
 *
 * **总开关**：场景 JSON 顶层写 `"style": "classic"` → 整份 HTML 回到旧观感；
 * 不写 / 写别的 → 走 `anthropic`（规范落地版，默认）。
 * 单帧内容密度上限只在 anthropic 档生效（classic 档 = 0，即不启用，保持旧场景原样）。
 */
const STYLE_TOKENS = {
  classic: {
    mode: 'classic',
    bg: '#0a0a0c', bgRad1: '#1b1b21', bgRad2: '#17171d', meshCore: '#1c1c2399',
    fg: '#e8e8ea', dim: '#9a9aa6', ok: '#4ade80', bad: '#f87171',
    serif: null,
    gridOpacity: '.30', gridStep: (base) => base * 3,
    noiseOpacity: '.062',
    vig: 'inset 0 0 320px 90px #06060799',
    padMul: [4, 2.7, 2], lblMul: 0.78, hudTracking: '.22em',
    cardRadius: '18px', cardBg: 'linear-gradient(180deg,#1a1a1f,#141418)',
    cardBorder: 'rgba(255,255,255,.085)', cardShadow: '0 26px 60px -28px #000c',
    cardShadowAccent: '0 26px 70px -26px #d9775733',
    surface: '#1b1b21', surfaceDeep: '#0e0e11', nodeRing: '#0b0b0def',
    h1Family: '', h1Weight: '700', h1Tracking: '-.01em', titleWeight: '600',
    fsDisplay: null, fsRatio: null, fsRef: 22,
    titleSize: 'var(--fs-lg)', statSize: 'var(--fs-xl)',
    dy: 18, dyDisplay: 18, easeDefault: 'outCubic', easeDisplay: 'outCubic',
    fadeDisplay: '0.5', fadeCard: '0.5', fadeSmall: '0.5',
    statsStep: 0.45, bulletStep: 0,
    density: 0, packetHold: 0, packetEase: 'outCubic',
    tabular: false, cjkLineHeight: '1.6',
  },
  anthropic: {
    mode: 'anthropic',
    bg: '#141413', bgRad1: '#1e1d1b', bgRad2: '#1a1917', meshCore: '#1b1a1899',
    fg: '#faf9f5', dim: '#a09d96', ok: '#5db872', bad: '#c64545',
    serif: '"Cormorant Garamond","Source Han Serif SC","Noto Serif SC",serif',
    gridOpacity: '.16', gridStep: (base) => Math.round((base * 3) / 8) * 8,
    noiseOpacity: '.025',                       // 规范区间 .02~.03，取中值
    vig: 'inset 0 0 240px 60px #06060780',
    padMul: [5, 3, 2.4], lblMul: 12 / 22, hudTracking: '.16em',
    cardRadius: '16px', cardBg: 'linear-gradient(180deg,#1e1d1b,#171715)',
    cardBorder: 'rgba(250,249,245,.10)', cardShadow: '0 18px 44px -30px #000c',
    cardShadowAccent: '0 18px 44px -30px #d9775733',
    surface: '#1e1d1b', surfaceDeep: '#121211', nodeRing: '#141413ef',
    h1Family: 'var(--serif)', h1Weight: '400', h1Tracking: '-.02em', titleWeight: '400',
    fsDisplay: [28, 36, 48, 64], fsRatio: '1.3333', fsRef: 22,   // 规范显示级四档（1080p 基准）
    titleSize: 'var(--fs-d2)', statSize: 'var(--fs-d3)',
    dy: 26, dyDisplay: 40, easeDefault: 'outCubic', easeDisplay: 'outExpo',
    fadeDisplay: '0.60', fadeCard: '0.45', fadeSmall: '0.28',
    statsStep: 0.14, bulletStep: 0.1,
    density: 3, packetHold: 0.2, packetEase: 'spring',
    tabular: true, cjkLineHeight: '1.75',
  },
};
/** 总开关解析：只有显式 "style": "classic" 会退回旧观感 */
const styleTokens = (spec) => STYLE_TOKENS[String(spec?.style ?? '').toLowerCase() === 'classic' ? 'classic' : 'anthropic'];

/**
 * 字号阶梯（规范 3.1：显示 64/48/36/28、正文 16、caption 13、micro 12）。
 * 规范基准是 1080p 横屏（本引擎 base=22），竖屏按 base 等比放大以保留原有"竖屏字号略大"。
 */
const fsLadder = (T, base) => {
  if (!T.fsDisplay) return null;
  const d = (px) => `${Math.round((px * base) / T.fsRef)}px`;
  const [d1, d2, d3, d4] = T.fsDisplay.map(d);
  return `--fs-ratio:${T.fsRatio}; --fs-d1:${d1}; --fs-d2:${d2}; --fs-d3:${d3}; --fs-d4:${d4};`
    + ` --fs-body:${d(16)}; --fs-caption:${d(13)}; --fs-micro:${d(12)};`;
};

/**
 * 单帧内容密度审计（规范 3.2 / 3.4：一帧内同时运动的元素 ≤ 3）。
 * 运动主体 = 带 data-in 的顶层元素；动态排版字块（class="k"）算 1 组整体，不逐个计数。
 * 产物：一个 HTML 注释 + 控制台告警；**不改场景时间轴**（排期是内容决策，规范也这么写）。
 */
function densityAudit(html, cap, duration) {
  if (!cap) return '<!-- density: disabled (classic) -->';
  const marks = [];
  const tagRe = /<[a-z][^>]*\bdata-in="([\d.]+)"[^>]*>/gi;
  for (const m of html.matchAll(tagRe)) {
    if (/class="k[\s"]/.test(m[0])) continue;               // 逐字错峰的字块
    const at = parseFloat(m[1]);
    if (!Number.isFinite(at) || at >= 99 || at > duration) continue;
    const f = m[0].match(/\bdata-fade="([\d.]+)"/);
    marks.push([at, at + parseFloat(f ? f[1] : '0.5')]);
  }
  let max = 0, at = 0;
  for (let t = 0; t <= duration; t += 0.05) {
    const n = marks.filter(([a, b]) => a <= t && t < b).length;
    if (n > max) { max = n; at = t; }
  }
  return `<!-- density: ${max > cap ? 'OVER' : 'ok'} max=${max} cap=${cap} at=${at.toFixed(2)}s groups=${marks.length} -->`;
}

/**
 * 由场景描述生成完整 HTML。
 * @param {object} spec   场景 JSON
 * @param {'16:9'|'9:16'} aspect 画幅
 */
export function buildHtml(spec, aspect = '16:9') {
  const vertical = aspect === '9:16';
  const [W, H] = vertical ? [1080, 1920] : [1920, 1080];
  const base = vertical ? 30 : 22;                     // 竖屏字号略大，等效视觉密度接近
  const scale = vertical ? 1.0 : 1.0;
  const T = styleTokens(spec);                         // 风格 token（总开关见 STYLE_TOKENS）
  const ladder = fsLadder(T, base);

  let body = '';
  let persistent = '';
  let scripts = '';
  for (const section of spec.sections) {
    for (const layer of section.layers) {
      const fn = REGISTRY[layer.type];
      if (!fn) throw new Error(`未知组件: ${layer.type}`);
      const out = fn(layer.props ?? {}, { section, aspect, W, H, T, base });
      if (layer.persist) {
        // persistent 层跨越所有段落（例如左上角段落名与进度条）
        persistent += `<section style="position:absolute;inset:0">${out.html ?? ''}</section>`;
      } else {
        body += `<section data-section="${section.id}" data-start="${section.start}" data-end="${section.end}"
                          style="position:absolute;inset:0">${out.html ?? ''}</section>`;
      }
      if (out.script) scripts += out.script;
    }
  }

  // ── 背景升级（v4）：spec.bg = "mesh" | "noise" | "both" | "none"（默认 both）──
  const bgMode = String(spec.bg ?? 'both').toLowerCase();
  const meshOn = bgMode === 'mesh' || bgMode === 'both';
  const noiseOn = bgMode === 'noise' || bgMode === 'both';
  // 内联 SVG 噪点（feTurbulence + 去饱和）当可平铺纹理：不引入任何外部素材文件
  const NOISE_URI = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='170' height='170'%3E%3Cfilter id='gn'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='170' height='170' filter='url(%23gn)' opacity='0.5'/%3E%3C/svg%3E";

  // 单帧内容密度审计（规范 3.2 / 3.4：一帧内同时运动的元素 ≤ 3）；只报不改，排期属于内容决策
  const densityNote = densityAudit(body, T.density, spec.duration);
  if (densityNote.includes('OVER')) console.error(`⚠ 单帧内容密度超上限: ${densityNote}`);

  const cssVars = `
    --accent:#d97757; --ok:${T.ok}; --bad:${T.bad}; --info:#60a5fa; --fg:${T.fg}; --dim:${T.dim};
    ${T.serif ? `--serif:${T.serif};` : ''}
    --fs-sm:${(base * 0.78).toFixed(1)}px; --fs-md:${(base * 1.25).toFixed(1)}px; --fs-lg:${(base * 1.55).toFixed(1)}px; --fs-xl:${(base * 2.2).toFixed(1)}px;
    ${ladder ? `${ladder}\n    ` : ''}--pad:${base * T.padMul[0]}px; --padTop:${base * T.padMul[1]}px; --padBottom:${base * T.padMul[2]}px;`;

  // 风格标记（可 grep）：active 行是本次真正生效的取值，classic 行是另一档的对照值
  const styleMarks = `<!-- style-active ${T.mode} | bg=${T.bg} fg=${T.fg} dim=${T.dim} grid=${T.gridOpacity} noise=${T.noiseOpacity} pad=${T.padMul.join('/')} radius=${T.cardRadius} shadow=${T.cardShadow} ease=${T.easeDisplay} dy=${T.dy}/${T.dyDisplay} stagger=${T.statsStep} density=${T.density} -->`
    + `\n<!-- style-inactive ${T.mode === 'classic' ? 'anthropic' : 'classic'} | bg=${T.mode === 'classic' ? STYLE_TOKENS.anthropic.bg : STYLE_TOKENS.classic.bg} fg=${T.mode === 'classic' ? STYLE_TOKENS.anthropic.fg : STYLE_TOKENS.classic.fg} grid=${T.mode === 'classic' ? STYLE_TOKENS.anthropic.gridOpacity : STYLE_TOKENS.classic.gridOpacity} pad=${(T.mode === 'classic' ? STYLE_TOKENS.anthropic.padMul : STYLE_TOKENS.classic.padMul).join('/')} radius=${T.mode === 'classic' ? STYLE_TOKENS.anthropic.cardRadius : STYLE_TOKENS.classic.cardRadius} stagger=${T.mode === 'classic' ? STYLE_TOKENS.anthropic.statsStep : STYLE_TOKENS.classic.statsStep} -->`;

  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>${esc(spec.title)}</title>
${styleMarks}
${densityNote}
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  html,body { width:${W}px; height:${H}px; overflow:hidden; background:${T.bg}; }
  body { font-family:"Microsoft YaHei UI","Microsoft YaHei","Segoe UI",system-ui,sans-serif; color:var(--fg); -webkit-font-smoothing:antialiased; ${cssVars} }
  #stage { position:absolute; inset:0; overflow:hidden; isolation:isolate; }
  #bg { position:absolute; inset:0; background:
        radial-gradient(1100px 700px at 22% 18%, ${T.bgRad1} 0%, transparent 62%),
        radial-gradient(900px 640px at 82% 84%, ${T.bgRad2} 0%, transparent 60%), ${T.bg}; }
  /* 渐变网格：多个彩色 blob 叠出「网格化渐变」，逐帧只做极慢平移（运行时喂 t） */
  #bg-mesh { position:absolute; inset:-8%;
    background:
      radial-gradient(42% 36% at 16% 20%, #d9775726 0%, transparent 66%),
      radial-gradient(38% 32% at 82% 12%, #60a5fa1f 0%, transparent 64%),
      radial-gradient(44% 40% at 88% 78%, #a855f71c 0%, transparent 66%),
      radial-gradient(36% 42% at 24% 86%, #4ade8014 0%, transparent 64%),
      radial-gradient(58% 54% at 50% 48%, ${T.meshCore} 0%, transparent 72%); }
  /* 细噪点：内联 SVG feTurbulence 当纹理（不引入外部素材），叠在背景上做胶片颗粒 */
  #bg-noise { position:absolute; inset:-140px; opacity:${T.noiseOpacity}; mix-blend-mode:overlay;
    background-repeat:repeat; background-size:170px 170px;
    background-image:url("${NOISE_URI}"); }
  #grid { position:absolute; inset:0; opacity:${T.gridOpacity};
    background-image:linear-gradient(to right, rgba(255,255,255,.055) 1px, transparent 1px),
                     linear-gradient(to bottom, rgba(255,255,255,.055) 1px, transparent 1px);
    background-size:${T.gridStep(base)}px ${T.gridStep(base)}px;
    -webkit-mask-image:radial-gradient(1100px 780px at 50% 46%, #000 38%, transparent 88%); }
  #vig { position:absolute; inset:0; box-shadow:${T.vig}; }
  .card { position:absolute; border-radius:${T.cardRadius}; background:${T.cardBg};
    border:1px solid ${T.cardBorder}; box-shadow:${T.cardShadow}; display:flex; flex-direction:column; }
  /* .dot 必须显式绝对定位：漏了这行时，光点会按静态流停在段落原点 (0,0)，
     表现为每帧左上角一个游离小圆点（排查了半天） */
  .dot { position:absolute; }
  .lbl { font-size:${(base * T.lblMul).toFixed(1)}px; letter-spacing:.16em; text-transform:uppercase; color:var(--dim); }
  .mono { font-family:"Cascadia Mono",Consolas,monospace;${T.tabular ? ' font-variant-numeric:tabular-nums;' : ''} }
  .tag { display:inline-block; padding:.28em .7em; border-radius:999px; font-size:${base * 0.75}px;
    border:1px solid rgba(255,255,255,.14); color:#c9c9d2; background:#ffffff08; }
  .tag.ok { color:var(--ok); border-color:${T.ok}55; background:${T.ok}12; }
  .tag.err { color:var(--bad); border-color:${T.bad}55; background:${T.bad}12; }
  .tag.info { color:var(--info); border-color:#60a5fa55; background:#60a5fa12; }
  .h1 { ${T.h1Family ? `font-family:${T.h1Family}; ` : ''}font-size:${base * (vertical ? 2.9 : 3.7)}px; font-weight:${T.h1Weight}; letter-spacing:${T.h1Tracking}; }
  ${T.h1Family ? '/* 规范 3.1：中文场景改用 500 字重补偿 CJK，且禁用负字距 */\n  html[lang^="zh"] .h1 { font-weight:500; letter-spacing:0; }\n  ' : ''}
  /* 动态排版的单字块：inline-block 才能各自位移/缩放/旋转；基线附近做转轴更像字幕机 */
  .k { display:inline-block; transform-origin:50% 78%; }
  /* 拖尾/残影：运行时只喂一个标量 --tr（1→0 衰减），形状、模糊、衰减曲线全部写在 CSS 里 */
  [data-trail] { --tr:0; --ki:0; --trdx:-1; --trdy:1; }
  .tr-x { --trdx:-1; --trdy:0; }
  .tr-y { --trdx:0; --trdy:1; }
  .tr-ghost::after { content:''; position:absolute; inset:-3px; border-radius:inherit;
    background:inherit; border:inherit; pointer-events:none; z-index:-1;
    transform:translate(calc(var(--tr) * 16px * var(--trdx)), calc(var(--tr) * 16px * var(--trdy))) scale(calc(1 + var(--tr) * .04));
    opacity:calc(var(--tr) * .42); filter:blur(8px); }
  .tr-ink { text-shadow:
    calc(var(--tr) * 5px * var(--trdx)) calc(var(--tr) * 5px * var(--trdy)) 5px rgba(232,232,234,.34),
    calc(var(--tr) * (10px + var(--ki) * .35px) * var(--trdx)) calc(var(--tr) * (10px + var(--ki) * .35px) * var(--trdy)) 12px rgba(217,119,87,.22); }
</style></head><body>
<div id="stage">
  <div id="bg"></div>
  ${meshOn ? '<div id="bg-mesh"></div>' : ''}
  ${noiseOn ? '<div id="bg-noise"></div>' : ''}
  <div id="grid"></div>
  ${body}
  ${persistent}
  <div id="vig"></div>
</div>
<script>
const DUR = ${spec.duration};
// 风格 token（由 buildHtml 注入；classic 档 = 改动前的旧数值）—— 运行时默认值全部从这里取
const STYLED = ${JSON.stringify({
    mode: T.mode, dy: T.dy, dyDisplay: T.dyDisplay, easeDefault: T.easeDefault, easeDisplay: T.easeDisplay,
    packetHold: T.packetHold, packetEase: T.packetEase, density: T.density,
  })};
// ── 通用运行时：所有动画都由 data-in/out/fade/dy/scale/rotate/ease/trail 推导，不含逐元素数学 ──
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
// ── 缓动库（v4）：元素用 data-ease="名字" 选；默认 outCubic，与旧版完全一致 ──
//    全部是纯函数（同 t 必得同帧），逐帧渲染才可复现。
const EASE={
  linear:(x)=>clamp(x,0,1),
  outCubic:(x)=>1-Math.pow(1-clamp(x,0,1),3),
  inOutCubic:(x)=>{const c=clamp(x,0,1); return c<.5?4*c*c*c:1-Math.pow(-2*c+2,3)/2;},
  outExpo:(x)=>(x<=0?0:x>=1?1:1-Math.pow(2,-10*x)),
  spring:(x)=>{const c=clamp(x,0,1); return c<=0?0:c>=1?1:1-Math.exp(-8.5*c)*Math.cos(10.5*c);},
};
const easeOf=(n)=>EASE[n]??EASE.outCubic;
const easeOut=EASE.outCubic, easeExpo=EASE.outExpo;   // 兼容组件脚本里已有的旧名字

// 组件注册的逐帧回调（数字滚动计数、时间线节点点亮…），seek(t) 末尾统一调用。
// 这里只提供插槽，动画本身仍然全部由 data-* 推导，组件不写自己的时间数学。
const hooks = (window.__hooks = window.__hooks ?? []);

// 段落级门控：每个 section 只在 [start,end] 内可见，元素透明度再乘上它。
// 第一版没有这层，导致所有段落同时挂在画面上 —— 元素级进出场管不住段落。
const sections=[...document.querySelectorAll('[data-section]')].map(el=>({
  el, start:parseFloat(el.dataset.start), end:parseFloat(el.dataset.end),
  alpha:1,
}));
const nodes=[...document.querySelectorAll('[data-in]')].map(el=>{
  // 拖尾：运行时只加类名 + 在入场窗口喂标量 --tr，残影的形状全在 CSS 的 .tr-* 规则里
  const trail=el.dataset.trail ?? null;
  if(trail) el.classList.add('tr-'+trail, 'tr-'+(el.dataset.trailAxis ?? 'x'));
  return {
    el, sec:el.closest('[data-section]'),
    inT:parseFloat(el.dataset.in), outT:parseFloat(el.dataset.out ?? '99'),
    fadeIn:parseFloat(el.dataset.fade ?? '0.5'), fadeOut:parseFloat(el.dataset.fadeOut ?? '0.4'),
    dy:parseFloat(el.dataset.dy ?? String(STYLED.dy)), sc:parseFloat(el.dataset.scale ?? '1'),
    rot:parseFloat(el.dataset.rotate ?? '0'), ease:easeOf(el.dataset.ease ?? STYLED.easeDefault),
    trail, trailAmp:parseFloat(el.dataset.trailAmp ?? '1'),
  };
});
const packets=[...document.querySelectorAll('[data-track=packet]')].map(el=>({
  el, sec:el.closest('[data-section]'), axis:el.dataset.axis ?? 'x',
  from:parseFloat(el.dataset.from), to:parseFloat(el.dataset.to),
  inT:parseFloat(el.dataset.in), outT:parseFloat(el.dataset.out ?? '99'),
}));
const drawers=[...document.querySelectorAll('[data-track=drawer]')].map(el=>({
  el, sec:el.closest('[data-section]'),
  open:parseFloat(el.dataset.open), close:parseFloat(el.dataset.close ?? '99'),
  width:parseFloat(el.dataset.width ?? '268'),
}));
const shade=document.getElementById('phone-shade');
const stageEl=document.getElementById('stage');
const meshEl=document.getElementById('bg-mesh'), grainEl=document.getElementById('bg-noise');
const SW=stageEl?stageEl.clientWidth:1920, SH=stageEl?stageEl.clientHeight:1080;

// 沿轴推进的轨道元素：grow=拉伸到 t 对应长度（填充条），move=平移到 t 对应位置（游标）
const progresses=[...document.querySelectorAll('[data-track=progress]')].map(el=>({
  el, sec:el.closest('[data-section]'), mode:el.dataset.mode ?? 'move', axis:el.dataset.axis ?? 'x',
  a:parseFloat(el.dataset.a), b:parseFloat(el.dataset.b),
  from:parseFloat(el.dataset.from), to:parseFloat(el.dataset.to),
}));

function seek(t){
  // 段落门控：0.45s 淡入 / 0.35s 淡出
  const secAlpha=new Map();
  for(const s of sections){
    let a=1;
    if(t<s.start-0.001) a=0;
    else if(t<s.start+0.45) a=easeOut((t-s.start)/0.45);
    if(a>0){
      if(t>s.end) a=0;
      else if(t>s.end-0.35) a=Math.min(a,1-easeOut((t-(s.end-0.35))/0.35));
    }
    secAlpha.set(s.el,a);
    s.el.style.visibility=a<=0.001?'hidden':'visible';
  }
  for(const n of nodes){
    let o=1,y=0,s=1,r=0;
    if(t<n.inT) o=0;
    else if(t<n.inT+n.fadeIn){
      const p=(t-n.inT)/n.fadeIn, k=n.ease(p);   // spring 会过冲：位移/旋转用原值，透明度再夹一次
      o=clamp(k,0,1); y=n.dy*(1-k); r=n.rot*(1-k);
      s=1+(n.sc-1)*(1-easeExpo(p));
    }
    if(t>n.outT) o=0;
    else if(t>n.outT-n.fadeOut){const k=easeOut((t-(n.outT-n.fadeOut))/n.fadeOut); o=Math.min(o,1-k);}
    if(n.sec) o*=(secAlpha.get(n.sec) ?? 1);
    n.el.style.opacity=o;
    n.el.style.visibility=o<=0.001?'hidden':'visible';
    if(n.dy!==0||n.sc!==1||n.rot!==0) n.el.style.transform='translateY('+y+'px) scale('+s+') rotate('+r+'deg)';
    // 拖尾强度：只在入场窗口里非零，1.6 倍渐变时长内线性收干，之后恒为 0（不改旧场景的任何帧）
    if(n.trail){
      const tk=clamp((t-n.inT)/(n.fadeIn*1.6),0,1);
      n.el.style.setProperty('--tr', ((t<n.inT||t>n.outT)?0:(1-tk)*n.trailAmp).toFixed(3));
    }
  }
  // 光点：规范 3.2 —— 终点前留 packetHold 秒停顿，缓动换 outExpo/spring（轻微 overshoot）
  const pEase=easeOf(STYLED.packetEase);
  for(const p of packets){
    const span=Math.max((p.to-p.from)-STYLED.packetHold,0.001);
    const k=pEase(clamp((t-p.from)/span,0,1));
    const sa=(p.sec?secAlpha.get(p.sec):1) ?? 1;   // 段落门控同样作用于光点
    // 横屏沿 X 走、竖屏沿 Y 走（纵排链路的连接线是垂直的）
    p.el.style.transform = p.axis==='y'
      ? 'translateY('+(k*100)+'%) scale('+(t<p.inT||t>p.outT?0.6:1)+')'
      : 'translateX('+(k*100)+'%) translateX('+(-k*18)+'px) scale('+(t<p.inT||t>p.outT?0.6:1)+')';
    p.el.style.opacity=(t<p.inT||t>p.outT)?0:sa;
    p.el.style.visibility=(t<p.inT||t>p.outT||sa<=0.001)?'hidden':'visible';
  }
  for(const d of drawers){
    const open=easeOut(clamp((t-d.open)/((d.close-d.open)*0.18),0,1));
    const shut=easeOut(clamp((t-(d.close-0.7))/0.6,0,1));
    const x=-d.width*(1-open)+d.width*shut;
    d.el.style.transform='translateX('+x+'px)';
    const sa=(d.sec?secAlpha.get(d.sec):1) ?? 1;
    d.el.style.opacity=sa;
    if(shade){const a=(t>d.open&&t<d.close-0.7)?0.67*open:0.67*Math.max(0,1-shut); shade.style.opacity=a*sa;}
  }
  // 进度轨道：把 [data-from,data-to] 的时间区间线性映射到轴的 [data-a,data-b]（% → px 用舞台实宽/实高）
  for(const p of progresses){
    const k=clamp((t-p.from)/((p.to-p.from)||1),0,1);
    const spanP=p.b-p.a;
    if(p.axis==='y'){
      if(p.mode==='grow') p.el.style.height=(k*spanP)+'%';
      else p.el.style.transform='translateY('+(k*spanP/100*SH)+'px)';
    } else {
      if(p.mode==='grow') p.el.style.width=(k*spanP)+'%';
      else p.el.style.transform='translateX('+(k*spanP/100*SW)+'px)';
    }
  }
  for(const fn of hooks) fn(t);
  if(window.__prog) window.__prog.style.width=(clamp(t/DUR,0,1)*100)+'%';
  if(window.__marks&&window.__hudName){
    let name=window.__marks[0][1];
    for(const [at,n] of window.__marks) if(t>=at) name=n;
    window.__hudName.textContent=name;
  }
  const g=document.getElementById('grid'); if(g) g.style.transform='translate('+(-t*6)+'px,'+(-t*3)+'px)';
  // 背景层极慢视差（网格漂移的反方向）+ 颗粒逐帧错位；都给整数/定点值，保证同 t 同帧可复现
  if(meshEl) meshEl.style.transform='translate('+(t*3.2).toFixed(2)+'px,'+(t*1.7).toFixed(2)+'px) scale('+(1.03+t*0.0004).toFixed(4)+')';
  if(grainEl) grainEl.style.backgroundPosition=Math.round((t*53)%170)+'px '+Math.round((t*71)%170)+'px';
}
${scripts}
window.seek=seek; window.DUR=DUR; seek(0);
</script>
</body></html>`;
}
