#!/usr/bin/env node
/**
 * 视频质检：把"成片到底行不行"变成可读的数字与一张接触表。
 *
 * 检查项：
 *   1. 容器/流信息（时长、分辨率、帧率、编码）是否符合声明
 *   2. 黑帧检测（黑场/空洞段落）—— 渲染引擎最典型的失败是"某段什么都没画"
 *   3. 接触表（按帧号等距抽 12 帧拼 4×3；步长 = ⌊总帧数/12⌋ 帧，短片也能出图）
 *   4. 响度（有音轨时）—— 复用 EBU R128
 *   5. 音画同轴（A/V SYNC）：
 *      5a. 音视频时长一致性 |video_duration - audio_duration| ≤ 100ms（分别读两条流）
 *      5b. 音频起始静音 ≤ 200ms（起始长时间静音 = 整段音画错位的典型症状）
 *      5c. 音画相关性（音频能量包络 vs 画面变化包络，Pearson r）+ 显著性：
 *          - t 检验 p 值：t = r*sqrt(n-2)/sqrt(1-r^2)，df = 有效桶数 - 2
 *          - 置换检验经验 p 值：打乱一路包络 ≥2000 次，经验 p = (#{|r_perm| ≥ |r_obs|} + 1)/(有效置换次数 + 1)
 *          - 判据：|r| ≥ 阈值 **且** p < 0.05 才 PASS（阈值 --min-r 可配，显著性水平 --alpha 可配）
 *          - 反相（r 显著为负）同样"显著"，但 |r| 满足阈值时按趋势标注同相/反相
 *
 * 用法:
 *   node engine/qa.mjs --video out/xxx.mp4 [--expect-duration 45] [--expect-size 1920x1080]
 *                      [--av-tol 0.1] [--head-silence 0.2] [--bin 0.5] [--min-r 0.15]
 *                      [--alpha 0.05] [--perm 2000]
 *   node engine/qa.mjs --fixtures [--fixtures-dir engine/fixtures]
 *                      # 生成（缺失时）并回归两个夹具，断言"同相 PASS / 反相 FAIL"
 *   node engine/qa.mjs --fixtures --make-only    # 只生成夹具，不做断言
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const flag = (n, d) => { const i = argv.indexOf(`--${n}`); return i === -1 ? d : argv[i + 1]; };
const has = (n) => argv.includes(`--${n}`);

const FFMPEG = flag('ffmpeg', 'D:\\dsh-video\\tools\\ffmpeg\\ffmpeg.exe');
const FFPROBE = flag('ffprobe', 'D:\\dsh-video\\tools\\ffmpeg\\ffprobe.exe');
// 音画同轴参数（默认值即验收阈值）
const AV_TOL = Number(flag('av-tol', '0.1'));          // 5a: 双流时长差上限（秒）
const HEAD_SIL = Number(flag('head-silence', '0.2'));  // 5b: 开头静音上限（秒）
const BIN = Number(flag('bin', '0.5'));                // 5c: 包络分桶宽度（秒）；音频窗口由实现保证等于它
const MIN_R = Number(flag('min-r', '0.15'));           // 5c: |r| 阈值（PASS 的必要条件）
const ALPHA = Number(flag('alpha', '0.05'));           // 5c: 显著性水平（PASS 的另一必要条件）
const PERM_N = Math.max(2000, Number(flag('perm', '2000')) || 2000); // 5c: 置换检验次数（下限 2000）

// 必须用 spawnSync：execFileSync 成功时不返回 stderr，而 ffmpeg 的分析结果全在 stderr，
// 会导致"响度拿到 null"、"黑帧检测在空输入上假通过"这类静默错误。
const run = (cmd, args) => {
  const r = spawnSync(cmd, args, { encoding: 'utf8', windowsHide: true, maxBuffer: 128 * 1024 * 1024 });
  return { out: r.stdout ?? '', err: r.stderr ?? '', status: r.status ?? 0 };
};

const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : null; };
// 读 PNG 真实宽高（直接解析 IHDR：字节 16..19 = 宽，20..23 = 高），不引第三方依赖。
// 用途：接触表"是否生成"不能只看字节数——低熵画面（合成夹具）实测只有 6.5KB。
const readPngSize = (p) => {
  try {
    const b = fs.readFileSync(p);
    if (b.length < 24 || b.toString('latin1', 1, 4) !== 'PNG') return null;
    return { w: b.readUInt32BE(16), h: b.readUInt32BE(20), bytes: b.length };
  } catch { return null; }
};
const getStreamDuration = (st) => num(st?.duration) ?? num(st?.tags?.DURATION) ?? null;
// 音频 RMS（dB）转线性功率，负值域 → 正值，避免对数域相关系数被压缩失真
const dbToLin = (db) => (Number.isFinite(db) ? Math.pow(10, db / 10) : 0);

// ── 统计：Pearson r + 两种显著性 ──
const pearson = (x, y) => {
  const n = Math.min(x.length, y.length);
  if (n < 8) return { r: null, n };
  const xs = x.slice(0, n), ys = y.slice(0, n);
  const mx = xs.reduce((s, v) => s + v, 0) / n, my = ys.reduce((s, v) => s + v, 0) / n;
  let sxy = 0, sxx = 0, syy = 0;
  for (let i = 0; i < n; i++) { const a = xs[i] - mx, b = ys[i] - my; sxy += a * b; sxx += a * a; syy += b * b; }
  if (sxx === 0 || syy === 0) return { r: null, n, note: '某一路包络恒定（如纯静音），标准差为 0' };
  return { r: +(sxy / Math.sqrt(sxx * syy)).toFixed(4), n };
};

// 对数伽马（Lanczos），用于 t 分布尾概率；不引入外部依赖，数值稳定
const lgamma = (z) => {
  const g = [676.5203681218851, -1259.1392167224028, 771.32342877765313,
    -176.61502916214059, 12.507343278686905, -0.13857109526572012,
    9.9843695780195716e-6, 1.5056327351493116e-7];
  if (z < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * z)) - lgamma(1 - z);
  z -= 1;
  let x = 0.99999999999980993;
  for (let i = 0; i < g.length; i++) x += g[i] / (z + i + 1);
  const t = z + g.length - 0.5;
  return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
};
// 正则化不完全贝塔函数 I_x(a,b)：连分式（Lentz），收敛快且无需第三方库
const betacf = (a, b, x) => {
  const FPMIN = 1e-300;
  const qab = a + b, qap = a + 1, qam = a - 1;
  let c = 1, d = 1 - qab * x / qap;
  if (Math.abs(d) < FPMIN) d = FPMIN;
  d = 1 / d;
  let h = d;
  for (let m = 1; m <= 300; m++) {
    const m2 = 2 * m;
    let aa = m * (b - m) * x / ((qam + m2) * (a + m2));
    d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
    c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d; h *= d * c;
    aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
    d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
    c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    const del = d * c; h *= del;
    if (Math.abs(del - 1) < 3e-12) break;
  }
  return h;
};
const betai = (a, b, x) => {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const bt = Math.exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * Math.log(x) + b * Math.log(1 - x));
  return x < (a + 1) / (a + b + 2) ? bt * betacf(a, b, x) / a : 1 - bt * betacf(b, a, 1 - x) / b;
};
// t 分布双尾 p 值，自由度 df = 有效桶数 - 2
const tTestP = (r, n) => {
  const df = n - 2;
  if (!(df > 0) || r === null || !Number.isFinite(r)) return { t: null, df, p: null };
  if (Math.abs(r) >= 1) return { t: Infinity, df, p: 0 };
  const t = r * Math.sqrt(df) / Math.sqrt(1 - r * r);
  return { t: +t.toFixed(4), df, p: +betai(df / 2, 0.5, df / (df + t * t)).toFixed(6) };
};
// 确定性 PRNG（xorshift32）：置换检验可复现，同一输入永远同一 p 值
const makeRng = (seed) => {
  let s = seed >>> 0 || 0x9e3779b9;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
};
// 置换检验：固定 x，打乱 y，统计 |r_perm| ≥ |r_obs| 的比例（经验 p 值）
const permTest = (x, y, obsR, nPerm, seed = 123456789) => {
  const n = Math.min(x.length, y.length);
  if (n < 8 || obsR === null) return { p: null, n_perm: 0 };
  const xs = x.slice(0, n), ys = y.slice(0, n);
  const rnd = makeRng(seed);
  const col = ys.slice();
  const absObs = Math.abs(obsR);
  let ge = 0, tried = 0;
  for (let k = 0; k < nPerm; k++) {
    for (let i = n - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const tmp = col[i]; col[i] = col[j]; col[j] = tmp; }
    const p = pearson(xs, col);
    if (p.r === null) continue;
    tried++;
    if (Math.abs(p.r) >= absObs) ge++;
  }
  return { p: +((ge + 1) / (tried + 1)).toFixed(6), n_perm: tried, ge, seed, min_perm: 2000 };
};

// 仅取"画面变化较大且音频有声"的桶再算一次：静止段(帧差≈0)和静音段会把 |r| 稀释，
// 单看全量 r 容易把同步的内容判成不同步。画面阈值取变化量的 60% 分位（自适应不同片子动态），
// 主判据仍用全量 r，这一项只是诊断。
const pearsonActive = (audioLin, videoChange) => {
  const n = Math.min(audioLin.length, videoChange.length);
  if (n < 8) return { r: null, n, thr: null };
  const sorted = [...videoChange.slice(0, n)].sort((a, b) => a - b);
  const thr = sorted[Math.floor(n * 0.6)] || 0;
  const xs = [], ys = [];
  for (let i = 0; i < n; i++) if (videoChange[i] > thr && audioLin[i] > 1e-9) { xs.push(audioLin[i]); ys.push(videoChange[i]); }
  const p = pearson(xs, ys);
  return { r: p.r, n: xs.length, thr: +thr.toFixed(4), kept: `${xs.length}/${n}` };
};

// ── 两路包络的窗口对齐 ──
// 音频桶 i 覆盖 [i*BIN, (i+1)*BIN)；视频桶因 tblend 丢掉前 2 帧（0.25s@8fps），桶 0 实际从
// 0.25s 起，即视频桶最多比音频桶晚半个桶（不是"整桶"）。
// 旧注释写"实测 6s/0.5s 时视频序列相对音频落后 1 个桶，这里把视频序列左移对齐"，与实现不符：
// 实现 shift 恒为 0（见函数体），而且若真落后 1 个桶，1Hz 交替的同相夹具会算出 r=-1，实测 r=+1。
// 故此处只把"两序列等长"显式化，不做位移；半桶偏移保留在噪声里。
const alignSeries = (audio, video, bin) => {
  const shift = 0; // 实测（6s/0.5s 与 45s/0.5s）：视频桶 i 与音频桶 i 已对齐，不需要位移
  const vs = video.slice(shift);
  const n = Math.min(audio.length, vs.length);
  return { a: audio.slice(0, n), v: vs.slice(0, n), shift, n };
};

// 画面"变化量"包络：以 4/BIN fps（BIN=0.5 → 8fps，实测 45s 片出 359 帧 showinfo）的采样率
// 抽帧做帧差（tblend=difference），再按 BIN 秒聚合为平均值。相比"相邻抽帧均值差"，帧差对局部
// 变化（主体移动、转场、逐字排版出现）敏感，也不会因抽帧间隔大而整桶漏掉变化 → 相关系数才有分辨力。
const getVideoChangeSeries = (video, bin) => {
  const sub = Math.max(1, Math.round(1 / bin * 4)); // 采样率 = 4/BIN 帧每秒（旧注释写"4×BIN"是错的）
  const r = run(FFMPEG, ['-hide_banner', '-nostats', '-i', video, '-an',
    '-vf', `fps=${sub},scale=160:90:flags=area,format=gray,tblend=all_mode=difference,showinfo`,
    '-f', 'null', '-']);
  const raw = [];
  for (const m of ((r.err || '') + (r.out || '')).matchAll(/mean:\[([\d.-]+)\]/g)) raw.push(Number(m[1]));
  // 固定丢前 2 帧（=0.25s@8fps）：tblend 对首个输出帧没有参考帧，mean 恒为 0（假变化），必须剔除。
  // 旧注释写"丢 1~2 个样本"，实现是恒丢 2。
  const usable = raw.slice(raw.length ? 2 : 0);
  const per = Math.max(1, Math.round(sub * bin)); // 每桶应有的采样帧数
  const bins = [];
  for (let i = 0; i + per <= usable.length; i += per) {
    const seg = usable.slice(i, i + per);
    bins.push(+(seg.reduce((s, v) => s + v, 0) / seg.length).toFixed(4));
  }
  // 对照项：同一份帧差序列**不剔除**头 2 帧、按同样每桶帧数再聚合一次。
  // 注意：老字段名 lumaBins / r_energy_vs_luma 是错的——那两路正则
  // （/mean:\[..\]/ 与 /mean:\[..\].*?stdev/）实测抓到 359/359 个**完全相同**的值，
  // 即"亮度对照"其实是同一份帧差序列；名字与用法都已改正。
  const binsHeadKept = [];
  for (let i = 0; i + per <= raw.length; i += per) {
    const seg = raw.slice(i, i + per);
    binsHeadKept.push(+(seg.reduce((s, v) => s + v, 0) / seg.length).toFixed(4));
  }
  return { raw, bins, binsHeadKept, frames: usable.length, sample_fps: sub, per_bin: per };
};

// 音频能量包络：astats 的 Overall.RMS_level。
// 三条实测结论（都用 `asetnsamples=...,ashowinfo` 现场量过 rate/nb_samples，不是猜的）：
//   1) reset 按"音频帧数"计数，不先 asetnsamples 就只能得到 ~21ms 的碎包；
//   2) **输出选项 -ar 不作用于滤镜链之前**：`-i x -ar 22050 -af asetnsamples=n=11025` 实测
//      asetnsamples 拿到的是源采样率 —— 48kHz 源 → rate:48000 nb_samples:11025，单窗
//      11025/48000 = **0.2297s**；22.05kHz 源 → rate:22050 nb_samples:11025，单窗 0.5s。
//      即窗口宽度随源采样率漂移，而报告里写死"0.5s@48k" → 标注与实现不符（本文件已修）。
//   3) "asetnsamples 单帧上限 11025 样本"不成立：实测 n=48000 → nb_samples=48000（1.0s），
//      n=96000 → nb_samples=96000（2.0s），无上限。
// 因此把重采样写进滤镜链（aresample 放在 asetnsamples 之前），窗口恒等于 BIN：
// 11025/22050 = 0.5s，48k 与 22.05k 源实测均为 0.5s。
// 为什么选择"改实现"而不是"改标注说明真实值"：包络窗口 ≠ 分桶宽度时，音频点与视频桶不是
// 同一时间基底，alignSeries 逐点配对会把"音频前 0.2297s×k"对上"视频前 0.5s×k"——实测 45s 片
// 音频 196 点 vs 视频 89 桶，只配前 89 对，等于拿音频 0~20.4s 去对视频 0~44.5s，r 无意义。
const ENVELOPE_SR = 22050;   // 包络提取用采样率；单窗样本数 = ENVELOPE_SR * BIN（无 11025 上限）
const getAudioRmsSeries = (video, bin, sampleRate) => {
  const sr = ENVELOPE_SR;
  const frames = Math.max(1, Math.round(sr * bin));
  const r = run(FFMPEG, ['-hide_banner', '-nostats', '-i', video, '-map', '0:a:0',
    '-af', `aresample=${sr},asetnsamples=n=${frames}:p=0,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-`,
    '-f', 'null', '-']);
  const out = [];
  for (const m of ((r.out || '') + (r.err || '')).matchAll(/RMS_level=(-?[\d.]+|inf|-inf)/g)) {
    const v = m[1] === 'inf' ? 0 : m[1] === '-inf' ? -120 : Number(m[1]);
    out.push(+dbToLin(v).toFixed(9));
  }
  // per_bin_sec 现在是"实现里真实生效"的窗口宽度（因为窗口宽度由 aresample 后的采样率决定）。
  // 报告里另加 envelope_resampled_in_graph，明确"重采样在链内"，避免以后有人再被 -ar 的顺序坑到。
  return { values: out, frame_samples: frames, per_bin_sec: +(frames / sr).toFixed(4), source_sr: sampleRate ?? null, envelope_sr: sr, resample: `aresample=${sr}（滤镜链内首次）` };
};

// 开头静音长度：解析 silencedetect，取覆盖 t=0 的那一段的结束时刻
const getHeadSilence = (video) => {
  const r = run(FFMPEG, ['-hide_banner', '-nostats', '-i', video, '-map', '0:a:0',
    '-af', 'silencedetect=n=-50dB:d=0.1', '-f', 'null', '-']);
  const txt = (r.err || '') + (r.out || '');
  let cur = null, head = 0, total = 0, segs = 0;
  for (const line of txt.split('\n')) {
    const s = /silence_start:\s*(-?[\d.]+)/.exec(line);
    const e = /silence_end:\s*([\d.]+)/.exec(line);
    if (s) { cur = Number(s[1]); segs++; }
    if (e) { const end = Number(e[1]); const st = cur ?? 0; total += Math.max(0, end - st); if (st <= 0.05 && end > head) head = end; cur = null; }
  }
  const tailOpen = /silence_start:/.test(txt.split('\n').slice(-3).join('\n')) ? cur : null;
  return { head: +head.toFixed(3), total: +total.toFixed(3), segments: segs, tail_open: tailOpen };
};

// ── 夹具生成（脚本化，全部由 ffmpeg lavfi 现生成，绝不手搓二进制）──
// 设计（每一处都是实测确定的，不是猜的）：
//   音频：880Hz 正弦被 1Hz 方波通断 → 每 1s 里前 0.5s 有声、后 0.5s 静音。
//         0.5s 分桶后包络交替（本轮实测 dB = -3.0729,-43.4715,-3.0399,-45.2021,… →
//         线性功率 0.4926,4.50e-05,0.4966,3.02e-05,…；旧注释写"0.49,0,0.50,0"把静音桶
//         当成了 0，实际是 ~4.5e-05 的小值，已按实测改写）。这就是"音频有起伏"的基准。
//   画面：整幅白块只在"每 1s 的第 1 帧"亮一帧（单帧脉冲），其余帧保持不变。
//         帧差包络因此也是交替的（本轮实测 showinfo 原始 mean = 0,0,0,207,0,207,…，
//         剔除头 2 帧后按每桶 4 帧取均值 → bins = 0,103.5,0,103.5,…，与整片均值
//         56.45 = 6×103.5/11 一致）。注意不能用"亮半秒"，
//         那会让每帧都有同幅跳变 → 帧差恒定 → 包络标准差为 0 → Pearson 直接不可定义。
//   相位（pulseAt 为画面脉冲在 1s 周期内的起点，均由实测确定）：
//     pulseAt=0.5 → 画面在音频**有声**的那半秒脉冲 → r=+1（同相）
//     pulseAt=0   → 画面在音频**静音**的那半秒脉冲 → r=-1（反相）
//     pulseAt=0.25（或不脉冲）→ 每帧都有等幅跳变 → 帧差恒定 → r 不可定义
// 判据：同相 → r=+1 且 p≈0 → PASS；反相 → |r|=1 但方向为负 → 判为反相并对齐失败。
const FIXTURE_SPECS = [
  { name: 'sync-inphase.mp4', label: '同相', expect: 'PASS', pulseAt: 0.5, wantTrend: '同相' },
  { name: 'sync-antiphase.mp4', label: '反相', expect: 'FAIL', pulseAt: 0, wantTrend: '反相' },
  { name: 'av-degenerate.mp4', label: '退化(帧差恒定)', expect: 'FAIL', pulseAt: null, wantTrend: '未知' },
];
const FIXTURE_SEC = 6, FIXTURE_FPS = 8;
const makeFixtures = (dir) => {
  fs.mkdirSync(dir, { recursive: true });
  const built = [];
  for (const spec of FIXTURE_SPECS) {
    const outFile = path.join(dir, spec.name);
    // 音频：1Hz 方波通断的 880Hz 正弦（方波由 if(gt(sin(...),0)) 生成，边界干净无爆音）
    const afilter = `aevalsrc='sin(880*PI*t)*if(gt(sin(PI*t*2),0),1,0)':s=22050:d=${FIXTURE_SEC}`;
    // 画面：每 1s 只有 1 帧是白的（脉冲宽度 = 1/FPS 秒），相位由 pulseAt 决定；
    // pulseAt=null 时改成"每帧都翻转"→ 帧差恒定 → 包络标准差 0（用于演示 r 不可定义）
    const w = 1 / FIXTURE_FPS;
    const on = spec.pulseAt === null
      ? 'lt(mod(t,1),0.5)'                     // 亮/暗各半秒 → 每帧都变
      : `between(mod(t,1),${spec.pulseAt},${spec.pulseAt + w})`; // 单帧脉冲
    const vf = `drawbox=x=0:y=0:w=256:h=144:c=white@1:t=fill:enable='${on}',format=gray`;
    const r = run(FFMPEG, ['-y', '-hide_banner', '-loglevel', 'error',
      '-f', 'lavfi', '-i', `color=s=256x144:r=${FIXTURE_FPS}:d=${FIXTURE_SEC}:c=0x303030`,
      '-f', 'lavfi', '-i', afilter,
      '-vf', vf,
      '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '30', '-g', `${FIXTURE_FPS}`, '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '32k', '-ac', '1', '-ar', '22050',
      '-shortest', '-movflags', '+faststart', outFile]);
    const ok = fs.existsSync(outFile) && fs.statSync(outFile).size > 0;
    built.push({ ...spec, file: outFile, bytes: ok ? fs.statSync(outFile).size : 0, ok, log: (r.err || '').slice(-300) });
  }
  return built;
};

// ── 单个视频的完整检查（供 --video 与 --fixtures 共用）──
const checkVideo = (VIDEO) => {
  const checks = [];
  const add = (name, ok, detail) => { checks.push({ name, ok: Boolean(ok), detail }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${name}  (${detail})`); };
  const EXPECT_DUR = flag('expect-duration', '');
  const EXPECT_SIZE = flag('expect-size', '');

  console.log(`\n视频质检: ${path.basename(VIDEO)}`);

  // ── 1. 流信息 ──
  const probe = JSON.parse(run(FFPROBE, ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', VIDEO]).out || '{}');
  const v = (probe.streams ?? []).find((s) => s.codec_type === 'video') ?? {};
  const a = (probe.streams ?? []).find((s) => s.codec_type === 'audio');
  const dur = Number(probe.format?.duration ?? 0);
  const fps = (() => { const [n, d] = String(v.r_frame_rate ?? '0/1').split('/').map(Number); return d ? n / d : 0; })();
  console.log(`  容器: ${(Number(probe.format?.size ?? 0) / 1048576).toFixed(2)}MB  ${dur}s  ${v.width}x${v.height} @${fps.toFixed(2)}fps  ${v.codec_name}${a ? ` + ${a.codec_name} ${a.sample_rate}Hz/${a.channels}ch` : ' (无音轨)'}`);

  add('分辨率符合预期', !EXPECT_SIZE || `${v.width}x${v.height}` === EXPECT_SIZE, `${v.width}x${v.height}${EXPECT_SIZE ? ` / 期望 ${EXPECT_SIZE}` : ''}`);
  add('时长符合预期', !EXPECT_DUR || Math.abs(dur - Number(EXPECT_DUR)) < 0.3, `${dur}s${EXPECT_DUR ? ` / 期望 ${EXPECT_DUR}s` : ''}`);
  add('帧率 ≥24fps（不要有掉帧的顿感）', fps >= 24, `${fps.toFixed(2)}fps`);

  // ── 2. 黑帧检测 ──
  const bd = run(FFMPEG, ['-hide_banner', '-i', VIDEO, '-vf', 'blackdetect=d=0.5:pix_th=0.06', '-an', '-f', 'null', '-']);
  const blackLines = ((bd.err || '') + (bd.out || '')).split('\n').filter((l) => l.includes('black_start'));
  const blackSpans = blackLines.map((l) => {
    const s = Number(/black_start:([\d.]+)/.exec(l)?.[1] ?? 0);
    const e = Number(/black_end:([\d.]+)/.exec(l)?.[1] ?? 0);
    return { start: s, end: e, len: +(e - s).toFixed(2) };
  });
  add('无 ≥0.5s 的纯黑段（引擎漏画会表现为黑场）', blackSpans.length === 0,
      blackSpans.length ? blackSpans.map((b) => `${b.start}~${b.end}s`).join(', ') : '未检出');

  // ── 3. 接触表 ──
  // 标注/实现对齐（两处都实测过）：
  //   ① 旧注释写"每 5 秒抽 1 帧"，实际步长是 round(dur/12) 秒 —— 45s 片实测 4s/帧。
  //   ② 旧的"已生成"判据是 size>10KB（把字节数当信息量代理）：6s 夹具实测产出的是
  //      1920x810 / 6518 字节的合法 PNG，图其实生成了，却被报成"生成失败"（假失败）。
  //      现改为读 PNG IHDR 真实尺寸 + 校验取用帧数。
  // 另：旧实现用 fps=1/step 抽帧，6s 片只取到 6 帧，tile 4x3 里 6 格是补黑的；
  // 改为按帧号等距取帧后，12 格都是真帧（45s 片：每 112 帧取 1，步长 3.7s）。
  const cols = 4, rows = 3;
  const sheet = VIDEO.replace(/\.mp4$/i, '') + '-contact.png';
  if (fs.existsSync(sheet)) fs.rmSync(sheet);
  const nbFrames = Number(v.nb_frames ?? 0) || Math.max(1, Math.round(dur * fps));
  const pick = Math.max(1, Math.floor(nbFrames / (cols * rows))); // 每 pick 帧取 1 帧 → 保证 ≥12 帧
  const selected = Math.floor(nbFrames / pick);
  run(FFMPEG, ['-y', '-hide_banner', '-loglevel', 'error', '-i', VIDEO, '-an',
    '-vf', `select='not(mod(n,${pick}))',scale=480:-1,tile=${cols}x${rows}`, '-frames:v', '1', sheet]);
  const sheetDim = readPngSize(sheet);
  const sheetOk = Boolean(sheetDim) && sheetDim.w === 480 * cols && sheetDim.h % rows === 0 && fs.statSync(sheet).size > 1000;
  const cellsOk = selected >= cols * rows;
  add('接触表已生成且 12 格均为真帧（用于人眼复核节奏）', sheetOk && cellsOk,
      sheetOk
        ? `${path.basename(sheet)} ${(fs.statSync(sheet).size / 1024).toFixed(1)}KB ${sheetDim.w}x${sheetDim.h} · 步长 ${(pick / fps).toFixed(2)}s/帧（每 ${pick} 帧取 1）· 取用 ${selected} 帧${cellsOk ? '' : ' ← 不足 12 帧'}`
        : `生成失败（文件${fs.existsSync(sheet) ? `存在但尺寸不符 dim=${sheetDim ? `${sheetDim.w}x${sheetDim.h}` : '非 PNG'}` : '缺失'}）`);

  // ── 4. 响度 ──
  let lufs = null, tp = null;
  if (a) {
    const r = run(FFMPEG, ['-hide_banner', '-nostats', '-i', VIDEO, '-af', 'ebur128=peak=true:framelog=quiet', '-f', 'null', '-']);
    const txt = (r.err || '') + (r.out || '');
    for (const line of txt.split('\n')) {
      const l = line.trim();
      if (l.startsWith('I:') && lufs === null) { try { lufs = parseFloat(l.split(/\s+/)[1]); } catch {} }
      if (l.startsWith('Peak:') && tp === null) { try { tp = parseFloat(l.split(/\s+/)[1]); } catch {} }
    }
    add('混音响度在 -16~-12 LUFS', lufs !== null && lufs >= -16 && lufs <= -12, `I=${lufs} LUFS`);
  }

  // ── 5. 音画同轴 ──
  const vDur = getStreamDuration(v);
  const aDur = a ? getStreamDuration(a) : null;
  const durDelta = (vDur !== null && aDur !== null) ? +Math.abs(vDur - aDur).toFixed(3) : null;
  if (!a) {
    add('A/V 双流时长一致（|Δ| ≤ 100ms）', true, '无音轨，本项 N/A');
  } else if (durDelta === null) {
    add('A/V 双流时长一致（|Δ| ≤ 100ms）', false, `流级时长读取失败 video=${vDur} audio=${aDur}`);
  } else {
    add('A/V 双流时长一致（|Δ| ≤ 100ms）', durDelta <= AV_TOL,
        `video=${vDur}s audio=${aDur}s Δ=${(durDelta * 1000).toFixed(0)}ms / 上限 ${(AV_TOL * 1000).toFixed(0)}ms`);
  }

  let headSil = null, silInfo = null;
  if (a) {
    silInfo = getHeadSilence(VIDEO);
    headSil = silInfo.head;
    add(`音频起始静音 ≤ ${(HEAD_SIL * 1000).toFixed(0)}ms（防整段错位）`, headSil <= HEAD_SIL,
        `起始静音 ${(headSil * 1000).toFixed(0)}ms · 全片静音 ${silInfo.total}s/${silInfo.segments} 段${headSil > 0 ? '（起点被静音覆盖）' : ''}`);
  }

  let corr = null, sig = null;
  if (a) {
    const vs = getVideoChangeSeries(VIDEO, BIN);
    const as = getAudioRmsSeries(VIDEO, BIN, Number(a.sample_rate) || 48000);
    const al = alignSeries(as.values, vs.bins, BIN);          // 按窗口起点对齐两路序列
    const pr = pearson(al.a, al.v);   // 音频能量(线性) vs 画面帧差包络
    const prValid = pearsonActive(al.a, al.v); // 只保留画面确有变化（>60% 分位）的桶
    // 对照：同一份帧差序列不剔头 2 帧的版本（老名字 r_energy_vs_luma 是错的，见 getVideoChangeSeries）
    const prHeadKept = pearson(al.a, (vs.binsHeadKept ?? []).slice(al.shift));
    // 自检：音频窗口必须等于 BIN，且音频点数与理论点数 round(dur/BIN) 相差 ≤2
    // （历史上窗口漂成 0.2297s 时，45s 片音频点 196 vs 理论 90，相差 106 → 这里会直接 FAIL）
    const expectPts = Math.round(dur / BIN);
    const winOk = Math.abs(as.per_bin_sec - BIN) < 1e-6;
    const ptsOk = Math.abs(as.values.length - expectPts) <= 2;
    add(`音频包络窗口 = 分桶宽度 BIN=${BIN}s（标注与实现一致）`, winOk && ptsOk,
        `窗口 ${as.per_bin_sec}s @${as.envelope_sr}Hz（源 ${as.source_sr ?? '?'}Hz，${as.resample}）· 点数 ${as.values.length} / 理论 ${expectPts} · ${winOk ? '窗口✓' : '窗口✗'}/${ptsOk ? '点数✓' : '点数✗'}`);
    // 显著性：自由度 = 有效桶数 - 2
    const tt = tTestP(pr.r, pr.n);
    const pm = permTest(al.a, al.v, pr.r, PERM_N);
    const tValid = tTestP(prValid.r, prValid.n); // 诊断：仅有效桶上的显著性
    sig = { n: pr.n, df: tt.df, t: tt.t, p_t: tt.p, p_perm: pm.p, n_perm: pm.n_perm, ge: pm.ge, perm_seed: pm.seed };
    corr = {
      method: 'Pearson( 音频线性功率包络 , 画面帧差包络 )，逐 BIN 秒分桶后计算',
      audio_series: `ffmpeg aresample=${as.envelope_sr}→asetnsamples=n=${as.frame_samples}(=${as.per_bin_sec}s@${as.envelope_sr}Hz，链内重采样后实测) + astats Overall.RMS_level，dB→线性功率 10^(dB/10)`,
      video_series: `ffmpeg fps=${vs.sample_fps}(=4/BIN),scale=160:90,format=gray,tblend=all_mode=difference,showinfo → 每 ${vs.per_bin} 帧取 mean 平均`,
      bin_sec: BIN, tolerance_ms: AV_TOL * 1000, head_silence_max_ms: HEAD_SIL * 1000,
      video_frames: vs.frames, video_bins: vs.bins.length, audio_samples: as.values.length, pairs: pr.n,
      envelope_window_sec: as.per_bin_sec, envelope_sr: as.envelope_sr, source_sr: as.source_sr ?? null,
      bin_alignment: { window_ok: winOk, expected_audio_points: expectPts, points_ok: ptsOk },
      r_energy_vs_change: pr.r, r_abs: pr.r === null ? null : +(Math.abs(pr.r)).toFixed(4),
      r_energy_vs_change_valid_bins: prValid.r, valid_pairs: prValid.kept,
      r_energy_vs_change_head_kept: prHeadKept.r, head_kept_pairs: prHeadKept.n,
      min_r_hint: MIN_R, video_change_bins: vs.bins, note: pr.note ?? null,
      // 新增：显著性（t 检验 + 置换检验）
      significance: {
        threshold_r: MIN_R, alpha: ALPHA, decision: 'PASS 需同时满足 |r| ≥ 阈值 且 p < alpha',
        n_bins_used: pr.n, df: tt.df, t_stat: tt.t, p_value_t: tt.p, method_t: 't = r*sqrt(df)/sqrt(1-r^2), df = 有效桶数-2',
        p_value_perm: pm.p, permutation_rounds_requested: PERM_N, permutation_rounds_run: pm.n_perm,
        permutations_ge_observed: pm.ge, permutation_seed: pm.seed, perm_min_rounds: 2000,
        valid_bins_only: { r: prValid.r, n: prValid.n, df: tValid.df, t: tValid.t, p_value_t: tValid.p },
      },
    };
    const tail = silInfo && silInfo.tail_open !== null ? ` · 尾部静音从 ${silInfo.tail_open}s 起` : '';
    const rAbs = pr.r === null ? null : Math.abs(pr.r);
    // 判据（三件套，缺一不可）：
    //   ① |r| ≥ 阈值   ② p < alpha（t 检验）   ③ 方向为正（同相）
    // 为什么必须加 ③：音画**反相**时 |r| 同样可能等于 1、p 也≈0，只按 |r| 判会把
    // 反相（画面动时音乐正处低谷）误判成 PASS。反相是真实存在的错位，必须算失败。
    const magOk = rAbs !== null && rAbs >= MIN_R;
    const sigOk = tt.p !== null && tt.p < ALPHA;
    const dirOk = pr.r !== null && pr.r > 0;
    const sign = pr.r === null ? '未知' : pr.r > 0 && rAbs >= MIN_R ? '同相' : pr.r < 0 && rAbs >= MIN_R ? '反相' : '无显著关联';
    sig.trend = sign; sig.direction_ok = dirOk;
    add(`音画包络显著同相（|r| ≥ ${MIN_R} 且 p < ${ALPHA} 且方向为正）`, magOk && sigOk && dirOk,
        `r=${pr.r === null ? 'null' : pr.r} (|r|=${rAbs}, n=${pr.n} 桶, bin=${BIN}s) · p_t=${tt.p}(t=${tt.t}, df=${tt.df}) · p_perm=${pm.p}(${pm.ge}/${pm.n_perm} 次置换 ≥ 观测) · 判据 ${magOk ? '|r|✓' : '|r|✗'}/${sigOk ? 'p✓' : 'p✗'}/${dirOk ? '方向✓' : '方向✗'} · 趋势=${sign} · 仅有效桶 r=${prValid.r}(${prValid.kept}, p_t=${tValid.p}) · 画面变化包络均值 ${(vs.bins.reduce((s, v2) => s + v2, 0) / Math.max(1, vs.bins.length)).toFixed(2)}${tail}`);
  }

  // ── 落盘 ──
  const report = {
    video: VIDEO, size_mb: +(Number(probe.format?.size ?? 0) / 1048576).toFixed(2),
    duration: dur, width: v.width, height: v.height, fps: +fps.toFixed(3),
    has_audio: Boolean(a), lufs, true_peak: tp,
    av_sync: {
      video_duration: vDur, audio_duration: aDur, duration_delta_ms: durDelta === null ? null : +(durDelta * 1000).toFixed(1),
      tolerance_ms: AV_TOL * 1000, duration_ok: a ? (durDelta !== null && durDelta <= AV_TOL) : null,
      head_silence_ms: headSil === null ? null : +(headSil * 1000).toFixed(1),
      head_silence_max_ms: HEAD_SIL * 1000, head_silence_ok: a ? headSil <= HEAD_SIL : null,
      silence_total_sec: silInfo ? silInfo.total : null, silence_segments: silInfo ? silInfo.segments : null,
      correlation: corr,
      av_correlation_sig: sig ? { r: corr.r_energy_vs_change, ...sig, min_r: MIN_R, alpha: ALPHA, pass: Boolean(corr.r_abs !== null && corr.r_abs >= MIN_R && sig.p_t !== null && sig.p_t < ALPHA && sig.direction_ok) } : null,
    },
    black_spans: blackSpans, contact_sheet: sheet, checks,
  };
  const jsonPath = VIDEO.replace(/\.mp4$/i, '') + '-qa.json';
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), 'utf8');
  const passed = checks.filter((c) => c.ok).length;
  console.log(`\n  通过 ${passed}/${checks.length} 项 · 报告 ${path.basename(jsonPath)}`);
  return { report, checks, passed, total: checks.length, avCorrPass: report.av_sync.av_correlation_sig ? report.av_sync.av_correlation_sig.pass : null, trend: report.av_sync.av_correlation_sig ? report.av_sync.av_correlation_sig.trend : null, r: corr?.r_energy_vs_change ?? null, p: sig?.p_t ?? null, n: sig?.n ?? null };
};

const FIXTURE_DIR = flag('fixtures-dir', 'D:\\dsh-video\\engine\\fixtures');

if (has('fixtures')) {
  console.log(`\n夹具模式: ${FIXTURE_DIR}`);
  const built = makeFixtures(FIXTURE_DIR);
  for (const b of built) console.log(`  [生成] ${b.name} ${(b.bytes / 1024).toFixed(1)}KB${b.bytes > 300 * 1024 ? ' ← 超过 300KB 上限' : ''}${b.ok ? '' : ` 失败: ${b.log}`}`);
  const over = built.filter((b) => b.bytes > 300 * 1024 || !b.ok);
  if (over.length) console.log(`  [警告] ${over.length} 个夹具不满足 "存在且 <300KB"`);
  if (has('make-only')) process.exit(over.length ? 1 : 0);

  const results = [];
  for (const b of built) results.push({ spec: b, ...checkVideo(b.file) });
  console.log('\n── 夹具断言 ──');
  const asserts = [];
  for (const r of results) {
    const want = r.spec.expect === 'PASS';
    const got = r.avCorrPass === true;
    const trendOk = r.spec.wantTrend === r.trend;
    const ok = got === want && trendOk;
    asserts.push(ok);
    console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${r.spec.label}夹具期望 ${r.spec.expect}/趋势${r.spec.wantTrend}，实得 ${got ? 'PASS' : 'FAIL'}/趋势${r.trend} · r=${r.r} p_t=${r.p} n=${r.n} 桶 · ${r.spec.name} ${(r.spec.bytes / 1024).toFixed(1)}KB${ok ? '' : `  ← 不符（判定${got === want ? '对' : '错'}/趋势${trendOk ? '对' : '错'}）`}`);
  }
  const allOk = asserts.every(Boolean) && over.length === 0;
  console.log(`\n  夹具回归: ${allOk ? 'PASS（同相 PASS、反相与退化 FAIL）' : 'FAIL'}`);
  process.exit(allOk ? 0 : 1);
}

const VIDEO = flag('video', '');
if (!VIDEO || !fs.existsSync(VIDEO)) { console.error('缺少 --video <存在的文件>，或使用 --fixtures'); process.exit(2); }
const res = checkVideo(VIDEO);
process.exit(res.passed === res.total ? 0 : 1);
