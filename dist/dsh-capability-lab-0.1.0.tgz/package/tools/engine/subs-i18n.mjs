#!/usr/bin/env node
/**
 * 双语字幕导出 subs-i18n.mjs —— 从同一份场景 JSON 抽中文文案，产出 zh / bilingual 两份 SRT。
 *
 * 为什么不改 subs.mjs：subs.mjs 是单语轨的稳定出口（已被 subbed mp4 依赖）。
 * 这里只复用它"从 spec 抽文字、不另维护字幕文件"的口径，输出另起文件名。
 *
 * 抽取口径（与 subs.mjs 逐行等价）：caption.items / bullets.items / title(标题+副标题)
 * / cards(label+title：body) / outro.lines + repo.foot → 同一套排序、相邻去重、重叠截断。
 *
 * 校验：每条 ≤2 行、每行 ≤42 列（全角按 2 计）。超限先自动折行，再压缩措辞；
 * 仍超限的逐条列出（不静默截断，原文一字不丢地保留在报告里）。
 *
 * 英译：由模型直接产出，专有名词保留原文，风格按顶部术语表统一。
 * 中文两档：zh2 = zh.srt 用的原文（原样超 2 行时才轻度压缩）；zh1 = 双语版单行（重度压缩，≤42）。
 * 双语版一行中文一行英文，两侧互补承载信息（例如 URL 放在中文行、通道名放在英文行），
 * 目的是让 URL / 标识符不被折断。
 *
 * 用法: node engine/subs-i18n.mjs [--spec scenes/x.json] [--outdir out] [--name dsh-phone-access]
 */
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const flag = (n, d) => { const i = argv.indexOf(`--${n}`); return i === -1 ? d : argv[i + 1]; };
const SPEC = flag('spec', 'D:\\dsh-video\\engine\\scenes\\dsh-phone-access.json');
const OUTDIR = flag('outdir', 'D:\\dsh-video\\out');
const NAME = flag('name') ?? path.basename(SPEC, '.json');
const MAX_COLS = 42;
const MAX_LINES = 2;

// ══════════════════════════════════════════════════════════════════════════
// 术语表（常量，统一风格用）
// ══════════════════════════════════════════════════════════════════════════
const GLOSSARY = {
  core: {
    '反向代理': 'reverse proxy',
    '网关': 'gateway',
    '守护脚本 / 守护任务': 'watchdog',
    '栅栏（Host 白名单）': 'fence (Host allow-list)',
    '同源校验': 'same-origin check',
    '签名 Cookie': 'signed Cookie',
    '覆盖式抽屉': 'overlay drawer',
    '安全区': 'safe area',
    '软键盘': 'soft keyboard',
    '窄屏适配': 'narrow-screen fit',
    '网卡': 'NIC',
    '补绑': 'rebind',
    '无头浏览器': 'headless browser',
    '回归验证': 'regression-verified',
    '坑': 'pitfall',
    '入口': 'route',
  },
  // 保留原文，不翻译
  keep: [
    'DeepSeek Harness', 'DSH', 'proxy.mjs', 'mobile.css', 'mobile.js', 'watchdog.ps1',
    'Tailscale', 'Cloudflare', 'Cookie', 'Host', 'Origin', 'Accept-Encoding', 'HTML',
    'gzip', 'br', 'URL', 'CDP', 'Edge', 'iOS', 'UA', 'loopback', 'MIT License',
    '127.0.0.1', 'resizes-content', '403', '404',
  ],
  // 仅双语版单行使用的压缩写法（保证 ≤42 列且不折 URL）
  short: {
    'Cloudflare 隧道': 'Cloudflare tunnel',
    '局域网直连': 'LAN direct',
  },
};

// ══════════════════════════════════════════════════════════════════════════
// 译文表：逐条对齐抽取结果（zh 为原样，用于校验场景是否改动）
//   zh1 = 双语版中文单行；en1 = 双语版英文单行
//   zh2 = 原样超过 2 行时的轻度压缩版（仅卡片的 3 条需要）
// ══════════════════════════════════════════════════════════════════════════
const I18N = [
  { zh: '手机上使用 DeepSeek Harness',
    zh1: '手机端使用 DeepSeek Harness',
    en1: 'DeepSeek Harness on your phone' },
  { zh: '一个反向代理 + 一套手机端 UI 适配 · 不改动 DSH 任何文件',
    zh1: '一个反向代理 + 手机端 UI 适配 · DSH 零改动',
    en1: 'Reverse proxy + mobile UI, DSH untouched' },
  { zh: 'Host 栅栏只认 loopback / 监听器绑定 IP / --trusted-host',
    zh1: '放行三处：loopback/绑定 IP/--trusted-host',
    en1: 'Fence: loopback / bind IP / --trusted-host' },
  { zh: '首页能开，任何操作全 403 —— 单纯端口转发是行不通的',
    zh1: '首页能开，操作全 403：端口转发行不通',
    en1: 'All actions 403: plain port-forward fails' },
  { zh: '重写头部后：栅栏、签名 Cookie、同源校验 同时满足',
    zh1: '重写头部：栅栏/签名 Cookie/同源 全过',
    en1: 'Rewrite: fence, signed Cookie, origin OK' },
  { zh: 'Harness 仍只监听 127.0.0.1 —— 一行 DSH 代码都没改',
    zh1: 'Harness 仍只监听 127.0.0.1，DSH 零改动',
    en1: 'Harness still on 127.0.0.1, DSH untouched' },
  { zh: '入口 1 局域网直连：http://192.168.1.59:8080/',
    zh1: '入口1 局域网直连 http://192.168.1.59:8080/',
    en1: 'Route 1 LAN: http://192.168.1.59:8080/' },
  { zh: '入口 2 Cloudflare 隧道：https://xxx.trycloudflare.com',
    zh1: '入口2 隧道 https://xxx.trycloudflare.com',
    en1: 'Route 2: Cloudflare tunnel' },
  { zh: '入口 3 Tailscale 私网：http://dsh-pc:8080/',
    zh1: '入口3 Tailscale 私网 http://dsh-pc:8080/',
    en1: 'Route 3 Tailscale: http://dsh-pc:8080/' },
  { zh: '同一个网关，三种入口 · 网卡地址变化时守护脚本自动补绑',
    zh1: '一个网关三种入口，网卡变化守护脚本自动补绑',
    en1: 'One gateway, 3 routes; rebind on NIC swap' },
  { zh: '侧栏改覆盖式抽屉：正文 110px → 342px',
    zh1: '侧栏改覆盖式抽屉：正文 110px → 342px',
    en1: 'Sidebar → overlay drawer: 110 → 342px' },
  { zh: '点会话自动收起 + 遮罩点击关闭',
    zh1: '点会话自动收起 + 遮罩点击关闭',
    en1: 'Tap session: collapse; tap scrim to close' },
  { zh: '输入框 ≥16px，防 iOS 聚焦缩放',
    zh1: '输入框 ≥16px，防 iOS 聚焦缩放',
    en1: 'Input ≥16px to stop iOS zoom on focus' },
  { zh: '安全区 / 软键盘 resizes-content',
    zh1: '安全区 / 软键盘 resizes-content',
    en1: 'Safe area / soft keyboard resizes-content' },
  { zh: '消息 / 表格 / 代码块 / 弹窗按窄屏适配',
    zh1: '消息 / 表格 / 代码块 / 弹窗按窄屏适配',
    en1: 'Messages/tables/code/modals: narrow-ready' },
  { zh: '只对移动 UA 注入，桌面零影响（40385B 原样）',
    zh1: '只对移动 UA 注入，桌面零影响（40385B）',
    en1: 'Mobile UA only; desktop untouched 40385B' },
  { zh: '坑 1 gzip 未解压：上游按 Accept-Encoding 回 gzip/br，直接在压缩字节上改 HTML → 手机满屏乱码',
    zh2: '坑 1 gzip 未解压：上游回 gzip/br，在压缩字节上改 HTML → 手机乱码',
    zh1: '坑1 gzip 未解压：压缩字节上改 HTML → 乱码',
    en1: 'Pitfall 1: gzip not decoded → garbled page' },
  { zh: '坑 2 ?? 批量 URL：/plugins/??a,b 被 new URL() 当成查询串重写 → 插件全 404，界面起不来',
    zh2: '坑 2 ?? 批量 URL：被 new URL() 重写成查询串 → 插件全 404，界面起不来',
    zh1: '坑2 new URL() 改写批量 URL → 插件全 404',
    en1: 'Pitfall 2: new URL() broke ?? URLs → 404' },
  { zh: '坑 3 setTimeout 不触发：客户端里 setTimeout 回调一次都不跑（interval 正常）→ 抽屉不自动收起',
    zh2: '坑 3 setTimeout 不触发：回调一次都不跑（interval 正常）→ 抽屉不自动收起',
    zh1: '坑3 setTimeout 一次都不跑 → 抽屉不自动收起',
    en1: 'Pitfall 3: setTimeout dead; drawer stuck' },
  { zh: '每个坑都用「本机 Edge 无头 + CDP 真实点击」回归验证过',
    zh1: '每个坑都用 Edge 无头 + CDP 真实点击验证',
    en1: 'Verified in headless Edge via CDP clicks' },
  { zh: '守护任务',
    zh1: '守护任务',
    en1: 'Watchdog' },
  { zh: '每 5 分钟检查网关与隧道，掉了自动拉起',
    zh1: '每 5 分钟检查网关与隧道，掉了自动拉起',
    en1: 'Every 5 min: check gateway/tunnel, restart' },
  { zh: '网卡变化自动补绑 Tailscale 网段 · 桌面留最新地址',
    zh1: '网卡变化补绑 Tailscale 网段，桌面留地址',
    en1: 'NIC change: rebind Tailscale, desktop URL' },
  { zh: 'dsh-phone-access · 反向代理 + 手机端适配，一行 DSH 代码都没改',
    zh1: 'dsh-phone-access · 反向代理 + 手机端适配',
    en1: 'dsh-phone-access: reverse proxy, mobile UI' },
];

// ══════════════════════════════════════════════════════════════════════════
// 1) 抽取中文文案（口径 = subs.mjs）
// ══════════════════════════════════════════════════════════════════════════
const spec = JSON.parse(fs.readFileSync(SPEC, 'utf8'));
const stripTags = (s) => String(s ?? '')
  .replace(/<br\s*\/?>/gi, ' ')
  .replace(/<[^>]+>/g, '')
  .replace(/&nbsp;/g, ' ')
  .replace(/&amp;/g, '&')
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/\s+/g, ' ')
  .trim();

const cues = [];
for (const section of spec.sections) {
  const secEnd = section.end;
  for (const layer of section.layers) {
    const p = layer.props ?? {};
    const push = (text, inT, outT) => {
      const clean = stripTags(text);
      if (clean) cues.push({ start: inT, end: outT ?? secEnd, text: clean, section: section.id });
    };
    if (layer.type === 'caption') {
      const items = p.items ?? [];
      items.forEach((it, i) => push(it.text, it.in, it.out ?? items[i + 1]?.in ?? secEnd));
    } else if (layer.type === 'bullets') {
      const items = p.items ?? [];
      items.forEach((it, i) => push(it.text, it.in, it.out ?? items[i + 1]?.in ?? secEnd));
    } else if (layer.type === 'title') {
      push(`${p.title ?? ''} ${p.accent ?? ''}`, 1.0, secEnd);
      push(p.subtitle, 1.4, secEnd);
    } else if (layer.type === 'cards') {
      for (const it of p.items ?? []) push(`${it.label ?? ''} ${it.title ?? ''}：${it.body ?? ''}`, it.in, it.out ?? secEnd);
    } else if (layer.type === 'outro') {
      for (const l of p.lines ?? []) push(l.text, l.in, l.out ?? secEnd);
      if (p.repo?.foot) push(p.repo.foot, p.repo.footIn ?? p.repo.in, secEnd);
    }
  }
}
cues.sort((a, b) => a.start - b.start);
const cleaned = [];
for (const c of cues) {
  if (c.end - c.start < 0.35) continue;
  const prev = cleaned[cleaned.length - 1];
  if (prev && prev.text === c.text) { prev.end = Math.max(prev.end, c.end); continue; }
  if (prev && prev.end > c.start) prev.end = Math.max(prev.start + 0.3, c.start - 0.05);
  cleaned.push({ ...c });
}

// ══════════════════════════════════════════════════════════════════════════
// 2) 列宽 / 折行 / 压缩
// ══════════════════════════════════════════════════════════════════════════
const isWide = (ch) => {
  const c = ch.codePointAt(0);
  return (c >= 0x1100 && c <= 0x115f) || (c >= 0x2e80 && c <= 0xa4cf) ||
    (c >= 0xac00 && c <= 0xd7a3) || (c >= 0xf900 && c <= 0xfaff) ||
    (c >= 0xfe30 && c <= 0xfe4f) || (c >= 0xff00 && c <= 0xff60) ||
    (c >= 0xffe0 && c <= 0xffe6);
};
const width = (s) => [...String(s)].reduce((w, ch) => w + (isWide(ch) ? 2 : 1), 0);

// 可断点：空格两侧、常见标点之后、斜杠之后；括号/箭头之前也可断（避免把 URL、数字劈开）
const BREAK_AFTER = /[·，、；：,;:。！？!?\/）】」]/;
const BREAK_BEFORE = /[（(【「→—]/;
function wrap(text, maxCols = MAX_COLS, maxLines = MAX_LINES) {
  const chars = [...text];
  if (!chars.length) return [''];
  const breaks = new Set([chars.length]);
  chars.forEach((c, i) => {
    if (/\s/.test(c) && i > 0) breaks.add(i);
    if (/\s/.test(c)) breaks.add(i + 1);
    if (BREAK_AFTER.test(c)) breaks.add(i + 1);
    if (BREAK_BEFORE.test(c) && i > 0) breaks.add(i);
  });
  const lines = [];
  let start = 0;
  while (start < chars.length) {
    if (lines.length === maxLines - 1) { lines.push(chars.slice(start).join('')); break; }
    let w = 0, cut = -1;
    for (let i = start; i < chars.length; i++) {
      w += isWide(chars[i]) ? 2 : 1;
      if (w > maxCols) break;
      if (breaks.has(i + 1)) cut = i + 1;
    }
    if (cut <= start) {
      let w2 = 0, i = start;
      while (i < chars.length && w2 + (isWide(chars[i]) ? 2 : 1) <= maxCols) { w2 += isWide(chars[i]) ? 2 : 1; i++; }
      cut = Math.max(i, start + 1);
    }
    // 折行不得改写原文：切出来的行原样拼接必须等于输入（行尾空格留在上一行）
    lines.push(chars.slice(start, cut).join(''));
    start = cut;
  }
  return lines.filter((l, i) => l.length || i === 0);
}

// 兜底压缩规则：从"信息损失最小"开始，逐条施加；只有真的变短才采用
const SHRINK_ZH = [
  [/（[^）]*）/g, ''],                    // 去掉括号里的补充说明
  [/\s*——\s*/g, '：'],                   // 破折号收成冒号
  [/、/g, '/'],
  [/\s*·\s*/g, ' · '],
  [/，/g, ' '],
  [/([\u2e80-\u9fff])\s+([A-Za-z0-9≥])/g, '$1$2'],   // 最后手段：去掉中英之间的空格
  [/([A-Za-z0-9])\s+([\u2e80-\u9fff])/g, '$1$2'],
];
const SHRINK_EN = [
  [/\bDeepSeek Harness\b/g, 'DSH'],
  [/\s*—\s*/g, ': '],
  [/\bPitfall\b/g, 'Pit'],
  [/\band\b/g, '+'],
  [/\bthe\b\s*/gi, ''],
];

const fit = (text, maxCols, maxLines, rules) => {
  let cur = text;
  let lines = wrap(cur, maxCols, maxLines);
  const steps = [{ text: cur, lines }];
  if (ok(lines, maxCols, maxLines)) return steps;   // 已合格：一个字都不动
  for (const [re, to] of rules) {
    const next = String(cur).replace(re, to).replace(/\s{2,}/g, ' ').trim();
    if (next === cur || width(next) >= width(cur)) continue;   // 无收益就跳过
    cur = next;
    lines = wrap(cur, maxCols, maxLines);
    steps.push({ text: cur, lines });
    if (ok(lines, maxCols, maxLines)) break;
  }
  return steps;
};
const ok = (lines, maxCols = MAX_COLS, maxLines = MAX_LINES) =>
  lines.length <= maxLines && lines.every((l) => width(l) <= maxCols);

// ══════════════════════════════════════════════════════════════════════════
// 3) 逐条组装 + 校验（超限全部收集，不静默截断）
// ══════════════════════════════════════════════════════════════════════════
const report = { spec: SPEC, cues: cleaned.length, violations: [], compressed: [], mismatched: [] };
const zhRows = [], biRows = [];

cleaned.forEach((cue, i) => {
  const t = I18N[i];
  if (!t) { report.violations.push({ cue: i + 1, kind: 'missing-translation', text: cue.text }); zhRows.push([cue.text]); biRows.push([cue.text]); return; }
  if (t.zh !== cue.text) report.mismatched.push({ cue: i + 1, scene: cue.text, table: t.zh });

  // zh.srt：原样优先，原样折不下 2 行时用 zh2（轻度压缩），每步都记账
  let zhLines = wrap(cue.text);
  let zhNote = '原样';
  if (!ok(zhLines)) {
    const alt = t.zh2 ?? cue.text;
    const mid = fit(alt, MAX_COLS, MAX_LINES, SHRINK_ZH);
    zhLines = mid[mid.length - 1].lines;
    zhNote = t.zh2 ? 'zh2 轻度压缩' : '规则压缩';
    report.compressed.push({ cue: i + 1, file: 'zh', from: cue.text, fromWidth: width(cue.text), to: mid[mid.length - 1].text });
  }
  if (!ok(zhLines)) report.violations.push({ cue: i + 1, file: 'zh', reason: '折行后仍超限', lines: zhLines.map((l) => `${width(l)}列`), text: cue.text });

  // bilingual：中文一行 + 英文一行
  const zhFit = fit(t.zh1 ?? cue.text, MAX_COLS, 1, SHRINK_ZH);
  const enFit = fit(t.en1, MAX_COLS, 1, SHRINK_EN);
  const zhLine = zhFit[zhFit.length - 1].lines[0] ?? '';
  const enLine = enFit[enFit.length - 1].lines[0] ?? '';
  if (zhFit.length > 1) report.compressed.push({ cue: i + 1, file: 'bilingual-zh', from: t.zh1, fromWidth: width(t.zh1), to: zhLine });
  if (enFit.length > 1) report.compressed.push({ cue: i + 1, file: 'bilingual-en', from: t.en1, fromWidth: width(t.en1), to: enLine });
  if (width(zhLine) > MAX_COLS) report.violations.push({ cue: i + 1, file: 'bilingual-zh', reason: `${width(zhLine)} 列 > ${MAX_COLS}`, text: zhLine });
  if (width(enLine) > MAX_COLS) report.violations.push({ cue: i + 1, file: 'bilingual-en', reason: `${width(enLine)} 列 > ${MAX_COLS}`, text: enLine });

  zhRows.push(zhLines);
  biRows.push([zhLine, enLine]);
  report.cueRows ??= [];
  report.cueRows.push({
    cue: i + 1, start: cue.start, section: cue.section,
    zhLines: zhLines.length, zhMax: Math.max(...zhLines.map(width)), zhNote,
    biZh: width(zhLine), biEn: width(enLine),
  });
});

// ══════════════════════════════════════════════════════════════════════════
// 4) 写文件（不覆盖 dsh-phone-access.srt）
// ══════════════════════════════════════════════════════════════════════════
const fmt = (t, sep) => {
  const ms = Math.max(0, Math.round(t * 1000));
  const h = String(Math.floor(ms / 3600000)).padStart(2, '0');
  const m = String(Math.floor(ms / 60000) % 60).padStart(2, '0');
  const s = String(Math.floor(ms / 1000) % 60).padStart(2, '0');
  const f = String(ms % 1000).padStart(3, '0');
  return `${h}:${m}:${s}${sep}${f}`;
};
const srt = (rows) => cleaned.map((c, i) =>
  `${i + 1}\n${fmt(c.start, ',')} --> ${fmt(c.end, ',')}\n${(rows[i] ?? []).join('\n')}\n`).join('\n');

fs.mkdirSync(OUTDIR, { recursive: true });
const zhPath = path.join(OUTDIR, `${NAME}.zh.srt`);
const biPath = path.join(OUTDIR, `${NAME}.bilingual.srt`);
fs.writeFileSync(zhPath, srt(zhRows), 'utf8');
fs.writeFileSync(biPath, srt(biRows), 'utf8');
const qaPath = path.join(OUTDIR, `${NAME}.i18n-qa.json`);
fs.writeFileSync(qaPath, JSON.stringify(report, null, 2), 'utf8');

// ══════════════════════════════════════════════════════════════════════════
// 5) 控制台报告
// ══════════════════════════════════════════════════════════════════════════
const maxZh = Math.max(...zhRows.map((r) => Math.max(...r.map(width))));
const maxBiZh = Math.max(...biRows.map((r) => width(r[0] ?? '')));
const maxEn = Math.max(...biRows.map((r) => width(r[1] ?? '')));
console.log(`场景: ${SPEC}  时长 ${spec.duration}s`);
console.log(`条数: ${cleaned.length}（zh.srt 与 bilingual.srt 同源同序）`);
console.log(`  ${zhPath}   最长行 ${maxZh} 列 / 折行 ≤2`);
console.log(`  ${biPath}   中文最长 ${maxBiZh} 列 / 英文最长 ${maxEn} 列`);
console.log(`  ${qaPath}`);
console.log('--- 逐条（zh行数/zh最长列 | 双语中/英列宽）---');
for (const r of report.cueRows) {
  console.log(`  #${String(r.cue).padStart(2)} [${r.section.padEnd(8)}] ${r.zhLines}行/${String(r.zhMax).padStart(2)}列 ${r.zhNote.padEnd(9)} | 中${String(r.biZh).padStart(2)} 英${String(r.biEn).padStart(2)}`);
}
console.log('--- 检查 ---');
if (report.mismatched.length) {
  console.log(`译表与场景不一致 ${report.mismatched.length} 条（场景改过，译文可能过期）:`);
  for (const m of report.mismatched) console.log(`  #${m.cue}: 场景="${m.scene}" / 译表="${m.table}"`);
} else console.log('译表与场景逐条一致（无过期译文）');
console.log(`超限（>2 行 或 >42 列）: ${report.violations.length} 条`);
for (const v of report.violations) console.log(`  ! #${v.cue} [${v.file}] ${v.reason ?? v.kind} ${v.text ?? ''}`);
console.log(`折行/压缩动用条目: ${report.compressed.length}`);
for (const c of report.compressed) console.log(`  ~ #${c.cue} [${c.file}] ${c.fromWidth}→${width(c.to)} 列: ${c.from}  ⇒  ${c.to}`);
const pass = report.violations.length === 0;
console.log(pass ? '结果: PASS —— 两份文件全部满足 ≤2 行 / ≤42 列' : '结果: FAIL —— 见上方超限明细');
process.exitCode = pass ? 0 : 1;
