#!/usr/bin/env node
/**
 * run-regression.mjs — 回归总闸（一次性跑完所有可离线验证的检查，任一失败 → 退出码 1）
 *
 *   node D:\dsh-tools\run-regression.mjs
 *
 * 12 项检查（1-7 为原有项，8-10 是上一轮接的门禁，11 是"漂移闸门"，12 是本轮新增的
 *            "核心簇 + 尾包率"双指标闸门）：
 *   1) 视觉/输入 自测      node D:\dsh-tools\aim\self-test.mjs（断言全过）
 *   2) 输入引擎纯函数自测   动态 import input.mjs 跑契约断言（input.mjs 无自带 --self-test 入口，已实测）
 *   3) 引擎语法            node --check D:\dsh-video\engine\lib.mjs
 *   4) 引擎编译冒烟         render.mjs --html-only 16:9 / 9:16，断言 exit=0 且 HTML 非空
 *   5) 音频                make-audio.py → <专属tmp>\regress-audio.wav，断言 10/10 质检通过
 *   6) 画廊                build-gallery.mjs → <专属tmp>\regress-gallery.html，断言 >100KB
 *   7) 质检脚本自检         node --check D:\dsh-video\engine\qa.mjs
 *   8) 质检夹具回归         qa.mjs --fixtures：同相夹具必须 PASS、反相与退化夹具必须 FAIL（判据+趋势双断言）
 *                          夹具先复制到带进程号的专属子目录再跑，跑完清理（并发安全）
 *   9) 交付包陈旧性         stale-check.mjs：出现任何 STALE 或 MISSING 即整体失败
 *  10) 最新成片质检         qa.mjs --video <最新 mp4 的副本>：通过数须 ≥ 现有 QA JSON 里的同口径最高通过数
 *                          （标准从 QA JSON 现读现算，不在本脚本里写死阈值）
 *  11) 反应时延漂移闸门     读 D:\dsh-arena 下最近一次"多局成绩"（multi-run JSON；无则回退 bench-real.json），
 *                          对逐局 avgReactionMs 断言：a) 末局−首局 ≤ 首局×10%；b) 末局 ≤ 700ms；
 *                          c) 越线（>700ms）局数 = 0。任一不满足 → 整体失败，并逐局打印 avgReactionMs。
 *                          无多局数据 → 记 SKIP（不算红）并写明原因。700ms 与 10% 是硬判据，不随数据放宽。
 *                          数据源 mtime 距今 > 6 小时 → 标 STALE_DATA 并降级为 SKIP（见下"数据新鲜度"）。
 *  12) 核心簇 + 尾包率 双指标闸门
 *                          读 D:\dsh-arena 下**时间上最近的一次"多局真实指针成绩"批次**（优先多局
 *                          JSON 的 runs[].reactionMs；没有时回退 runs\ 下最近一次连续单局窗口，
 *                          默认 6 局），断言：
 *                          a) 每局核心簇（样本 ≤800ms）中位 ≤ TH_CORE（现数据推导值 350ms）
 *                          b) >900ms 尾包率 ≤ TH_TAIL（逐局 + 合并；现数据推导值 1%）
 *                          c) 命中率 ≥ TH_HIT（逐局 + 合并；现数据推导值 95%）
 *                          三个阈值**全部由被检数据现场推导**（公式与过程随结果一起打印），
 *                          并与冻结锚取"更严的一方"生效：数据变差不放宽、数据变好自动收紧。
 *                          数据不足（局数 <3 / 单局样本 <50 / 合并样本 <300）或 mtime > 6h → SKIP。
 *                          换口径的理由见 REGRESSION.md"为什么纯均值口径会被 1 条尾包翻转"。
 *
 * 分档（默认 = 平衡档）：
 *   （默认）        跑 1-4、6-11，跳过第 5 项（音频合成 ~55s，最重的一项）
 *   --offline       只跑纯本地轻项：1-4、7-11，跳过第 5 项与第 6 项（要抽帧/扫全盘的重产物项）
 *   --with-audio    全长档：1-11 全跑（含第 5 项音频与第 6 项画廊）
 *   档位跳过的项也在结果表里占一行 SKIP，三态表（PASS/FAIL/SKIP）完整可核。
 *
 * 副作用约束：音频/画廊/成片质检的临时产物一律落**本次进程专属**的 D:\dsh-tmp\run-<pid>-<ts>\；
 * make-audio.py 固定会写 D:\dsh-video\out\ 下的质检报告与频谱图，本闸跑前备份、跑后原样恢复，
 * 不动 out\ 里的成品。第 10 项把最新成片**复制到 tmp** 再质检，qa.mjs 写出的 -qa.json /
 * -contact.png 全部落 tmp，不往 D:\dsh-video\out\ 写一个字节；第 9 项 stale-check.mjs 本身只读，
 * 不改交付包。跑完即清理本次专属 tmp（--keep-tmp 保留，供取证）。
 *
 * 并发安全（本轮修，针对上一轮第 8 项的"首次 FAIL、复跑 PASS"假红）：
 *   · 每次运行都有进程专属根目录 D:\dsh-tmp\run-<pid>-<时间戳>\，它同时是子进程的 TEMP/TMP；
 *     音频/画廊/快照/陈旧性 JSON/备份全部落在这里，多路并发跑本闸不再共用任何写路径。
 *   · 第 8 项：先把基准夹具**复制**到 <专属根>\fixtures\ 再跑 qa.mjs --fixtures-dir 指向该副本，
 *     断言也读同一副本，跑完随专属根一起清理；并额外断言夹具 mp4 与 -qa.json 都是本次新写，
 *     防止"播种副本恰好存在"掩盖 ffmpeg 生成失败。
 *   · 第 11 项数据新鲜度：漂移数据源 mtime 距今超过 6 小时 → 标 STALE_DATA 并降级为 SKIP，
 *     且 body 里如实写明"按硬判据本应是什么结论"，数据过期不掩盖真实越线。
 *
 * 用法：
 *   node D:\dsh-tools\run-regression.mjs [--offline] [--with-audio] [--keep-tmp]
 *                                      [--drift-source=<成绩 JSON>] [--drift-max-age-hours=<n>]
 *                                      [--gate12-source=<成绩 JSON>] [--gate12-max-age-hours=<n>]
 * 退出码：任一项 FAIL → 1；全过（含 SKIP）→ 0。SKIP 只在"数据不存在/不足/过期"时出现，绝不掩盖真实越线。
 */
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const TOOLS = 'D:\\dsh-tools';
const VIDEO = 'D:\\dsh-video';
const TMP_ROOT = 'D:\\dsh-tmp';
// ── 进程专属临时根（并发安全的核心）──────────────────────────────────────────
// 旧版把音频/画廊/快照/夹具全写在固定的 D:\dsh-tmp\<名字>，两路并发跑本闸时互相踩写，
// 第 8 项的夹具目录 engine\fixtures 更是直接共用 → 出现"首次 FAIL、复跑 PASS"的并发假红。
// 现在每次运行独占 run-<pid>-<时间戳>\，子进程的 TEMP/TMP 也指到这里。
const RUN_TAG = `${process.pid}-${Date.now().toString(36)}`;
const TMP = path.join(TMP_ROOT, `run-${RUN_TAG}`);
process.env.TEMP = TMP;
process.env.TMP = TMP;
fs.mkdirSync(TMP, { recursive: true });

// ── 分档开关 ──────────────────────────────────────────────────────────────
//   --offline    : 跳过"要重新合成/抽帧的重产物"两项（5 音频、6 画廊）
//   --with-audio : 全长档，把 5 与 6 都放回来（两个开关同时给时，--with-audio 优先）
const ARGV = new Set(process.argv.slice(2));
const OFFLINE = ARGV.has('--offline');
const WITH_AUDIO = ARGV.has('--with-audio');
const KEEP_TMP = ARGV.has('--keep-tmp');           // 保留本次专属 tmp 供取证（默认跑完清理）
const argVal = (name, dflt = null) => {
  const hit = process.argv.slice(2).find((a) => a.startsWith(`--${name}=`));
  return hit === undefined ? dflt : hit.slice(name.length + 3);
};
const PLAN = {
  5: WITH_AUDIO,                    // 音频合成：实测 ~55s，最重，默认平衡档不跑
  6: WITH_AUDIO || !OFFLINE,        // 画廊：实测 ~9s，要扫全盘 + 抽 16 帧缩略图，--offline 不跑
};
const MODE = WITH_AUDIO ? 'full（--with-audio）' : OFFLINE ? 'offline（--offline）' : 'balanced（默认平衡档）';
const ALL_ITEMS = 12;
const SKIPPED = Object.keys(PLAN).filter((k) => !PLAN[k]).map(Number);
const willRun = (id) => !SKIPPED.includes(id);

const NODE_CANDIDATES = [
  'C:\\Users\\35126\\AppData\\Roaming\\dsh-desktop\\harness\\.desktop-bin\\node.cmd',
  process.execPath,
];
const NODE = NODE_CANDIDATES.find((p) => fs.existsSync(p)) ?? process.execPath;
const PY_LONG = 'D:\\ds\\DSH Desktop\\.build\\office-runtime\\primary-runtime\\dependencies\\python.exe';
// junction 放在 TMP_ROOT 而不是专属 tmp 里：它要跨进程复用，不能被"跑完清理"删掉。
const PY_JUNCTION = path.join(TMP_ROOT, 'pyroot');

/**
 * 解析出可执行的 python 解释器路径。
 * 实测坑：`spawnSync('D:\\ds\\DSH Desktop\\...\\python.exe')` 直接 ENOENT（Node 对带空格路径的
 * file 处理 + D 盘无 8.3 短名，`for %~sI` 返回的仍是长路径），cmd /c 包裹又会被 cmd 拆散。
 * 所以在该 python 目录旁建一个**无空格的 junction**（D:\dsh-tmp\pyroot）再调用，已实测可用。
 */
function ensurePython() {
  const viaJunction = path.join(PY_JUNCTION, 'python.exe');
  if (fs.existsSync(viaJunction)) return { exe: viaJunction, how: 'junction（已存在）' };
  if (fs.existsSync(PY_LONG)) return { exe: PY_LONG, how: '直连长路径' };
  const mk = spawnSync(process.env.ComSpec ?? 'cmd.exe',
    ['/c', 'mklink', '/J', PY_JUNCTION, path.dirname(PY_LONG)], { encoding: 'utf8', windowsHide: true });
  if (fs.existsSync(viaJunction)) {
    return { exe: viaJunction, how: `junction（本轮新建，${(mk.stdout ?? '').trim().split(/\r?\n/)[0] ?? ''}）` };
  }
  return { exe: PY_LONG, how: `未建 junction，回退长路径（mklink exit=${mk.status}）` };
}
const PY_INFO = ensurePython();
const PY = PY_INFO.exe;
const SPEC = path.join(VIDEO, 'engine', 'scenes', 'dsh-phone-access.json');
const AUDIO_WAV = path.join(TMP, 'regress-audio.wav');
const GALLERY_OUT = path.join(TMP, 'regress-gallery.html');
const REPORT = path.join(TOOLS, 'regression-report.json');

// ── 颜色（NO_COLOR 时自动关闭）─────────────────────────────────────────────
const NC = !!process.env.NO_COLOR;
const C = {
  g: NC ? '' : '\x1b[1;32m', r: NC ? '' : '\x1b[1;31m', y: NC ? '' : '\x1b[1;33m',
  c: NC ? '' : '\x1b[1;36m', d: NC ? '' : '\x1b[2m', b: NC ? '' : '\x1b[1m', x: NC ? '' : '\x1b[0m',
};

// ── 通用执行器 ────────────────────────────────────────────────────────────
function run(cmd, args, { timeoutMs = 600000 } = {}) {
  const t0 = Date.now();
  // .cmd / .bat（DSH 自带 node.cmd）在 Node 20+ 不能直接 spawn（EINVAL），必须 cmd /c 包一层。
  // 注意：带空格的 .exe 路径**不能**走 cmd /c（实测 cmd 会把 "D:\ds\DSH Desktop\..." 拆成 "D:\ds\DSH"），
  // 所以 python 统一用下面 ensurePython() 解析出的无空格路径（junction）。
  const useCmd = /\.(cmd|bat)$/i.test(cmd);
  const r = useCmd
    ? spawnSync(process.env.ComSpec ?? 'cmd.exe', ['/c', cmd, ...args], {
        encoding: 'utf8', timeout: timeoutMs, windowsHide: true, maxBuffer: 64 * 1024 * 1024,
        // PYTHONUTF8/PYTHONIOENCODING：让 python 子进程按 UTF-8 输出，否则中文质检行会是 GBK 乱码、无法解析。
        env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
      })
    : spawnSync(cmd, args, {
        encoding: 'utf8', timeout: timeoutMs, windowsHide: true, maxBuffer: 64 * 1024 * 1024,
        env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
      });
  const out = (r.stdout ?? '') + (r.stderr ?? '');
  return { code: r.status ?? 1, out, ms: Date.now() - t0, err: r.error ? String(r.error.message) : null, timedOut: r.error?.code === 'ETIMEDOUT' };
}

const results = [];
let DRIFT_GATE = null;   // 第 11 项漂移闸门的结构化结果（块内赋值，汇总报告里引用）
let TAIL_GATE = null;    // 第 12 项"核心簇 + 尾包率"双指标闸门的结构化结果（块内赋值）
/**
 * 三态记录：status = 'PASS' | 'FAIL' | 'SKIP'。
 * 传 status 时它说了算（SKIP 只在"数据不存在/不足/过期"这类不可判定场景用，不算红、不影响退出码）；
 * 不传 status 时沿用旧语义：ok=true → PASS、ok=false → FAIL。
 */
function record(id, title, cmd, ok, ms, detail, out = '', status = null) {
  const st = status ?? (ok ? 'PASS' : 'FAIL');
  results.push({ id, title, cmd, ok: st !== 'FAIL', status: st, durationMs: ms, detail, outputTail: out.slice(-3000), outputBytes: out.length });
  const tag = st === 'PASS' ? `${C.g}PASS${C.x}` : st === 'SKIP' ? `${C.y}SKIP${C.x}` : `${C.r}FAIL${C.x}`;
  console.log(`${C.d}──${C.x} 第 ${id} 项 ${C.b}${title}${C.x}  ${tag}  ${C.d}${(ms / 1000).toFixed(1)}s${C.x}`);
  console.log(`     ${C.d}$ ${cmd}${C.x}`);
  console.log(`     ${C.c}${detail}${C.x}`);
  if (out.trim()) {
    console.log(`${st === 'FAIL' ? C.y : C.d}     ↳ 输出尾部：${C.x}`);
    for (const line of out.trimEnd().split(/\r?\n/).slice(-18)) console.log(`${C.d}       ${line}${C.x}`);
  }
  console.log('');
}
const shortCmd = (cmd, args) => `${path.basename(cmd)} ${args.map((a) => (/\s/.test(a) ? `"${a}"` : a)).join(' ')}`;

/**
 * 「档位跳过」也要在结果表里占一行 SKIP —— 三态表（PASS/FAIL/SKIP）必须完整，
 * 否则第 5 项在平衡档里会整行消失，验收方看不出"是没跑，还是跑了没记"。
 * 它不计红、不影响退出码，并且从 ranItems 里排除（report.mode.ranItems 只列真跑的项）。
 */
function recordPlannedSkip(id, title, why) {
  record(id, title, `(档位未跑：${why})`, true, 0,
    `SKIP：档位 ${MODE} 未跑本项 —— ${why}（SKIP 不计红、不影响退出码）`, '', 'SKIP');
  results.at(-1).plannedSkip = true;
}

// ── 副作用防护：备份/恢复 make-audio.py 固定写的 out\ 质检文件 ─────────────
const AUDIO_TOUCHED = ['qa-spec-spectrogram.png', 'qa-audio-spec.json', 'qa-regress-audio.json'];
const BACKUP = path.join(TMP, 'regress-backup');
const backupState = [];
function backupOut() {
  fs.rmSync(BACKUP, { recursive: true, force: true });
  fs.mkdirSync(BACKUP, { recursive: true });
  for (const name of AUDIO_TOUCHED) {
    const src = path.join(VIDEO, 'out', name);
    const exists = fs.existsSync(src);
    backupState.push({ name, exists, src, bak: path.join(BACKUP, name), size: exists ? fs.statSync(src).size : 0 });
    if (exists) fs.copyFileSync(src, path.join(BACKUP, name));
  }
}
function restoreOut() {
  const done = [];
  for (const s of backupState) {
    if (s.exists) {
      fs.copyFileSync(s.bak, s.src);
      const same = fs.statSync(s.src).size === s.size;
      done.push(`${s.name}: 已还原${same ? '' : '（大小不一致）'}`);
    } else if (fs.existsSync(s.src)) {
      fs.rmSync(s.src, { force: true });
      done.push(`${s.name}: 已删除本轮新生成`);
    } else {
      done.push(`${s.name}: 未产生`);
    }
  }
  return done;
}

const t0 = Date.now();
console.log(`${C.b}╔══════════════════════════════════════════════════════════════╗${C.x}`);
console.log(`${C.b}║  DSH 回归总闸 run-regression.mjs     12 项检查 / 任一失败即整体失败  ║${C.x}`);
console.log(`${C.b}╚══════════════════════════════════════════════════════════════╝${C.x}`);
console.log(`${C.d}档位 = ${MODE}`);
console.log(`跳过 = ${SKIPPED.length ? SKIPPED.map((i) => `第${i}项`).join('、') + `（${SKIPPED.includes(5) ? '--with-audio 可开启' : ''}${SKIPPED.includes(6) ? `${SKIPPED.includes(5) ? '；' : ''}--offline 下关闭` : ''}）` : `（无，全部 ${ALL_ITEMS} 项都跑）`}`);
console.log(`node = ${NODE}`);
console.log(`python = ${PY}  （${PY_INFO.how}）`);
console.log(`TEMP/TMP = ${TMP}  ← 本次进程专属（进程号 ${process.pid}），跑完清理${KEEP_TMP ? '（--keep-tmp：保留）' : ''}`);
console.log(`报告 = ${REPORT}${C.x}\n`);

if (willRun(5)) backupOut();

// ═══ 1) 视觉/输入 自测 ═════════════════════════════════════════════════════
{
  const f = path.join(TOOLS, 'aim', 'self-test.mjs');
  const r = run(NODE, [f], { timeoutMs: 180000 });
  const m = r.out.match(/汇总：(\d+) 组 PASS \/ (\d+) 组 FAIL，断言 (\d+) 条/);
  const asserts = m ? Number(m[3]) : -1;
  const passGroups = m ? Number(m[1]) : -1;
  const failGroups = m ? Number(m[2]) : -1;
  const ok = r.code === 0 && m && failGroups === 0 && asserts > 0;
  record(1, '视觉/输入 自测 aim/self-test.mjs', shortCmd(NODE, [f]), ok, r.ms,
    m ? `exit=${r.code} 组 PASS=${passGroups} FAIL=${failGroups} 断言=${asserts} 条`
      : `exit=${r.code} 未解析到汇总行（err=${r.err ?? '无'}）`, r.out);
}

// ═══ 2) 输入引擎纯函数自测 ═════════════════════════════════════════════════
{
  const f = path.join(TOOLS, 'aim', 'input.mjs');
  const src = fs.readFileSync(f, 'utf8');
  const hasSelfCli = /--self-?test/.test(src);
  const t0b = Date.now();
  const checks = [];
  const ck = (label, cond, detail = '') => checks.push({ label, ok: !!cond, detail: String(detail) });
  try {
    const M = await import(pathToFileURL(f).href);
    const names = Object.keys(M).sort();
    ck('导出的纯函数数量 ≥ 30', names.length >= 30, `${names.length} 个`);
    ck('无 --self-test 入口（故本项自建断言）', !hasSelfCli, hasSelfCli ? '发现了入口' : 'input.mjs CLI 仅 --list-tools/--health/--pointer');
    ck('clamp 边界', M.clamp(-1, 0, 10) === 0 && M.clamp(99, 0, 10) === 10 && M.clamp(5, 0, 10) === 5);
    ck('lerp(0,10,0.25)=2.5', M.lerp(0, 10, 0.25) === 2.5, M.lerp(0, 10, 0.25));
    ck('mulberry32 同 seed 确定', M.mulberry32(42)() === M.mulberry32(42)() && M.mulberry32(7)() !== M.mulberry32(8)());
    const easingOk = Object.keys(M.EASINGS).every((k) => M.ease(k, 0) === 0 && M.ease(k, 1) === 1);
    ck('全部缓动 f(0)=0 / f(1)=1', easingOk, `${Object.keys(M.EASINGS).length} 条：${Object.keys(M.EASINGS).join(',')}`);
    ck('vkOf 虚拟键码 a=65 / Enter=13', M.vkOf('a') === 65 && M.vkOf('Enter') === 13, `${M.vkOf('a')}/${M.vkOf('Enter')}`);
    const mv = M.planMove({ from: { x: 0, y: 0 }, to: { x: 300, y: 200 }, seed: 7 });
    const pt = mv.points;
    const mono = pt.every((p, i) => i === 0 || (p.t >= pt[i - 1].t && p.atMs >= pt[i - 1].atMs));
    const ends = pt[0].x === 0 && pt[0].y === 0 && pt[pt.length - 1].x === 300 && pt[pt.length - 1].y === 200;
    // planMove 的 points 含起点（首点 = from），所以 points.length = steps + 1（实测 22 点 / 21 步）。
    ck('planMove：步数/单调/首尾锚点', pt.length === mv.steps + 1 && mono && ends,
      `${pt.length} 点 = 起点 + ${mv.steps} 步，末点=(${pt[pt.length - 1].x},${pt[pt.length - 1].y})`);
    const mv2 = M.planMove({ from: { x: 0, y: 0 }, to: { x: 300, y: 200 }, seed: 7 });
    ck('planMove 同 seed 可复现', JSON.stringify(mv.points) === JSON.stringify(mv2.points));
    const ch = M.planChord({ keys: ['Control', 'c'], holdMs: 70, staggerMs: 12 });
    const downs = ch.events.filter((e) => e.op === 'down').length;
    const upsFirst = ch.events.findIndex((e) => e.op === 'up');
    ck('planChord：按下先于抬起且时序递增', downs === 2 && upsFirst > 1 && ch.events.every((e, i) => i === 0 || e.atMs >= ch.events[i - 1].atMs),
      `downs=${downs} totalMs=${ch.totalMs}`);
    const rep = M.planKeyRepeat({ key: 'Backspace', count: 3 });
    ck('planKeyRepeat：3 次 → 6 事件 / 140ms', rep.events.length === 6 && rep.totalMs === 140, `${rep.events.length} 事件 ${rep.totalMs}ms`);
    const ns = M.normalizeAction(['moveRel', 10, 20]);
    ck('normalizeAction 别名与数组简写', M.normalizeAction('Enter').keys?.[0] === 'Enter' && ns.name === 'moveRel' && ns.dx === 10 && ns.dy === 20);
    const sc = M.planSchedule([{ name: 'moveTo', x: 100, y: 100 }, { name: 'click', x: 100, y: 100 }, { name: 'moveRel', dx: 50, dy: 0 }]);
    const scMono = sc.timeline.every((s, i) => i === 0 || s.atMs >= sc.timeline[i - 1].atMs);
    // planSchedule.count 是时间线条目数（=timeline.length），动作数看 segments。
    ck('planSchedule：链式锚点 + 绝对时间递增', sc.segments.length === 3 && sc.count === sc.timeline.length && scMono
      && sc.endAnchor.x === 150 && sc.endAnchor.y === 100,
      `动作=${sc.segments.length} 时间线=${sc.timeline.length} 条 endAnchor=(${sc.endAnchor.x},${sc.endAnchor.y})`);
    const ex = M.expandAction(M.normalizeAction({ name: 'moveTo', x: 100, y: 50 }), { startMs: 500, index: 0 });
    ck('expandAction：起点不早于 startMs 且落在目标点', ex.steps[0].atMs >= 500 && ex.steps.at(-1).x === 100 && ex.steps.at(-1).y === 50,
      `${ex.steps.length} 步 ${ex.steps[0].atMs}→${ex.endMs}ms`);
    const est = M.estimateActionMs({ name: 'click' });
    ck('estimateActionMs(click)=240', est === 240, est);
  } catch (e) {
    ck('import input.mjs 并执行断言', false, e.message);
  }
  const passed = checks.filter((c) => c.ok).length;
  const failedList = checks.filter((c) => !c.ok);
  const ok = failedList.length === 0 && checks.length >= 14;
  const detail = `断言 ${passed}/${checks.length} 过${failedList.length ? `；失败：${failedList.map((c) => c.label).join(' / ')}` : ''}`;
  const fake = [`$ node --check ${path.basename(f)} (输入引擎纯函数契约自测，无桌面动作)`,
    ...checks.map((c) => `  ${c.ok ? '✓' : '✗'} ${c.label}${c.detail ? `  ⟨${c.detail}⟩` : ''}`)].join('\n');
  record(2, '输入引擎纯函数自测（自建契约断言）', `node --check input.mjs + import(...) 契约断言（input.mjs 无 --self-test）`,
    ok, Date.now() - t0b, detail, fake);
}

// ═══ 3) 引擎语法 ══════════════════════════════════════════════════════════
{
  const f = path.join(VIDEO, 'engine', 'lib.mjs');
  const r = run(NODE, ['--check', f], { timeoutMs: 60000 });
  record(3, '引擎语法 node --check engine/lib.mjs', shortCmd(NODE, ['--check', f]), r.code === 0 && r.out.trim() === '',
    r.ms, `exit=${r.code} 输出=${r.out.trim() ? r.out.trim().split(/\r?\n/)[0] : '(空，语法正常)'}`, r.out);
}

// ═══ 4) 引擎编译冒烟（16:9 + 9:16 --html-only）════════════════════════════
{
  const t0b = Date.now();
  const legs = [];
  let htmlOk = true;
  for (const aspect of ['16:9', '9:16']) {
    const tag = aspect.replace(':', 'x');
    const html = path.join(VIDEO, 'engine', '.build', `dsh-phone-access-${tag}.html`);
    const r = run(NODE, [path.join(VIDEO, 'engine', 'render.mjs'), '--spec', SPEC, '--aspect', aspect, '--html-only'], { timeoutMs: 120000 });
    const fresh = fs.existsSync(html) && fs.statSync(html).mtimeMs >= t0b;
    const size = fs.existsSync(html) ? fs.statSync(html).size : 0;
    const head = size ? fs.readFileSync(html, 'utf8').slice(0, 200) : '';
    const okLeg = r.code === 0 && fresh && size > 1024 && /<html/i.test(head);
    htmlOk = htmlOk && okLeg;
    legs.push({ aspect, code: r.code, size, fresh, ok: okLeg, out: r.out });
  }
  const detail = legs.map((l) => `${l.aspect}: exit=${l.code} HTML=${l.size}B 新写=${l.fresh ? '是' : '否'} ${l.ok ? '✔' : '✘'}`).join(' | ');
  const out = legs.map((l) => `── ${l.aspect} ──\n${l.out.trimEnd()}`).join('\n');
  record(4, '引擎编译冒烟 --html-only 16:9 / 9:16',
    `render.mjs --spec dsh-phone-access.json --aspect <16:9|9:16> --html-only`, htmlOk, Date.now() - t0b, detail, out);
}

// ═══ 5) 音频（make-audio.py + 10/10 质检）═════════════════════════════════
if (willRun(5)) {
  const r = run(PY, [path.join(VIDEO, 'tools', 'make-audio.py'), '--spec', SPEC, '--out', AUDIO_WAV], { timeoutMs: 900000 });
  // 质检结论有两个来源：① make-audio.py 写出的结构化报告 ② stdout 的「通过 N/M 项」行。
  // 结构化报告更硬（不受 console 编码影响），优先用它；stdout 作为交叉校验。
  const qaJsonPath = path.join(VIDEO, 'out', 'qa-regress-audio.json');
  let checks = null;
  try { checks = JSON.parse(fs.readFileSync(qaJsonPath, 'utf8')).checks ?? null; } catch { /* 报告未产出则回退 stdout */ }
  const src = Array.isArray(checks) && checks.length ? 'qa-regress-audio.json' : 'stdout';
  const m = r.out.match(/通过\s+(\d+)\/(\d+)\s*项/);
  const passed = Array.isArray(checks) && checks.length ? checks.filter((c) => c.ok).length : (m ? Number(m[1]) : -1);
  const total = Array.isArray(checks) && checks.length ? checks.length : (m ? Number(m[2]) : -1);
  const failLines = Array.isArray(checks) && checks.length
    ? checks.filter((c) => !c.ok).map((c) => `${c.check} → ${c.detail}`)
    : r.out.split(/\r?\n/).filter((l) => l.includes('[FAIL]')).map((l) => l.trim());
  const wavSize = fs.existsSync(AUDIO_WAV) ? fs.statSync(AUDIO_WAV).size : 0;
  const ok = r.code === 0 && passed === 10 && total === 10 && failLines.length === 0 && wavSize > 1024 * 1024;
  const detail = `exit=${r.code} 质检 通过 ${passed}/${total} 项（来源 ${src}） WAV=${(wavSize / 1048576).toFixed(2)}MB`
    + (failLines.length ? ` 失败项：${failLines.join(' ; ')}` : '')
    + (r.err ? ` spawn错误：${r.err}` : '');
  record(5, '音频生成 make-audio.py（10/10 质检）', shortCmd(PY, ['tools/make-audio.py', '--spec', SPEC, '--out', AUDIO_WAV]),
    ok, r.ms, detail, r.out);
  console.log(`${C.d}   out\ 质检文件恢复：${restoreOut().join(' | ')}${C.x}\n`);
} else {
  recordPlannedSkip(5, '音频生成 make-audio.py（10/10 质检）', '音频合成 ~55s 最重，默认平衡档跳过；--with-audio 可开启');
}

// ═══ 6) 画廊 ══════════════════════════════════════════════════════════════
if (willRun(6)) {
  const f = path.join(VIDEO, 'docs', 'build-gallery.mjs');
  const r = run(NODE, [f, '--out', GALLERY_OUT], { timeoutMs: 900000 });
  const size = fs.existsSync(GALLERY_OUT) ? fs.statSync(GALLERY_OUT).size : 0;
  const ok = r.code === 0 && size > 100 * 1024;
  const vids = (r.out.match(/收录视频 (\d+) 个/) ?? [])[1] ?? '?';
  const mats = (r.out.match(/素材图 (\d+) 张/) ?? [])[1] ?? '?';
  record(6, '画廊生成 build-gallery.mjs', shortCmd(NODE, [f, '--out', GALLERY_OUT]), ok, r.ms,
    `exit=${r.code} ${path.basename(GALLERY_OUT)}=${(size / 1024).toFixed(1)}KB（阈值 >100KB） 视频=${vids} 素材图=${mats}`, r.out);
} else {
  recordPlannedSkip(6, '画廊生成 build-gallery.mjs', '画廊要扫全盘 + 抽 16 帧缩略图，--offline 档跳过');
}

// ═══ 7) 质检脚本自检 ══════════════════════════════════════════════════════
{
  const f = path.join(VIDEO, 'engine', 'qa.mjs');
  const r = run(NODE, ['--check', f], { timeoutMs: 60000 });
  record(7, '质检脚本自检 node --check engine/qa.mjs', shortCmd(NODE, ['--check', f]), r.code === 0 && r.out.trim() === '',
    r.ms, `exit=${r.code} 输出=${r.out.trim() ? r.out.trim().split(/\r?\n/)[0] : '(空，语法正常)'}`, r.out);
}

// ═══ 8) 质检夹具回归（同相 PASS / 反相 FAIL / 退化 FAIL）══════════════════
// 这一项是第 10 项的"秤的校准"：先用已知答案的三个夹具证明 qa.mjs 的音画同轴判据没坏
// （同相夹具必须判 PASS；反相夹具 |r|=1 但方向为负，必须判 FAIL；帧差恒定的退化夹具必须判"不可定义"→FAIL）。
// 夹具由 qa.mjs 自己用 ffmpeg lavfi 现场生成（不手搓二进制），断言同时看 stdout 结论与各夹具的 -qa.json 字段。
//
// 【并发安全】旧版直接读写在共享的 D:\dsh-video\engine\fixtures —— 两路进程同时跑本闸时，
// A 的 ffmpeg 正在写 mp4、B 的 qa.mjs 去读同一文件 → B 可能读到半个文件 → 单局结论错误；
// 表现为"首次 FAIL、复跑 PASS"的假红。现在：
//   ① 基准夹具先**复制**到 <进程专属 tmp>\fixtures\（带进程号，两个进程互不可见）；
//   ② qa.mjs --fixtures-dir 指向该副本，断言也只读该副本；
//   ③ 断言 mp4 与 -qa.json 的 mtime 都 ≥ 本项起跑时刻（qa.mjs 的 makeFixtures 用 ffmpeg -y，
//      必然重写；这条同时防止"播种副本恰好已存在"把 ffmpeg 生成失败掩盖成 PASS）；
//   ④ 跑完随专属 tmp 一起清理（--keep-tmp 可留证）。
{
  const QA = path.join(VIDEO, 'engine', 'qa.mjs');
  const FIXDIR_SRC = path.join(VIDEO, 'engine', 'fixtures');   // 只读的基准夹具
  const FIXDIR = path.join(TMP, 'fixtures');                  // 本次进程专属的工作副本
  const t0b = Date.now();
  let seeded = 0;
  try {
    fs.rmSync(FIXDIR, { recursive: true, force: true });
    fs.mkdirSync(FIXDIR, { recursive: true });
    for (const name of fs.readdirSync(FIXDIR_SRC)) {
      const src = path.join(FIXDIR_SRC, name);
      if (!fs.statSync(src).isFile()) continue;
      fs.copyFileSync(src, path.join(FIXDIR, name));   // 复制基准夹具（含 mp4/-qa.json/接触单/README）
      seeded++;
    }
  } catch (e) {
    console.log(`${C.y}   夹具播种失败（不致命，qa.mjs 会现场重建）：${e.message}${C.x}`);
  }
  const r = run(NODE, [QA, '--fixtures', '--fixtures-dir', FIXDIR], { timeoutMs: 600000 });
  // [文件名, 夹具标签, 期望判定, 期望趋势]
  const EXPECT = [
    ['sync-inphase.mp4', '同相', 'PASS', '同相'],
    ['sync-antiphase.mp4', '反相', 'FAIL', '反相'],
    ['av-degenerate.mp4', '退化(帧差恒定)', 'FAIL', '未知'],
  ];
  const rows = EXPECT.map(([file, label, want, wantTrend]) => {
    const j = path.join(FIXDIR, file.replace(/\.mp4$/i, '-qa.json'));
    const mp4 = path.join(FIXDIR, file);
    let sig = null, fresh = false, bytes = 0, mp4Fresh = false;
    try { const st = fs.statSync(j); fresh = st.mtimeMs >= t0b; bytes = st.size; } catch { /* 报告没出来 */ }
    try { mp4Fresh = fs.statSync(mp4).mtimeMs >= t0b; } catch { /* mp4 没生成 */ }
    try { sig = JSON.parse(fs.readFileSync(j, 'utf8')).av_sync?.av_correlation_sig ?? null; } catch { /* 未解析 */ }
    const got = sig ? (sig.pass ? 'PASS' : 'FAIL') : '?';
    const trend = sig?.trend ?? '?';
    const okRow = fresh && mp4Fresh && got === want && trend === wantTrend;
    return { file, label, want, wantTrend, got, trend, fresh, mp4Fresh, bytes, r: sig?.r ?? null, p: sig?.p_t ?? null, okRow };
  });
  const cliLine = /夹具回归:\s*(PASS|FAIL)/.exec(r.out)?.[1] ?? '?';
  const badRow = rows.filter((x) => !x.okRow);
  const ok = r.code === 0 && cliLine === 'PASS' && rows.length === 3 && badRow.length === 0;
  const detail = rows.map((x) => `${x.label}: 期望 ${x.want}/${x.wantTrend} 实得 ${x.got}/${x.trend} r=${x.r} p_t=${x.p} ${x.okRow ? '✔' : '✘'}（${x.file} ${(x.bytes / 1024).toFixed(1)}KB${x.fresh ? '' : ' 报告未刷新'}${x.mp4Fresh ? '' : ' mp4 未新写'}）`).join(' | ')
    + ` · qa.mjs CLI 结论=${cliLine} exit=${r.code}`
    + ` · 隔离：基准夹具 ${seeded} 个 → 进程专属副本 ${path.relative(TMP_ROOT, FIXDIR)}（pid ${process.pid}），跑完随专属 tmp 清理`;
  record(8, '质检夹具回归 qa.mjs --fixtures（同相PASS/反相FAIL/退化FAIL）',
    shortCmd(NODE, [QA, '--fixtures', '--fixtures-dir', `<专属tmp>\\fixtures`]), ok, Date.now() - t0b, detail, r.out);
}

// ═══ 9) 交付包陈旧性 stale-check.mjs（STALE/MISSING 即失败）══════════════════
// 只读：stale-check.mjs 自己不写任何交付包内容；本项只把它的结构化结果落到 tmp 供解析。
{
  const SC = path.join(TOOLS, 'stale-check.mjs');
  const jsonOut = path.join(TMP, `stale-check-${MODE.startsWith('offline') ? 'offline' : WITH_AUDIO ? 'full' : 'balanced'}.json`);
  // 注意：stale-check.mjs 只认 `--json=<路径>`（它的解析是 argv.find(a => a.startsWith('--json')) 再 slice(7)），
  // 写成 `--json <路径>` 两个参数时分享不到路径，会被它落到默认的 D:\dsh-tmp\stale-check.json —— 这里必须用等号形式。
  const r = run(NODE, [SC, `--json=${jsonOut}`], { timeoutMs: 600000 });
  const m = r.out.match(/汇总:\s*FRESH=(\d+)\s+STALE=(\d+)\s+MISSING=(\d+)/);
  const tallies = m ? { FRESH: +m[1], STALE: +m[2], MISSING: +m[3] } : null;
  let bad = [], parsed = false;
  try { bad = (JSON.parse(fs.readFileSync(jsonOut, 'utf8')).rows ?? []).filter((x) => x.status !== 'FRESH'); parsed = true; } catch { /* 结果未落盘 */ }
  const ok = r.code === 0 && tallies !== null && tallies.STALE === 0 && tallies.MISSING === 0;
  const detail = `exit=${r.code} 条目 FRESH=${tallies?.FRESH ?? '?'} STALE=${tallies?.STALE ?? '?'} MISSING=${tallies?.MISSING ?? '?'}（判据：STALE=0 且 MISSING=0 且退出码 0）`
    + (bad.length ? ` · 待重打包 ${bad.length} 项：${bad.slice(0, 3).map((b) => `[${b.status}] ${b.dst}`).join(' ; ')}${bad.length > 3 ? ` …共 ${bad.length} 项` : ''}` : parsed ? ' · 包内副本与源一致' : ' · 结果 JSON 未落盘')
    + (m ? '' : ' ← 未解析到汇总行');
  record(9, '交付包陈旧性 stale-check.mjs（有 STALE/MISSING 即失败）',
    shortCmd(NODE, [SC, `--json=${jsonOut}`]), ok, r.ms, detail, r.out);
}

// ═══ 10) 最新成片质检（通过数须达现有 QA 报告的同口径最高标准）══════════════
// 标准不写死：从 D:\dsh-video\out 下已有的 *-qa.json 里，挑出 checks 条数与本轮相同的报告，
// 取其中"通过数最大者"当标准（例如同为 9 项的成片报告里最高 9/9 → 标准就是 9）。
// 为避免污染成片目录，先把最新 mp4 复制到 tmp 再质检，qa.mjs 的 -qa.json / -contact.png 全落 tmp。
{
  const QA = path.join(VIDEO, 'engine', 'qa.mjs');
  const outDir = path.join(VIDEO, 'out');
  const t0b = Date.now();
  const cands = fs.readdirSync(outDir, { withFileTypes: true })
    .filter((d) => d.isFile() && /\.mp4$/i.test(d.name))
    .map((d) => ({ name: d.name, p: path.join(outDir, d.name), st: fs.statSync(path.join(outDir, d.name)) }))
    .sort((a, b) => b.st.mtimeMs - a.st.mtimeMs);
  const latest = cands[0] ?? null;
  if (!latest) {
    record(10, '最新成片质检 qa.mjs（通过数须达现有标准）', `qa.mjs --video <out\\*.mp4>`, false, 0,
      'D:\\dsh-video\\out 顶层没有 mp4，无法确定"最新成片"', '');
  } else {
    const snap = path.join(TMP, 'latest-snapshot.mp4');
    fs.copyFileSync(latest.p, snap);
    const r = run(NODE, [QA, '--video', snap], { timeoutMs: 900000 });
    const qj = path.join(TMP, 'latest-snapshot-qa.json');
    let rep = null, fresh = false;
    try { fresh = fs.statSync(qj).mtimeMs >= t0b; } catch { /* 报告未产出 */ }
    try { rep = JSON.parse(fs.readFileSync(qj, 'utf8')); } catch { /* 未解析 */ }
    const checks = rep?.checks ?? [];
    const total = checks.length;
    const passed = checks.filter((c) => c.ok).length;
    const failedNames = checks.filter((c) => !c.ok).map((c) => c.name);
    // 当前标准：out\ 里同口径（checks 条数相同）的 QA JSON 的最大通过数
    const std = [];
    for (const n of fs.readdirSync(outDir).filter((x) => /-qa\.json$/i.test(x))) {
      try {
        const j = JSON.parse(fs.readFileSync(path.join(outDir, n), 'utf8'));
        const c = j.checks ?? [];
        if (c.length === total && total > 0) std.push({ f: n, passed: c.filter((x) => x.ok).length, video: j.video ? path.basename(j.video) : '?' });
      } catch { /* 跳过坏报告 */ }
    }
    const bar = std.length ? Math.max(...std.map((s) => s.passed)) : null;
    const barFrom = std.filter((s) => s.passed === bar).map((s) => s.f).join('、');
    const ok = !!rep && fresh && total > 0 && bar !== null && passed >= bar;
    const detail = `最新成片 ${latest.name}（${(latest.st.size / 1048576).toFixed(2)}MB，mtime ${new Date(latest.st.mtimeMs).toISOString()}）→ 副本质检通过 ${passed}/${total}`
      + ` · 当前标准 ${bar}/${total}（同口径报告 ${std.length} 份，最高取自 ${barFrom || '无'}）`
      + `${ok ? '' : ` ← 未达标${rep ? '' : '/报告缺失'}${failedNames.length ? ` 失败项：${failedNames.join(' ; ')}` : ''}（exit=${r.code}）`}`
      + ` · qa.mjs exit=${r.code}`;
    record(10, '最新成片质检 qa.mjs（通过数须达现有标准）',
      shortCmd(NODE, [QA, '--video', `tmp\\latest-snapshot.mp4 ← out\\${latest.name}`]), ok, r.ms, detail, r.out);
  }
}

// ═══ 11) 反应时延漂移闸门 ══════════════════════════════════════════════════
// 反证组的口径：只看"得分差"的旧判据漏掉了**反应时延单调变差**——命中数、命中率、得分差都可以在
// "越打越慢、末局越 700ms 红线"的同时依旧好看。本项把漂移本身变成判据，数据、阈值都在这里现读现算：
//   · 数据源：D:\dsh-arena 下"最近一次多局成绩"（multi-run JSON，逐局 avgReactionMs ≥ 2 局者才算）；
//             一个都没有时回退 bench-real.json；再没有 → SKIP（不判红，写明原因）。
//   · a) 末局 − 首局 ≤ 首局 × 10%      —— 抓住"单调变差"这类缓慢漂移（哪怕还没越线）
//   · b) 末局 ≤ 700ms                  —— 末局不得踩线（红线口径来自 CONTROL-BENCH L2）
//   · c) 越线局数（>700ms）= 0          —— 中途任何一局越线都算失败
// 阈值不写死在被检数据里、也不随数据放宽：三项全硬。任一不满足 → 本项 FAIL → 整体 FAIL。
//
// 【数据新鲜度闸门（本轮新增）】被检数据源 mtime 距今 > 6 小时 → 标 STALE_DATA 并降级为 SKIP。
// 理由：拿几小时前的旧成绩去断言"当前能力漂移"，测的是旧机器状态，结论不可归因；
// 降级为 SKIP（不算红）而不是放行 —— body 里同时写明"按硬判据本应是什么结论"，
// 数据一刷新本项立刻恢复三项硬判。阈值/判据不因过期而放宽。
{
  const ARENA = 'D:\\dsh-arena';
  const LINE_MS = 700;       // 反应红线（ms）——与 CONTROL-BENCH / bench-real 的 L2 口径一致
  const GROWTH_MAX = 0.10;   // 首→末允许的最大增幅（10%）
  const WANT_ROUNDS = 6;     // 判据的想定局数（多局成绩本来就是 6 局制）
  const DRIFT_MAX_AGE_H = Number(argVal('drift-max-age-hours', '6'));   // 数据新鲜度硬上限（小时）
  const DRIFT_SOURCE = argVal('drift-source', null);                    // 只读指定源（自检/取证用）
  const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);

  // 从各种"多局成绩"结构里抽逐局 avgReactionMs 序列；≥2 局才算"多局"，否则不认
  function extractSeries(j) {
    const tries = [
      ['endurance3min.rounds[].avgReactionMs', () => (j.endurance3min?.rounds ?? []).map((r) => num(r?.avgReactionMs))],
      ['runs[].arenaRun.avgReactionMs', () => (j.runs ?? []).map((r) => num(r?.arenaRun?.avgReactionMs))],
      ['runs[].avgReactionMs', () => (j.runs ?? []).map((r) => num(r?.avgReactionMs ?? r?.arenaRun?.avgReactionMs))],
      ['channels.*.runs[].avgReactionMs', () => Object.values(j.channels ?? {}).flatMap((c) => (c?.runs ?? []).map((r) => num(r?.avgReactionMs)))],
    ];
    for (const [label, get] of tries) {
      let s = [];
      try { s = get(); } catch { s = []; }
      s = s.filter((x) => x !== null);
      if (s.length >= 2) return { label, series: s };
    }
    return null;
  }

  // 扫描 D:\dsh-arena（含子目录）找候选；按 mtime 取最新一份。runs\run-*.json 是单局，天然被"≥2 局"过滤掉。
  const cands = [];
  (function walkDir(dir) {
    let ents = [];
    try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const d of ents) {
      const p = path.join(dir, d.name);
      if (d.isDirectory()) { walkDir(p); continue; }
      if (!/\.json$/i.test(d.name)) continue;
      let j = null, st = null;
      try { st = fs.statSync(p); j = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { continue; }
      const ex = extractSeries(j);
      if (!ex) continue;
      cands.push({ p, rel: path.relative(ARENA, p), mtimeMs: st.mtimeMs, size: st.size, label: ex.label, series: ex.series });
    }
  })(ARENA);
  cands.sort((a, b) => b.mtimeMs - a.mtimeMs);
  // --drift-source=<路径>：只读指定源（自检"过期数据 → STALE_DATA → SKIP"用，不改被检数据）。
  if (DRIFT_SOURCE) {
    const wantAbs = path.resolve(DRIFT_SOURCE);
    let only = cands.find((c) => path.resolve(c.p) === wantAbs) ?? null;
    if (!only) {
      try {
        const st = fs.statSync(wantAbs);
        const ex = extractSeries(JSON.parse(fs.readFileSync(wantAbs, 'utf8')));
        if (ex) only = { p: wantAbs, rel: `${DRIFT_SOURCE}（--drift-source）`, mtimeMs: st.mtimeMs, size: st.size, label: ex.label, series: ex.series };
      } catch { /* 读不到就按"无数据"走 SKIP */ }
    }
    cands.length = 0;
    if (only) cands.push(only);
  }
  const benchReal = cands.find((c) => /^bench-real\.json$/i.test(c.rel)) ?? null;
  // "最近一次多局成绩"：优先非回退项；全都只看得到 bench-real.json 时才算"回退"
  const primary = cands.find((c) => !/^bench-real\.json$/i.test(c.rel)) ?? null;
  const pick = primary ?? benchReal;
  const viaFallback = !!pick && pick === benchReal;
  const inv = cands.filter((c) => c !== pick).slice(0, 4)
    .map((c) => `${c.rel}(${c.series.length}局 ${new Date(c.mtimeMs).toISOString().slice(11, 19)})`).join('、');

  // ── 数据新鲜度：mtime 距今 > 上限 → STALE_DATA → 降级 SKIP ──
  const ageMs = pick ? Date.now() - pick.mtimeMs : null;
  const ageH = ageMs === null ? null : ageMs / 3600000;
  const staleData = ageH !== null && ageH > DRIFT_MAX_AGE_H;
  const freshStr = ageH === null ? '无数据' : `${ageH.toFixed(2)}h（上限 ${DRIFT_MAX_AGE_H}h）→ ${staleData ? 'STALE_DATA' : 'FRESH'}`;

  const out = [];
  const t0b = Date.now();
  let status, detail;
  if (!pick) {
    status = 'SKIP';
    detail = `SKIP：${ARENA} 下没有任何"多局（≥2 局 avgReactionMs）"成绩 JSON，回退项 bench-real.json 也不可用`
      + ` → 无数据可判漂移（SKIP 不是放行：数据一出现本项即按 700ms/10%/越线0 三项硬判）`
      + `；扫描到候选 ${cands.length} 份`;
    out.push(`扫描 ${ARENA}：候选多局成绩 JSON ${cands.length} 份`);
    out.push('未找到可判定的多局数据 → SKIP');
  } else if (staleData) {
    // 过期数据不判红、也不放行：把"若按硬判据会是什么结论"如实写在 body 里，防止 SKIP 掩盖越线。
    const s = pick.series;
    const first = s[0], last = s.at(-1);
    const growth = (last - first) / first;
    const over = s.map((v, i) => ({ v, i })).filter((x) => x.v > LINE_MS);
    const hard = growth <= GROWTH_MAX && last <= LINE_MS && over.length === 0;
    const wouldBe = hard ? 'PASS' : 'FAIL';
    status = 'SKIP';
    detail = `SKIP（STALE_DATA）：漂移数据源 ${pick.rel} 的 mtime 距今 ${ageH.toFixed(2)}h > 硬上限 ${DRIFT_MAX_AGE_H}h`
      + ` → 数据过期，不足以断言"当前"能力漂移，降级为 SKIP（不判红也不放行）`
      + ` · 源 ${pick.rel}（${s.length} 局，mtime ${new Date(pick.mtimeMs).toISOString()}）· 逐局 ${s.join(' → ')}ms`
      + ` · 末局 ${last}ms（若按硬判据本应为 ${wouldBe}：首→末 ${(growth * 100).toFixed(2)}%，越线 ${over.length} 局 —— 因过期不予采信）`
      + ` · 新鲜度 ${freshStr} · 数据一刷新本项立即恢复三项硬判，判据不因过期放宽`;
    out.push(`数据源：${pick.rel}（${pick.size}B，mtime ${new Date(pick.mtimeMs).toISOString()}，抽取路径 ${pick.label}，局数 ${s.length}）`);
    out.push(`数据新鲜度：距今 ${ageH.toFixed(2)}h > 上限 ${DRIFT_MAX_AGE_H}h → STALE_DATA`);
    s.forEach((v, i) => out.push(`  第 ${i + 1} 局 avgReactionMs = ${v}${v > LINE_MS ? `  ← 越线（> ${LINE_MS}ms）` : ''}`));
    out.push(`  STALE_DATA 处置：降级为 SKIP（不判红、不影响退出码）；按硬判据本应为 ${wouldBe}`);
    out.push(`  归因提示：数据过期，本项的红/绿都不成立 —— 请先重跑靶场拿到 ${DRIFT_MAX_AGE_H} 小时内成绩再判`);
  } else {
    const s = pick.series;
    const first = s[0], last = s.at(-1);
    const growth = (last - first) / first;
    const over = s.map((v, i) => ({ v, i })).filter((x) => x.v > LINE_MS);
    const aOk = growth <= GROWTH_MAX;
    const bOk = last <= LINE_MS;
    const cOk = over.length === 0;
    const ok = aOk && bOk && cOk;
    status = ok ? 'PASS' : 'FAIL';
    const evalMs = Date.now() - t0b;
    out.push(`数据源：${pick.rel}（${pick.size}B，mtime ${new Date(pick.mtimeMs).toISOString()}，抽取路径 ${pick.label}，本局数 ${s.length}）`);
    out.push(`数据新鲜度：距今 ${ageH.toFixed(2)}h ≤ 上限 ${DRIFT_MAX_AGE_H}h → FRESH（过期即降级 SKIP）`);
    if (viaFallback) out.push('未发现多局成绩 → 按约定回退 bench-real.json');
    s.forEach((v, i) => {
      const over0 = v > LINE_MS;
      out.push(`  第 ${i + 1} 局 avgReactionMs = ${v}${over0 ? `  ← 越线（> ${LINE_MS}ms，超出 ${(v - LINE_MS).toFixed(1)}ms）` : ''}`);
    });
    out.push(`  首局 ${first} → 末局 ${last}：增量 ${(last - first).toFixed(1)}ms = ${(growth * 100).toFixed(2)}%（判据 a ≤ ${(GROWTH_MAX * 100).toFixed(0)}%）→ ${aOk ? 'PASS' : 'FAIL'}`);
    out.push(`  判据 b 末局 ${last} ≤ ${LINE_MS}ms → ${bOk ? 'PASS' : `FAIL（超出 ${(last - LINE_MS).toFixed(1)}ms）`}`);
    out.push(`  判据 c 越线局数 = ${over.length} 局 / 共 ${s.length} 局（判据 = 0 局）→ ${cOk ? 'PASS' : `FAIL（越线局：${over.map((x) => `第${x.i + 1}局=${x.v}ms`).join('、')}）`}`);
    out.push(`  红线未放宽：${LINE_MS}ms 与 ${(GROWTH_MAX * 100).toFixed(0)}% 为硬判据，未因本轮数据调整`
      + (s.length === WANT_ROUNDS ? `（局数 ${s.length} = 想定 ${WANT_ROUNDS} 局）` : `（注意：局数 ${s.length} ≠ 想定 ${WANT_ROUNDS} 局，按实际局数口径执行，阈值未放宽）`));
    out.push(`  末局实测：${s.slice(-1)[0]}ms；能力是否退化以本闸门结论为准，不看得分差`);
    detail = `${ok ? 'PASS' : 'FAIL'} · 源 ${pick.rel}（${s.length} 局${viaFallback ? '，回退 bench-real.json' : ''}，mtime ${new Date(pick.mtimeMs).toISOString()}，新鲜度 ${ageH.toFixed(2)}h ≤ ${DRIFT_MAX_AGE_H}h = FRESH）`
      + ` · 首→末 ${first}→${last}ms（${(growth * 100).toFixed(2)}% ≤10% → ${aOk ? '过' : '不过'}）`
      + ` · 末局 ≤700ms → ${bOk ? '过' : '不过'}`
      + ` · 越线局数 ${over.length} = 0 → ${cOk ? '过' : '不过'}`
      + ` · 逐局 ${s.join(' → ')}ms`
      + (ok ? '' : ' ← 反应时延已漂移/越线（判据 a/b/c 之一不满足，未调阈值迁就）')
      + ` · 耗时 ${evalMs}ms`;
    DRIFT_GATE = { source: pick.rel, rounds: s.length, series: s, ageHours: +ageH.toFixed(3), maxAgeHours: DRIFT_MAX_AGE_H, staleData: false, verdict: status };
  }
  if (!DRIFT_GATE) {
    DRIFT_GATE = {
      source: pick?.rel ?? null, rounds: pick?.series.length ?? 0, series: pick?.series ?? [],
      ageHours: ageH === null ? null : +ageH.toFixed(3), maxAgeHours: DRIFT_MAX_AGE_H, staleData, verdict: status,
    };
  }
  detail += (inv ? ` · 另见候选：${inv}` : '');
  record(11, '反应时延漂移闸门（首→末≤10% / 末局≤700ms / 越线局=0）',
    `自读 ${ARENA} 最近一次多局成绩 JSON，逐局断言 avgReactionMs（无数据 → SKIP；mtime > ${DRIFT_MAX_AGE_H}h → STALE_DATA → SKIP）`,
    status !== 'FAIL', Date.now() - t0b, detail, out.join('\n'), status);
}

// ═══ 12) 核心簇 + 尾包率 双指标闸门 ═════════════════════════════════════════
// 【为什么原来的"纯均值口径"会被 1 条尾包翻转】均值是线性聚合，对尾部一点不设防：
// 现网 6 局均值的**全部信号**（局间极差）只有 7.70ms，而单独 1 条 646ms 尾包混进 128 条
// 样本（其余 ≈222ms）里，就能把那一局的均值挪 1.0~3.4ms —— 吃掉整段信号的 13%~44%。
// 于是任何 ms 量级的均值判据（"局间均值波动 ≤2ms""均值 ≤223ms"）都会被**单独 1 条尾包**
// 从 PASS 翻成 FAIL（也能反向翻回来），闸门读数随一条噪声跳变。核心簇中位在同样 6 局里恒为
// 221.5~223.0ms，尾包再多也推不动它。所以本项改成"双指标"：
//   a) 每局核心簇（≤800ms 样本）中位 ≤ TH_CORE —— 抗尾包的中心位置指标；
//   b) >900ms 尾包率 ≤ TH_TAIL（逐局 + 合并）—— 把尾包**显式**设上限，不再让它混进均值；
//   c) 命中率 ≥ TH_HIT（逐局 + 合并）。
// 三个阈值一律从被检数据现场推导（公式与中间量随结果打印），并与冻结锚取"更严的一方"生效：
// 数据变差不放宽判据，数据变好自动收紧。数据不足（局数/样本数不够）或过期 → SKIP，不判红也不放行。
{
  const ARENA = 'D:\\dsh-arena';
  const CORE_MS = 800;      // 核心簇上界：≤800ms 的样本算核心簇
  const TAIL_MS = 900;      // 尾包红线：>900ms 记 1 条尾包（800~900ms 是灰色带，两边都不认）
  const ANCHOR = { core: 350, tail: 0.01, hit: 0.95 };   // 冻结锚：硬判据，永不因数据放宽
  const ROUNDS_WANT = 6, MIN_ROUNDS = 3, MIN_PER_ROUND = 50, MIN_TOTAL = 300;
  const MAX_AGE_H = Number(argVal('gate12-max-age-hours', '6'));   // 数据新鲜度硬上限（小时）
  const SRC = argVal('gate12-source', null);                       // 只读指定源（自检/取证用）
  const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
  const quantile = (arr, p) => {
    const a = arr.slice().sort((x, y) => x - y);
    if (!a.length) return null;
    const i = (a.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i);
    return lo === hi ? a[lo] : a[lo] + (a[hi] - a[lo]) * (i - lo);
  };
  const isReal = (ch) => !ch || /real/i.test(String(ch));   // 只认真实指针通道；无标注时放行并在 body 注明
  const normRound = (r, idx) => {
    const ms = (Array.isArray(r?.reactionMs) ? r.reactionMs : []).map(num).filter((v) => v !== null);
    return {
      label: `第${num(r?.round) ?? idx + 1}局`,
      hits: num(r?.hits) ?? ms.length, misses: num(r?.misses), ms, mean: num(r?.avgReactionMs),
    };
  };

  // ── 源①：多局成绩 JSON（runs[].reactionMs 原始逐样本）────────────────────
  const multi = [];
  (function walk(dir) {
    let ents = [];
    try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const d of ents) {
      const p = path.join(dir, d.name);
      if (d.isDirectory()) { walk(p); continue; }
      if (!/\.json$/i.test(p)) continue;
      let j = null, st = null;
      try { st = fs.statSync(p); j = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { continue; }
      const runs = Array.isArray(j.runs) ? j.runs : null;
      if (!runs || runs.length < 2 || !isReal(j.channel ?? j.cfg?.channel)) continue;
      const rounds = runs.map(normRound).filter((x) => x.ms.length >= 20);
      if (rounds.length < 2) continue;
      multi.push({
        kind: '多局成绩 JSON（runs[].reactionMs）', p, rel: path.relative(ARENA, p),
        mtimeMs: st.mtimeMs, size: st.size, rounds,
        note: j.channel ? `channel=${j.channel}` : 'channel 未标注',
      });
    }
  })(ARENA);

  // ── 源②：runs\ 最近一次连续单局窗口（多局 JSON 被清理时的等价回退）──────────
  const winBatch = (() => {
    const dir = path.join(ARENA, 'runs');
    let ents = [];
    try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
    const files = ents.filter((d) => d.isFile() && /^run-.*\.json$/i.test(d.name))
      .map((d) => ({ p: path.join(dir, d.name), st: fs.statSync(path.join(dir, d.name)) }))
      .sort((a, b) => b.st.mtimeMs - a.st.mtimeMs).slice(0, ROUNDS_WANT);
    const rounds = [];
    for (const f of files.slice().reverse()) {
      let j = null;
      try { j = JSON.parse(fs.readFileSync(f.p, 'utf8')); } catch { continue; }
      if (j.aborted === true) continue;
      const r = normRound(j, rounds.length);
      r.file = path.basename(f.p);
      r.startedAt = j.startedAt ?? null;
      if (r.ms.length >= 20 && r.misses !== null) rounds.push(r);
    }
    if (rounds.length < 2) return null;
    const t = rounds.map((r) => Date.parse(r.startedAt ?? '')).filter((v) => Number.isFinite(v));
    const spanMin = t.length > 1 ? (Math.max(...t) - Math.min(...t)) / 60000 : 0;
    return {
      kind: 'runs\\ 连续单局窗口（多局 JSON 缺失时的回退）', p: path.join(dir, rounds.at(-1).file),
      rel: `runs\\${rounds[0].file} … ${rounds.at(-1).file}`,
      mtimeMs: Math.max(...files.map((f) => f.st.mtimeMs)),
      size: files.reduce((a, f) => a + f.st.size, 0), rounds, spanMin,
      note: `通道未标注（runs\\run-*.json 无 channel 字段）· 窗口跨时 ${spanMin.toFixed(1)} 分钟`,
    };
  })();

  const cands = [];
  if (!SRC) {
    cands.push(...multi);
    if (winBatch) cands.push(winBatch);
  } else {
    try {
      const p = path.resolve(SRC);
      const st = fs.statSync(p);
      const j = JSON.parse(fs.readFileSync(p, 'utf8'));
      const runs = Array.isArray(j.runs) ? j.runs : null;
      const rounds = (runs ?? [j]).map(normRound).filter((x) => x.ms.length >= 20);
      if (rounds.length) {
        cands.push({ kind: `--gate12-source=${SRC}`, p, rel: SRC, mtimeMs: st.mtimeMs, size: st.size, rounds, note: '指定源' });
      }
    } catch { /* 读不到就按"无数据"走 SKIP */ }
  }
  // 连续性闸门：单局窗口跨会话（> 12 分钟）不算"一次多局成绩"
  const viable = cands.filter((c) => c.spanMin === undefined || c.spanMin <= 12);
  viable.sort((a, b) => b.mtimeMs - a.mtimeMs);
  const pick = viable[0] ?? null;                 // 取时间上最近的一次成绩批次

  const out = [];
  const t0b = Date.now();
  const ageH = pick ? (Date.now() - pick.mtimeMs) / 3600000 : null;
  const stale = ageH !== null && ageH > MAX_AGE_H;
  const shortfalls = [];
  if (pick) {
    if (pick.rounds.length < MIN_ROUNDS) shortfalls.push(`局数 ${pick.rounds.length} < ${MIN_ROUNDS}`);
    const small = pick.rounds.filter((r) => r.ms.length < MIN_PER_ROUND);
    if (small.length) shortfalls.push(`含样本 <${MIN_PER_ROUND} 条的局 ${small.length} 个`);
    const badDenom = pick.rounds.filter((r) => r.misses === null);
    if (badDenom.length) shortfalls.push(`缺 hits/misses 的局 ${badDenom.length} 个`);
    const tot = pick.rounds.flatMap((r) => r.ms).length;
    if (tot < MIN_TOTAL) shortfalls.push(`合并样本 ${tot} < ${MIN_TOTAL}`);
  }
  const enough = !!pick && shortfalls.length === 0;
  const allMs = pick ? pick.rounds.flatMap((r) => r.ms) : [];
  const N = allMs.length;

  let status, detail, ST = null;
  if (!pick) {
    status = 'SKIP';
    detail = `SKIP：${ARENA} 下既没有"多局成绩 JSON（runs[].reactionMs）"，也没有 runs\\ 最近连续单局窗口`
      + `（候选 ${cands.length} 份，跨会话窗口 ${cands.length - viable.length} 份被连续性闸门剔除）`
      + ` → 无数据可判核心簇/尾包率（SKIP 不是放行：数据一出现即按 a/b/c 三项硬判）`;
    out.push(`扫描 ${ARENA}：多局 JSON 候选 ${multi.length} 份，runs\\ 窗口回退 ${winBatch ? '可用' : '不可用'}`);
    out.push('无可判定的"多局真实指针成绩" → SKIP');
  } else if (!enough) {
    status = 'SKIP';
    detail = `SKIP：数据不足 —— ${shortfalls.join('；')}（充足性门槛：局数 ≥${MIN_ROUNDS}、单局样本 ≥${MIN_PER_ROUND}、`
      + `合并样本 ≥${MIN_TOTAL}，取不到就降级 SKIP，不用小样本硬判）· 源 ${pick.rel}（${pick.kind}）`;
    out.push(`数据源：${pick.rel}（${pick.kind}，${pick.size}B，mtime ${new Date(pick.mtimeMs).toISOString()}）`);
    out.push(`数据不足：${shortfalls.join('；')} → SKIP（不判红、不影响退出码）`);
  } else {
    const per = pick.rounds.map((r) => {
      const s = r.ms.slice().sort((a, b) => a - b);
      const core = s.filter((v) => v <= CORE_MS);
      const tail = s.filter((v) => v > TAIL_MS);
      const denom = r.hits + r.misses;
      return {
        label: r.label, n: s.length, hits: r.hits, misses: r.misses, denom, hitRate: denom ? r.hits / denom : null,
        coreN: core.length, coreMed: quantile(core, 0.5), coreP90: quantile(core, 0.9), med: quantile(s, 0.5),
        mean: r.mean ?? s.reduce((a, b) => a + b, 0) / s.length, max: s.at(-1),
        tailN: tail.length, tailRate: tail.length / s.length, dropped: s.length - core.length,
        // 均值脆弱性取证：抽掉本局最大那 1 条样本，均值会移动多少
        dTop: (r.mean ?? s.reduce((a, b) => a + b, 0) / s.length) - (s.slice(0, -1).reduce((a, b) => a + b, 0) / (s.length - 1)),
      };
    });
    const pCore = allMs.filter((v) => v <= CORE_MS);
    const pTail = allMs.filter((v) => v > TAIL_MS);
    const hitsT = per.reduce((a, p) => a + p.hits, 0), missT = per.reduce((a, p) => a + p.misses, 0);
    const pooledHit = hitsT / (hitsT + missT);
    const pooledCoreMed = quantile(pCore, 0.5), pooledTailRate = pTail.length / N;

    // ── 阈值推导：全部来自本批数据（公式+中间量都打印）──────────────────
    const nTyp = Math.round(quantile(per.map((p) => p.n), 0.5));
    const maxCoreMed = Math.max(...per.map((p) => p.coreMed));
    const DER_CORE = Math.ceil((maxCoreMed * 1.5) / 50) * 50;                  // 最差局核心中位 ×1.5 → 上取 50ms 整档
    const worstMiss = Math.max(...per.map((p) => p.misses / p.denom));
    const DER_HIT = Math.floor(((1 - 2 * worstMiss) * 100) / 5) * 5 / 100;     // 1 − 2×最差失误率 → 下取 5% 整档
    const DER_TAIL = Math.ceil(100 / nTyp) / 100;                             // "单局允许 1 条尾包" → 上取百分比整档
    const TH = {
      core: Math.min(ANCHOR.core, DER_CORE),      // 取更严一方：数据变差不放宽
      tail: Math.min(ANCHOR.tail, DER_TAIL),
      hit: Math.max(ANCHOR.hit, DER_HIT),         // 命中率越大越严
    };

    const aBad = per.filter((p) => p.coreMed > TH.core);
    const bBad = per.filter((p) => p.tailRate > TH.tail);
    const bPooled = pooledTailRate <= TH.tail;
    const cBad = per.filter((p) => p.hitRate < TH.hit);
    const cPooled = pooledHit >= TH.hit;
    const ok = aBad.length === 0 && bBad.length === 0 && bPooled && cBad.length === 0 && cPooled;
    // 过期数据不判红、也不放行：把"若按硬判据会是什么结论"如实写进 body，防止 SKIP 掩盖越线。
    const wouldBe = ok ? 'PASS' : 'FAIL';
    status = stale ? 'SKIP' : wouldBe;

    const meanSpread = Math.max(...per.map((p) => p.mean)) - Math.min(...per.map((p) => p.mean));
    const dTopMax = Math.max(...per.map((p) => p.dTop)), dTopMin = Math.min(...per.map((p) => p.dTop));
    const runId = `gate12-${createHash('sha1').update(per.map((p) => `${p.hits}/${p.misses}/${p.n}`).join('|')).digest('hex').slice(0, 8)}-n${N}`;

    out.push(`数据批次：${pick.kind} · ${pick.rel}（${pick.size}B，mtime ${new Date(pick.mtimeMs).toISOString()}）`
      + ` · runId=${runId} · ${per.length} 局 / 样本 N=${N}（样本=命中条反应时；未命中不进分布，命中率另算） · ${pick.note}`);
    out.push(`数据新鲜度：距今 ${ageH.toFixed(2)}h ≤ 上限 ${MAX_AGE_H}h → FRESH（过期即降级 SKIP）`);
    out.push(`阈值推导 a) 逐局核心簇(≤${CORE_MS}ms)中位最大 ${maxCoreMed.toFixed(1)}ms ×1.5 = ${(maxCoreMed * 1.5).toFixed(1)}`
      + ` → 上取 50ms 整档 ${DER_CORE}ms ｜ 冻结锚 ${ANCHOR.core}ms ｜ 生效 ${TH.core}ms（取更严一方）`);
    out.push(`阈值推导 b) 单局样本中位 ${nTyp} 条 →"单局最多 1 条尾包"= ${(100 / nTyp).toFixed(3)}%`
      + ` → 上取百分比整档 ${(DER_TAIL * 100).toFixed(2)}% ｜ 冻结锚 ${(ANCHOR.tail * 100).toFixed(2)}% ｜ 生效 ${(TH.tail * 100).toFixed(2)}%`);
    out.push(`阈值推导 c) 逐局最差失误率 ${(worstMiss * 100).toFixed(3)}%（${per.map((p) => `${p.misses}/${p.denom}`).join(' ')}）`
      + ` → 1−2×该值 = ${((1 - 2 * worstMiss) * 100).toFixed(2)}% → 下取 5% 整档 ${(DER_HIT * 100).toFixed(0)}% ｜ 冻结锚 ${(ANCHOR.hit * 100).toFixed(0)}% ｜ 生效 ${(TH.hit * 100).toFixed(0)}%`);
    for (const p of per) {
      out.push(`  第${p.label.replace(/^第|局$/g, '')}局 n=${String(p.n).padStart(3)} 核心中位 ${String(p.coreMed.toFixed(1)).padStart(5)}ms`
        + ` 核心p90 ${String(p.coreP90.toFixed(1)).padStart(5)}ms 全中位 ${String(p.med.toFixed(1)).padStart(5)}ms 均值 ${String(p.mean.toFixed(2)).padStart(6)}ms(参照)`
        + ` 最大 ${String(p.max).padStart(3)}ms 尾包 ${p.tailN} 条 ${(p.tailRate * 100).toFixed(2)}% 命中 ${p.hits}/${p.denom} = ${(p.hitRate * 100).toFixed(2)}%`
        + (p.dropped ? ` ← >${CORE_MS}ms 剔除 ${p.dropped} 条` : ''));
    }
    out.push(`判据 a（每局核心簇中位 ≤${TH.core}ms）：${aBad.length === 0 ? `PASS（逐局最大 ${maxCoreMed.toFixed(1)}ms）` : `FAIL（${aBad.map((p) => `第${p.label}${p.coreMed}ms`).join('、')}）`}`);
    out.push(`判据 b（>${TAIL_MS}ms 尾包率 ≤${(TH.tail * 100).toFixed(2)}%）：逐局 ${bBad.length === 0 ? `PASS（逐局均为 ${per.map((p) => (p.tailRate * 100).toFixed(2) + '%').join(' ')}）` : `FAIL（${bBad.map((p) => `第${p.label}=${(p.tailRate * 100).toFixed(2)}%`).join('、')}）`}`
      + ` ｜ 合并 ${pTail.length}/${N} = ${(pooledTailRate * 100).toFixed(4)}% → ${bPooled ? 'PASS' : 'FAIL'}`);
    out.push(`判据 c（命中率 ≥${(TH.hit * 100).toFixed(0)}%）：逐局 ${cBad.length === 0 ? `PASS（最差 ${(Math.min(...per.map((p) => p.hitRate)) * 100).toFixed(2)}%）` : `FAIL（${cBad.map((p) => `第${p.label}=${(p.hitRate * 100).toFixed(2)}%`).join('、')}）`}`
      + ` ｜ 合并 ${hitsT}/${hitsT + missT} = ${(pooledHit * 100).toFixed(2)}% → ${cPooled ? 'PASS' : 'FAIL'}`);
    out.push(`口径告示（均值为什么不能当判据）：本批 6 局均值极差仅 ${meanSpread.toFixed(2)}ms，而抽掉单局最大的那 1 条样本`
      + `就能让该局均值移动 ${dTopMin.toFixed(2)}~${dTopMax.toFixed(2)}ms（= 整段信号的 ${((dTopMin / meanSpread) * 100).toFixed(0)}%~${((dTopMax / meanSpread) * 100).toFixed(0)}%）`
      + ` → 1 条尾包足以翻转任何 ms 量级的均值判据；核心簇中位与尾包率对本批样本的响应分别是 0 与显式计数。`);
    out.push(`阈值不放宽：${TH.core}ms / ${(TH.tail * 100).toFixed(2)}% / ${(TH.hit * 100).toFixed(0)}% 为生效判据（锚与数据推导取更严一方），`
      + `本项不因 ${per.length} 局而非想定 ${ROUNDS_WANT} 局放宽` + (per.length === ROUNDS_WANT ? '（局数=想定）' : `（实际 ${per.length} 局）`));
    if (stale) {
      out.push(`STALE_DATA 处置：源 mtime 距今 ${ageH.toFixed(2)}h > 上限 ${MAX_AGE_H}h → 降级 SKIP（不判红、不影响退出码）；`
        + `按硬判据本应为 ${wouldBe} —— 因过期不予采信，请先重跑靶场拿到 ${MAX_AGE_H} 小时内的成绩再判`);
    }

    detail = `源 ${pick.rel}（${pick.kind}${pick.note ? `，${pick.note}` : ''}，${per.length} 局 N=${N}，mtime ${new Date(pick.mtimeMs).toISOString()}，`
      + `新鲜度 ${ageH.toFixed(2)}h ${stale ? '>' : '≤'} 上限 ${MAX_AGE_H}h${stale ? ' = STALE_DATA' : ' = FRESH'}）`
      + ` · runId=${runId} · a 核心簇中位 ≤${TH.core}ms → ${aBad.length ? '不过' : '过'}（逐局最大 ${maxCoreMed.toFixed(1)}ms）`
      + ` · b 尾包率 ≤${(TH.tail * 100).toFixed(2)}% → ${bBad.length === 0 && bPooled ? '过' : '不过'}（合并 ${pTail.length}/${N}=${(pooledTailRate * 100).toFixed(4)}%）`
      + ` · c 命中率 ≥${(TH.hit * 100).toFixed(0)}% → ${cBad.length === 0 && cPooled ? '过' : '不过'}（合并 ${(pooledHit * 100).toFixed(2)}%）`
      + ` · 逐局核心中位 ${per.map((p) => p.coreMed.toFixed(1)).join('/')}ms`
      + (ok ? '' : ' ← 核心簇/尾包/命中率三项之一不满足（阈值由数据推导，未放宽）')
      + (stale ? ` ← 但源已过期（${ageH.toFixed(2)}h > ${MAX_AGE_H}h）：本项降级 SKIP，按硬判据本应为 ${wouldBe}` : '');

    ST = {
      runId, source: pick.rel, kind: pick.kind, sourceNote: pick.note, rounds: per.length, samples: N,
      ageHours: +ageH.toFixed(3), maxAgeHours: MAX_AGE_H, staleData: stale, wouldBe,
      anchors: { coreMs: ANCHOR.core, tailRate: ANCHOR.tail, hitRate: ANCHOR.hit },
      derived: { coreMs: DER_CORE, tailRate: +DER_TAIL.toFixed(4), hitRate: DER_HIT, typicalRoundSamples: nTyp, worstCoreMedianMs: +maxCoreMed.toFixed(2), worstMissRate: +worstMiss.toFixed(4) },
      effective: { coreMs: TH.core, tailRate: TH.tail, hitRate: TH.hit },
      perRound: per.map((p) => ({
        round: p.label, samples: p.n, hits: p.hits, misses: p.misses, hitRate: +p.hitRate.toFixed(4),
        coreSamples: p.coreN, coreMedianMs: +p.coreMed.toFixed(2), allMedianMs: +p.med.toFixed(2), meanMs: +p.mean.toFixed(2),
        maxMs: p.max, tailCount: p.tailN, tailRate: +p.tailRate.toFixed(4), droppedOverCore: p.dropped,
      })),
      pooled: {
        samples: N, coreSamples: pCore.length, coreMedianMs: +pooledCoreMed.toFixed(2),
        tailCount: pTail.length, tailRate: +pooledTailRate.toFixed(4), hits: hitsT, misses: missT, hitRate: +pooledHit.toFixed(4),
      },
      meanFragility: { meanSpreadMs: +meanSpread.toFixed(2), meanShiftFromOneTopSampleMs: { min: +dTopMin.toFixed(2), max: +dTopMax.toFixed(2) } },
      verdict: status,
    };
  }
  if (!ST) {
    ST = {
      runId: null, source: pick?.rel ?? null, kind: pick?.kind ?? null, rounds: pick?.rounds.length ?? 0,
      samples: N, ageHours: ageH === null ? null : +ageH.toFixed(3), maxAgeHours: MAX_AGE_H,
      staleData: stale, shortfalls, verdict: status,
    };
  }
  TAIL_GATE = ST;
  record(12, '核心簇中位 + 尾包率 双指标闸门（a 核心中位 / b 尾包率 / c 命中率）',
    `自读 ${ARENA} 最近一次多局真实指针成绩（多局 JSON → runs\\ 连续单局窗口回退），`
    + `阈值由数据推导并与锚取更严一方（无数据/样本不足 → SKIP；mtime > ${MAX_AGE_H}h → STALE_DATA → SKIP）`,
    status !== 'FAIL', Date.now() - t0b, detail, out.join('\n'), status);
}

// ═══ 汇总 + 报告 ══════════════════════════════════════════════════════════
const totalMs = Date.now() - t0;
const passedCount = results.filter((r) => r.status === 'PASS').length;
const skipped = results.filter((r) => r.status === 'SKIP');
const failed = results.filter((r) => r.status === 'FAIL');
const plannedSkipped = results.filter((r) => r.plannedSkip);

console.log(`${C.b}══ 回归结果表（档位：${MODE}）══${C.x}`);
console.log(`${C.d}  状态   项  检查内容                                耗时      结论${C.x}`);
for (const r of results) {
  const tag = r.status === 'PASS' ? `${C.g}PASS${C.x}` : r.status === 'SKIP' ? `${C.y}SKIP${C.x}` : `${C.r}FAIL${C.x}`;
  console.log(`  ${tag}  [${String(r.id).padStart(2, ' ')}] ${r.title.padEnd(34, ' ')} ${(r.durationMs / 1000).toFixed(1).padStart(7)}s   ${r.detail}`);
}
const verdict = failed.length === 0 ? `${C.g}全部通过${C.x}` : `${C.r}整体失败（${failed.map((f) => `第${f.id}项`).join('、')}）${C.x}`;
console.log(`\n  ${C.b}合计：共 ${ALL_ITEMS} 项，跑了 ${results.length - plannedSkipped.length} 项（本档跳过 ${SKIPPED.length ? SKIPPED.map((i) => `第${i}项`).join('、') : '无'}），PASS ${passedCount} / SKIP ${skipped.length} / FAIL ${failed.length}，总耗时 ${(totalMs / 1000).toFixed(1)}s → ${verdict}`);
console.log(`  退出码：${failed.length === 0 ? 0 : 1}${skipped.length ? `（SKIP ${skipped.map((s) => `第${s.id}项`).join('、')} 不计红：${skipped.filter((s) => !s.plannedSkip).length ? '含数据不足/过期项' : '全部为档位跳过'}）` : ''}`);

const report = {
  tool: 'D:\\dsh-tools\\run-regression.mjs',
  startedAt: new Date(t0).toISOString(),
  finishedAt: new Date().toISOString(),
  totalMs,
  concurrency: {
    runTag: RUN_TAG, processId: process.pid,
    tmpRoot: TMP_ROOT, runTmp: TMP, keepTmp: KEEP_TMP,
    isolatedFixtureDir: path.join(TMP, 'fixtures'),
    note: '每次运行独占 run-<pid>-<ts>\\；夹具先复制到 <专属>\\fixtures 再由 qa.mjs 现场重建并断言，跑完清理',
  },
  mode: {
    name: MODE, offline: OFFLINE, withAudio: WITH_AUDIO, skippedItems: SKIPPED,
    ranItems: results.filter((r) => !r.plannedSkip).map((r) => r.id),
    plannedSkipItems: plannedSkipped.map((r) => r.id),
  },
  node: NODE,
  python: PY,
  pythonResolvedVia: PY_INFO.how,
  spec: SPEC,
  passed: passedCount,
  skipped: skipped.length,
  failed: failed.length,
  exitCode: failed.length === 0 ? 0 : 1,
  driftGate: DRIFT_GATE,
  tailGate: TAIL_GATE,
  checks: results.map((r) => ({
    id: r.id, title: r.title, cmd: r.cmd, ok: r.ok, status: r.status, durationMs: r.durationMs,
    plannedSkip: !!r.plannedSkip, detail: r.detail, outputBytes: r.outputBytes, outputTail: r.outputTail,
  })),
};
fs.mkdirSync(path.dirname(REPORT), { recursive: true });
fs.writeFileSync(REPORT, JSON.stringify(report, null, 2), 'utf8');
console.log(`\n${C.d}报告：${REPORT}（含档位、逐项耗时、concurrency 段、driftGate 段与 tailGate 段）${C.x}`);

// ── 跑完清理本次进程专属 tmp（并发安全的另一半：不留共享残留）────────────────
let tmpSize = 0, tmpFiles = 0;
(function measure(d) {
  let ents = [];
  try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) measure(p);
    else { try { tmpFiles++; tmpSize += fs.statSync(p).size; } catch { /* 竞态忽略 */ } }
  }
})(TMP);
if (KEEP_TMP) {
  console.log(`${C.d}专属 tmp 保留（--keep-tmp）：${TMP}  ${tmpFiles} 文件 / ${(tmpSize / 1048576).toFixed(2)}MB${C.x}`);
} else {
  let cleaned = false, err = null;
  try { fs.rmSync(TMP, { recursive: true, force: true, maxRetries: 3 }); cleaned = !fs.existsSync(TMP); } catch (e) { err = e.message; }
  console.log(`${C.d}专属 tmp 清理：${TMP}  ${cleaned ? `已删除（${tmpFiles} 文件 / ${(tmpSize / 1048576).toFixed(2)}MB）` : `未清干净${err ? `（${err}）` : ''}`}${C.x}`);
}

process.exitCode = failed.length === 0 ? 0 : 1;
