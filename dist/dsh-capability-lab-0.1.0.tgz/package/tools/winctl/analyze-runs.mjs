/**
 * analyze-runs · 按"报告批次 + 通道"出成功率读数（分通道、带 run id、失败模式归类）
 *
 * 分母规则（与 recompute-l1 一致，作为本任务的判据口径）：
 *  1) 单位 = 一份报告里的一条 winctl 通道 run（naive 只另列，绝不与 winctl 混算）；
 *  2) 裁决 = 基准的外部 verify（字段 ok）；通道自报 okSelf 只作对照；
 *  3) verified 文案含「前置条件不成立 / 本次结果无效 / 无法判定」的样本**显式剔除并计数**；
 *  4) BEFORE = mtime < --before-cut 的报告；AFTER = mtime >= 该点且带标签的报告。
 *
 * 用法:
 *   node analyze-runs.mjs --before-cut 2026-11-06T23:05:00Z --after-label AFTER-FIX
 */
import fs from 'node:fs';
import path from 'node:path';

const DIR = 'D:\\dsh-tools\\winctl\\reports';
const argv = process.argv.slice(2);
const arg = (k, d) => { const i = argv.indexOf(`--${k}`); return i === -1 ? d : argv[i + 1]; };
const BEFORE_CUT = Date.parse(arg('before-cut', '2026-11-06T23:05:00Z'));
const AFTER_LABEL = arg('after-label', 'AFTER-FIX');
const jsonOut = arg('json', '');
const UND = /前置条件不成立|本次结果无效|无法判定/;
const NOVER = /该任务无外部判定/;

const rows = [];
for (const f of fs.readdirSync(DIR).filter((x) => /^bench-.*\.json$/.test(x)).sort()) {
  const st = fs.statSync(path.join(DIR, f));
  let j; try { j = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8')); } catch { continue; }
  if (!j?.results?.length) continue;
  const label = j.label ?? null;
  for (const r of j.results) {
    for (const ch of ['naive', 'winctl']) {
      (r[ch] ?? []).forEach((e, i) => {
        if (e.skip) return;
        rows.push({
          file: f, runId: j.runId ?? f.replace('.json', ''), label, mtime: st.mtimeMs, channel: ch, task: r.id, repeat: i + 1,
          ok: e.ok === true, okSelf: e.okSelf === true, ms: Number(e.ms ?? 0), note: String(e.note ?? ''), verified: String(e.verified ?? ''),
          undecidable: UND.test(e.verified ?? ''), noVerify: NOVER.test(e.verified ?? ''),
        });
      });
    }
  }
}

const pct = (n, d) => (d ? Number(((n / d) * 100).toFixed(1)) : null);
const med = (a) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const m = s.length >> 1; return s.length % 2 ? s[m] : Math.round((s[m - 1] + s[m]) / 2); };

function summarize(label, filter) {
  const base = rows.filter(filter);
  const out = { label, channels: {} };
  for (const ch of ['winctl', 'naive']) {
    const all = base.filter((r) => r.channel === ch);
    const und = all.filter((r) => r.undecidable);
    const nv = all.filter((r) => !r.undecidable && r.noVerify);
    const n = all.filter((r) => !r.undecidable && !r.noVerify);
    out.channels[ch] = {
      n: n.length, ok: n.filter((r) => r.ok).length, ratePct: pct(n.filter((r) => r.ok).length, n.length), medMs: med(n.map((r) => r.ms)),
      zeroFilter: { n: all.length, ok: all.filter((r) => r.ok).length, ratePct: pct(all.filter((r) => r.ok).length, all.length) },
      droppedUndecidable: und.length, setAsideNoVerify: nv.length,
      byTask: Object.entries(n.reduce((m, r) => { (m[r.task] ??= { n: 0, ok: 0 }); m[r.task].n++; if (r.ok) m[r.task].ok++; return m; }, {}))
        .map(([task, v]) => ({ task, ...v, ratePct: pct(v.ok, v.n) })).sort((a, b) => a.ratePct - b.ratePct),
      fails: n.filter((r) => !r.ok).map((r) => ({ file: r.file, runId: r.runId, task: r.task, repeat: r.repeat, ms: r.ms, note: r.note, verified: r.verified })),
    };
  }
  return out;
}

const before = summarize('BEFORE', (r) => r.mtime < BEFORE_CUT && !r.label);
const afterRuns = [...new Set(rows.filter((r) => r.label?.startsWith(AFTER_LABEL)).map((r) => r.runId))].sort();
const after = summarize(`AFTER (${afterRuns.length} 轮合并)`, (r) => r.label?.startsWith(AFTER_LABEL));
const perRun = afterRuns.map((id) => {
  const s = summarize(id, (r) => r.runId === id);
  return { runId: id, winctl: s.channels.winctl, naive: s.channels.naive };
});

const fmt = (s) => `${String(s.n).padStart(4)} ${String(s.ok).padStart(4)} ${String(s.ratePct).padStart(7)}%  med ${String(s.medMs ?? '-').padStart(6)}ms  剔无效 ${String(s.droppedUndecidable).padStart(2)}  单列无判定 ${String(s.setAsideNoVerify).padStart(2)}  [zero-filter ${s.zeroFilter.ratePct}%/${s.zeroFilter.n}]`;
console.log('# winctl 通道读数（判据口径：分通道 + 外部 verify + 剔除不可度量）');
console.log('\n## BEFORE（本轮修复前的全部报告，mtime < ' + new Date(BEFORE_CUT).toISOString() + '）');
console.log('  winctl : ' + fmt(before.channels.winctl));
console.log('  naive  : ' + fmt(before.channels.naive));
console.log('\n## AFTER 每轮（带 run id）');
for (const r of perRun) console.log(`  ${r.runId}  winctl ${fmt(r.winctl)}   naive ${fmt(r.naive)}`);
console.log('\n## AFTER 合并（' + afterRuns.length + ' 轮）');
console.log('  winctl : ' + fmt(after.channels.winctl));
console.log('  naive  : ' + fmt(after.channels.naive));
console.log('\n## 分任务对比（winctl）');
const tasks = [...new Set([...before.channels.winctl.byTask, ...after.channels.winctl.byTask].map((t) => t.task))];
console.log('  任务'.padEnd(24) + 'BEFORE'.padEnd(20) + 'AFTER');
for (const t of tasks) {
  const b = before.channels.winctl.byTask.find((x) => x.task === t) ?? { n: 0, ok: 0, ratePct: null };
  const a = after.channels.winctl.byTask.find((x) => x.task === t) ?? { n: 0, ok: 0, ratePct: null };
  console.log(`  ${t.padEnd(22)} ${(b.ratePct + '%').padStart(7)} (n=${b.n})`.padEnd(20) + `${(a.ratePct + '%').padStart(7)} (n=${a.n})`);
}
console.log('\n## AFTER 剩余失败明细（winctl）');
if (!after.channels.winctl.fails.length) console.log('  （无）');
for (const f of after.channels.winctl.fails) console.log(`  ${f.runId}/${f.task}#${f.repeat} ${f.ms}ms | ${f.note.slice(0, 100)} | ${f.verified.slice(0, 80)}`);
console.log('\n## 判定');
const wr = after.channels.winctl.ratePct;
const pool = { n: after.channels.winctl.n, ok: after.channels.winctl.ok };
console.log(`  AFTER winctl 合并命中率 = ${wr}% （${pool.ok}/${pool.n}）→ 判据线 ≥90%: ${wr >= 90 ? '达标 ✅' : '未达标 ❌'}`);
const perRunPass = perRun.map((r) => ({ runId: r.runId, rate: r.winctl.ratePct, pass: r.winctl.ratePct >= 90 }));
console.log(`  按轮：${perRunPass.map((r) => `${r.runId.slice(-6)}=${r.rate}%${r.pass ? '✅' : '❌'}`).join('  ')}  → 3 轮全达标：${perRunPass.every((r) => r.pass) ? '是 ✅' : '否 ❌'}`);

if (jsonOut) {
  fs.writeFileSync(jsonOut, JSON.stringify({ generatedAt: new Date().toISOString(), beforeCut: new Date(BEFORE_CUT).toISOString(), afterLabel: AFTER_LABEL, before, after, perRun }, null, 1), 'utf8');
  console.log(`\nJSON: ${jsonOut}`);
}
