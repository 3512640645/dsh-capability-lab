#!/usr/bin/env node
/**
 * winctl · 触控能力基准
 *
 * 同一批任务跑两条通道，用成功率与耗时量化差距：
 *   A 通道（naive）：OCR/估算坐标 → 点击 → **不做校验**（我早先的做法）
 *   B 通道（winctl）：元素优先 → invoke/set_value/click → **动作后校验 + 自愈重试**
 *
 * 用法: node winctl/bench.mjs [--repeat 3] [--only calc-sum]
 */
import fs from 'node:fs';
import path from 'node:path';
import { connect, findWindows, readText, windowBy, waitForWindow } from './mcp.mjs';
import { locate, waitFor, waitForText, waitForAnyTextFast, activateIfNeeded, setValueVerified, activate, clickElement, invokeElement, typeText, pressKeys, typeAndVerify, sleep } from './index.mjs';

const argv = process.argv.slice(2);
const val = (f, d) => { const i = argv.indexOf(`--${f}`); return i === -1 ? d : argv[i + 1]; };
const REPEAT = Number(val('repeat', 3));
const ONLY = val('only', '');
const CHANNEL = val('channel', 'both');   // both | winctl | naive（隔离排查用）
const LABEL = val('label', '');           // 本轮标签（写进报告，便于分批复现）
const STARTED_AT = new Date().toISOString();
const TOKEN = "winctl-clip-";   // 剪贴板任务的唯一令牌
const DRAG_TOL = 16;            // 拖拽位移容差：Aero 的拖动阈值会吃掉几个像素，给 16px 余量

/**
 * 确保目标应用有窗口：没有就启动并等它出现。
 * 基准测试不该依赖"用户恰好开着某个程序"——环境要自己准备。
 */
async function ensureApp(client, { exe, titleRe, classNameRe, settleMs = 2500 }) {
  let w = await windowBy(client, { title: titleRe, className: classNameRe });
  if (w) return w;
  console.log(`  (启动 ${exe} …)`);
  await client.tool('launch_app', { target: exe, waitMs: settleMs });
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    await sleep(800);
    w = await windowBy(client, { title: titleRe, className: classNameRe });
    if (w) return w;
  }
  return null;
}

/**
 * 确保没有遗留的原生对话框。
 *
 * 为什么必须有：A 通道跑完会留下一个另存为对话框，清理没干净时，
 * B 通道随后按 Ctrl+S 时命中的还是那个**旧对话框**（waitForWindow 只按类名找），
 * 于是定位失败 —— 表现为"B 通道单独跑 100%，跑在 A 后面就 0%"。
 * 是通道间的**状态污染**，不是通道本身的问题。
 * 教训：基准里每个通道开始前都要主动建立干净状态，不能假设上一轮收干净了。
 */
async function ensureNoDialog(client, { attempts = 4 } = {}) {
  for (let i = 0; i < attempts; i++) {
    const dlg = (await findWindows(client, { useCache: false })).find((w) => w.className === '#32770');
    if (!dlg) return true;
    await pressKeys(client, dlg.nativeWindowHandle, ['ESC']).catch(() => {});
    await sleep(500);
  }
  return false;
}

/* ─────────────── 新增两个任务用的观测/定位辅助（只在本文件内用） ─────────────── */

/**
 * 取一次 UIA 树快照，并抽出所有 TreeItem（左树节点）及其**直接子节点名**。
 *
 * 为什么不用 find/扁平结果：扁平结果丢掉了父子关系，"多出来的节点是否真挂在这个目标下面"
 * 只能靠深度猜。树快照保留了 children 结构，于是判定可以硬到"该 TreeItem 的 children 从空变非空"。
 * 为什么查询必须限定控件类型（本项目的教训）：只按名字找，「此电脑」「下载」这些字
 * 在地址栏/内容区/树里都可能有，命中未必是树节点。
 */
async function treeSnapshot(client, hwnd, { maxNodes = 3000, maxDepth = 12, treeTimeoutMs = 8000 } = {}) {
  // 参数上限是硬约束：maxNodes ≤ 3000、maxDepth ≤ 12（超过会被插件以 INVALID_ARGUMENTS 拒绝）。
  // 修复记录：旧值 maxNodes=6000 让每一次树读取都报错返回空树 → 被 setup 误判成
  // "导航树里只枚举到 0 个 TreeItem" → tree-expand 被自判为"前置条件不成立"。
  // 那是**基准自己的参数 bug**，不是平台限制。现在把调用错误单独带出来，避免再次混淆。
  const r = await client.tool('accessibility_tree', {
    nativeWindowHandle: hwnd, maxNodes: Math.min(maxNodes, 3000), maxDepth: Math.min(maxDepth, 12),
    treeTimeoutMs, viewMode: 'control', detailLevel: 'full',
  }).catch((e) => ({ isError: true, text: String(e) }));
  return {
    items: collectTreeItems(r.data?.tree ?? null),
    truncated: r.data?.truncated === true,
    nodeCount: r.data?.nodeCount ?? 0,
    toolError: r.isError ? String(r.text).replace(/\s+/g, ' ').slice(0, 120) : null,
    error: r.isError ? String(r.text).slice(0, 80) : null,
  };
}

/** DFS 收集 TreeItem 记录；非 TreeItem 的包装节点透明穿过（子项仍算作上层树节点的孩子）。 */
function collectTreeItems(root, out = [], parent = null) {
  for (const c of root?.children ?? []) {
    const isItem = String(c.controlType ?? '').includes('TreeItem');
    let rec = parent;
    if (isItem) {
      rec = {
        id: c.id ?? null,
        name: String(c.name ?? '').trim(),
        depth: typeof c.depth === 'number' ? c.depth : null,
        box: c.boundingBox ?? null,
        patterns: Array.isArray(c.patterns) ? c.patterns : [],
        childNames: [],
        parent: parent?.name ?? null,
      };
      out.push(rec);
      if (parent) parent.childNames.push(rec.name);
    }
    collectTreeItems(c, out, rec);
  }
  return out;
}

/** 结构性判定：目标 TreeItem 的 children 是否从"基线里的空"变成"有基线没见过的新项"。 */
function expandedChildren(ctx, items) {
  const t = items.find((x) => x.name === ctx.target.name);
  if (!t) return { ok: false, reason: `树里找不到节点「${ctx.target.name}」`, count: 0, fresh: [] };
  const base = new Set(ctx.baseNames ?? []);
  const fresh = t.childNames.filter((n) => !base.has(n));
  return {
    ok: fresh.length > 0, count: t.childNames.length, fresh, node: t,
    reason: fresh.length ? '' : (t.childNames.length ? 'children 里的名字基线里都出现过，无法归因' : 'children 仍为空'),
  };
}

/** 读窗口当前位置（每次重新枚举窗口，不吃缓存）。 */
async function windowBox(client, hwnd) {
  const w = (await findWindows(client)).find((x) => x.nativeWindowHandle === hwnd);
  return w?.boundingBox ?? null;
}

/** 读虚拟屏幕矩形：screenshot 的 desktop 作用域会返回屏幕 bounds（纯只读观测，不碰鼠标键盘）。 */
async function screenBounds(client) {
  try {
    const r = await client.tool('screenshot', { scope: 'desktop', maxWidth: 480 });
    const b = r.data?.screenshot?.bounds ?? r.data?.meta?.screenshot?.bounds;
    if (b && b.width > 0 && b.height > 0) return b;
  } catch { /* 取不到就退化成固定位移，并在运行里说明 */ }
  return null;
}

/** 把拖拽插值成多步：后端每步停 25ms，分步移动能让窗口自己的拖动循环跟上指针。 */
function dragPath(sx, sy, ex, ey, steps = 6) {
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    pts.push({ x: Math.round(sx + (ex - sx) * t), y: Math.round(sy + (ey - sy) * t) });
  }
  return pts;   // 至少 2 个点；path 为屏幕坐标，直线插值即可
}

/* ─────────── 遮挡感知的窗口摆位（drag-move 的失败模式：起点被别的窗口盖住） ───────────
 *
 * 现场证据（bench-2026-11-06213611.json）：drag 连续 3 轮全部报
 * POINT_COVERED: (874,285) shows another window ('Windows 安全中心', class Shell_Syste…)。
 * 这是插件**设计性的安全拒绝**（windows-uia.ps1 Assert-PointOnTarget）：
 * 真实输入落在最上层窗口上，起点露出别的进程的窗口就不发输入。
 * 而拖动只检查 path 的**第一个点**，所以只要把标题栏摆到一块没被盖住的区域就能过。
 *
 * 摆位用 move_window（SetWindowPos 路径，不碰指针、不需要前台），属于**环境准备**，
 * 不是被测动作 —— 被测动作仍然是"指针从起点拖到终点"。
 */

/** 标题栏内的一组候选落点（避开右侧的最小化/最大化/关闭）。 */
function titleBarPoints(box) {
  const out = [];
  for (const fx of [0.22, 0.38, 0.54, 0.70]) for (const dy of [14, 22]) out.push({ x: Math.round(box.x + box.width * fx), y: Math.round(box.y + dy) });
  return out;
}

/** 逐点命中测试：返回第一个"落点属于目标进程"的点（与插件 Assert-PointOnTarget 同判据）。 */
async function hitTestOwnProcess(client, hwnd, processId, points) {
  const misses = [];
  for (const p of points) {
    const r = await client.tool('element_info', { x: p.x, y: p.y }).catch(() => null);
    const info = r?.data?.element;
    if (info && (info.processId === processId || info.nativeWindowHandle === hwnd)) return { point: p, info };
    if (info) misses.push(`${p.x},${p.y}→${String(info.name ?? '').slice(0, 12)}`);
  }
  return { point: null, misses };
}

/**
 * 把窗口摆到一个"标题栏露出"的位置。
 * 先试屏幕四角/中线的网格（中下部通常最空），每摆一次就重新命中测试。
 * 返回 { box, point, spot, tried }；point=null 表示所有候选位点都被盖住（此时才允许判不可度量）。
 */
async function placeTitleBarExposed(client, hwnd, processId, { box, screen, maxSpots = 16 } = {}) {
  const w = box.width; const h = box.height;
  const xs = [screen.x + 8, Math.round(screen.x + 8 + (screen.width - w - 16) * 0.5), screen.x + screen.width - w - 8];
  const ys = [screen.y + 8, Math.round(screen.y + 8 + (screen.height - h - 16) * 0.5), screen.y + screen.height - h - 8];
  const spots = [];
  for (const y of ys) for (const x of xs) spots.push({ x: Math.round(x), y: Math.round(y) });
  for (let i = 1; i <= 4; i++) spots.push({ x: Math.round(screen.x + 8 + (screen.width - w - 16) * i / 5), y: screen.y + screen.height - h - 8 });
  const tried = [];
  for (const s of spots.slice(0, maxSpots)) {
    await client.tool('move_window', { nativeWindowHandle: hwnd, x: s.x, y: s.y, activate: true }).catch(() => {});
    await sleep(260);
    const b = (await windowBox(client, hwnd)) ?? box;
    const hit = await hitTestOwnProcess(client, hwnd, processId, titleBarPoints(b));
    tried.push(`(${s.x},${s.y})${hit.point ? '✔' : '✘'}`);
    if (hit.point) return { box: b, point: hit.point, spot: s, tried };
  }
  return { box: null, point: null, spot: null, tried };
}

/** 读某个 UIA 节点的 value 字段（外部判定用：不靠 OCR、不靠窗口标题）。 */
async function uiaValueOf(client, hwnd, nameQuery, { controlTypes = [], timeoutMs = 2500 } = {}) {
  const deadline = Date.now() + timeoutMs;
  let last = null;
  for (;;) {
    const r = await client.tool('accessibility_tree', {
      nativeWindowHandle: hwnd, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 3000, viewMode: 'control', detailLevel: 'full',
    }).catch(() => null);
    const all = [];
    const walk = (n) => { for (const c of n?.children ?? []) { all.push(c); walk(c); } };
    walk(r?.data?.tree ?? null);
    const hit = all.find((c) => String(c.name ?? '').trim() === nameQuery
      && (!controlTypes.length || controlTypes.some((t) => String(c.controlType ?? '').includes(t)))) ?? null;
    if (hit) { last = hit; const v = hit.value ?? hit.Value ?? null; if (v !== null && v !== undefined) return { found: true, value: String(v), controlType: hit.controlType }; }
    if (Date.now() > deadline) return { found: false, value: last ? String(last.value ?? '') : null, reason: last ? '节点没有 value 字段' : `整树里找不到名为「${nameQuery}」的节点` };
    await sleep(300);
  }
}

/** 读计算器显示屏（"显示为 56" 这类元素名）。返回元素名或 null。 */
async function calcDisplay(client, hwnd, { timeoutMs = 1200 } = {}) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const r = await client.tool('find', { query: '显示为', nativeWindowHandle: hwnd, maxResults: 6, ocrFallback: false }).catch(() => null);
    const hit = (r?.data?.results ?? []).find((h) => /显示为/.test(String(h.name ?? '')));
    if (hit) return String(hit.name).replace(/\s+/g, ' ').trim();
    if (Date.now() > deadline) return null;
    await sleep(250);
  }
}

/* ───────────────────────── 任务定义 ───────────────────────── */

const TASKS = [
  {
    id: 'calc-sum',
    name: '计算器：7×8 得出 56',
    async setup(client) {
      const w = await ensureApp(client, { exe: 'calc.exe', titleRe: '计算器|Calculator', classNameRe: 'ApplicationFrameWindow|WinUIDesktopWin32WindowClass' });
      if (!w) return null;
      const hwnd = w.nativeWindowHandle;
      // **状态重置**：计算器显示屏会保留上一轮的结果。不清零的话"看到 56"是白送 ——
      // 实测同一批次里 A 通道连"七"都没找到（找不到键 七），外部判定却报"显示确为 56"，
      // 因为上一轮 winctl 把 56 留在了屏上。这是判定有效性 bug，不是成功率。
      await activate(client, hwnd);
      await sleep(500);
      const displayBefore = await calcDisplay(client, hwnd);
      let cleared = false;
      for (let i = 0; i < 3 && !cleared; i++) {
        await pressKeys(client, hwnd, ['ESC']);   // Windows 计算器：ESC = C（清零）
        await sleep(350);
        const d = await calcDisplay(client, hwnd);
        if (d !== null && !/\b56\b/.test(d)) cleared = true;
      }
      return { hwnd, title: w.name, displayBefore, cleared };
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      for (const k of ['七', '乘以', '八', '等于']) {
        const r = await client.tool('find', { query: k, nativeWindowHandle: ctx.hwnd, maxResults: 4, ocrFallback: true });
        const hit = (r.data?.results ?? []).find((h) => h.x !== undefined);
        if (!hit) return { ok: false, ms: Date.now() - t0, note: `找不到键 ${k}` };
        await client.tool('click', { x: hit.x, y: hit.y, nativeWindowHandle: ctx.hwnd, activate: true });
        await sleep(120);
      }
      return { ok: true, ms: Date.now() - t0, note: '坐标点击发出后未校验' };
    },
    // 由基准统一裁决（不采信通道自报）
    async verify(client, ctx) {
      if (ctx.cleared === false) return { ok: false, note: `前置条件不成立（显示屏未能清零：${ctx.displayBefore}），本次结果无效` };
      const d = await calcDisplay(client, ctx.hwnd, { timeoutMs: 2500 });
      if (d === null) return { ok: false, note: '读不到显示屏元素' };
      const hard = /\b56\b/.test(d);
      return { ok: hard, note: hard ? `显示屏确为 56（前置已清零：${ctx.displayBefore}）` : `显示不是 56（${d}）` };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      // 诊断结论：按键的真实 UIA 名是中文（七/八/乘以/等于）；
      // 查 "7" 会命中显示屏"显示为 7"，属于命名陷阱。
      for (const k of ['七', '乘以', '八', '等于']) {
        const hit = await locate(client, ctx.hwnd, k);
        if (!hit) return { ok: false, ms: Date.now() - t0, note: `找不到键 ${k}` };
        await invokeElement(client, ctx.hwnd, hit);
        await sleep(120);
      }
      const got = await waitForText(client, ctx.hwnd, '56', { timeoutMs: 3000 });
      return { ok: Boolean(got), ms: Date.now() - t0, note: got ? '校验到结果 56' : '校验失败：未见 56' };
    },
  },
  {
    id: 'notepad-type',
    name: '记事本：写入中文并回读校验',
    async setup(client) {
      const w = await ensureApp(client, { exe: 'notepad.exe', titleRe: 'Notepad|记事本', classNameRe: 'Notepad' });
      if (!w) return null;
      const hwnd = w.nativeWindowHandle;
      // 状态重置：先清空正文。不清空的话"回读校验"会被上一轮残留的同一句话白送通过。
      await activate(client, hwnd);
      await sleep(400);
      await pressKeys(client, hwnd, ['ctrl', 'a']);
      await pressKeys(client, hwnd, ['DELETE']);
      await sleep(300);
      const before = await uiaValueOf(client, hwnd, '文本编辑器', { controlTypes: ['Document', 'Edit'], timeoutMs: 1500 });
      return { hwnd, title: w.name, valueBefore: before.value ?? null, preempty: !String(before.value ?? '').includes('校验通过') };
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      await activate(client, ctx.hwnd);
      await client.tool('type_text', { text: '触控自检 naive', nativeWindowHandle: ctx.hwnd, method: 'auto' });
      return { ok: true, ms: Date.now() - t0, note: '输入发出后未校验' };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      // 诊断结论：正文元素名为「文本编辑器」，直接 set_value 最稳；
      // 校验必须把整窗文字拼接后匹配（OCR 会把中文按字切词）。
      const editor = await locate(client, ctx.hwnd, '文本编辑器');
      const r = await typeAndVerify(client, ctx.hwnd, 'winctl 校验通过 2026', '校验通过', { editor });
      return { ok: r.ok, ms: Date.now() - t0, note: `${r.method}，第 ${r.attempts} 次${r.ok ? '校验通过' : '仍失败'}` };
    },
    // 外部判定（本轮新增）：这个任务原来**没有** verify()，于是 12 条样本全部落在"无外部判定"里，
    // 只能采信通道自报。现在直接读 UIA 正文节点的 value 字段 —— 不看 OCR、不看窗口标题
    // （标题里也含"校验通过"，用 wait_for(title/text) 会白送通过）。
    async verify(client, ctx) {
      if (!ctx.preempty) return { ok: false, note: `前置条件不成立（清空后正文仍含"校验通过"：${String(ctx.valueBefore).slice(0, 30)}），本次结果无效` };
      const v = await uiaValueOf(client, ctx.hwnd, '文本编辑器', { controlTypes: ['Document', 'Edit'], timeoutMs: 2500 });
      if (!v.found) return { ok: false, note: `读不到正文节点的 value（${v.reason}）` };
      const ok = v.value.includes('校验通过');
      return { ok, note: ok ? `正文 value 确含「校验通过」（${v.controlType}，${v.value.length} 字）` : `正文 value 不含「校验通过」：${v.value.slice(0, 40)}` };
    },
  },
  {
    id: 'window-activate',
    name: '窗口激活：带到前台并确认',
    async setup(client) {
      const w = await ensureApp(client, { exe: 'notepad.exe', titleRe: 'Notepad|记事本', classNameRe: 'Notepad' });
      if (!w) return null;
      return { hwnd: w.nativeWindowHandle, title: w.name };
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      const ps = `Add-Type -Namespace W -Name F -MemberDefinition '[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);'; [void][W.F]::SetForegroundWindow([IntPtr]${ctx.hwnd})`;
      const { execFileSync } = await import('node:child_process');
      try { execFileSync('powershell', ['-NoProfile', '-Command', ps], { windowsHide: true }); } catch { /* ignore */ }
      await sleep(500);
      const wins = await findWindows(client);
      const fg = wins.find((w) => w.hasKeyboardFocus);
      return { ok: Boolean(fg && fg.nativeWindowHandle === ctx.hwnd), ms: Date.now() - t0, note: `前台=${fg?.name ?? '未知'}` };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      for (let attempt = 1; attempt <= 4; attempt++) {
        await activate(client, ctx.hwnd);
        const wins = await findWindows(client);
        const fg = wins.find((w) => w.hasKeyboardFocus);
        if (fg && fg.nativeWindowHandle === ctx.hwnd) return { ok: true, ms: Date.now() - t0, note: `第 ${attempt} 次抢到前台` };
      }
      return { ok: false, ms: Date.now() - t0, note: '4 次均未抢到前台' };
    },
    // 外部判定：不看通道怎么说，直接查"现在到底谁在前台"
    async verify(client, ctx) {
      const wins = await findWindows(client, { useCache: false });
      const fg = wins.find((w) => w.hasKeyboardFocus);
      return { ok: Boolean(fg && fg.nativeWindowHandle === ctx.hwnd), note: `前台窗口=${(fg?.name ?? '未知').slice(0, 24)}` };
    },
  },
  {
    id: 'dialog-control',
    name: '原生对话框：定位「文件名」并写入后关闭',
    async setup(client) {
      const w = await ensureApp(client, { exe: 'notepad.exe', titleRe: 'Notepad|记事本', classNameRe: 'Notepad' });
      if (!w) return null;
      return { hwnd: w.nativeWindowHandle, title: w.name };
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      await ensureNoDialog(client);
      await activate(client, ctx.hwnd);
      await pressKeys(client, ctx.hwnd, ['ctrl', 's']);
      await sleep(1500);
      const dlg = await windowBy(client, { className: '#32770' });
      if (!dlg) return { ok: false, ms: Date.now() - t0, note: '另存为对话框未出现' };
      await client.tool('type_text', { text: 'winctl-naive.txt', nativeWindowHandle: dlg.nativeWindowHandle, method: 'auto' });
      ctx.dlgHwnd = dlg.nativeWindowHandle;   // 对话框先别关，交给外部判定
      ctx.written = 'winctl-naive';
      return { ok: true, ms: Date.now() - t0, note: '已向对话框发送输入（未自校验）' };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      await ensureNoDialog(client);
      await activateIfNeeded(client, ctx.hwnd);
      await pressKeys(client, ctx.hwnd, ['ctrl', 's']);
      // 等对话框出现：交给后端 wait_for(window)，不要自己每轮枚举窗口
      const dlg = await waitForWindow(client, { className: '#32770', timeoutMs: 8000 });
      if (!dlg) return { ok: false, ms: Date.now() - t0, note: '另存为对话框未出现' };
      const hwnd = dlg.nativeWindowHandle;
      await activate(client, hwnd);   // 实测：窗口不在前台时 UIA 树会变窄，定位会失败
      // 快速路径：限定 controlType=Edit 一步定位（查「文件名」会命中标签），
      // set_value 直接写入，服务端 wait_for(text) 校验 —— 三步搞定
      const res = await setValueVerified(client, hwnd, '文件名', 'winctl-verified.txt', { controlType: 'Edit', timeoutMs: 5000 });
      ctx.dlgHwnd = hwnd;                     // 对话框先别关，交给外部判定
      ctx.written = 'winctl-verified';
      return { ok: res.ok, ms: Date.now() - t0, note: res.ok ? `元素定位 + 写入成功（${res.via}）` : res.note };
    },
    // 外部判定：对话框输入框里到底有没有写进去
    async verify(client, ctx) {
      if (!ctx.dlgHwnd) return { ok: false, note: '对话框未留下可检查的句柄' };
      const got = await waitForAnyTextFast(client, ctx.dlgHwnd, ctx.written, { timeoutMs: 2500 });
      return { ok: Boolean(got), note: got ? `输入框内容确含「${ctx.written}」（${got.via}）` : `输入框里没有「${ctx.written}」` };
    },
    async cleanup(client, ctx) {
      if (ctx.dlgHwnd) await pressKeys(client, ctx.dlgHwnd, ['ESC']).catch(() => {});
      ctx.dlgHwnd = null;
    },
  },
  {
    // 新增能力：跨窗口剪贴板往返（复制 → 在另一个窗口粘贴 → 回读确认）
    id: 'clipboard-roundtrip',
    name: '剪贴板：跨窗口复制粘贴并回读确认',
    async setup(client) {
      const w = await ensureApp(client, { exe: 'notepad.exe', titleRe: 'Notepad|记事本', classNameRe: 'Notepad' });
      if (!w) return null;
      const hwnd = w.nativeWindowHandle;
      await activate(client, hwnd);
      // 统一准备状态：把待复制的令牌写进记事本
      await pressKeys(client, hwnd, ['ctrl', 'a']);
      await pressKeys(client, hwnd, ['DELETE']);
      const res = await setValueVerified(client, hwnd, '文本编辑器', TOKEN, { controlType: 'Edit', timeoutMs: 6000 });
      if (!res.ok) {
        // 退路：直接模拟键盘输入
        await typeText(client, hwnd, TOKEN);
      }
      return { hwnd, token: TOKEN };
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      await client.tool('keypress', { keys: ['ctrl', 'a'], nativeWindowHandle: ctx.hwnd, activate: true });
      await client.tool('keypress', { keys: ['ctrl', 'c'], nativeWindowHandle: ctx.hwnd });
      // 注：原本想用 Win+R 打开运行框当粘贴目标，但插件**设计性屏蔽了 Windows 键**
      // （文档原文 "The Windows key is blocked by design"），所以改用另存为对话框的输入框。
      await client.tool('keypress', { keys: ['ctrl', 's'], nativeWindowHandle: ctx.hwnd });
      await sleep(900);
      const dlg = (await findWindows(client, { useCache: false })).find((w) => w.className === '#32770');
      if (!dlg) return { ok: false, ms: Date.now() - t0, note: '另存为对话框没出现' };
      // 老做法：按窗口比例估一个输入框坐标盲点
      const b = dlg.boundingBox ?? { x: 0, y: 0, width: 800, height: 600 };
      await client.tool('click', { x: Math.round(b.x + b.width * 0.5), y: Math.round(b.y + b.height * 0.72), activate: true });
      await client.tool('keypress', { keys: ['ctrl', 'v'], nativeWindowHandle: dlg.nativeWindowHandle });
      await sleep(300);
      ctx.dlgHwnd = dlg.nativeWindowHandle;   // 留着给外部判定
      ctx.token = ctx.token ?? '';
      return { ok: true, ms: Date.now() - t0, note: '按键发出后未校验（自报成功）' };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      await ensureNoDialog(client);
      await activateIfNeeded(client, ctx.hwnd);
      await pressKeys(client, ctx.hwnd, ['ctrl', 'a']);
      await pressKeys(client, ctx.hwnd, ['ctrl', 'c']);
      await pressKeys(client, ctx.hwnd, ['ctrl', 's']);
      const dlg = await waitForWindow(client, { className: '#32770', timeoutMs: 8000 });
      if (!dlg) return { ok: false, ms: Date.now() - t0, note: '另存为对话框没出现' };
      const hwnd = dlg.nativeWindowHandle;
      // 元素优先：按控件类型定位真正的输入框（查名字会命中旁边的标签）
      const edit = await locate(client, hwnd, '文件名', { controlType: 'Edit', retries: 3, intervalMs: 200, ocrFallback: false, maxDepth: 5, maxNodes: 400, treeTimeoutMs: 1500 });
      if (!edit) { await pressKeys(client, hwnd, ['ESC']); return { ok: false, ms: Date.now() - t0, note: '找不到文件名输入框' }; }
      await invokeElement(client, hwnd, edit).catch(() => {});
      await pressKeys(client, hwnd, ['ctrl', 'v']);
      // 校验：粘贴的内容必须真的出现在对话框输入框里
      ctx.dlgHwnd = hwnd;
      return { ok: true, ms: Date.now() - t0, note: '已执行复制 → 粘贴流程' };
    },
    // 外部判定：剪贴板内容必须真的落到另一个窗口的输入框里
    async verify(client, ctx) {
      if (!ctx.dlgHwnd) return { ok: false, note: '对话框未留下可检查的句柄' };
      const got = await waitForAnyTextFast(client, ctx.dlgHwnd, ctx.token, { timeoutMs: 3000 });
      return { ok: Boolean(got), note: got ? `剪贴板内容确已到达目标窗口（${got.via}）` : '目标窗口里读不到剪贴板内容' };
    },
    async cleanup(client, ctx) {
      if (ctx.dlgHwnd) await pressKeys(client, ctx.dlgHwnd, ['ESC']).catch(() => {});
      ctx.dlgHwnd = null;
    },
  },
  {
    // 新增能力：几何操作 + 结果校验（移动窗口后确认真的移动了）
    id: 'win-move',
    name: '窗口移动：移动后确认新坐标',
    async setup(client) {
      const w = await ensureApp(client, { exe: 'calc.exe', titleRe: '计算器|Calculator', classNameRe: 'ApplicationFrameWindow|WinUIDesktopWin32WindowClass' });
      if (!w) return null;
      return { hwnd: w.nativeWindowHandle, box: w.boundingBox };
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      const b = ctx.box ?? { x: 100, y: 100 };
      ctx.expected = { x: b.x + 60, y: b.y + 40 };
      await client.tool('move_window', { nativeWindowHandle: ctx.hwnd, x: ctx.expected.x, y: ctx.expected.y });
      return { ok: true, ms: Date.now() - t0, note: '移动指令发出后未校验' };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      const before = ctx.box ?? {};
      const target = { x: (before.x ?? 100) + 90, y: (before.y ?? 100) + 60 };
      ctx.expected = target;
      await client.tool('move_window', { nativeWindowHandle: ctx.hwnd, x: target.x, y: target.y });
      // 校验：重新枚举窗口（绕过缓存）确认位置确实变了，且接近目标
      const deadline = Date.now() + 4000;
      let after = null;
      while (Date.now() < deadline) {
        await sleep(300);
        const w = (await findWindows(client, { useCache: false })).find((x) => x.nativeWindowHandle === ctx.hwnd);
        if (w?.boundingBox) {
          after = w.boundingBox;
          const dx = Math.abs(after.x - target.x);
          const dy = Math.abs(after.y - target.y);
          if (dx <= 12 && dy <= 12) return { ok: true, ms: Date.now() - t0, note: `位置确认 (${after.x},${after.y}) ≈ 目标 (${target.x},${target.y})` };
        }
      }
      return { ok: false, ms: Date.now() - t0, note: after ? `位置不符：实际 (${after.x},${after.y})` : '移动后读不到窗口位置' };
    },
    // 外部判定：窗口位置是否真的到了期望值（两个通道用同一把尺子）
    async verify(client, ctx) {
      if (!ctx.expected) return { ok: false, note: '通道未记录期望位置' };
      const w = (await findWindows(client, { useCache: false })).find((x) => x.nativeWindowHandle === ctx.hwnd);
      if (!w?.boundingBox) return { ok: false, note: '读不到窗口位置' };
      const dx = Math.abs(w.boundingBox.x - ctx.expected.x);
      const dy = Math.abs(w.boundingBox.y - ctx.expected.y);
      return { ok: dx <= 12 && dy <= 12, note: `实际(${w.boundingBox.x},${w.boundingBox.y}) vs 期望(${ctx.expected.x},${ctx.expected.y})` };
    },
  },
  {
    // 新增能力：滚动 + 内容变化校验（"界面变了没有"这类最容易被自报成功蒙过去）
    id: 'notepad-scroll',
    name: '滚动：滚动后确认可见内容发生变化',
    async setup(client) {
      const w = await ensureApp(client, { exe: 'notepad.exe', titleRe: 'Notepad|记事本', classNameRe: 'Notepad' });
      if (!w) return null;
      const hwnd = w.nativeWindowHandle;
      await activate(client, hwnd);
      await pressKeys(client, hwnd, ['ctrl', 'a']);
      await pressKeys(client, hwnd, ['DELETE']);
      const lines = Array.from({ length: 60 }, (_, i) => `行 ${String(i + 1).padStart(2, '0')} ${'·'.repeat(6)} SCROLLTEST`);
      const res = await setValueVerified(client, hwnd, '文本编辑器', lines.join('\r\n'), { controlType: 'Edit', timeoutMs: 6000 });
      if (!res.ok) await typeText(client, hwnd, lines.slice(0, 12).join('\r\n'));
      // 关键：程序写入后光标停在文末、视图也在文末 —— 不把视图拉回开头的话，
      // "行 01" 本来就不在可见区，判定条件会被白送（实测 A 通道 1ms 就"通过"了）。
      await pressKeys(client, hwnd, ['ctrl', 'HOME']);
      await sleep(400);
      const before = await readText(client, hwnd);
      const beforeText = before.words.map((x) => x.text).join('');
      const norm = (s) => String(s).replace(/\s+/g, '');
      const precondition = norm(beforeText).includes(norm('行 01'));
      return { hwnd, firstLine: '行 01', beforeText, precondition };
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      await client.tool('scroll', { nativeWindowHandle: ctx.hwnd, direction: 'down', amount: 5, activate: true });
      return { ok: true, ms: Date.now() - t0, note: '滚动指令发出后未校验' };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      await activateIfNeeded(client, ctx.hwnd);
      const base = await client.tool('scroll', { nativeWindowHandle: ctx.hwnd, direction: 'down', amount: 5 }).catch(() => null);
      if (base?.isError) {
        // 有些控件不吃 scroll：退化成键盘（Ctrl+End 跳到文末也算"内容变了"）
        await pressKeys(client, ctx.hwnd, ['ctrl', 'END']);
      }
      // 校验：窗口内首行文字应当不再可见（内容确实滚走了）
      const deadline = Date.now() + 4000;
      let nowText = '';
      while (Date.now() < deadline) {
        const r = await readText(client, ctx.hwnd);
        nowText = r.words.map((x) => x.text).join('');
        if (!nowText.includes(ctx.firstLine)) {
          return { ok: true, ms: Date.now() - t0, note: '首行已滚出可见区（内容确实变了）' };
        }
        await sleep(400);
      }
      return { ok: false, ms: Date.now() - t0, note: `首行仍可见（${nowText.length} 字）` };
    },
    // 外部判定：首行必须已经滚出可见区（前置条件不成立时判无效，不许白送）
    async verify(client, ctx) {
      if (!ctx.precondition) return { ok: false, note: '前置条件不成立（首行本就不在可见区），本次结果无效' };
      const r = await readText(client, ctx.hwnd);
      const t = r.words.map((x) => x.text).join('');
      const norm = (s) => String(s).replace(/\s+/g, '');
      const still = norm(t).includes(norm(ctx.firstLine));
      return { ok: !still, note: still ? '首行仍在可见区（滚动未生效）' : '首行已滚出可见区' };
    },
  },
  {
    // 新增能力：左树（TreeItem）展开。
    // 为什么需要它：导航树里的「展开」是元素动作，不是像素动作 —— 单点坐标点下去
    // 往往只是"选中/导航"，树根本没展开。所以判定必须是"子项真的多出来了"。
    id: 'tree-expand',
    name: '资源管理器左树：展开节点并确认子项出现',
    async setup(client) {
      // 两条实测教训：
      // 1) explorer.exe 作为外壳进程一直在跑，光启动它不会新开窗口 —— 必须带上要打开的目录；
      // 2) 插件的 launch_app **只接受完整可执行路径且不接受参数**（传 "explorer.exe D:\\" 会返回
      //    LAUNCH_NOT_FOUND）。所以这里用 Node 自己拉起窗口，再回到元素通道操作。
      const { execFile } = await import('node:child_process');
      let w = await windowBy(client, { className: 'CabinetWClass' });
      if (!w) {
        execFile('explorer.exe', ['D:\\'], { windowsHide: true }, () => {});
        const deadline = Date.now() + 15000;
        while (!w && Date.now() < deadline) {
          await sleep(800);
          w = await windowBy(client, { className: 'CabinetWClass' });
        }
      }
      if (!w) return null;
      const hwnd = w.nativeWindowHandle;
      await activate(client, hwnd);   // 实测：窗口不在前台时 UIA 树会变窄，树节点会枚举不到
      await sleep(900);
      const base = await treeSnapshot(client, hwnd);
      if (base.toolError) {
        // 区分"调用失败"与"确实没有 TreeItem"：调用失败时不能自称"只枚举到 0 个节点"。
        return { hwnd, title: w.name, precondition: false, reason: `树读取调用失败（参数或后端错误）：${base.toolError}` };
      }
      if (base.truncated) {
        return { hwnd, title: w.name, precondition: false, reason: `基线树快照被截断（扫到 ${base.nodeCount} 个节点）${base.error ? '：' + base.error : ''}，无法证明"子项新增"` };
      }
      const items = base.items.filter((x) => x.name);
      if (items.length < 3) {
        return { hwnd, title: w.name, precondition: false, reason: `导航树里只枚举到 ${items.length} 个 TreeItem（控件类型限定为 TreeItem；该窗口全树共 ${base.nodeCount} 个节点）` };
      }
      // 结构化判断"谁当前是折叠的"：children 为空才是折叠 —— 已展开的节点再 expand 不会产生新子项，
      // 选它会让两个通道都白跑，必须先排除。
      const CANDS = ['此电脑', 'This PC', '网络', 'Network', 'OneDrive', '主文件夹', 'Home', '图库', 'Gallery'];
      const folded = items.filter((x) => !x.childNames.length);
      const withPattern = folded.filter((x) => x.patterns.includes('ExpandCollapse'));
      // patterns 拿不到时（provider 不支持缓存该模式）退一步：只从"一定有子节点"的名字里挑
      const pool = withPattern.length ? withPattern : folded.filter((x) => CANDS.includes(x.name));
      const target = CANDS.map((n) => pool.find((x) => x.name === n)).find(Boolean) ?? pool[0];
      if (!target) {
        return { hwnd, title: w.name, precondition: false, reason: `导航树里没有"当前处于折叠且可展开"的节点（共 ${items.length} 个 TreeItem，已展开 ${items.length - folded.length} 个）` };
      }
      return {
        hwnd, title: w.name,
        precondition: true,
        // 目标规格冻结：通道不许改写它；verify 只认这里定下的目标名与基线
        target: Object.freeze({ name: target.name, depth: target.depth, id: target.id }),
        patternKnown: withPattern.length > 0,
        baseNames: items.map((x) => x.name),
        baseCount: items.length,
      };
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      if (!ctx.precondition) return { ok: false, ms: Date.now() - t0, note: `前置条件不成立：${ctx.reason}` };
      await activate(client, ctx.hwnd);
      // 老做法：**只按名字找**（不限定控件类型），拿第一个带坐标的命中就点它的中心，点完不看结果。
      // 这正是本项目踩过的坑：同名字段在地址栏/内容区都可能有，命中未必是树节点。
      const r = await client.tool('find', { query: ctx.target.name, nativeWindowHandle: ctx.hwnd, maxResults: 6, ocrFallback: true });
      const hits = r.data?.results ?? [];
      const hit = hits.find((h) => h.boundingBox?.centerX !== undefined) ?? hits.find((h) => h.x !== undefined);
      if (!hit) return { ok: false, ms: Date.now() - t0, note: `找不到「${ctx.target.name}」` };
      const x = Math.round(hit.boundingBox?.centerX ?? hit.x);
      const y = Math.round(hit.boundingBox?.centerY ?? hit.y);
      await client.tool('click', { x, y, nativeWindowHandle: ctx.hwnd, activate: true });
      await sleep(700);
      return { ok: true, ms: Date.now() - t0, note: `按名字命中 ${hits.length} 个（控件类型未限定），点(${x},${y})后未校验` };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      if (!ctx.precondition) return { ok: false, ms: Date.now() - t0, note: `前置条件不成立：${ctx.reason}` };
      await activateIfNeeded(client, ctx.hwnd);
      await activate(client, ctx.hwnd);
      // 元素优先 + **限定控件类型**：按名字只查 TreeItem，避开地址栏/内容区里的同名文字
      const el = await locate(client, ctx.hwnd, ctx.target.name, {
        controlType: 'TreeItem', exact: true, retries: 3, intervalMs: 300,
        maxDepth: 12, maxNodes: 3000, treeTimeoutMs: 6000, ocrFallback: false,
      });
      let how = null;
      if (el?.id) {
        const r = await client.tool('invoke', { elementId: el.id, nativeWindowHandle: ctx.hwnd, action: 'expand', fallbackClick: false })
          .catch((e) => ({ isError: true, text: String(e) }));
        if (!r.isError) how = 'invoke:expand';
        else {
          // 退路：聚焦该节点 + 右方向键（标准树控件行为），仍然不点坐标
          await client.tool('focus', { elementId: el.id, nativeWindowHandle: ctx.hwnd }).catch(() => {});
          await pressKeys(client, ctx.hwnd, ['right']);
          how = `focus+右方向键（expand 报错：${String(r.text).slice(0, 40)}）`;
        }
      } else {
        // 最后退路：连元素 id 都拿不到，只能点该节点左侧的展开箭头（坐标兜底，成败交给外部判定）
        const item = (await treeSnapshot(client, ctx.hwnd)).items.find((x) => x.name === ctx.target.name);
        if (!item?.box) return { ok: false, ms: Date.now() - t0, note: `限定 TreeItem 后既无元素 id 也无包围盒：${ctx.target.name}` };
        const cy = item.box.centerY ?? (item.box.y + item.box.height / 2);
        await client.tool('click', { x: Math.round(item.box.x + 12), y: Math.round(cy), nativeWindowHandle: ctx.hwnd, activate: true });
        how = '坐标点展开箭头';
      }
      // 自校验：轮询树快照，等"该节点的 children"真的从空变非空（最终仍由外部 verify 复核）
      const deadline = Date.now() + 5000;
      for (;;) {
        const now = await treeSnapshot(client, ctx.hwnd);
        const res = expandedChildren(ctx, now.items);
        if (res.ok) {
          return { ok: true, ms: Date.now() - t0, note: `${how} 后「${ctx.target.name}」的 children 从 0 变成 ${res.count}（${res.fresh.slice(0, 3).join('、')}）` };
        }
        if (Date.now() > deadline) return { ok: false, ms: Date.now() - t0, note: `${how} 后 5s 内「${ctx.target.name}」的 children 仍未出现新项（${res.reason}）` };
        await sleep(500);
      }
    },
    // 外部判定：不看通道怎么说，重新取一次树快照，看目标 TreeItem 的 children 是否真的从空变非空
    async verify(client, ctx) {
      if (!ctx?.precondition) return { ok: false, note: `前置条件不成立（${ctx?.reason ?? '导航树不可用'}），本次结果无效` };
      if (!ctx.target?.name) return { ok: false, note: '未记录展开目标，本次结果无效' };
      const deadline = Date.now() + 5000;
      let last = '未观察到子项新增';
      for (;;) {
        const now = await treeSnapshot(client, ctx.hwnd);
        if (now.truncated) {
          last = `树快照被截断（扫到 ${now.nodeCount} 个节点）："没有新子项"不成立，判无效`;
        } else {
          const res = expandedChildren(ctx, now.items);
          const gone = (ctx.baseNames ?? []).filter((n) => !now.items.some((x) => x.name === n)).length;
          if (!res.node) {
            last = `树里已找不到「${ctx.target.name}」（窗口内容被改动），判无效`;
          } else if (gone > Math.max(3, Math.round((ctx.baseNames?.length ?? 0) * 0.6))) {
            last = `原有节点消失 ${gone}/${ctx.baseNames.length}，整棵树被重建，证据无法归因到"展开"，判无效`;
          } else if (res.ok) {
            return {
              ok: true,
              note: `展开「${ctx.target.name}」后该 TreeItem 的 children 确实从 0 变成 ${res.count}（${res.fresh.slice(0, 3).join('、')}），节点总数 ${ctx.baseCount}→${now.items.length}`,
            };
          } else {
            last = `「${ctx.target.name}」（深度 ${res.node.depth}）没有出现新子项：${res.reason}，节点总数 ${ctx.baseCount}→${now.items.length}`;
          }
        }
        if (Date.now() > deadline) break;
        await sleep(400);
      }
      return { ok: false, note: last };
    },
    // 收尾：把展开的节点折叠回去，避免污染后续轮次/通道的基线
    async cleanup(client, ctx) {
      if (!ctx?.precondition || !ctx.target?.name) return;
      const el = await locate(client, ctx.hwnd, ctx.target.name, {
        controlType: 'TreeItem', exact: true, retries: 1, intervalMs: 200,
        maxDepth: 12, maxNodes: 3000, treeTimeoutMs: 5000, ocrFallback: false,
      }).catch(() => null);
      if (el?.id) await client.tool('invoke', { elementId: el.id, nativeWindowHandle: ctx.hwnd, action: 'collapse', fallbackClick: false }).catch(() => {});
    },
  },
  {
    // 新增能力：真实指针拖拽（抓标题栏 → 位移 → 位置核对）。
    // 刻意**不用 move_window** —— 那条路径已经有 win-move 在测，这里测的是指针拖动的整条链路
    // （坐标 → 按下 → 分步移动 → 抬起），它走的是 SendInput 真输入，和 SetWindowPos 完全不同。
    id: 'drag-move',
    name: '拖拽：拖窗口标题栏到位移目标并确认新位置',
    async setup(client) {
      const w = await ensureApp(client, { exe: 'calc.exe', titleRe: '计算器|Calculator', classNameRe: 'ApplicationFrameWindow|WinUIDesktopWin32WindowClass' });
      if (!w) return null;
      const hwnd = w.nativeWindowHandle;
      await activate(client, hwnd);   // 真拖拽要目标在前台（drag 自己也会抢，但先摆正更稳）
      await sleep(400);
      let box = (await windowBox(client, hwnd)) ?? w.boundingBox;
      const screen = await screenBounds(client);
      const ctx = { hwnd, title: w.name, startBox: box, screen, processId: w.processId, precondition: true, reason: '' };
      if (!box || !(box.width > 0) || !(box.height > 0)) {
        ctx.precondition = false; ctx.reason = '读不到窗口矩形';
        return ctx;
      }
      if (screen && (box.width >= screen.width - 8 || box.height >= screen.height - 8)) {
        // 最大化窗口拖标题栏是"还原"，不是"移动"：判无效，而不是判失败
        ctx.precondition = false;
        ctx.reason = `窗口已最大化（${box.width}×${box.height} vs 屏幕 ${screen.width}×${screen.height}），标题栏拖拽会变成"还原"`;
        return ctx;
      }
      // 环境准备：先把窗口摆到"标题栏不被别的进程窗口遮住"的位置（move_window，不碰指针）。
      // 不做这一步的实测后果：drag 连续 3 轮全部 POINT_COVERED（贴着被 "Windows 安全中心" 盖住的点）。
      let placed = null;
      if (screen) {
        placed = await placeTitleBarExposed(client, hwnd, w.processId, { box, screen });
        if (placed.point) { box = placed.box; ctx.startBox = box; ctx.placeNote = `标题栏已摆到露出位置 (${placed.spot.x},${placed.spot.y})`; }
        else ctx.placeNote = `未能找到完全露出的标题栏位置（试过 ${placed.tried.length} 处：${placed.tried.slice(0, 4).join(' ')}…）`;
      }
      const sx0 = placed?.point?.x ?? box.x + box.width * 0.35;
      const sy0 = placed?.point?.y ?? box.y + 14;   // 标题栏内的安全高度：避开右侧的最小化/最大化/关闭
      let dx; let dy;
      if (screen) {
        // 朝屏幕中心方向位移：既不会撞屏幕边缘被钳制，也不会触发 Aero Snap（贴边吸半屏/最大化）
        const cx = screen.x + screen.width / 2;
        const cy = screen.y + screen.height / 2;
        dx = (Math.sign(cx - sx0) || 1) * Math.max(60, Math.min(120, Math.round(Math.abs(cx - sx0))));
        dy = (Math.sign(cy - sy0) || 1) * Math.max(40, Math.min(90, Math.round(Math.abs(cy - sy0))));
        // 位移后整窗仍要在屏内（留 8px 余量），否则收缩位移
        const loX = screen.x + 8 - box.x;
        const hiX = screen.x + screen.width - 8 - box.x - box.width;
        const loY = screen.y + 8 - box.y;
        const hiY = screen.y + screen.height - 8 - box.y - box.height;
        if (hiX < loX || hiY < loY) {
          ctx.precondition = false; ctx.reason = `窗口比屏幕还大（${box.width}×${box.height}），没有有效位移空间`;
          return ctx;
        }
        dx = Math.max(loX, Math.min(hiX, dx));
        dy = Math.max(loY, Math.min(hiY, dy));
        if (Math.abs(dx) < 40 || Math.abs(dy) < 30) {
          ctx.precondition = false; ctx.reason = `屏内可用位移太小（${dx},${dy}），做不出有意义的拖拽`;
          return ctx;
        }
      } else {
        dx = 100; dy = 70;   // 退化路径：取不到屏幕矩形时用固定位移
      }
      ctx.delta = { dx, dy };
      ctx.startPoint = { x: Math.round(sx0), y: Math.round(sy0) };
      ctx.endPoint = { x: Math.round(sx0 + dx), y: Math.round(sy0 + dy) };
      ctx.screenKnown = Boolean(screen);
      return ctx;
    },
    async naive(client, ctx) {
      const t0 = Date.now();
      if (!ctx.precondition) return { ok: false, ms: Date.now() - t0, note: `前置条件不成立：${ctx.reason}` };
      const b = ctx.startBox;
      const { dx, dy } = ctx.delta;
      // 老做法：按窗口比例估标题栏位置（顶部 2% 高度、横向 50%），一次拖到位，拖完不看窗口在哪
      const sx = Math.round(b.x + b.width * 0.5);
      const sy = Math.round(b.y + Math.max(6, b.height * 0.02));
      ctx.expected = { x: b.x + dx, y: b.y + dy };
      ctx.path = dragPath(sx, sy, sx + dx, sy + dy);
      const r = await client.tool('drag', { path: ctx.path, nativeWindowHandle: ctx.hwnd, activate: true })
        .catch((e) => ({ isError: true, text: String(e) }));
      await sleep(600);
      return {
        ok: !r.isError, ms: Date.now() - t0,
        note: r.isError ? `drag 报错：${String(r.text).slice(0, 60)}` : `按比例估标题栏(${sx},${sy})拖(${dx},${dy})，未校验`,
      };
    },
    async winctl(client, ctx) {
      const t0 = Date.now();
      if (!ctx.precondition) return { ok: false, ms: Date.now() - t0, note: `前置条件不成立：${ctx.reason}` };
      const { dx, dy } = ctx.delta;
      // 修复后：起点来自 setup 的**遮挡感知摆位 + 命中测试**，已经是"露出且属于目标进程"的点；
      // 若第一次仍被拒（环境在两次调用之间变了，比如弹出的通知盖住了起点），
      // 就重新摆位 + 换点重试（最多 2 次），而不是直接放弃或盲点。
      let attemptNote = '';
      for (let attempt = 1; attempt <= 3; attempt++) {
        await activateIfNeeded(client, ctx.hwnd);
        await activate(client, ctx.hwnd);
        const b = (await windowBox(client, ctx.hwnd)) ?? ctx.startBox;
        let start = ctx.startPoint;
        let hitNote = ctx.placeNote ?? '';
        // 每轮都重新命中测试：窗口可能被别人挪过 / 屏幕状态变了
        const hit = await hitTestOwnProcess(client, ctx.hwnd, ctx.processId, titleBarPoints(b));
        if (hit.point) {
          start = hit.point;
          hitNote = `命中 (${hit.point.x},${hit.point.y}) → ${hit.info?.controlType ?? '?'}「${String(hit.info?.name ?? '').slice(0, 12)}」`;
        } else if (attempt > 1 || !ctx.startPoint) {
          // 全被盖住：换一块空屏幕区域再试（move_window 不碰指针，安全）
          const pl = await placeTitleBarExposed(client, ctx.hwnd, ctx.processId, { box: b, screen: ctx.screen });
          if (pl.point) { start = pl.point; hitNote = `重新摆位到 (${pl.spot.x},${pl.spot.y}) 后命中 (${pl.point.x},${pl.point.y})`; }
          else { attemptNote = `3 次尝试内标题栏始终被别的窗口盖住（试过 ${pl.tried.length} 处）`; await sleep(400); continue; }
        } else {
          hitNote = `${hitNote}；候选点全被覆盖，用 setup 记录的起点 (${start.x},${start.y})`;
        }
        const startBox = (await windowBox(client, ctx.hwnd)) ?? b;
        ctx.startBox = { x: startBox.x, y: startBox.y, width: startBox.width, height: startBox.height };
        ctx.expected = { x: startBox.x + dx, y: startBox.y + dy };
        ctx.path = dragPath(start.x, start.y, start.x + dx, start.y + dy);
        const r = await client.tool('drag', { path: ctx.path, nativeWindowHandle: ctx.hwnd, activate: true })
          .catch((e) => ({ isError: true, text: String(e) }));
        if (r.isError) {
          const txt = String(r.text).replace(/\s+/g, ' ');
          attemptNote = `${hitNote}；第 ${attempt} 次 drag 被拒：${txt.slice(0, 90)}`;
          if (/POINT_COVERED/.test(txt)) { await sleep(500); continue; }   // 起点被盖 → 重新摆位重试
          return { ok: false, ms: Date.now() - t0, note: attemptNote };
        }
        // 自校验：等窗口位置真的到位，且尺寸没变（吸附/最大化会让尺寸变，那不是"移动"）
        const deadline = Date.now() + 4000;
        let last = null;
        for (;;) {
          const now = await windowBox(client, ctx.hwnd);
          if (now) {
            last = now;
            const sameSize = Math.abs(now.width - ctx.startBox.width) <= 2 && Math.abs(now.height - ctx.startBox.height) <= 2;
            const ddx = Math.abs(now.x - ctx.expected.x);
            const ddy = Math.abs(now.y - ctx.expected.y);
            if (sameSize && ddx <= DRAG_TOL && ddy <= DRAG_TOL) {
              return { ok: true, ms: Date.now() - t0, note: `${hitNote}；第 ${attempt} 次拖(${dx},${dy})后位置(${now.x},${now.y})到位，尺寸未变` };
            }
          }
          if (Date.now() > deadline) break;
          await sleep(350);
        }
        return {
          ok: false, ms: Date.now() - t0,
          note: last ? `${hitNote}；位置不符：实际(${last.x},${last.y}) vs 期望(${ctx.expected.x},${ctx.expected.y})` : '拖后读不到窗口位置',
        };
      }
      return { ok: false, ms: Date.now() - t0, note: attemptNote || '3 次尝试均失败' };
    },
    // 外部判定：窗口真的按拖拽位移到了期望位置，且是"纯移动"（尺寸不变、不是吸附/最大化）
    async verify(client, ctx) {
      if (!ctx?.precondition) return { ok: false, note: `前置条件不成立（${ctx?.reason ?? '窗口不可拖'}），本次结果无效` };
      if (!ctx.expected || !ctx.startBox || !ctx.delta) return { ok: false, note: '通道未记录期望位置/起始位置/位移，本次结果无效' };
      const deadline = Date.now() + 4000;
      let last = '未观察到位移';
      for (;;) {
        const b = await windowBox(client, ctx.hwnd);
        if (!b) {
          last = '读不到窗口位置';
        } else {
          const sameSize = Math.abs(b.width - ctx.startBox.width) <= 2 && Math.abs(b.height - ctx.startBox.height) <= 2;
          const ddx = Math.abs(b.x - ctx.expected.x);
          const ddy = Math.abs(b.y - ctx.expected.y);
          const total = Math.abs(ctx.delta.dx) + Math.abs(ctx.delta.dy);
          const moved = Math.abs(b.x - ctx.startBox.x) + Math.abs(b.y - ctx.startBox.y);
          if (!sameSize) {
            last = `尺寸被改变（${ctx.startBox.width}×${ctx.startBox.height} → ${b.width}×${b.height}）：不是"纯移动"（可能被吸附/最大化），判无效`;
          } else if (moved < Math.round(total * 0.6)) {
            last = `位移不足：起点(${ctx.startBox.x},${ctx.startBox.y}) → 实际(${b.x},${b.y})，只动了 ${moved}px，要求 ≈${total}px`;
          } else if (ddx <= DRAG_TOL && ddy <= DRAG_TOL) {
            return {
              ok: true,
              note: `标题栏拖拽后位置确实到位：实际(${b.x},${b.y}) ≈ 期望(${ctx.expected.x},${ctx.expected.y})，位移(${ctx.delta.dx},${ctx.delta.dy})，尺寸未变`,
            };
          } else {
            last = `实际(${b.x},${b.y}) vs 期望(${ctx.expected.x},${ctx.expected.y})，偏差(${ddx},${ddy}) > 容差 ${DRAG_TOL}`;
          }
        }
        if (Date.now() > deadline) break;
        await sleep(350);
      }
      return { ok: false, note: last };
    },
  },
];

/* ───────────────────────── 执行 ───────────────────────── */

const client = await connect();
const results = [];

/**
 * 环境前置检查（本轮新增的教训）：
 * 如果前台被一个**提权窗口**占住（例如本机 UAC 策略下 taskschd.msc 会静默提权），
 * 低完整性的插件既夺不回前台、也点不动它 —— 所有"真实输入"类任务会集体失败。
 * 那属于**环境故障**，不是操控能力不行，必须在报告里显式区分，否则会把环境噪声
 * 记成能力缺陷（本会话真实发生过：一个探针拉起的提权 MMC 让整条 drag 链路全灭）。
 */
async function preflight(client) {
  const notes = [];
  let probeWin = null;
  for (const t of ['Notepad', 'ApplicationFrameWindow']) {
    probeWin = (await findWindows(client, { useCache: false })).find((w) => String(w.className).includes(t) && w.boundingBox?.width > 100);
    if (probeWin) break;
  }
  if (!probeWin) { notes.push('未找到可用于前台检查的普通窗口'); return { ok: null, notes }; }
  await client.tool('activate_window', { nativeWindowHandle: probeWin.nativeWindowHandle }).catch(() => {});
  await sleep(700);
  const wins = await findWindows(client, { useCache: false });
  const fg = wins.find((w) => w.hasKeyboardFocus);
  const ok = Boolean(fg && fg.nativeWindowHandle === probeWin.nativeWindowHandle);
  if (!ok) {
    const blocker = fg ? `hwnd=${fg.nativeWindowHandle} pid=${fg.processId} "${String(fg.name ?? '').slice(0, 24)}"` : '未知';
    notes.push(`前台无法被接管：激活 "${probeWin.name}" 后前台仍是 ${blocker} —— 真实输入类任务（拖拽/坐标点击/按键）本轮不可度量`);
  }
  return { ok, probe: probeWin.name, foreground: fg ? { hwnd: fg.nativeWindowHandle, pid: fg.processId, name: fg.name } : null, notes };
}
const env = await preflight(client);
console.log(`环境前置检查：前台可接管 = ${env.ok === null ? '未知' : env.ok ? '✔ 是' : '✘ 否'}   ${env.notes.join(' / ')}`);

for (const task of TASKS) {
  if (ONLY && task.id !== ONLY) continue;
  const ctx = await task.setup(client);
  if (!ctx) {
    console.log(`跳过 ${task.id}：目标应用没在运行`);
    continue;
  }
  console.log(`\n▶ ${task.name}  (${ctx.title ?? ''})`);
  const row = { id: task.id, name: task.name, naive: [], winctl: [] };
  // **由基准统一裁决**：通道自报的 ok 只作为参考，最终成功与否看任务的 verify()。
  // 没有这一步，A 通道（不做任何校验的坐标流）会把"自报成功"混进成功率里 ——
  // 这正是记事本任务里 A 通道 100% 却是假阳性的原因。
  const judge = async (r, ctxRun) => {
    if (!task.verify) return { ...r, okSelf: r.ok, verified: '（该任务无外部判定）' };
    let v = null;
    try { v = await task.verify(client, ctxRun); } catch (e) { v = { ok: false, note: `verify 异常: ${String(e).slice(0, 40)}` }; }
    return { ...r, okSelf: r.ok, ok: Boolean(v?.ok), verified: v?.note ?? '' };
  };
  for (let i = 0; i < REPEAT; i++) {
    // 每次测量前把状态重置回同一初始点（重新跑一遍 setup）。
    // 不这么做，A 通道跑完的画面会留给 B 通道，上一轮的滚动也会残留 ——
    // 实测出现过 A 通道 1ms"通过"（其实是上一轮已经把内容滚走了），完全是假数据。
    const fresh = async () => (await task.setup(client)) ?? ctx;

    const ctxA = await fresh();
    const a = CHANNEL === 'winctl' ? { ok: true, ms: 0, note: '（本次跳过 A 通道）', skip: true } : await judge(await task.naive(client, ctxA), ctxA);
    if (task.cleanup) await task.cleanup(client, ctxA).catch(() => {});
    await ensureNoDialog(client).catch(() => {});
    row.naive.push(a);
    console.log(`   naive  #${i + 1}  ${a.skip ? '—' : a.ok ? '✔' : '✘'}${!a.skip && a.okSelf !== a.ok ? '（自报✔/实测✘）' : ''}  ${String(a.ms).padStart(5)}ms  ${a.note ?? ''}`);

    const ctxB = await fresh();
    const b = CHANNEL === 'naive' ? { ok: true, ms: 0, note: '（本次跳过 B 通道）', skip: true } : await judge(await task.winctl(client, ctxB), ctxB);
    if (task.cleanup) await task.cleanup(client, ctxB).catch(() => {});
    await ensureNoDialog(client).catch(() => {});
    row.winctl.push(b);
    console.log(`   winctl #${i + 1}  ${b.skip ? '—' : b.ok ? '✔' : '✘'}${!b.skip && b.okSelf !== b.ok ? '（自报✔/实测✘）' : ''}  ${String(b.ms).padStart(5)}ms  ${b.note ?? ''}`);
  }
  results.push(row);
}

const rate = (arr) => { const v = arr.filter((x) => !x.skip); return v.length ? v.filter((x) => x.ok).length / v.length : 0; };
const avg = (arr) => { const v = arr.filter((x) => !x.skip); return v.length ? Math.round(v.reduce((s, x) => s + x.ms, 0) / v.length) : 0; };

console.log('\n═══════════════ 汇总 ═══════════════');
console.log('任务'.padEnd(26) + 'A通道'.padEnd(12) + 'B通道'.padEnd(12) + 'A均值'.padEnd(10) + 'B均值');
let aAll = []; let bAll = [];
for (const r of results) {
  aAll = aAll.concat(r.naive); bAll = bAll.concat(r.winctl);
  console.log(
    r.name.padEnd(24)
    + `${(rate(r.naive) * 100).toFixed(0)}%`.padEnd(14)
    + `${(rate(r.winctl) * 100).toFixed(0)}%`.padEnd(14)
    + `${avg(r.naive)}ms`.padEnd(12)
    + `${avg(r.winctl)}ms`,
  );
}
console.log('─'.repeat(80));
console.log(
  '总体'.padEnd(25)
  + `${(rate(aAll) * 100).toFixed(0)}%`.padEnd(14)
  + `${(rate(bAll) * 100).toFixed(0)}%`.padEnd(14)
  + `${avg(aAll)}ms`.padEnd(12)
  + `${avg(bAll)}ms`,
);

fs.mkdirSync('D:\\dsh-tools\\winctl\\reports', { recursive: true });
const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '');
const runId = `bench-${stamp}`;
const src = (p) => { const s = fs.statSync(p); return { file: path.basename(p), bytes: s.size, mtime: new Date(s.mtimeMs).toISOString() }; };
const out = path.join('D:\\dsh-tools\\winctl\\reports', `${runId}.json`);
fs.writeFileSync(out, JSON.stringify({
  runId, label: LABEL || null, channel: CHANNEL, repeat: REPEAT,
  startedAt: STARTED_AT, finishedAt: new Date().toISOString(),
  environment: env,
  sourceRevisions: {
    bench: src('D:\\dsh-tools\\winctl\\bench.mjs'),
    actions: src('D:\\dsh-tools\\winctl\\index.mjs'),
    transport: src('D:\\dsh-tools\\winctl\\mcp.mjs'),
  },
  results,
  summary: { naive: { rate: rate(aAll), avgMs: avg(aAll) }, winctl: { rate: rate(bAll), avgMs: avg(bAll) } },
}, null, 2), 'utf8');
console.log(`\n明细: ${out}`);
console.log(`run id: ${runId}${LABEL ? `  标签: ${LABEL}` : ''}  通道: ${CHANNEL}  repeat: ${REPEAT}`);
console.log(`分通道成功率（外部 verify 裁决）：winctl ${(rate(bAll) * 100).toFixed(1)}% (n=${bAll.filter((x) => !x.skip).length})  |  naive ${(rate(aAll) * 100).toFixed(1)}% (n=${aAll.filter((x) => !x.skip).length})`);

await client.close();
process.exit(0);
