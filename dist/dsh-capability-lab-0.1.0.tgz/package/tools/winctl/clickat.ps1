# clickat.ps1 · 在指定屏幕点发一次真实鼠标点击（SendInput 路径）
# 用途：把前台从"提权窗口"（UIPI 挡住插件接管前台）拉回到普通窗口。
# 注：向**非提权**窗口注入输入是允许的；这正是解开前台锁的办法。
param([Parameter(Mandatory = $true)][int]$X, [Parameter(Mandatory = $true)][int]$Y)

$src = @'
using System;
using System.Runtime.InteropServices;
public class WcuClick {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, System.Text.StringBuilder s, int n);
  public static string Fg() { var sb = new System.Text.StringBuilder(256); GetWindowText(GetForegroundWindow(), sb, 256); return sb.ToString(); }
  public static void Click(int x, int y) {
    SetCursorPos(x, y); System.Threading.Thread.Sleep(120);
    mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero); System.Threading.Thread.Sleep(60);
    mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
  }
}
'@
Add-Type -TypeDefinition $src -Language CSharp
"点击前前台: " + [WcuClick]::Fg()
[WcuClick]::Click($X, $Y)
Start-Sleep -Milliseconds 700
"点击后前台: " + [WcuClick]::Fg()
