import { connect, findWindows, windowBy } from './mcp.mjs';

const client = await connect();
const wins = await findWindows(client);
console.log(`窗口数: ${wins.length}`);
for (const w of wins) {
  if (!w.name) continue;
  console.log(`  name="${w.name}"  class=${w.className}  pid=${w.processId}  hwnd=${w.nativeWindowHandle}  focus=${w.hasKeyboardFocus}`);
}
const re = new RegExp('Notepad|记事本', 'i');
console.log('\n正则测试:');
for (const w of wins) {
  if (!w.name) continue;
  console.log(`  ${JSON.stringify(w.name)} -> ${re.test(w.name)}`);
}
const byTitle = await windowBy(client, { title: 'Notepad|记事本' });
console.log('\nwindowBy(Notepad|记事本) =>', byTitle ? byTitle.name : 'null');
const byCalc = await windowBy(client, { title: '计算器|Calculator' });
console.log('windowBy(计算器|Calculator) =>', byCalc ? byCalc.name : 'null');
await client.close();
process.exit(0);
