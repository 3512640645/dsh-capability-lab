#!/usr/bin/env node
/** 诊断：把计算器的元素名和记事本的 OCR 结果原样打出来。 */
import { connect, findWindows, readText } from './mcp.mjs';

const client = await connect();
const wins = await findWindows(client);
const calc = wins.find((w) => /计算器|Calculator/.test(w.name ?? ''));
const note = wins.find((w) => /Notepad|记事本/.test(w.name ?? ''));

if (calc) {
  console.log(`\n=== 计算器 hwnd=${calc.nativeWindowHandle} class=${calc.className} ===`);
  const t = await client.tool('accessibility_tree', { nativeWindowHandle: calc.nativeWindowHandle, maxDepth: 8, maxNodes: 60 });
  if (t.isError) console.log('  accessibility_tree 不可用:', t.text.slice(0, 200));
  else {
    const nodes = t.data?.nodes ?? t.data?.tree ?? [];
    const flat = JSON.stringify(t.data ?? {});
    // 直接打印节点名，便于看真实命名
    const names = (t.data?.nodes ?? []).map((n) => `${n.controlType ?? '?'}:${n.name ?? ''}`).filter((s) => s.length > 2);
    console.log(`  节点数 ${names.length}`);
    for (const n of names.slice(0, 40)) console.log('   ', n);
    if (!names.length) console.log('  原始:', flat.slice(0, 700));
  }
  for (const q of ['7', '七', '八', '乘', '×', '等于']) {
    const r = await client.tool('find', { query: q, nativeWindowHandle: calc.nativeWindowHandle, maxResults: 3, ocrFallback: false });
    const hits = r.data?.results ?? [];
    console.log(`  find("${q}") -> ${hits.length} 个  ${hits.map((h) => h.name).join(' | ')}`);
  }
}

if (note) {
  console.log(`\n=== 记事本 hwnd=${note.nativeWindowHandle} class=${note.className} ===`);
  const { words } = await readText(client, note.nativeWindowHandle);
  console.log(`  OCR 词数 ${words.length}`);
  console.log('  ' + words.map((w) => `${w.text}(${w.x},${w.y})`).join(' ').slice(0, 800));
  const r = await client.tool('find', { query: '自检', nativeWindowHandle: note.nativeWindowHandle, maxResults: 5, ocrFallback: true });
  console.log(`  find("自检") -> ${(r.data?.results ?? []).map((h) => `${h.source}:${h.name}`).join(' | ') || '无'}`);
  const doc = await client.tool('find', { query: '文本编辑器', nativeWindowHandle: note.nativeWindowHandle, maxResults: 5, ocrFallback: false });
  console.log(`  find("文本编辑器") -> ${(doc.data?.results ?? []).map((h) => `${h.name}#${h.id}`).join(' | ') || '无'}`);
}

await client.close();
process.exit(0);
