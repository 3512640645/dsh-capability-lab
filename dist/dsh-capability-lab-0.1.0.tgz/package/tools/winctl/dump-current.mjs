/** dump-current · 逐条列出"现行实现段"的 winctl run（含无效/无外部判定标记） */
import fs from 'node:fs';
import path from 'node:path';

const DIR = 'D:\\dsh-tools\\winctl\\reports';
const floorArg = process.argv[2] === '--all' ? 0 : fs.statSync('D:\\dsh-tools\\winctl\\bench.mjs').mtimeMs;
const UND = /前置条件不成立|本次结果无效|无法判定/;
let n = 0; let ok = 0;
for (const f of fs.readdirSync(DIR).filter((x) => /^bench-.*\.json$/.test(x)).sort()) {
  const st = fs.statSync(path.join(DIR, f));
  if (st.mtimeMs < floorArg) continue;
  const j = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
  if (!j.results) continue;
  console.log(`== ${f}  mtime=${st.mtime.toISOString()}`);
  for (const r of j.results) (r.winctl ?? []).forEach((e, i) => {
    if (e.skip) return;
    const und = UND.test(e.verified ?? '');
    const nov = /该任务无外部判定/.test(e.verified ?? '');
    if (!und) { n++; if (e.ok) ok++; }
    console.log(`   ${String(r.id).padEnd(20)}#${i + 1} ok=${e.ok} self=${e.okSelf} ${String(e.ms).padStart(6)}ms ${und ? '[剔无效]' : ''}${nov ? '[无外部判定]' : ''} | ${String(e.note ?? '').slice(0, 85)} || ${String(e.verified ?? '').slice(0, 70)}`);
  });
}
console.log(`\n入分母 n=${n} ok=${ok} = ${n ? ((ok / n) * 100).toFixed(1) : '-'}%`);
