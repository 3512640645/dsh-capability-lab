# fg-rescue.ps1 - move the foreground away from an elevated window, then RESTORE the original setting.
# Pure ASCII on purpose: Windows PowerShell 5.1 reads .ps1 as ANSI when there is no BOM, so any
# non-ASCII byte here can break the parser. Why this exists:
#   The session runs at Medium IL. The elevated mmc.exe (Task Scheduler) that a probe started
#   grabbed the foreground; while an elevated window owns the foreground, both the foreground
#   lock and UIPI block SetForegroundWindow from the plugin, so every real-input action
#   (drag / coordinate click / keypress) becomes unrunnable. This script temporarily sets the
#   foreground lock timeout to 0, hands the foreground to a normal window, then restores the
#   original timeout so the benchmark still runs under the original configuration.
param([int]$TargetHwnd = 0)
$src = @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public class FgRescue {
  [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint a, uint b, ref uint p, uint f);
  [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint a, uint b, IntPtr p, uint f);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  public static uint GetTimeout() { uint v = 0; SystemParametersInfo(0x2000, 0, ref v, 0); return v; }
  public static void SetTimeout(uint v) { SystemParametersInfo(0x2001, 0, (IntPtr)(long)v, 2); }
  public static string Fg() { var sb = new StringBuilder(256); var h = GetForegroundWindow(); GetWindowText(h, sb, 256); return h + ":" + sb.ToString(); }
  public static uint PidOf(IntPtr h) { uint p; GetWindowThreadProcessId(h, out p); return p; }
  public static bool Force(IntPtr h) {
    uint dummy = 0;
    uint fgThread = GetWindowThreadProcessId(GetForegroundWindow(), out dummy);
    uint me = GetCurrentThreadId();
    bool att = AttachThreadInput(me, fgThread, true);
    try { ShowWindow(h, 9); return SetForegroundWindow(h); } finally { if (att) AttachThreadInput(me, fgThread, false); }
  }
}
'@
Add-Type -TypeDefinition $src -Language CSharp

$orig = [FgRescue]::GetTimeout()
Write-Output ("original ForegroundLockTimeout = " + $orig + " ms")
Write-Output ("foreground before: " + [FgRescue]::Fg())
[FgRescue]::SetTimeout(0)
Start-Sleep -Milliseconds 300
Write-Output ("temporarily set to = " + [FgRescue]::GetTimeout() + " ms")
$ok = [FgRescue]::Force([IntPtr]$TargetHwnd)
Start-Sleep -Milliseconds 800
$now = [FgRescue]::GetForegroundWindow()
Write-Output ("Force(" + $TargetHwnd + ") = " + $ok + "  foreground now: " + [FgRescue]::Fg() + " (pid=" + [FgRescue]::PidOf($now) + ")")
[FgRescue]::SetTimeout($orig)
Start-Sleep -Milliseconds 200
Write-Output ("restored ForegroundLockTimeout = " + [FgRescue]::GetTimeout() + " ms")
Write-Output ("foreground after restore: " + [FgRescue]::Fg())
