/**
 * winctl · 动作层
 *
 * 设计原则（每一条都来自一次真实翻车）：
 *  1. 元素优先：能用 UIA 元素就用元素（invoke/click/click elementId），
 *     元素动作不依赖像素，也不受窗口遮挡影响。
 *  2. 坐标兜底：元素拿不到时用 OCR 找到文字坐标再点（自绘/Flutter 应用只能这样）。
 *  3. 真实点击必须先激活：物理点击落在最上层窗口，不激活就可能点到别的窗口上。
 *  4. 双击要快：间隔必须远小于系统双击阈值，否则被当成两次单击。
 *  5. 动作后校验：每个动作都要有一条可观测证据（元素出现/文字出现/值变化），
 *     校验不过就重试——"发出去了"不等于"生效了"。
 */
import { readText, windowBy, findWindowsCached } from './mcp.mjs';

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 系统双击阈值（ms），用于决定模拟双击的间隔。 */
export async function doubleClickGap() {
  return 70; // HKCU\Control Panel\Mouse\DoubleClickSpeed 默认 500ms；70ms 足够安全
}

/* ───────────────────────── 定位 ───────────────────────── */

/** 在窗口里找元素：先 UIA，无果再 OCR，返回统一结构 {kind,id,x,y,name,box}。 */
export async function locate(client, hwnd, query, { retries = 8, intervalMs = 400, ocrFallback = true, exact = false,
  // 扫描范围限制：find 默认 treeTimeoutMs=5000 且尽量扫全树，这是"单次调用 0.3~0.9s"的主因。
  // 对话框/工具条这类目标层级很浅，收紧这几项能显著提速（见 README 性能特征）。
  maxDepth = 6, maxNodes = 600, treeTimeoutMs = 2000, controlType = undefined, activate = false } = {}) {
  const nameEq = (h) => String(h.name ?? '').trim() === query.trim();
  // 顺序很关键：**先限定"可点击的元素（有 id）"，再在里面挑精确匹配**。
  // 反过来（先全局挑精确匹配）会选中没有 id 的纯文本节点，点击直接失败 ——
  // 这个顺序错误当场被基准测出来：计算器「等于」从 100% 掉到 0%。
  const pick = (results) => {
    const withId = results.filter((h) => h.id);
    const exactClickable = withId.find(nameEq);
    if (exactClickable) return exactClickable;
    if (!exact && withId.length) return withId[0];
    const exactAny = results.find(nameEq);
    if (exactAny && exactAny.x !== undefined && exactAny.y !== undefined) return exactAny;   // OCR 命中
    if (exact) return null;
    return results.find((h) => h.x !== undefined && h.y !== undefined) ?? null;
  };
  for (let attempt = 0; attempt < retries; attempt++) {
    const r = await client.tool('find', {
      query, nativeWindowHandle: hwnd, maxResults: 12, ocrFallback,
      maxDepth, maxNodes, treeTimeoutMs, activate,
      ...(controlType ? { controlType } : {}),
    });
    const results = r.data?.results ?? [];
    const hit = pick(results);
    if (hit) {
      const base = { name: hit.name, attempt, exact: nameEq(hit) };
      if (hit.id) return { kind: 'element', id: hit.id, x: hit.boundingBox?.centerX, y: hit.boundingBox?.centerY, box: hit.boundingBox, ...base };
      return { kind: 'ocr', x: hit.x, y: hit.y, box: hit.boundingBox, ...base };
    }
    await sleep(intervalMs);
  }
  return null;
}

/**
 * 把值写进一个输入框：**定位（限定 controlType）→ set_value → 服务端校验**。
 *
 * 相比老写法（locate 重试 + invoke + typeText + 本地轮询校验）：
 *   - `controlType:'Edit'` 是关键：查「文件名」会命中旁边的**标签**（改它报"值为只读"），
 *     真正的输入框名字其实是「文件名:」；用控件类型限定才能一步命中；
 *   - `set_value` 走 ValuePattern/EM_REPLACESEL，不用先聚焦再敲键盘（311ms vs 1123ms）；
 *   - 校验用服务端 `wait_for(text)`（770ms vs 本地轮询 2646ms）——前提是目标窗口已激活，
 *     因为它默认作用域是 active_window。
 */
export async function setValueVerified(client, hwnd, query, value, { timeoutMs = 6000, controlType = 'Edit', activate = true, exact = false } = {}) {
  // 逐级放宽：先窄后宽（窄的扫得快，宽的兜得住）。
  // 实测发现"窗口不在前台时 UIA 树会变窄"，所以第一级失败不一定是控件不存在，
  // 而是扫描范围/前台状态所致 —— 必须能自动放宽，否则会误判成"找不到控件"。
  const plans = [
    { controlType, maxDepth: 5, maxNodes: 400, treeTimeoutMs: 1500, ocrFallback: false, retries: 3, label: '收紧+控件类型' },
    { controlType, maxDepth: 8, maxNodes: 1200, treeTimeoutMs: 5000, ocrFallback: false, retries: 2, label: '默认范围+控件类型' },
    { controlType: undefined, maxDepth: 8, maxNodes: 1200, treeTimeoutMs: 5000, ocrFallback: true, retries: 2, label: '默认范围+名称' },
  ];
  let el = null;
  let usedPlan = null;
  for (const p of plans) {
    el = await locate(client, hwnd, query, { ...p, intervalMs: 250, exact, activate });
    if (el?.id) { usedPlan = p.label; break; }
  }
  if (!el || !el.id) return { ok: false, note: `找不到可写入的「${query}」（三种扫描策略都试过）` };

  const r = await client.tool('set_value', {
    elementId: el.id, nativeWindowHandle: hwnd, value, activate, fallbackType: true,
  }).catch((e) => ({ isError: true, text: String(e) }));

  // 服务端条件校验（一次调用），失败再退回本地多通道
  let via = 'wait_for:text';
  const need = String(value).replace(/\s/g, '').slice(0, 12);
  const wf = await client.tool('wait_for', {
    condition: 'text', query: need, nativeWindowHandle: hwnd, scope: 'desktop', timeoutMs: Math.min(timeoutMs, 3000), intervalMs: 200,
  }).catch(() => null);
  if (!(wf && !wf.isError && (wf.data?.found === true || wf.data?.verification === 'observed'))) {
    const got = await waitForAnyTextFast(client, hwnd, need, { timeoutMs: 2500 });
    via = got?.via ?? null;
    if (!got) return { ok: false, note: `set_value ${r.isError ? '报错：' + String(r.text).slice(0, 80) : '已发送但校验未通过'}（定位策略：${usedPlan}）`, raw: r };
  }
  return { ok: true, via, plan: usedPlan, element: el, raw: r.isError ? r.text : 'ok' };
}

/** 等元素出现（返回元素或 null）。 */
export async function waitFor(client, hwnd, query, { timeoutMs = 8000, intervalMs = 400 } = {}) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const hit = await locate(client, hwnd, query, { retries: 1, intervalMs: 0 });
    if (hit) return hit;
    if (Date.now() > deadline) return null;
    await sleep(intervalMs);
  }
}

/**
 * 校验某段文字是否已出现在窗口里。
 *
 * **通道优先级：UIA 文本 > OCR > 窗口标题**。
 * 这是基准测试抓到的第二个真 bug：记事本正文的中文 OCR 会认错
 * （"探针" 被识别成 "深钅十"），但 UIA 里的文本元素是精确的。
 * 只依赖 OCR 会让"明明写进去了"被判成失败。
 */
export async function waitForAnyText(client, hwnd, needle, { timeoutMs = 8000, intervalMs = 350, allowOcr = true } = {}) {
  const want = String(needle).replace(/\s/g, '');
  const deadline = Date.now() + timeoutMs;
  let round = 0;

  for (;;) {
    round += 1;
    // 1) UIA：精确且快（原生控件通常立刻命中）
    try {
      const r = await client.tool('find', { query: needle, nativeWindowHandle: hwnd, maxResults: 8, ocrFallback: false });
      const hit = (r.data?.results ?? []).find((h) => String(h.name ?? '').replace(/\s/g, '').includes(want));
      if (hit) return { via: 'uia', text: hit.name, box: hit.boundingBox };
    } catch { /* 降级 */ }

    // 2) OCR：始终保留这条通道（Edit 控件的"值"不在 UIA Name 里，只靠 UIA 会漏判），
    //    只在后面轮次节流，避免每轮都付 OCR 成本。
    if (allowOcr && (round <= 2 || round % 2 === 1)) {
      try {
        const { words } = await readText(client, hwnd);
        const joined = words.map((w) => w.text).join('').replace(/\s/g, '');
        if (joined.includes(want)) return { via: 'ocr', text: needle };
      } catch { /* 降级 */ }
    }

    // 3) 窗口标题（走缓存，不再每次付枚举窗口的 1.3s）
    try {
      const wins = await findWindowsCached(client);
      const w = wins.find((x) => x.nativeWindowHandle === hwnd);
      if (w && String(w.name ?? '').replace(/\s/g, '').includes(want)) return { via: 'title', text: w.name };
    } catch { /* 继续 */ }

    if (Date.now() > deadline) return null;
    await sleep(intervalMs);
  }
}

/** 兼容旧名：现在走多通道校验。 */
export const waitForText = waitForAnyText;

/**
 * 快速校验：**并发**跑两条服务端等待条件，谁先命中用谁。
 *
 * 计时实测（对话框任务）：串行写法里 element 条件要为"输入进 Edit 的值不在 UIA Name 里"
 * 白等满 5s 超时，然后 text 条件才命中 —— 单这一项就吃掉 4.7s。
 * 并发之后总耗时 ≈ min(两条件)，而不是 sum。
 */
export async function waitForAnyTextFast(client, hwnd, needle, { timeoutMs = 6000, prefer = 'auto', debug = process.env.WINCTL_DEBUG === '1' } = {}) {
  const want = String(needle).replace(/\s/g, '');

  // 关键认知：MCP 传输是**串行**的——一个 wait_for 会独占连接直到它返回。
  // 所以绝不能"并发"发多个等待条件（那只是把它们排队，长的会拖死短的）。
  // 正确做法：先做一次零等待的本地检查，再按优先级**串行**用一个条件等。

  const localCheck = async (allowOcr) => {
    try {
      const r = await client.tool('find', { query: needle, nativeWindowHandle: hwnd, maxResults: 8, ocrFallback: false });
      if ((r.data?.results ?? []).some((h) => String(h.name ?? '').replace(/\s/g, '').includes(want))) return { via: 'uia' };
    } catch { /* 继续 */ }
    if (allowOcr) {
      try {
        const { words } = await readText(client, hwnd);
        if (words.map((w) => w.text).join('').replace(/\s/g, '').includes(want)) return { via: 'ocr' };
      } catch { /* 继续 */ }
    }
    return null;
  };

  const immediate = await localCheck(true);
  if (immediate) return { ...immediate, text: needle };

  // 条件顺序：输入类值优先 text（Edit 的值不在 UIA Name 里），控件出现类优先 element。
  const order = prefer === 'element' ? ['element', 'text'] : ['text', 'element'];
  const deadline = Date.now() + timeoutMs;

  for (const condition of order) {
    const budget = deadline - Date.now();
    if (budget < 500) break;
    const r = await client.tool('wait_for', {
      condition, query: needle, nativeWindowHandle: hwnd, scope: 'desktop',
      timeoutMs: budget, intervalMs: 200,
    }).catch(() => null);
    if (debug) console.error(`[winctl] wait_for(${condition} "${needle}") -> found=${r?.data?.found} ver=${r?.data?.verification} ${r?.data?.waitedMs}ms`);
    if (r && !r.isError && (r.data?.found === true || r.data?.verification === 'observed')) {
      return { via: `wait_for:${condition}`, text: needle };
    }
    const again = await localCheck(condition === 'text');
    if (again) return { ...again, text: needle };
  }

  // 最后兜底：窗口标题
  try {
    const wins = await findWindowsCached(client);
    const w = wins.find((x) => x.nativeWindowHandle === hwnd);
    if (w && String(w.name ?? '').replace(/\s/g, '').includes(want)) return { via: 'title', text: w.name };
  } catch { /* ignore */ }
  return null;
}

/**
 * 等元素出现并直接返回它（服务端等待 + 一次 find 取 id），
 * 比"本地反复 find"省掉多次 0.9s 级的树扫描。
 */
export async function waitForElementFast(client, hwnd, query, { timeoutMs = 6000 } = {}) {
  try {
    const r = await client.tool('wait_for', {
      condition: 'element', query, nativeWindowHandle: hwnd, timeoutMs, intervalMs: 200,
    });
    if (!r.isError && (r.data?.verification === 'observed' || r.data?.observed === true)) {
      const hit = await locate(client, hwnd, query, { retries: 2, intervalMs: 200 });
      if (hit) return hit;
    }
  } catch { /* 退回轮询 */ }
  return locate(client, hwnd, query, { retries: 4, intervalMs: 350 });
}

/** 已经在前台就不必再激活（activate 实测 ~1.7s，能省则省）。 */
export async function activateIfNeeded(client, hwnd) {
  try {
    const wins = await findWindowsCached(client);
    const w = wins.find((x) => x.nativeWindowHandle === hwnd);
    if (w?.hasKeyboardFocus) return { skipped: true };
  } catch { /* 查不到就老实激活 */ }
  await activate(client, hwnd);
  return { skipped: false };
}

/**
 * 直接给控件写值（优于模拟输入）。
 * 能拿到元素的自动化值就用 set_value；否则退化成 点击聚焦 + type_text。
 */
export async function setValue(client, hwnd, element, value) {
  const t0 = Date.now();
  if (element?.kind === 'element') {
    const r = await client.tool('set_value', { elementId: element.id, value, nativeWindowHandle: hwnd });
    if (!r.isError) return { ok: true, method: 'set_value', ms: Date.now() - t0 };
  }
  if (element) await clickElement(client, hwnd, element);
  const t = await typeText(client, hwnd, value);
  return { ok: t.ok, method: 'type_text', ms: Date.now() - t0 };
}

/** 输入文本并校验（写不进去就重试），preferEditor 为编辑器元素时走 set_value。 */
export async function typeAndVerify(client, hwnd, value, expect, { attempts = 3, editor = null, clearFirst = true } = {}) {
  const t0 = Date.now();
  for (let i = 1; i <= attempts; i++) {
    if (editor) {
      await setValue(client, hwnd, editor, value);
    } else {
      await activate(client, hwnd);
      if (clearFirst) await pressKeys(client, hwnd, ['ctrl', 'a']);
      await typeText(client, hwnd, value);
    }
    const got = await waitForAnyTextFast(client, hwnd, expect ?? value, { timeoutMs: 2500 });
    if (got) return { ok: true, method: editor ? 'set_value' : 'type_text', attempts: i, ms: Date.now() - t0 };
    await sleep(300);
  }
  return { ok: false, method: editor ? 'set_value' : 'type_text', attempts, ms: Date.now() - t0 };
}

/* ───────────────────────── 激活 ───────────────────────── */

/** 把窗口带到前台。真实点击之前必须先做这一步。 */
export async function activate(client, hwnd) {
  const r = await client.tool('activate_window', { nativeWindowHandle: hwnd });
  await sleep(400);
  return !r.isError;
}

/* ───────────────────────── 动作（带校验） ───────────────────────── */

/**
 * 点元素：优先 elementId（后台点击，不需前台），失败才退化为坐标点击。
 * @returns {{ok:boolean, method:string, attempts:number, ms:number}}
 */
export async function clickElement(client, hwnd, element) {
  const t0 = Date.now();
  if (element.kind === 'element') {
    const r = await client.tool('click', { elementId: element.id, nativeWindowHandle: hwnd });
    if (!r.isError) return { ok: true, method: 'element', attempts: 1, ms: Date.now() - t0 };
    const d = await client.tool('double_click', { elementId: element.id, nativeWindowHandle: hwnd });
    if (!d.isError) return { ok: true, method: 'element-dblclick', attempts: 1, ms: Date.now() - t0 };
  }
  await activate(client, hwnd);
  const r = await client.tool('click', { x: Math.round(element.x), y: Math.round(element.y), nativeWindowHandle: hwnd, activate: true });
  return { ok: !r.isError, method: 'coord', attempts: 1, ms: Date.now() - t0 };
}

/** 用 UIA invoke 打开/触发某元素（比模拟双击可靠得多）。 */
export async function invokeElement(client, hwnd, element) {
  const t0 = Date.now();
  if (element.kind === 'element') {
    const r = await client.tool('invoke', { elementId: element.id, nativeWindowHandle: hwnd });
    if (!r.isError) return { ok: true, method: 'invoke', ms: Date.now() - t0 };
  }
  return { ...(await clickElement(client, hwnd, element)), ms: Date.now() - t0 };
}

/**
 * 打开目录/双击条目：**不模拟双击**，改为"选中 + Enter"（列表有焦点时 Enter 即打开），
 * 这条路径不受双击阈值影响，是今天最大的教训。
 */
export async function openItem(client, hwnd, query, { verifyText } = {}) {
  const t0 = Date.now();
  const hit = await locate(client, hwnd, query);
  if (!hit) return { ok: false, method: 'none', reason: `找不到 ${query}`, ms: Date.now() - t0 };

  const inv = await invokeElement(client, hwnd, hit);
  if (inv.ok && (!verifyText || await waitForText(client, hwnd, verifyText, { timeoutMs: 4000 }))) {
    return { ok: true, method: inv.method, ms: Date.now() - t0 };
  }
  // 退路：坐标单击选中，再 Enter
  await activate(client, hwnd);
  await client.tool('click', { x: Math.round(hit.x), y: Math.round(hit.y), nativeWindowHandle: hwnd, activate: true });
  await sleep(300);
  await client.tool('keypress', { keys: ['ENTER'], nativeWindowHandle: hwnd });
  await sleep(900);
  const ok = verifyText ? Boolean(await waitForText(client, hwnd, verifyText, { timeoutMs: 4000 })) : true;
  return { ok, method: 'click+enter', ms: Date.now() - t0 };
}

/** 输入文本（走 MCP 的 type_text，比 SendKeys 稳，且自动处理焦点）。 */
export async function typeText(client, hwnd, text, { method = 'auto' } = {}) {
  const t0 = Date.now();
  const r = await client.tool('type_text', { text, nativeWindowHandle: hwnd, method });
  return { ok: !r.isError, text: r.text?.slice(0, 120), ms: Date.now() - t0 };
}

/** 发按键。 */
export async function pressKeys(client, hwnd, keys) {
  const t0 = Date.now();
  const r = await client.tool('keypress', { keys, nativeWindowHandle: hwnd });
  return { ok: !r.isError, ms: Date.now() - t0 };
}

/** 取窗口矩形（供坐标换算/截图裁剪）。 */
export async function windowRect(client, hwnd) {
  const wins = await (await import('./mcp.mjs')).findWindows(client);
  const w = wins.find((x) => x.nativeWindowHandle === hwnd || x.id === hwnd);
  return w?.boundingBox ?? null;
}

export { windowBy, readText };
