/**
 * winctl · 传输层
 *
 * 与 dsh-computer-use-win 的 MCP server 建立**长连接**：一次握手，多次调用。
 * 旧写法每次调用都 spawn 一个新 server（~1.4s 启动 + 握手），做多步操作时
 * 光启动就吃掉十几秒；这里改为复用会话。
 */
import { spawn } from 'node:child_process';
import path from 'node:path';

const ROOT = process.env.WCU_ROOT ?? 'D:\\dsh-tools\\wcu\\package';

/** 建立会话。mode: 'full' 工具全（含 invoke/set_value/focus/element_info），'lite' 更轻。 */
export async function connect({ mode = process.env.WCU_MODE ?? 'full' } = {}) {
  const child = spawn(process.execPath, [path.join(ROOT, 'mcp', 'server.mjs')], {
    cwd: ROOT,
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', WCU_TOOL_MODE: mode, WCU_BROWSER_HEADLESS: '1' },
    stdio: ['pipe', 'pipe', 'pipe'],
    windowsHide: true,
  });

  let buffer = '';
  const waiters = new Map();
  const stderrChunks = [];
  let nextId = 0;
  let closed = false;

  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => {
    buffer += chunk;
    for (;;) {
      const nl = buffer.indexOf('\n');
      if (nl === -1) break;
      const line = buffer.slice(0, nl).trim();
      buffer = buffer.slice(nl + 1);
      if (!line.startsWith('{')) continue;
      let msg; try { msg = JSON.parse(line); } catch { continue; }
      if (msg.id !== undefined && waiters.has(msg.id)) {
        const { resolve } = waiters.get(msg.id);
        waiters.delete(msg.id);
        resolve(msg);
      }
    }
  });
  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (c) => {
    stderrChunks.push(c);
    if (stderrChunks.length > 200) stderrChunks.shift();
  });
  child.on('exit', (code) => {
    closed = true;
    for (const { reject } of waiters.values()) {
      reject(new Error(`MCP server 退出 (code ${code})\n${stderrChunks.join('').slice(-800)}`));
    }
    waiters.clear();
  });

  const rpc = (method, params, timeoutMs = 120000) => {
    const id = ++nextId;
    return new Promise((resolve, reject) => {
      waiters.set(id, { resolve, reject });
      child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', id, method, params })}\n`);
      setTimeout(() => {
        if (waiters.delete(id)) reject(new Error(`${method} 超时 (${timeoutMs}ms)`));
      }, timeoutMs);
    });
  };

  await rpc('initialize', {
    protocolVersion: '2024-11-05',
    capabilities: {},
    clientInfo: { name: 'winctl', version: '1.0' },
  });
  child.stdin.write(`${JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized', params: {} })}\n`);

  const tool = async (name, args = {}) => {
    const res = await rpc('tools/call', { name: `windows_computer_use_${name}`, arguments: args });
    const text = (res.result?.content ?? []).filter((c) => c.type === 'text').map((c) => c.text).join('\n');
    let data = null;
    try { data = JSON.parse(text); } catch { /* 有些返回不是 JSON */ }
    return { text, data, isError: res.result?.isError === true };
  };

  return {
    tool,
    rpc,
    get closed() { return closed; },
    stderr: () => stderrChunks.join(''),
    async close() {
      try { child.stdin.end(); } catch { /* ignore */ }
      await new Promise((r) => setTimeout(r, 150));
      return process.exitCode ?? 0;
    },
  };
}

/** 枚举顶层窗口。 */
export async function findWindows(client, { includeInvisible = false, maxWindows = 80 } = {}) {
  const r = await client.tool('list_windows', { includeInvisible, maxWindows });
  return r.data?.windows ?? [];
}

/**
 * 带缓存的窗口枚举。
 * 一次 list_windows 在这台机器上要 ~1.3s，而校验循环里会反复调用它——
 * 缓存 1.5s 既不牺牲正确性（窗口变化没那么快），又把校验开销压下来。
 */
const winCache = new WeakMap();
export async function findWindowsCached(client, { ttlMs = 1500, force = false } = {}) {
  const entry = winCache.get(client);
  const now = Date.now();
  if (!force && entry && now - entry.at < ttlMs) return entry.wins;
  const wins = await findWindows(client);
  winCache.set(client, { at: now, wins });
  return wins;
}

/** 按标题/类名找窗口，返回窗口对象（含 nativeWindowHandle / boundingBox）。默认走缓存枚举。 */
export async function windowBy(client, { title, className, processId, useCache = true } = {}) {
  const wins = useCache ? await findWindowsCached(client) : await findWindows(client);
  return wins.find((w) => (
    (!title || new RegExp(title, 'i').test(w.name ?? ''))
    && (!className || new RegExp(className, 'i').test(w.className ?? ''))
    && (!processId || w.processId === processId)
  )) ?? null;
}

/**
 * 等一个窗口出现（用后端的 wait_for window 条件，服务端轮询），
 * 出现后再从缓存枚举里取出窗口对象。避免"每轮枚举一次窗口"的 1.3s 开销。
 */
export async function waitForWindow(client, { title, className, processId, timeoutMs = 8000 } = {}) {
  const args = { condition: 'window', timeoutMs, intervalMs: 250 };
  if (title) args.windowTitle = title;
  if (processId) args.processId = processId;
  try {
    const r = await client.tool('wait_for', args);
    const observed = !r.isError && (r.data?.verification === 'observed' || r.data?.observed === true || r.data?.window);
    if (observed) {
      const w = await windowBy(client, { title, className, processId, useCache: false })
        ?? await windowBy(client, { title, className, processId });
      if (w) return w;
    }
  } catch { /* 退回轮询 */ }

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const w = await windowBy(client, { title, className, processId });
    if (w) return w;
    await new Promise((r) => setTimeout(r, 350));
  }
  return null;
}

/** 读窗口可见文字（UIA 稀疏时的主力观测手段），返回按位置排序的词表。 */
export async function readText(client, hwnd) {
  const r = await client.tool('ocr', { nativeWindowHandle: hwnd, maxWidth: 1600 });
  if (r.isError || !r.data) return { words: [], raw: r.text };
  const words = [];
  for (const line of r.data.lines ?? []) for (const w of line.words ?? []) words.push(w);
  words.sort((a, b) => (a.y - b.y) || (a.x - b.x));
  return { words, raw: r.data.text ?? '', bounds: r.data.imageBounds };
}

/** 读窗口文字拼成一整串（便于断言）。 */
export async function readTextJoined(client, hwnd) {
  const { words } = await readText(client, hwnd);
  return words.map((w) => w.text).join('');
}
