﻿import { connect, windowBy, waitForWindow } from './mcp.mjs';
import { locate, activate, activateIfNeeded, invokeElement, setValueVerified, typeText, pressKeys, waitForAnyTextFast, sleep } from './index.mjs';
const client = await connect();
const marks = [];
const mark = (l, t0) => marks.push([l, Date.now() - t0]);
let t = Date.now();
const note = await windowBy(client, { title: 'Notepad|记事本' });
mark('windowBy(记事本)', t);
if (!note) { console.log('记事本没开'); await client.close(); process.exit(0); }
const hwnd = note.nativeWindowHandle;
t = Date.now(); const act = await activateIfNeeded(client, hwnd); mark(`activateIfNeeded(${act.skipped ? '已在前台,跳过' : '执行激活'})`, t);
t = Date.now(); await pressKeys(client, hwnd, ['ctrl', 's']); mark('pressKeys ctrl+s', t);
t = Date.now(); const dlg = await waitForWindow(client, { className: '#32770', timeoutMs: 8000 }); mark('waitForWindow(#32770)', t);
if (!dlg) { console.log('对话框没出'); await client.close(); process.exit(0); }
const dh = dlg.nativeWindowHandle;
t = Date.now(); const r = await setValueVerified(client, dh, '文件名', 'winctl-fast.txt'); mark('setValueVerified(文件名) [定位+设值+校验]', t);
t = Date.now(); await pressKeys(client, dh, ['ESC']); mark('pressKeys ESC', t);
console.log('分阶段耗时（新方案）:');
for (const [l, ms] of marks) console.log(`  ${String(ms).padStart(6)}ms  ${l}`);
console.log(`  setValue 结果: ${r.ok ? '通过（' + r.via + '）' : '未通过 - ' + r.note}`);
await client.close();
process.exit(0);
