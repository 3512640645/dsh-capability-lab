﻿import { connect, windowBy, waitForWindow, readText } from './mcp.mjs';
import { activate, activateIfNeeded, pressKeys, sleep } from './index.mjs';
const client = await connect();
const marks = []; const mark = (l, t) => marks.push([l, Date.now() - t]);
let t = Date.now();
const note = await windowBy(client, { title: 'Notepad|记事本' });
mark('windowBy(记事本) 冷缓存', t);
await activate(client, note.nativeWindowHandle);
const hwnd = note.nativeWindowHandle;
t = Date.now(); await pressKeys(client, hwnd, ['ctrl', 's']); mark('pressKeys ctrl+s', t);
t = Date.now(); const dlg = await waitForWindow(client, { className: '#32770', timeoutMs: 8000 }); mark('waitForWindow(#32770)', t);
const dh = dlg.nativeWindowHandle;
await activate(client, dh);

t = Date.now();
const f = await client.tool('find', { query: '文件名', controlType: 'Edit', nativeWindowHandle: dh, maxResults: 4, ocrFallback: false, maxDepth: 4, maxNodes: 300, treeTimeoutMs: 1500 });
const edit = (f.data?.results ?? [])[0];
mark('find(文件名, Edit, 收紧)', t);
console.log('  命中: ' + JSON.stringify(edit?.name) + ' id=' + edit?.id);

t = Date.now();
const sv = await client.tool('set_value', { elementId: edit.id, nativeWindowHandle: dh, value: 'winctl-fast.txt', activate: true, fallbackType: true });
mark('set_value', t);
console.log('  set_value: ' + JSON.stringify(sv.data ?? sv.text).slice(0, 160));

t = Date.now();
const vf = await client.tool('wait_for', { condition: 'text', query: 'winctl-fast', nativeWindowHandle: dh, timeoutMs: 3000, intervalMs: 200 });
mark('wait_for(text) 服务端校验', t);
console.log('  校验: found=' + vf.data?.found + ' ver=' + vf.data?.verification + ' waited=' + vf.data?.waitedMs);

t = Date.now(); await pressKeys(client, dh, ['ESC']); mark('pressKeys ESC', t);
console.log('\n分阶段耗时:');
for (const [l, ms] of marks) console.log(`  ${String(ms).padStart(6)}ms  ${l}`);
console.log('  合计(不含首个 windowBy): ' + marks.slice(1).reduce((s, x) => s + x[1], 0) + 'ms');
await client.close();
process.exit(0);
