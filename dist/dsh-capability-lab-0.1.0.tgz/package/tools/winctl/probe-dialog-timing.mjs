/** 给"原生对话框"流程做分阶段计时，找出真正的耗时点。 */
import { connect, windowBy, waitForWindow, readText, findWindowsCached } from './mcp.mjs';
import { locate, waitFor, invokeElement, typeText, pressKeys, activate, waitForAnyTextFast, sleep } from './index.mjs';

const client = await connect();
const marks = [];
const mark = (label, t0) => { marks.push([label, Date.now() - t0]); };

let t = Date.now();
const note = await windowBy(client, { title: 'Notepad|记事本' });
mark('windowBy(记事本) [含缓存首查]', t);
if (!note) { console.log('记事本没开'); await client.close(); process.exit(0); }
const hwnd = note.nativeWindowHandle;

t = Date.now(); await activate(client, hwnd); mark('activate', t);
t = Date.now(); await pressKeys(client, hwnd, ['ctrl', 's']); mark('pressKeys ctrl+s', t);
t = Date.now(); const dlg = await waitForWindow(client, { className: '#32770', timeoutMs: 8000 }); mark('waitForWindow(#32770)', t);
if (!dlg) { console.log('对话框没出'); await client.close(); process.exit(0); }
const dh = dlg.nativeWindowHandle;

t = Date.now(); const edit = await waitFor(client, dh, '文件名', { timeoutMs: 6000 }); mark('waitFor(文件名)', t);
t = Date.now(); if (edit) await invokeElement(client, dh, edit).catch(() => {}); mark('invokeElement(文件名)', t);
t = Date.now(); await typeText(client, dh, 'winctl-timing.txt'); mark('typeText', t);
t = Date.now(); const got = await waitForAnyTextFast(client, dh, 'winctl-timing', { timeoutMs: 4000 }); mark('waitForAnyTextFast', t);
t = Date.now(); await pressKeys(client, dh, ['ESC']); mark('pressKeys ESC', t);

t = Date.now(); await findWindowsCached(client, { force: true }); mark('窗口枚举(强制刷新一次)', t);
t = Date.now(); await readText(client, dh).catch(() => {}); mark('readText(对话框,已关)', t);

console.log('分阶段耗时:');
for (const [label, ms] of marks) console.log(`  ${String(ms).padStart(6)}ms  ${label}`);
console.log(`  校验结果: ${got ? got.via : '未命中'}`);
await client.close();
process.exit(0);
