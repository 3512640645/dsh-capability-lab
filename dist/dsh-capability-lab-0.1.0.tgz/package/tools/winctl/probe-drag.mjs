/**
 * probe-drag · 复现"前台锁"拒绝：UWP(计算器) 与 Win32(记事本) 各试一次 drag
 * 目的：判断 foreground lock 是应用类型相关，还是摆位循环留下的状态问题。
 */
import { connect, findWindows, windowBy } from './mcp.mjs';
import { activate, sleep } from './index.mjs';

const client = await connect();
const fg = async (tag) => {
  const ws = await findWindows(client, { useCache: false });
  const f = ws.find((w) => w.hasKeyboardFocus);
  console.log(`   [fg@${tag}] hwnd=${f?.nativeWindowHandle} "${String(f?.name ?? '').slice(0, 30)}" cls=${f?.className}`);
  return f;
};
const boxOf = async (hwnd) => (await findWindows(client, { useCache: false })).find((w) => w.nativeWindowHandle === hwnd)?.boundingBox;

const run = async (label, w, { doActivate = true } = {}) => {
  console.log(`\n== ${label} hwnd=${w.nativeWindowHandle} "${w.name}"`);
  if (doActivate) { await client.tool('activate_window', { nativeWindowHandle: w.nativeWindowHandle }); await sleep(600); }
  await fg('activate 后');
  const b = await boxOf(w.nativeWindowHandle);
  console.log(`   box=[${b.x},${b.y} ${b.width}x${b.height}]`);
  const path = [];
  for (let i = 0; i <= 6; i++) path.push({ x: Math.round(b.x + b.width * 0.3 + 100 * i / 6), y: Math.round(b.y + 14 + 60 * i / 6) });
  const r = await client.tool('drag', { path, nativeWindowHandle: w.nativeWindowHandle, activate: true }).catch((e) => ({ isError: true, text: String(e) }));
  console.log(`   drag isError=${r.isError} text=${String(r.text).replace(/\s+/g, ' ').slice(0, 260)}`);
  if (r.data) console.log(`   data=${JSON.stringify(r.data).slice(0, 260)}`);
  await sleep(500);
  const after = await boxOf(w.nativeWindowHandle);
  console.log(`   拖动后 box=[${after.x},${after.y}]`);
  await fg('drag 后');
};

// 1) 计算器（UWP）
const calc = await windowBy(client, { title: '计算器|Calculator', className: 'ApplicationFrameWindow|WinUIDesktopWin32WindowClass' });
if (calc) await run('计算器 UWP', calc); else console.log('无计算器窗口');

// 2) 记事本（Win32）
const np = await windowBy(client, { title: 'Notepad|记事本', className: 'Notepad' });
if (np) {
  await client.tool('activate_window', { nativeWindowHandle: np.nativeWindowHandle });
  await sleep(500);
  const b = (await boxOf(np.nativeWindowHandle));
  await run('记事本 Win32', np);
  // 复位：拖回原处
  await client.tool('move_window', { nativeWindowHandle: np.nativeWindowHandle, x: b.x, y: b.y });
}

// 3) 再试一次计算器：先 move_window(activate:true) 再 drag
if (calc) await run('计算器 UWP · 第二次', calc);

await client.close();
process.exit(0);
