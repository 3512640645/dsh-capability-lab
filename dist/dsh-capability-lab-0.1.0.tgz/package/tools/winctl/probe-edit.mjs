﻿import { connect, windowBy, waitForWindow } from './mcp.mjs';
import { activate, pressKeys, sleep, locate } from './index.mjs';
const client = await connect();
const note = await windowBy(client, { title: 'Notepad|记事本' });
await activate(client, note.nativeWindowHandle);
await pressKeys(client, note.nativeWindowHandle, ['ctrl', 's']);
const dlg = await waitForWindow(client, { className: '#32770', timeoutMs: 8000 });
const dh = dlg.nativeWindowHandle;
await activate(client, dh);

for (const args of [
  { label: 'controlType=Edit 且空查询', a: { query: '', controlType: 'Edit', nativeWindowHandle: dh, maxResults: 8, ocrFallback: false } },
  { label: 'controlType=Edit 查询 文件名', a: { query: '文件名', controlType: 'Edit', nativeWindowHandle: dh, maxResults: 8, ocrFallback: false } },
  { label: 'controlType=Edit 查询 Edit', a: { query: 'Edit', controlType: 'Edit', nativeWindowHandle: dh, maxResults: 8, ocrFallback: false } },
]) {
  const t = Date.now();
  const r = await client.tool('find', args.a);
  const res = r.data?.results ?? [];
  console.log(`${args.label}: ${Date.now()-t}ms 命中 ${res.length} 个`);
  for (const h of res.slice(0, 4)) console.log(`    id=${h.id} name="${h.name}" box=${JSON.stringify(h.boundingBox)}`);
}
await pressKeys(client, dh, ['ESC']);
await client.close();
process.exit(0);
