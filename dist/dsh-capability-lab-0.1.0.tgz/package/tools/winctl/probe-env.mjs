/**
 * probe-env · 现场取数：当前桌面窗口、遮挡关系、explorer 树节点、计算器显示状态
 * 只读观测，不产生真实点击（除必要的激活）。
 */
import { connect, findWindows } from './mcp.mjs';
import { sleep } from './index.mjs';

const client = await connect();
const wins = await findWindows(client, { useCache: false, includeInvisible: true, maxWindows: 120 });
const vis = wins.filter((w) => w.boundingBox && w.boundingBox.width > 0);
console.log(`顶层窗口 total=${wins.length} visible=${vis.length}`);
for (const w of vis.slice(0, 40)) {
  const b = w.boundingBox;
  console.log(`  hwnd=${w.nativeWindowHandle} pid=${w.processId} fg=${w.hasKeyboardFocus ? 'FG' : '  '} min=${w.isMinimized ? 'M' : '-'} [${b.x},${b.y} ${b.width}x${b.height}] cls=${String(w.className).slice(0, 34)} name="${String(w.name).slice(0, 40)}"`);
}

// explorer 树节点复测（树展开任务的前置条件）
const exp = vis.find((w) => w.className === 'CabinetWClass');
if (exp) {
  console.log(`\n[explorer] hwnd=${exp.nativeWindowHandle} name="${exp.name}"`);
  for (const opts of [
    { viewMode: 'control', detailLevel: 'full', maxDepth: 12, maxNodes: 6000, treeTimeoutMs: 8000, label: 'control/full' },
    { viewMode: 'control', detailLevel: 'basic', maxDepth: 20, maxNodes: 12000, treeTimeoutMs: 12000, label: 'control/basic' },
    { viewMode: 'raw', detailLevel: 'full', maxDepth: 20, maxNodes: 12000, treeTimeoutMs: 12000, label: 'raw/full' },
  ]) {
    const r = await client.tool('accessibility_tree', { nativeWindowHandle: exp.nativeWindowHandle, ...opts }).catch((e) => ({ isError: true, text: String(e) }));
    const walk = (n, out = []) => { for (const c of n?.children ?? []) { out.push(c); walk(c, out); } return out; };
    const all = walk(r.data?.tree ?? null);
    const ti = all.filter((c) => String(c.controlType ?? '').includes('TreeItem'));
    console.log(`  ${opts.label}: nodeCount=${r.data?.nodeCount} truncated=${r.data?.truncated} 总节点=${all.length} TreeItem=${ti.length} ${ti.slice(0, 6).map((x) => x.name).join(' | ')}`);
  }
} else {
  console.log('\n[explorer] 当前无 CabinetWClass 窗口');
}

// 计算器显示状态（calc-sum 的白送风险：上一次的 56 还在屏上）
const calc = vis.find((w) => /Calculator|计算器/.test(w.name ?? ''));
if (calc) {
  const r = await client.tool('find', { query: '显示为', nativeWindowHandle: calc.nativeWindowHandle, maxResults: 8, ocrFallback: false }).catch(() => null);
  console.log(`\n[calc] hwnd=${calc.nativeWindowHandle} 显示元素: ${JSON.stringify((r?.data?.results ?? []).map((x) => x.name))}`);
} else {
  console.log('\n[calc] 当前无计算器窗口');
}

// notepad 正文状态
const np = vis.find((w) => w.className === 'Notepad');
if (np) {
  const r = await client.tool('find', { query: '文本编辑器', nativeWindowHandle: np.nativeWindowHandle, maxResults: 4, ocrFallback: false }).catch(() => null);
  console.log(`[notepad] hwnd=${np.nativeWindowHandle} 文本编辑器元素命中=${(r?.data?.results ?? []).length}`);
}

console.log('\n[fg] ' + JSON.stringify(vis.filter((w) => w.hasKeyboardFocus).map((w) => w.name)));
await client.close();
process.exit(0);
