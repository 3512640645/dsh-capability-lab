/** probe-fg · 定位"占据前台的提权窗口"与可点击的安全点（非提权窗口覆盖处） */
import { connect, findWindows } from './mcp.mjs';

const client = await connect();
const ws = await findWindows(client, { useCache: false, includeInvisible: false, maxWindows: 200 });
const vis = ws.filter((w) => w.boundingBox && w.boundingBox.width > 0);
console.log(`可见窗口 ${vis.length}`);
for (const w of vis.slice(0, 45)) {
  const b = w.boundingBox;
  console.log(`  hwnd=${String(w.nativeWindowHandle).padStart(9)} pid=${String(w.processId).padStart(6)} ${w.hasKeyboardFocus ? 'FG' : '  '} [${String(b.x).padStart(5)},${String(b.y).padStart(4)} ${String(b.width).padStart(4)}x${String(b.height).padStart(4)}] ${String(w.className).slice(0, 26).padEnd(28)} "${String(w.name).slice(0, 26)}"`);
}
const mmc = vis.find((w) => /MMCMainFrame/.test(w.className ?? ''));
console.log(`\nMMC 提权窗: ${mmc ? `hwnd=${mmc.nativeWindowHandle} pid=${mmc.processId} [${mmc.boundingBox.x},${mmc.boundingBox.y} ${mmc.boundingBox.width}x${mmc.boundingBox.height}] FG=${mmc.hasKeyboardFocus}` : '无'}`);

// 取几个候选点的 z 序命中：任务栏空白、屏幕右下角、桌面左上下角
const pts = [[400, 876], [720, 876], [1400, 876], [60, 400], [1380, 300], [700, 500], [189, 22], [30, 830]];
console.log('\n命中测试（点 → 最上层窗口）:');
for (const [x, y] of pts) {
  const r = await client.tool('element_info', { x, y }).catch(() => null);
  const e = r?.data?.element;
  console.log(`  (${String(x).padStart(4)},${String(y).padStart(3)}) → hwnd=${e?.nativeWindowHandle} pid=${e?.processId} "${String(e?.name ?? '').slice(0, 24)}" cls=${String(e?.className ?? '').slice(0, 22)}`);
}
await client.close();
process.exit(0);
