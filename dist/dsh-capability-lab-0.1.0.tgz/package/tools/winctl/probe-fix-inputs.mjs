/**
 * probe-fix-inputs · 为三处修复取现场事实：
 *  (A) notepad 正文元素的 UIA 值是否可读（给 notepad-type 补外部判定）
 *  (B) 计算器显示屏元素命名 + ESC 能否清零（防"上一轮的 56"白送通过）
 *  (C) 是否存在真正暴露 TreeItem 的窗口（tree-expand 可度量性）
 */
import { connect, findWindows, windowBy, readText } from './mcp.mjs';
import { activate, locate, sleep, pressKeys, invokeElement } from './index.mjs';

const client = await connect();
const args = process.argv.slice(2);
const launch = async (exe, titleRe, classNameRe, ms = 20000) => {
  let w = await windowBy(client, { title: titleRe, className: classNameRe });
  if (w) return w;
  await client.tool('launch_app', { target: exe, waitMs: 2500 });
  const dl = Date.now() + ms;
  while (Date.now() < dl) { await sleep(900); w = await windowBy(client, { title: titleRe, className: classNameRe, useCache: false }); if (w) return w; }
  return null;
};
const walk = (n, out = [], d = 0) => { for (const c of n?.children ?? []) { out.push({ c, d }); walk(c, out, d + 1); } return out; };

/* ---------- (A) notepad ---------- */
{
  const w = await launch('notepad.exe', 'Notepad|记事本', 'Notepad');
  if (!w) console.log('[A] notepad 起不来');
  else {
    const hwnd = w.nativeWindowHandle;
    await activate(client, hwnd); await sleep(800);
    const ed = await locate(client, hwnd, '文本编辑器', { controlType: 'Edit', retries: 3, intervalMs: 300, ocrFallback: false });
    console.log(`[A] notepad hwnd=${hwnd} 编辑器元素 id=${ed?.id ? 'yes' : 'no'}`);
    if (ed?.id) await client.tool('set_value', { elementId: ed.id, nativeWindowHandle: hwnd, value: 'winctl 校验通过 2026', fallbackType: true });
    await sleep(600);
    const r = await client.tool('accessibility_tree', { nativeWindowHandle: hwnd, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 8000, viewMode: 'control', detailLevel: 'full' }).catch((e) => ({ isError: true, text: String(e) }));
    console.log(`[A] tree isError=${r.isError} ${r.isError ? String(r.text).slice(0, 120) : ''}`);
    for (const { c, d } of walk(r.data?.tree ?? null)) {
      const keys = Object.keys(c).filter((k) => !['children'].includes(k));
      const val = c.value ?? c.Value ?? c.text ?? c.Text ?? null;
      if (String(c.controlType ?? '').includes('Edit') || val || /校验通过/.test(String(c.name ?? ''))) {
        console.log(`   ${' '.repeat(d * 2)}${c.controlType} name="${String(c.name ?? '').slice(0, 40)}" 值字段=${JSON.stringify(val).slice(0, 60)} keys=${keys.join(',')}`);
      }
    }
    const ocr = await readText(client, hwnd);
    console.log(`[A] OCR 拼接: ${ocr.words.map((x) => x.text).join('').slice(0, 80)}`);
    const f = await client.tool('find', { query: '校验通过', nativeWindowHandle: hwnd, maxResults: 8, ocrFallback: false });
    console.log(`[A] find(UIA only) '校验通过' 命中 ${(f.data?.results ?? []).length}: ${JSON.stringify((f.data?.results ?? []).map((h) => ({ n: h.name, ct: h.controlType, id: !!h.id }))).slice(0, 200)}`);
  }
}

/* ---------- (B) calculator ---------- */
if (args.includes('--calc')) {
  const w = await launch('calc.exe', '计算器|Calculator', 'ApplicationFrameWindow|WinUIDesktopWin32WindowClass');
  if (!w) console.log('[B] calc 起不来');
  else {
    const hwnd = w.nativeWindowHandle;
    await activate(client, hwnd); await sleep(900);
    const disp = async (tag) => {
      const r = await client.tool('find', { query: '显示为', nativeWindowHandle: hwnd, maxResults: 6, ocrFallback: false }).catch(() => null);
      console.log(`[B] ${tag} 显示屏候选: ${JSON.stringify((r?.data?.results ?? []).map((h) => h.name))}`);
    };
    await disp('初始');
    for (const k of ['七', '乘以', '八', '等于']) { const hit = await locate(client, hwnd, k); if (hit) await invokeElement(client, hwnd, hit); await sleep(150); }
    await disp('按完 7*8=');
    for (let i = 0; i < 3; i++) { await pressKeys(client, hwnd, ['ESC']); await sleep(400); await disp(`ESC×${i + 1}`); }
  }
}

/* ---------- (C) 树靶 ---------- */
if (args.includes('--tree')) {
  const cands = [
    ['%windir%\\system32\\taskschd.msc', 'Task Scheduler|任务计划程序', 'MMCMainFrame'],
    ['%windir%\\system32\\eventvwr.msc', 'Event Viewer|事件查看器', 'MMCMainFrame'],
  ];
  for (const [exe, titleRe, cls] of cands) {
    let w = await windowBy(client, { className: cls });
    if (!w) {
      const { execFile } = await import('node:child_process');
      execFile('cmd.exe', ['/c', 'start', '', exe.replace('%windir%', process.env.windir)], { windowsHide: true }, () => {});
      const dl = Date.now() + 25000;
      while (!w && Date.now() < dl) { await sleep(1200); w = await windowBy(client, { className: cls, useCache: false }); }
    }
    if (!w) { console.log(`[C] ${exe} 起不来`); continue; }
    await activate(client, w.nativeWindowHandle); await sleep(1800);
    const r = await client.tool('accessibility_tree', { nativeWindowHandle: w.nativeWindowHandle, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 9000, viewMode: 'control', detailLevel: 'full' }).catch((e) => ({ isError: true, text: String(e) }));
    const all = walk(r.data?.tree ?? null);
    const ti = all.filter((x) => String(x.c.controlType ?? '').includes('TreeItem'));
    console.log(`[C] ${exe} isError=${r.isError} nodeCount=${r.data?.nodeCount} 节点=${all.length} TreeItem=${ti.length} ${r.isError ? String(r.text).slice(0, 100) : ''}`);
    console.log(`    TreeItem: ${ti.slice(0, 10).map((x) => `${x.c.name}${((x.c.children ?? []).length ? '*' : '')}${x.c.id ? '#' : ''}`).join(' | ').slice(0, 300)}`);
    await client.tool('close_window', { nativeWindowHandle: w.nativeWindowHandle }).catch(() => {});
  }
}

await client.close();
process.exit(0);
