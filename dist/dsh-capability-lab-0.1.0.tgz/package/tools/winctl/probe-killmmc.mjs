/**
 * probe-killmmc · 用"外壳自己"的通道关掉提权窗口
 * 思路：提权窗口本身不能被低完整性进程触碰（UIPI），但**任务栏按钮属于 explorer（中完整性）**，
 * 右键菜单也是 explorer 画的 —— 走这条通道有机会让外壳去关它。
 */
import { connect, findWindows } from './mcp.mjs';
import { activate, sleep } from './index.mjs';

const client = await connect();
const walk = (n, out = [], d = 0) => { for (const c of n?.children ?? []) { out.push({ c, d }); walk(c, out, d + 1); } return out; };

const hwndArg = Number(process.argv[2] ?? 3803358);
const ws = await findWindows(client, { useCache: false });
const target = ws.find((w) => w.nativeWindowHandle === hwndArg);
console.log(`目标 hwnd=${hwndArg} "${target?.name}" box=${JSON.stringify(target?.boundingBox)}`);

// 0) UIA 能否读提权窗口（预期：被 UIPI 挡住 → 这就是"插件无法操作提权窗口"的现场证据）
const tr = await client.tool('accessibility_tree', { nativeWindowHandle: hwndArg, maxNodes: 500, maxDepth: 8, treeTimeoutMs: 3000 }).catch((e) => ({ isError: true, text: String(e) }));
console.log(`[UIA] 提权窗口 isError=${tr.isError} 节点=${walk(tr.data?.tree ?? null).length} ${tr.isError ? '原文=' + String(tr.text).slice(0, 100) : ''}`);

// 1) close_window 直发 WM_CLOSE（预期：被 UIPI 挡）
const cr = await client.tool('close_window', { nativeWindowHandle: hwndArg }).catch((e) => ({ isError: true, text: String(e) }));
console.log(`[close_window] isError=${cr.isError} text=${String(cr.text).replace(/\s+/g, ' ').slice(0, 160)} data=${JSON.stringify(cr.data).slice(0, 160)}`);
await sleep(800);
console.log(`[close_window 后] 窗口还在吗 = ${Boolean((await findWindows(client, { useCache: false })).find((w) => w.nativeWindowHandle === hwndArg))}`);

// 2) 找任务栏按钮
const tray = (await findWindows(client, { useCache: false })).find((w) => w.className === 'Shell_TrayWnd');
console.log(`[任务栏] hwnd=${tray?.nativeWindowHandle} box=${JSON.stringify(tray?.boundingBox)}`);
const tb = await client.tool('accessibility_tree', { nativeWindowHandle: tray?.nativeWindowHandle, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 6000, detailLevel: 'full' }).catch((e) => ({ isError: true, text: String(e) }));
const nodes = walk(tb.data?.tree ?? null);
console.log(`[任务栏树] isError=${tb.isError} 节点=${nodes.length} ${tb.isError ? String(tb.text).slice(0, 120) : ''}`);
for (const { c } of nodes) {
  const nm = String(c.name ?? '').trim();
  if (nm && (/任务计划|MMC|计划程序/.test(nm) || /Button/.test(String(c.controlType ?? '')))) {
    console.log(`   ${c.controlType} "${nm.slice(0, 40)}" box=${JSON.stringify(c.boundingBox)} id=${c.id ? 'y' : 'n'}`);
  }
}
await client.close();
process.exit(0);
