/** probe-mmc-tree · 提权窗口的 UIA 树能否被"invoke/关闭"（UIA 读取实测可用：20 节点） */
import { connect } from './mcp.mjs';

const client = await connect();
const hwnd = Number(process.argv[2] ?? 3803358);
const r = await client.tool('accessibility_tree', { nativeWindowHandle: hwnd, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 8000, detailLevel: 'full' }).catch((e) => ({ isError: true, text: String(e) }));
const walk = (n, out = [], d = 0) => { for (const c of n?.children ?? []) { out.push({ c, d }); walk(c, out, d + 1); } return out; };
const nodes = walk(r.data?.tree ?? null);
console.log(`isError=${r.isError} 节点=${nodes.length} truncated=${r.data?.truncated} ${r.isError ? String(r.text).slice(0, 120) : ''}`);
for (const { c, d } of nodes) {
  console.log(`${' '.repeat(d * 2)}${String(c.controlType ?? '?').padEnd(16)} name="${String(c.name ?? '').slice(0, 34).padEnd(34)}" id=${c.id ? 'Y' : 'n'} patterns=${JSON.stringify(c.patterns ?? []).slice(0, 70)} box=${c.boundingBox ? `${c.boundingBox.x},${c.boundingBox.y} ${c.boundingBox.width}x${c.boundingBox.height}` : '-'}`);
}
await client.close();
process.exit(0);
