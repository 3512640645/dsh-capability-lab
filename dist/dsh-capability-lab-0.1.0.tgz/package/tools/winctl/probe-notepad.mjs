import { connect, windowBy, readText } from './mcp.mjs';
import { locate, setValue, typeAndVerify, sleep } from './index.mjs';

const client = await connect();
const w = await windowBy(client, { title: 'Notepad|记事本' });
if (!w) { console.log('记事本没开'); await client.close(); process.exit(0); }
const hwnd = w.nativeWindowHandle;
console.log(`窗口: ${w.name}  hwnd=${hwnd}`);

const editor = await locate(client, hwnd, '文本编辑器');
console.log('编辑器元素:', editor ? `${editor.kind} ${editor.id} ${editor.name}` : '未找到');

const sv = editor ? await client.tool('set_value', { elementId: editor.id, value: 'winctl 探针BBB', nativeWindowHandle: hwnd }) : null;
console.log('set_value isError =', sv?.isError, ' 返回片段:', (sv?.text ?? '').slice(0, 200));
await sleep(900);

const { words } = await readText(client, hwnd);
console.log(`OCR 词数 ${words.length}`);
console.log('词表:', words.map((x) => x.text).join('|'));
const joined = words.map((x) => x.text).join('').replace(/\s/g, '');
console.log('拼接后:', joined.slice(0, 200));
console.log('包含「探针」?', joined.includes('探针'));
console.log('包含「探针BBB」?', joined.includes('探针BBB'));

const viaUia = await client.tool('find', { query: '探针', nativeWindowHandle: hwnd, maxResults: 5, ocrFallback: false });
console.log('UIA find("探针") ->', (viaUia.data?.results ?? []).map((h) => `${h.name}`).join(' | ') || '无');

const r = await typeAndVerify(client, hwnd, 'winctl 校验通过 2026', '校验通过', { editor });
console.log('typeAndVerify:', JSON.stringify(r));

await client.close();
process.exit(0);
