﻿import { connect, windowBy, waitForWindow } from './mcp.mjs';
import { activate, pressKeys, invokeElement, typeText, locate, sleep, activateIfNeeded } from './index.mjs';
const client = await connect();
const note = await windowBy(client, { title: 'Notepad|记事本' });
const hwnd = note.nativeWindowHandle;
await activate(client, hwnd);
await pressKeys(client, hwnd, ['ctrl', 's']);
const dlg = await waitForWindow(client, { className: '#32770', timeoutMs: 8000 });
if (!dlg) { console.log('对话框没出'); await client.close(); process.exit(0); }
const dh = dlg.nativeWindowHandle;
const edit = await locate(client, dh, '文件名');
await invokeElement(client, dh, edit).catch(() => {});
await typeText(client, dh, 'winctl-scope-test.txt');
await sleep(400);

for (const args of [
  { label: 'text + active_window（默认）', a: { condition: 'text', query: 'winctl-scope-test', nativeWindowHandle: dh, timeoutMs: 2500 } },
  { label: '先激活对话框再 text', a: null },
  { label: 'text + scope:desktop', a: { condition: 'text', query: 'winctl-scope-test', nativeWindowHandle: dh, scope: 'desktop', timeoutMs: 2500 } },
  { label: 'element + scope:desktop', a: { condition: 'element', query: 'winctl-scope-test', nativeWindowHandle: dh, scope: 'desktop', timeoutMs: 2500 } },
]) {
  if (!args.a) { await activate(client, dh); console.log('  → 已激活对话框'); await sleep(500); 
    const r = await client.tool('wait_for', { condition: 'text', query: 'winctl-scope-test', nativeWindowHandle: dh, timeoutMs: 2500 });
    console.log(`  ${args.label}: ${JSON.stringify(r.data).slice(0, 200)}`); continue; }
  const t0 = Date.now();
  const r = await client.tool('wait_for', args.a);
  console.log(`  ${args.label} (${Date.now() - t0}ms): found=${r.data?.found} verification=${r.data?.verification}`);
}
await pressKeys(client, dh, ['ESC']);
await client.close();
process.exit(0);
