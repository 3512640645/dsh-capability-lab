﻿import { connect, windowBy, waitForWindow } from './mcp.mjs';
import { locate, activate, pressKeys, sleep } from './index.mjs';
const client = await connect();
const note = await windowBy(client, { title: 'Notepad|记事本' });
const hwnd = note.nativeWindowHandle;
await activate(client, hwnd);
await pressKeys(client, hwnd, ['ctrl', 's']);
const dlg = await waitForWindow(client, { className: '#32770', timeoutMs: 8000 });
const dh = dlg.nativeWindowHandle;
await activate(client, dh);
console.log('对话框已激活 hwnd=' + dh);

let t = Date.now();
const tight = await locate(client, dh, '文件名', { retries: 3, intervalMs: 200, maxDepth: 5, maxNodes: 400, treeTimeoutMs: 1500 });
console.log(`收紧扫描定位: ${Date.now()-t}ms -> ${JSON.stringify(tight?.box)} id=${tight?.id}`);

t = Date.now();
const plain = await locate(client, dh, '文件名', { retries: 1, intervalMs: 0 });
console.log(`默认扫描定位: ${Date.now()-t}ms -> id=${plain?.id}`);

t = Date.now();
const sv = await client.tool('set_value', { elementId: plain.id, nativeWindowHandle: dh, value: 'winctl-fast.txt', activate: true, fallbackType: true });
console.log(`set_value 原始: ${Date.now()-t}ms -> ${JSON.stringify(sv.data ?? sv.text).slice(0, 300)}`);
await sleep(400);
const ocr = await client.tool('ocr', { nativeWindowHandle: dh });
console.log('OCR 文本: ' + JSON.stringify((ocr.data?.text ?? '').slice(0, 120)));
const { words } = await (await import('./mcp.mjs')).readText(client, dh);
console.log('readText 片段: ' + words.map(w => w.text).join('').slice(0, 120));
await pressKeys(client, dh, ['ESC']);
await client.close();
process.exit(0);
