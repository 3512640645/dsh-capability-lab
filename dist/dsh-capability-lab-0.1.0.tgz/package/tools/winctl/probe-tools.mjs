/** probe-tools · 列出插件 MCP 工具清单（找有没有关窗/取值/缩放相关的工具） */
import { connect } from './mcp.mjs';
const client = await connect();
const r = await client.rpc('tools/list', {});
const names = (r.result?.tools ?? []).map((t) => t.name.replace('windows_computer_use_', ''));
console.log(`工具数=${names.length}`);
console.log(names.join('  '));
for (const t of r.result?.tools ?? []) {
  const n = t.name.replace('windows_computer_use_', '');
  if (/close|window|drag|value|element_info|wait_for|launch/i.test(n)) console.log(`\n## ${n}\n${String(t.description).slice(0, 400)}\nSCHEMA: ${JSON.stringify(t.inputSchema?.properties ?? {}).slice(0, 800)}`);
}
await client.close();
process.exit(0);
