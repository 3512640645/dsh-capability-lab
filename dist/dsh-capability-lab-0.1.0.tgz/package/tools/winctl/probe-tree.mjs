/**
 * probe-tree · 复测 explorer 左树可达性：激活前/后各取一次 accessibility_tree
 * 目的：判断 tree-expand 的"前置条件不成立"是环境所致还是调用参数所致。
 */
import { connect, findWindows } from './mcp.mjs';
import { activate, sleep } from './index.mjs';

const client = await connect();
const walk = (n, out = []) => { for (const c of n?.children ?? []) { out.push(c); walk(c, out); } return out; };

const wins = await findWindows(client, { useCache: false, includeInvisible: true, maxWindows: 200 });
const cands = wins.filter((w) => w.className === 'CabinetWClass' && w.boundingBox && w.boundingBox.x > -1000);
console.log(`explorer 候选 ${cands.length} 个：`);
for (const w of cands) console.log(`  hwnd=${w.nativeWindowHandle} pid=${w.processId} fg=${w.hasKeyboardFocus} [${w.boundingBox.x},${w.boundingBox.y} ${w.boundingBox.width}x${w.boundingBox.height}] "${w.name}"`);

const target = cands.find((w) => w.hasKeyboardFocus) ?? cands[0];
if (!target) { console.log('无可用 explorer 窗口'); await client.close(); process.exit(0); }
console.log(`\n目标 hwnd=${target.nativeWindowHandle}`);

for (const phase of ['激活前', '激活后']) {
  if (phase === '激活后') { await activate(client, target.nativeWindowHandle); await sleep(1200); }
  const r = await client.tool('accessibility_tree', {
    nativeWindowHandle: target.nativeWindowHandle, maxNodes: 6000, maxDepth: 12, treeTimeoutMs: 8000, viewMode: 'control', detailLevel: 'full',
  }).catch((e) => ({ isError: true, text: String(e) }));
  const all = walk(r.data?.tree ?? null);
  const ti = all.filter((c) => String(c.controlType ?? '').includes('TreeItem'));
  console.log(`[${phase}] isError=${r.isError} nodeCount=${r.data?.nodeCount} truncated=${r.data?.truncated} 全树节点=${all.length} TreeItem=${ti.length}`);
  if (r.isError || all.length === 0) console.log(`    原文: ${String(r.text).replace(/\s+/g, ' ').slice(0, 200)}`);
  if (ti.length) console.log(`    TreeItem 名: ${ti.map((x) => x.name).join(' | ').slice(0, 300)}`);
  const types = {};
  for (const n of all) types[n.controlType] = (types[n.controlType] ?? 0) + 1;
  console.log(`    控件类型分布: ${JSON.stringify(types).slice(0, 400)}`);
}
await client.close();
process.exit(0);
