/**
 * probe-tree2 · 修正 maxNodes 上限后复测左树（bench 里传 6000 超过插件上限 3000 → 调用报错 → 被误判"前置条件不成立"）
 */
import { connect, findWindows } from './mcp.mjs';
import { activate, sleep } from './index.mjs';

const client = await connect();
const walk = (n, out = []) => { for (const c of n?.children ?? []) { out.push(c); walk(c, out); } return out; };

const wins = await findWindows(client, { useCache: false, includeInvisible: true, maxWindows: 200 });
const target = wins.find((w) => w.className === 'CabinetWClass' && w.boundingBox && w.boundingBox.x > -1000);
if (!target) { console.log('无 explorer 窗口'); await client.close(); process.exit(0); }
await activate(client, target.nativeWindowHandle);
await sleep(1500);
console.log(`目标 hwnd=${target.nativeWindowHandle} "${target.name}"`);

for (const opts of [
  { maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 8000, label: 'maxNodes=3000 d12' },
  { maxNodes: 2000, maxDepth: 12, treeTimeoutMs: 8000, label: 'maxNodes=2000 d12' },
  { maxNodes: 3000, maxDepth: 20, treeTimeoutMs: 12000, label: 'maxNodes=3000 d20' },
]) {
  const r = await client.tool('accessibility_tree', {
    nativeWindowHandle: target.nativeWindowHandle, viewMode: 'control', detailLevel: 'full',
    maxNodes: opts.maxNodes, maxDepth: opts.maxDepth, treeTimeoutMs: opts.treeTimeoutMs,
  }).catch((e) => ({ isError: true, text: String(e) }));
  const all = walk(r.data?.tree ?? null);
  const ti = all.filter((c) => String(c.controlType ?? '').includes('TreeItem'));
  console.log(`[${opts.label}] isError=${r.isError} nodeCount=${r.data?.nodeCount} truncated=${r.data?.truncated} 节点=${all.length} TreeItem=${ti.length} ${r.isError ? '原文=' + String(r.text).slice(0, 120) : ''}`);
  if (ti.length) {
    console.log(`    TreeItem: ${ti.map((x) => `${x.name}${(x.children ?? []).length ? '*' : ''}`).join(' | ').slice(0, 400)}`);
    // 折叠性：children 空的节点
    const folded = ti.filter((x) => !(x.children ?? []).length);
    console.log(`    其中 children 为空(折叠)的: ${folded.map((x) => x.name).join('、')}`);
    console.log(`    带 patterns: ${JSON.stringify(ti.slice(0, 3).map((x) => ({ n: x.name, p: x.patterns, id: !!x.id })))}`);
  }
}
await client.close();
process.exit(0);
