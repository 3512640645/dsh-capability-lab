/**
 * probe-tree3 · 换靶验证：哪些窗口真的通过 UIA 暴露 TreeItem（树展开任务的可度量前提）
 * 候选：explorer(新UI)、regedit(经典 Win32 TreeView)。只读枚举，不做真实点击。
 */
import { connect, findWindows, windowBy } from './mcp.mjs';
import { activate, sleep } from './index.mjs';

const client = await connect();
const walk = (n, out = [], d = 0) => { for (const c of n?.children ?? []) { out.push({ c, d }); walk(c, out, d + 1); } return out; };

// 1) explorer 现状结构
const ex = (await findWindows(client, { useCache: false })).find((w) => w.className === 'CabinetWClass');
if (ex) {
  const r = await client.tool('accessibility_tree', { nativeWindowHandle: ex.nativeWindowHandle, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 8000, viewMode: 'control', detailLevel: 'full' });
  const all = walk(r.data?.tree ?? null);
  console.log(`[explorer] nodeCount=${r.data?.nodeCount} 节点=${all.length}`);
  for (const { c, d } of all.slice(0, 8)) console.log(`   ${' '.repeat(d * 2)}${c.controlType} name="${String(c.name).slice(0, 40)}" id=${c.id ? 'yes' : 'no'} children=${(c.children ?? []).length}`);
}

// 2) regedit 作为树靶
const { execFile } = await import('node:child_process');
let re = await windowBy(client, { className: 'RegEdit_RegEdit' }, );
if (!re) {
  console.log('\n[regedit] 未运行，启动……');
  execFile('regedit.exe', [], { windowsHide: true }, () => {});
  const deadline = Date.now() + 15000;
  while (!re && Date.now() < deadline) { await sleep(1000); re = await windowBy(client, { className: 'RegEdit_RegEdit', useCache: false }); }
}
if (!re) { console.log('[regedit] 起不来'); }
else {
  console.log(`[regedit] hwnd=${re.nativeWindowHandle} "${re.name}"`);
  await activate(client, re.nativeWindowHandle); await sleep(1500);
  for (const label of ['control', 'raw']) {
    const r = await client.tool('accessibility_tree', { nativeWindowHandle: re.nativeWindowHandle, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 8000, viewMode: label, detailLevel: 'full' }).catch((e) => ({ isError: true, text: String(e) }));
    const all = walk(r.data?.tree ?? null);
    const ti = all.filter((x) => String(x.c.controlType ?? '').includes('TreeItem'));
    console.log(`[regedit/${label}] isError=${r.isError} nodeCount=${r.data?.nodeCount} 节点=${all.length} TreeItem=${ti.length}`);
    for (const x of ti.slice(0, 10)) console.log(`   depth=${x.d} name="${x.c.name}" id=${x.c.id ? 'yes' : 'no'} patterns=${JSON.stringify(x.c.patterns)} children=${(x.c.children ?? []).length}`);
    if (r.isError) console.log('   原文=' + String(r.text).slice(0, 160));
  }
  const types = {};
  for (const { c } of walk((await client.tool('accessibility_tree', { nativeWindowHandle: re.nativeWindowHandle, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 8000 })).data?.tree ?? null)) types[c.controlType] = (types[c.controlType] ?? 0) + 1;
  console.log('[regedit] 控件类型分布: ' + JSON.stringify(types).slice(0, 400));
}
await client.close();
process.exit(0);
