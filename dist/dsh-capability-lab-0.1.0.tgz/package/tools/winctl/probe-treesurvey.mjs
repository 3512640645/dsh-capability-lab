/**
 * probe-treesurvey · 全桌面找"真正暴露 TreeItem 的窗口"
 * 结论用于 tree-expand：要么找到可度量的靶，要么给出"本机不可度量"的现场证据。
 */
import { connect, findWindows } from './mcp.mjs';
import { sleep } from './index.mjs';

const client = await connect();
const walk = (n, out = []) => { for (const c of n?.children ?? []) { out.push(c); walk(c, out); } return out; };
const wins = (await findWindows(client, { useCache: false, maxWindows: 200 }))
  .filter((w) => w.boundingBox && w.boundingBox.width > 120 && w.boundingBox.height > 120 && w.boundingBox.x > -1000);

console.log(`候选窗口 ${wins.length} 个，逐个取树（maxNodes=3000/maxDepth=12）…`);
const found = [];
for (const w of wins.slice(0, 26)) {
  const t0 = Date.now();
  const r = await client.tool('accessibility_tree', { nativeWindowHandle: w.nativeWindowHandle, maxNodes: 3000, maxDepth: 12, treeTimeoutMs: 3500, viewMode: 'control', detailLevel: 'full' }).catch((e) => ({ isError: true, text: String(e) }));
  const all = walk(r.data?.tree ?? null);
  const ti = all.filter((c) => String(c.controlType ?? '').includes('TreeItem'));
  const tag = `${all.length}节点/${ti.length}TreeItem`;
  if (ti.length) found.push({ w, ti });
  console.log(`  ${String(w.className).slice(0, 26).padEnd(28)} "${String(w.name).slice(0, 26).padEnd(26)}" ${tag}${r.isError ? ' ERR=' + String(r.text).slice(0, 60) : ''} (${Date.now() - t0}ms)`);
  await sleep(60);
}
console.log('\n暴露 TreeItem 的窗口：');
for (const f of found) console.log(`  hwnd=${f.w.nativeWindowHandle} "${f.w.name}" TreeItem=${f.ti.length} 例: ${f.ti.slice(0, 6).map((x) => x.name).join('、')}`);
if (!found.length) console.log('  无（本会话内没有任何窗口通过 UIA 暴露 TreeItem）');
await client.close();
process.exit(0);
