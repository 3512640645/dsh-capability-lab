/** 把 wait_for 的原始返回打出来，确认正确的判定字段。 */
import { connect, windowBy } from './mcp.mjs';

const client = await connect();
const note = await windowBy(client, { title: 'Notepad|记事本' });
if (!note) { console.log('记事本没开'); await client.close(); process.exit(0); }
const hwnd = note.nativeWindowHandle;
const title = note.name;
// 用窗口标题里一定存在的字串做基准（保证条件必然成立）
const present = 'Notepad';
console.log(`窗口: ${title} hwnd=${hwnd}`);

for (const [label, args] of [
  ['window(present)', { condition: 'window', windowTitle: 'Notepad', timeoutMs: 4000 }],
  ['element(present)', { condition: 'element', query: '文本编辑器', nativeWindowHandle: hwnd, timeoutMs: 4000 }],
  ['element(absent)', { condition: 'element', query: '不存在的控件XYZ', nativeWindowHandle: hwnd, timeoutMs: 1500 }],
  ['text(present)', { condition: 'text', query: '文件', nativeWindowHandle: hwnd, timeoutMs: 4000 }],
  ['text(absent)', { condition: 'text', query: '不存在的文字QQQ', nativeWindowHandle: hwnd, timeoutMs: 1500 }],
]) {
  const t0 = Date.now();
  const r = await client.tool('wait_for', args);
  console.log(`\n--- ${label}  (${Date.now() - t0}ms) isError=${r.isError}`);
  console.log('  raw:', JSON.stringify(r.data ?? r.text).slice(0, 420));
}

await client.close();
process.exit(0);
