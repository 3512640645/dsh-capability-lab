/**
 * recompute-l1 · 按判据口径自己重算 winctl 通道成功率（不采信通道自报，不混算 naive）
 *
 * 分母规则（本脚本的判据口径，写在输出里）：
 *  1) 单位 = 一份报告里的**一条 winctl 通道 run**（naive 只另列，绝不与 winctl 混算）；
 *  2) 裁决 = 基准的外部 verify 结果（字段 ok）；通道自报 okSelf 仅作对照；
 *  3) 不可度量样本**显式剔除并计数**：verified 文案含「前置条件不成立 / 本次结果无效 / 无法判定」；
 *  4) 无外部判定的样本（verify 缺失）也**单列**，可选是否入分母；
 *  5) 报告窗口 = 可按时间切三段：全时段 / 现行实现段（mtime >= bench.mjs 最后修改）/ 末次 repeat。
 *
 * 用法: node recompute-l1.mjs [--json out.json]
 */
import fs from 'node:fs';
import path from 'node:path';

const DIR = 'D:\\dsh-tools\\winctl\\reports';
const argv = process.argv.slice(2);
const jsonOut = (() => { const i = argv.indexOf('--json'); return i === -1 ? null : argv[i + 1]; })();

const benchMtime = fs.statSync('D:\\dsh-tools\\winctl\\bench.mjs').mtimeMs;
const files = fs.readdirSync(DIR).filter((f) => /^bench-.*\.json$/.test(f)).sort();
const UNDECIDABLE = /前置条件不成立|本次结果无效|无法判定|无法度量/;
const NOVERIFY = /该任务无外部判定/;

const rows = [];   // 展平后的 run 级记录
const empty = [];
for (const f of files) {
  const p = path.join(DIR, f);
  const st = fs.statSync(p);
  let j;
  try { j = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { continue; }
  if (!j?.results?.length) { empty.push(`${f}(${st.size}B)`); continue; }
  const idx = Number((f.match(/(\d{13})\.json$/) ?? [])[1] ?? NaN);   // 文件名里的 UTC 戳
  let runIdx = 0;
  for (const r of j.results) {
    const list = r.naive ?? [];
    for (let i = 0; i < list.length; i++) {
      for (const ch of ['naive', 'winctl']) {
        const e = (r[ch] ?? [])[i];
        if (!e || e.skip) continue;
        rows.push({
          file: f, mtime: st.mtimeMs, fileStamp: idx, task: r.id, taskName: r.name, channel: ch, repeat: i + 1, runIdx: runIdx++,
          ok: e.ok === true, okSelf: e.okSelf === true, ms: Number(e.ms ?? 0),
          note: String(e.note ?? ''), verified: String(e.verified ?? ''),
          undecidable: UNDECIDABLE.test(String(e.verified ?? '')),
          noVerify: NOVERIFY.test(String(e.verified ?? '')),
        });
      }
    }
  }
}

const pct = (n, d) => (d ? Number(((n / d) * 100).toFixed(1)) : null);
const med = (a) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const m = s.length >> 1; return s.length % 2 ? s[m] : Math.round((s[m - 1] + s[m]) / 2); };

function seg(label, filter, { dropUndecidable = true, requireVerify = true } = {}) {
  const base = rows.filter(filter).filter((r) => r.channel === 'winctl');
  const undec = base.filter((r) => r.undecidable);
  const nover = base.filter((r) => !r.undecidable && r.noVerify);
  let n = base.filter((r) => !r.undecidable);
  if (requireVerify) n = n.filter((r) => !r.noVerify);
  const ok = n.filter((r) => r.ok).length;
  return {
    label, n: n.length, ok, ratePct: pct(ok, n.length), medMs: med(n.map((r) => r.ms)),
    droppedUndecidable: undec.length, setAsideNoVerify: nover.length,
    rawNoFilter: { n: base.length, ok: base.filter((r) => r.ok).length, ratePct: pct(base.filter((r) => r.ok).length, base.length) },
  };
}

const idxOfLastChange = Math.max(...rows.map((r) => r.fileStamp), 0);
const currentSeg = rows.filter((r) => r.mtime >= benchMtime).map((r) => r.fileStamp);
const segFloor = currentSeg.length ? Math.min(...currentSeg) : Infinity;

const segments = [
  seg('S0 全时段 · zero filter (winctl)', () => true, { dropUndecidable: false, requireVerify: false }),
  seg('S1 全时段 · 仅剔不可度量 (winctl)', () => true),
  seg('S2 全时段 · 剔不可度量 + 剔无外部判定 (winctl)', () => true, { requireVerify: true }),
  seg(`S3 现行实现段(mtime>=bench.mjs ${new Date(benchMtime).toISOString().slice(0, 16)}Z) · 仅剔不可度量`, (r) => r.mtime >= benchMtime, { requireVerify: false }),
  seg('S4 现行实现段 · 剔不可度量 + 剔无外部判定', (r) => r.mtime >= benchMtime, { requireVerify: true }),
  seg('S5 现行实现段 · 仅末次 repeat', (r) => r.mtime >= benchMtime && r.repeat === 3, { requireVerify: true }),
];

const byTask = {};
for (const r of rows.filter((x) => x.channel === 'winctl' && !x.undecidable)) {
  const t = (byTask[r.task] ??= { task: r.task, n: 0, ok: 0, fails: [] });
  t.n++; if (r.ok) t.ok++; else t.fails.push(r);
}
const taskRows = Object.values(byTask)
  .map((t) => ({ ...t, ratePct: pct(t.ok, t.n), failList: t.fails, fails: t.fails.length }))
  .sort((a, b) => a.ratePct - b.ratePct);

// 失败模式归类（按 note/verified 关键词）
const MODES = [
  ['POINT_COVERED 被别的窗口盖住', /POINT_COVERED/],
  ['找不到元素/键（定位失败）', /找不到|未见|无包围盒/],
  ['对话框未出现', /对话框(未出现|没出现)|另存为对话框/],
  ['校验未通过（写入/显示不对）', /校验|首行仍|位置不符|位移不足|读不到|没有|仍失败|仍可见/],
  ['其他/未分类', /.*/],
];
const modes = {};
for (const t of taskRows) for (const f of t.failList) {
  const m = MODES.find(([_, re]) => re.test(f.note) || re.test(f.verified));
  (modes[m[0]] ??= { mode: m[0], n: 0, tasks: {}, examples: [] });
  modes[m[0]].n++;
  modes[m[0]].tasks[f.task] = (modes[m[0]].tasks[f.task] ?? 0) + 1;
  if (modes[m[0]].examples.length < 3) modes[m[0]].examples.push(`${f.file}/${f.task}#${f.repeat}: ${f.note.slice(0, 90)}`);
}
const modeRows = Object.values(modes).sort((a, b) => b.n - a.n);
for (const m of modeRows) if (m.mode === '其他/未分类') m.n = Object.values(modes).find((x) => x.mode === '其他/未分类')?.n ?? 0;

const out = {
  generatedAt: new Date().toISOString(),
  source: DIR, benchMtime: new Date(benchMtime).toISOString(),
  reportFiles: files.length, emptyReports: empty, winctlRunsTotal: rows.filter((r) => r.channel === 'winctl').length,
  denominatorRule: 'winctl 通道 run 级；判据=外部 verify(ok)，不看 okSelf；含「前置条件不成立/本次结果无效/无法判定」的样本显式剔除并计数；无外部判定的样本单列；naive 通道只另列不混算',
  segments, byTask: taskRows.map((t) => ({ task: t.task, n: t.n, ok: t.ok, ratePct: t.ratePct })),
  failureModes: modeRows.map((m) => ({ mode: m.mode, n: m.n, tasks: m.tasks, examples: m.examples })),
  failureDetail: taskRows.flatMap((t) => t.failList.map((f) => ({ file: f.file, task: f.task, repeat: f.repeat, ms: f.ms, note: f.note, verified: f.verified }))),
};

console.log(`# winctl 通道成功率重算  (源: ${DIR}, ${files.length} 份报告, ${out.winctlRunsTotal} 条 winctl run)`);
console.log(`# bench.mjs 最后修改: ${out.benchMtime}`);
console.log('# 分母规则: ' + out.denominatorRule);
console.log('');
console.log('口径'.padEnd(46) + 'n'.padStart(5) + 'ok'.padStart(5) + '成功率'.padStart(9) + '中位ms'.padStart(9) + '  剔无效'.padStart(8) + '  单列无判定');
for (const s of segments) {
  console.log(s.label.padEnd(42) + String(s.n).padStart(6) + String(s.ok).padStart(5) + `${s.ratePct}%`.padStart(10) + String(s.medMs ?? '-').padStart(9) + String(s.droppedUndecidable).padStart(8) + String(s.setAsideNoVerify).padStart(11) + `   [zero-filter ${s.rawNoFilter.ratePct}%/${s.rawNoFilter.n}]`);
}
console.log('\n# 分任务（winctl，剔不可度量后的全时段）');
for (const t of taskRows) console.log(`  ${t.task.padEnd(22)} n=${String(t.n).padStart(3)} ok=${String(t.ok).padStart(3)} ${String(t.ratePct).padStart(5)}%  失败 ${t.fails}`);
console.log('\n# 失败模式 Top');
for (const m of modeRows) console.log(`  ${m.n.toString().padStart(4)}  ${m.mode}  ← ${JSON.stringify(m.tasks)}`);
console.log('\n# 失败明细（全部）');
for (const f of out.failureDetail) console.log(`  ${f.file}/${f.task}#${f.repeat} ${String(f.ms).padStart(5)}ms | ${f.note.slice(0, 110)} | ${f.verified.slice(0, 90)}`);

if (jsonOut) { fs.writeFileSync(jsonOut, JSON.stringify(out, null, 1), 'utf8'); console.log(`\nJSON: ${jsonOut}`); }
