#!/usr/bin/env node
/**
 * 环境自检：把所有"隐含假设"变成可读事实。
 *
 * 之前踩的坑几乎都来自未经验证的假设：
 *   - 双击间隔（Windows 默认阈值 500ms，我用了 ~500ms → 被当成两次单击）
 *   - DPI 缩放（截图是物理像素，SetCursorPos 也用物理像素，但应用若是 DPI-unaware 会不一致）
 *   - 窗口遮挡（真实点击落到最上层窗口，不是"我以为的那个"）
 *   - 应用是否暴露 UIA 树（Flutter 应用几乎不暴露 → 必须走 OCR）
 *
 * 用法: node winctl/selfcheck.mjs
 */
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { connect, findWindows, readText } from './mcp.mjs';

const out = [];
const push = (k, v) => { out.push([k, v]); console.log(`  ${k.padEnd(34)} ${v}`); };

console.log('=== winctl 环境自检 ===\n');

// ── 1. 系统与显示 ─────────────────────────────────────────────────────
push('node', process.version);
push('platform', `${os.platform()} ${os.release()} ${os.arch()}`);

const dpiScript = [
  'Add-Type -AssemblyName System.Windows.Forms',
  'Add-Type -AssemblyName System.Drawing',
  '$s = [System.Windows.Forms.Screen]::PrimaryScreen',
  '$g = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)',
  'Write-Output ("primary=" + $s.Bounds.Width + "x" + $s.Bounds.Height + ";dpi=" + [Math]::Round($g.DpiX))',
].join('; ');
let dpiInfo = 'unknown';
try {
  const raw = execFileSync('powershell', ['-NoProfile', '-Command', dpiScript], { encoding: 'utf8', windowsHide: true }).trim();
  dpiInfo = raw.split('\n').pop().trim();
} catch (e) { dpiInfo = `error: ${e.message}`; }
const m = /primary=(\d+)x(\d+);dpi=(\d+)/.exec(dpiInfo);
const scale = m ? Number(m[3]) / 96 : 1;
push('主屏逻辑分辨率', m ? `${m[1]}x${m[2]} @ ${m[3]} dpi` : dpiInfo);
push('缩放系数', `${scale.toFixed(3)}  ${scale === 1 ? '(无需换算)' : '(截图↔屏幕坐标需要换算!)'}`);

// ── 2. 鼠标双击阈值 ────────────────────────────────────────────────────
let dbl = 'unknown';
try {
  dbl = execFileSync('powershell', ['-NoProfile', '-Command',
    "(Get-ItemProperty 'HKCU:\\Control Panel\\Mouse').DoubleClickSpeed"], { encoding: 'utf8', windowsHide: true }).trim().split('\n').pop().trim();
} catch { /* keep */ }
push('双击阈值', `${dbl} ms  → 模拟双击必须远小于它`);

// ── 3. 前台窗口策略 ────────────────────────────────────────────────────
let fg = 'unknown';
try {
  fg = execFileSync('powershell', ['-NoProfile', '-Command',
    "(Get-ItemProperty 'HKCU:\\Control Panel\\Desktop').ForegroundLockTimeout"], { encoding: 'utf8', windowsHide: true }).trim().split('\n').pop().trim();
} catch { /* keep */ }
push('ForegroundLockTimeout', `${fg} ms  (0 = 允许抢占前台)`);

// ── 4. MCP 后端与窗口枚举 ──────────────────────────────────────────────
const t0 = Date.now();
const client = await connect();
push('MCP 后端启动+握手', `${Date.now() - t0} ms`);

const t1 = Date.now();
const wins = await findWindows(client);
push('枚举顶层窗口', `${wins.length} 个，${Date.now() - t1} ms`);

const byProc = new Map();
for (const w of wins) {
  const key = `pid:${w.processId}`;
  if (!byProc.has(key)) byProc.set(key, []);
  byProc.get(key).push(w);
}
const named = wins.filter((w) => w.name);
push('有标题的窗口', `${named.length} 个`);

// 分类：UIA 可用的原生应用 vs Flutter/自绘应用
const flutterLike = named.filter((w) => /FLUTTER|Electron|Chrome_WidgetWin/i.test(w.className ?? ''));
push('自绘/Flutter/Electron 类窗口', `${flutterLike.length} 个  (UIA 树通常稀疏 → 需要 OCR 兜底)`);
for (const w of flutterLike.slice(0, 4)) push(`  · ${w.name.slice(0, 22)}`, w.className);

// ── 5. UIA 密度探测：挑一个真实窗口量一下"元素可见度" ──────────────────
const candidates = named.filter((w) => /记事本|Notepad|计算器|Calculator|资源管理器|天翼云盘/.test(w.name));
push('用于采样的窗口', candidates.length ? candidates.map((c) => c.name).join(' / ') : '(未运行，跳过密度采样)');

for (const c of candidates.slice(0, 3)) {
  // UIA 密度：扫一遍这个窗口的可见文字节点数（>0 说明能走元素通道，=0 只能靠 OCR）
  try {
    const t = Date.now();
    const r = await client.tool('find', {
      query: c.name.slice(0, 1),
      nativeWindowHandle: c.nativeWindowHandle,
      maxResults: 3,
      ocrFallback: false,
    });
    const scanned = r.data?.scannedNodes ?? 0;
    push(`UIA 节点数 · ${c.name.slice(0, 14)}`, `${scanned} (${Date.now() - t} ms)  ${scanned > 5 ? '→ 元素通道可用' : '→ 元素稀少，走 OCR'}`);
  } catch (e) {
    push(`UIA 探测失败 · ${c.name.slice(0, 14)}`, String(e.message ?? e).slice(0, 60));
  }
  // OCR 通道是否可用
  try {
    const t = Date.now();
    const { words } = await readText(client, c.nativeWindowHandle);
    push(`OCR 词数 · ${c.name.slice(0, 14)}`, `${words.length} (${Date.now() - t} ms)`);
  } catch (e) {
    push(`OCR 失败 · ${c.name.slice(0, 14)}`, String(e.message ?? e).slice(0, 60));
  }
}

// ── 6. 依赖盘点 ────────────────────────────────────────────────────────
const deps = {
  'MCP 插件目录': 'D:\\dsh-tools\\wcu\\package',
  ffmpeg: 'D:\\dsh-video\\tools\\ffmpeg\\ffmpeg.exe',
  python: 'D:\\ds\\DSH Desktop\\.build\\office-runtime\\primary-runtime\\dependencies\\python\\python.exe',
  edge: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
};
console.log('\n--- 依赖 ---');
for (const [name, p] of Object.entries(deps)) push(name, fs.existsSync(p) ? 'ok' : '缺失');

fs.mkdirSync('D:\\dsh-tools\\winctl\\reports', { recursive: true });
const report = path.join('D:\\dsh-tools\\winctl\\reports', `selfcheck-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '')}.txt`);
fs.writeFileSync(report, out.map(([k, v]) => `${k}\t${v}`).join('\n'), 'utf8');
console.log(`\n报告已写入 ${report}`);

await client.close();
process.exit(0);
